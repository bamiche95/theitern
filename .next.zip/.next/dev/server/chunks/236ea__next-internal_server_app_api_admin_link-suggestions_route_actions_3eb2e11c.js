module.exports = [
"[project]/theitern/.next-internal/server/app/api/admin/link-suggestions/route/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=236ea__next-internal_server_app_api_admin_link-suggestions_route_actions_3eb2e11c.js.map