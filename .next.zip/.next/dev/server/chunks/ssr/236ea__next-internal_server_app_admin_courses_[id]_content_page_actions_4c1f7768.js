module.exports = [
"[project]/theitern/.next-internal/server/app/admin/courses/[id]/content/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=236ea__next-internal_server_app_admin_courses_%5Bid%5D_content_page_actions_4c1f7768.js.map