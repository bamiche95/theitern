module.exports = [
"[project]/theitern/.next-internal/server/app/admin/courses/[id]/sections/new/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=236ea__next-internal_server_app_admin_courses_%5Bid%5D_sections_new_page_actions_ade7ef0f.js.map