module.exports = [
"[project]/theitern/node_modules/@tsparticles/engine/esm/Core/Utils/Constants.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "canvasFirstIndex",
    ()=>canvasFirstIndex,
    "canvasTag",
    ()=>canvasTag,
    "clickRadius",
    ()=>clickRadius,
    "countOffset",
    ()=>countOffset,
    "decayOffset",
    ()=>decayOffset,
    "defaultAlpha",
    ()=>defaultAlpha,
    "defaultAngle",
    ()=>defaultAngle,
    "defaultDensityFactor",
    ()=>defaultDensityFactor,
    "defaultFps",
    ()=>defaultFps,
    "defaultFpsLimit",
    ()=>defaultFpsLimit,
    "defaultLoops",
    ()=>defaultLoops,
    "defaultOpacity",
    ()=>defaultOpacity,
    "defaultRadius",
    ()=>defaultRadius,
    "defaultRatio",
    ()=>defaultRatio,
    "defaultReduceFactor",
    ()=>defaultReduceFactor,
    "defaultRemoveQuantity",
    ()=>defaultRemoveQuantity,
    "defaultRetryCount",
    ()=>defaultRetryCount,
    "defaultRgbMin",
    ()=>defaultRgbMin,
    "defaultTime",
    ()=>defaultTime,
    "defaultTransform",
    ()=>defaultTransform,
    "defaultTransformValue",
    ()=>defaultTransformValue,
    "defaultVelocity",
    ()=>defaultVelocity,
    "deleteCount",
    ()=>deleteCount,
    "double",
    ()=>double,
    "doublePI",
    ()=>doublePI,
    "empty",
    ()=>empty,
    "errorPrefix",
    ()=>errorPrefix,
    "generatedAttribute",
    ()=>generatedAttribute,
    "generatedFalse",
    ()=>generatedFalse,
    "generatedTrue",
    ()=>generatedTrue,
    "hMax",
    ()=>hMax,
    "hMin",
    ()=>hMin,
    "hPhase",
    ()=>hPhase,
    "half",
    ()=>half,
    "identity",
    ()=>identity,
    "inverseFactorNumerator",
    ()=>inverseFactorNumerator,
    "lFactor",
    ()=>lFactor,
    "lMax",
    ()=>lMax,
    "lMin",
    ()=>lMin,
    "lengthOffset",
    ()=>lengthOffset,
    "loadMinIndex",
    ()=>loadMinIndex,
    "loadRandomFactor",
    ()=>loadRandomFactor,
    "manualCount",
    ()=>manualCount,
    "manualDefaultPosition",
    ()=>manualDefaultPosition,
    "midColorValue",
    ()=>midColorValue,
    "millisecondsToSeconds",
    ()=>millisecondsToSeconds,
    "minCoordinate",
    ()=>minCoordinate,
    "minCount",
    ()=>minCount,
    "minFpsLimit",
    ()=>minFpsLimit,
    "minIndex",
    ()=>minIndex,
    "minLimit",
    ()=>minLimit,
    "minRetries",
    ()=>minRetries,
    "minStrokeWidth",
    ()=>minStrokeWidth,
    "minVelocity",
    ()=>minVelocity,
    "minZ",
    ()=>minZ,
    "minimumLength",
    ()=>minimumLength,
    "minimumSize",
    ()=>minimumSize,
    "mouseDownEvent",
    ()=>mouseDownEvent,
    "mouseLeaveEvent",
    ()=>mouseLeaveEvent,
    "mouseMoveEvent",
    ()=>mouseMoveEvent,
    "mouseOutEvent",
    ()=>mouseOutEvent,
    "mouseUpEvent",
    ()=>mouseUpEvent,
    "none",
    ()=>none,
    "one",
    ()=>one,
    "originPoint",
    ()=>originPoint,
    "percentDenominator",
    ()=>percentDenominator,
    "phaseNumerator",
    ()=>phaseNumerator,
    "posOffset",
    ()=>posOffset,
    "qTreeCapacity",
    ()=>qTreeCapacity,
    "quarter",
    ()=>quarter,
    "randomColorValue",
    ()=>randomColorValue,
    "removeDeleteCount",
    ()=>removeDeleteCount,
    "removeMinIndex",
    ()=>removeMinIndex,
    "resizeEvent",
    ()=>resizeEvent,
    "rgbFactor",
    ()=>rgbFactor,
    "rgbMax",
    ()=>rgbMax,
    "rollFactor",
    ()=>rollFactor,
    "sMax",
    ()=>sMax,
    "sMin",
    ()=>sMin,
    "sNormalizedOffset",
    ()=>sNormalizedOffset,
    "sextuple",
    ()=>sextuple,
    "sizeFactor",
    ()=>sizeFactor,
    "squareExp",
    ()=>squareExp,
    "subdivideCount",
    ()=>subdivideCount,
    "threeQuarter",
    ()=>threeQuarter,
    "touchCancelEvent",
    ()=>touchCancelEvent,
    "touchDelay",
    ()=>touchDelay,
    "touchEndEvent",
    ()=>touchEndEvent,
    "touchEndLengthOffset",
    ()=>touchEndLengthOffset,
    "touchMoveEvent",
    ()=>touchMoveEvent,
    "touchStartEvent",
    ()=>touchStartEvent,
    "triple",
    ()=>triple,
    "tryCountIncrement",
    ()=>tryCountIncrement,
    "visibilityChangeEvent",
    ()=>visibilityChangeEvent,
    "zIndexFactorOffset",
    ()=>zIndexFactorOffset
]);
const generatedAttribute = "generated", mouseDownEvent = "pointerdown", mouseUpEvent = "pointerup", mouseLeaveEvent = "pointerleave", mouseOutEvent = "pointerout", mouseMoveEvent = "pointermove", touchStartEvent = "touchstart", touchEndEvent = "touchend", touchMoveEvent = "touchmove", touchCancelEvent = "touchcancel", resizeEvent = "resize", visibilityChangeEvent = "visibilitychange", errorPrefix = "tsParticles - Error", percentDenominator = 100, half = 0.5, millisecondsToSeconds = 1000, originPoint = {
    x: 0,
    y: 0,
    z: 0
}, defaultTransform = {
    a: 1,
    b: 0,
    c: 0,
    d: 1
}, randomColorValue = "random", midColorValue = "mid", double = 2, doublePI = Math.PI * double, defaultFps = 60, defaultAlpha = 1, generatedTrue = "true", generatedFalse = "false", canvasTag = "canvas", defaultRetryCount = 0, squareExp = 2, qTreeCapacity = 4, defaultRemoveQuantity = 1, defaultRatio = 1, defaultReduceFactor = 1, subdivideCount = 4, inverseFactorNumerator = 1.0, rgbMax = 255, hMax = 360, sMax = 100, lMax = 100, hMin = 0, sMin = 0, hPhase = 60, empty = 0, quarter = 0.25, threeQuarter = half + quarter, minVelocity = 0, defaultTransformValue = 1, minimumSize = 0, minimumLength = 0, zIndexFactorOffset = 1, defaultOpacity = 1, clickRadius = 1, touchEndLengthOffset = 1, minCoordinate = 0, removeDeleteCount = 1, removeMinIndex = 0, defaultFpsLimit = 120, minFpsLimit = 0, canvasFirstIndex = 0, loadRandomFactor = 10000, loadMinIndex = 0, one = 1, none = 0, decayOffset = 1, tryCountIncrement = 1, minRetries = 0, rollFactor = 1, minZ = 0, defaultRadius = 0, posOffset = -quarter, sizeFactor = 1.5, minLimit = 0, countOffset = 1, minCount = 0, minIndex = 0, manualCount = 0, lengthOffset = 1, defaultDensityFactor = 1, deleteCount = 1, touchDelay = 500, manualDefaultPosition = 50, defaultAngle = 0, identity = 1, minStrokeWidth = 0, lFactor = 1, lMin = 0, rgbFactor = 255, triple = 3, sextuple = 6, sNormalizedOffset = 1, phaseNumerator = 1, defaultRgbMin = 0, defaultVelocity = 0, defaultLoops = 0, defaultTime = 0;
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Enums/Directions/MoveDirection.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "MoveDirection",
    ()=>MoveDirection
]);
var MoveDirection;
(function(MoveDirection) {
    MoveDirection["bottom"] = "bottom";
    MoveDirection["bottomLeft"] = "bottom-left";
    MoveDirection["bottomRight"] = "bottom-right";
    MoveDirection["left"] = "left";
    MoveDirection["none"] = "none";
    MoveDirection["right"] = "right";
    MoveDirection["top"] = "top";
    MoveDirection["topLeft"] = "top-left";
    MoveDirection["topRight"] = "top-right";
    MoveDirection["outside"] = "outside";
    MoveDirection["inside"] = "inside";
})(MoveDirection || (MoveDirection = {}));
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/TypeUtils.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "isArray",
    ()=>isArray,
    "isBoolean",
    ()=>isBoolean,
    "isFunction",
    ()=>isFunction,
    "isNull",
    ()=>isNull,
    "isNumber",
    ()=>isNumber,
    "isObject",
    ()=>isObject,
    "isString",
    ()=>isString
]);
function isBoolean(arg) {
    return typeof arg === "boolean";
}
function isString(arg) {
    return typeof arg === "string";
}
function isNumber(arg) {
    return typeof arg === "number";
}
function isFunction(arg) {
    return typeof arg === "function";
}
function isObject(arg) {
    return typeof arg === "object" && arg !== null;
}
function isArray(arg) {
    return Array.isArray(arg);
}
function isNull(arg) {
    return arg === null || arg === undefined;
}
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Core/Utils/Vectors.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Vector",
    ()=>Vector,
    "Vector3d",
    ()=>Vector3d
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Core/Utils/Constants.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/TypeUtils.js [app-ssr] (ecmascript)");
;
;
class Vector3d {
    constructor(xOrCoords, y, z){
        this._updateFromAngle = (angle, length)=>{
            this.x = Math.cos(angle) * length;
            this.y = Math.sin(angle) * length;
        };
        if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isNumber"])(xOrCoords) && xOrCoords) {
            this.x = xOrCoords.x;
            this.y = xOrCoords.y;
            const coords3d = xOrCoords;
            this.z = coords3d.z ? coords3d.z : __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["originPoint"].z;
        } else if (xOrCoords !== undefined && y !== undefined) {
            this.x = xOrCoords;
            this.y = y;
            this.z = z ?? __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["originPoint"].z;
        } else {
            throw new Error(`${__TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["errorPrefix"]} Vector3d not initialized correctly`);
        }
    }
    static get origin() {
        return Vector3d.create(__TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["originPoint"].x, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["originPoint"].y, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["originPoint"].z);
    }
    get angle() {
        return Math.atan2(this.y, this.x);
    }
    set angle(angle) {
        this._updateFromAngle(angle, this.length);
    }
    get length() {
        return Math.sqrt(this.getLengthSq());
    }
    set length(length) {
        this._updateFromAngle(this.angle, length);
    }
    static clone(source) {
        return Vector3d.create(source.x, source.y, source.z);
    }
    static create(x, y, z) {
        return new Vector3d(x, y, z);
    }
    add(v) {
        return Vector3d.create(this.x + v.x, this.y + v.y, this.z + v.z);
    }
    addTo(v) {
        this.x += v.x;
        this.y += v.y;
        this.z += v.z;
    }
    copy() {
        return Vector3d.clone(this);
    }
    distanceTo(v) {
        return this.sub(v).length;
    }
    distanceToSq(v) {
        return this.sub(v).getLengthSq();
    }
    div(n) {
        return Vector3d.create(this.x / n, this.y / n, this.z / n);
    }
    divTo(n) {
        this.x /= n;
        this.y /= n;
        this.z /= n;
    }
    getLengthSq() {
        return this.x ** __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["squareExp"] + this.y ** __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["squareExp"];
    }
    mult(n) {
        return Vector3d.create(this.x * n, this.y * n, this.z * n);
    }
    multTo(n) {
        this.x *= n;
        this.y *= n;
        this.z *= n;
    }
    normalize() {
        const length = this.length;
        if (length != __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["none"]) {
            this.multTo(__TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["inverseFactorNumerator"] / length);
        }
    }
    rotate(angle) {
        return Vector3d.create(this.x * Math.cos(angle) - this.y * Math.sin(angle), this.x * Math.sin(angle) + this.y * Math.cos(angle), __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["originPoint"].z);
    }
    setTo(c) {
        this.x = c.x;
        this.y = c.y;
        const v3d = c;
        this.z = v3d.z ? v3d.z : __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["originPoint"].z;
    }
    sub(v) {
        return Vector3d.create(this.x - v.x, this.y - v.y, this.z - v.z);
    }
    subFrom(v) {
        this.x -= v.x;
        this.y -= v.y;
        this.z -= v.z;
    }
}
class Vector extends Vector3d {
    constructor(xOrCoords, y){
        super(xOrCoords, y, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["originPoint"].z);
    }
    static get origin() {
        return Vector.create(__TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["originPoint"].x, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["originPoint"].y);
    }
    static clone(source) {
        return Vector.create(source.x, source.y);
    }
    static create(x, y) {
        return new Vector(x, y);
    }
}
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/NumberUtils.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "animate",
    ()=>animate,
    "calcExactPositionOrRandomFromSize",
    ()=>calcExactPositionOrRandomFromSize,
    "calcExactPositionOrRandomFromSizeRanged",
    ()=>calcExactPositionOrRandomFromSizeRanged,
    "calcPositionFromSize",
    ()=>calcPositionFromSize,
    "calcPositionOrRandomFromSize",
    ()=>calcPositionOrRandomFromSize,
    "calcPositionOrRandomFromSizeRanged",
    ()=>calcPositionOrRandomFromSizeRanged,
    "cancelAnimation",
    ()=>cancelAnimation,
    "clamp",
    ()=>clamp,
    "collisionVelocity",
    ()=>collisionVelocity,
    "degToRad",
    ()=>degToRad,
    "getDistance",
    ()=>getDistance,
    "getDistances",
    ()=>getDistances,
    "getParticleBaseVelocity",
    ()=>getParticleBaseVelocity,
    "getParticleDirectionAngle",
    ()=>getParticleDirectionAngle,
    "getRandom",
    ()=>getRandom,
    "getRangeMax",
    ()=>getRangeMax,
    "getRangeMin",
    ()=>getRangeMin,
    "getRangeValue",
    ()=>getRangeValue,
    "mix",
    ()=>mix,
    "parseAlpha",
    ()=>parseAlpha,
    "randomInRange",
    ()=>randomInRange,
    "setAnimationFunctions",
    ()=>setAnimationFunctions,
    "setRandom",
    ()=>setRandom,
    "setRangeValue",
    ()=>setRangeValue
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Directions$2f$MoveDirection$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Enums/Directions/MoveDirection.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Core/Utils/Constants.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Vectors$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Core/Utils/Vectors.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/TypeUtils.js [app-ssr] (ecmascript)");
;
;
;
;
let _random = Math.random;
const _animationLoop = {
    nextFrame: (cb)=>requestAnimationFrame(cb),
    cancel: (idx)=>cancelAnimationFrame(idx)
};
function setRandom(rnd = Math.random) {
    _random = rnd;
}
function getRandom() {
    const min = 0, max = 1;
    return clamp(_random(), min, max - Number.EPSILON);
}
function setAnimationFunctions(nextFrame, cancel) {
    _animationLoop.nextFrame = (callback)=>nextFrame(callback);
    _animationLoop.cancel = (handle)=>cancel(handle);
}
function animate(fn) {
    return _animationLoop.nextFrame(fn);
}
function cancelAnimation(handle) {
    _animationLoop.cancel(handle);
}
function clamp(num, min, max) {
    return Math.min(Math.max(num, min), max);
}
function mix(comp1, comp2, weight1, weight2) {
    return Math.floor((comp1 * weight1 + comp2 * weight2) / (weight1 + weight2));
}
function randomInRange(r) {
    const max = getRangeMax(r), minOffset = 0;
    let min = getRangeMin(r);
    if (max === min) {
        min = minOffset;
    }
    return getRandom() * (max - min) + min;
}
function getRangeValue(value) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isNumber"])(value) ? value : randomInRange(value);
}
function getRangeMin(value) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isNumber"])(value) ? value : value.min;
}
function getRangeMax(value) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isNumber"])(value) ? value : value.max;
}
function setRangeValue(source, value) {
    if (source === value || value === undefined && (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isNumber"])(source)) {
        return source;
    }
    const min = getRangeMin(source), max = getRangeMax(source);
    return value !== undefined ? {
        min: Math.min(min, value),
        max: Math.max(max, value)
    } : setRangeValue(min, max);
}
function getDistances(pointA, pointB) {
    const dx = pointA.x - pointB.x, dy = pointA.y - pointB.y, squareExp = 2;
    return {
        dx: dx,
        dy: dy,
        distance: Math.sqrt(dx ** squareExp + dy ** squareExp)
    };
}
function getDistance(pointA, pointB) {
    return getDistances(pointA, pointB).distance;
}
function degToRad(degrees) {
    const PIDeg = 180;
    return degrees * Math.PI / PIDeg;
}
function getParticleDirectionAngle(direction, position, center) {
    if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isNumber"])(direction)) {
        return degToRad(direction);
    }
    switch(direction){
        case __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Directions$2f$MoveDirection$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["MoveDirection"].top:
            return -Math.PI * __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["half"];
        case __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Directions$2f$MoveDirection$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["MoveDirection"].topRight:
            return -Math.PI * __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["quarter"];
        case __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Directions$2f$MoveDirection$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["MoveDirection"].right:
            return __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["empty"];
        case __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Directions$2f$MoveDirection$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["MoveDirection"].bottomRight:
            return Math.PI * __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["quarter"];
        case __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Directions$2f$MoveDirection$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["MoveDirection"].bottom:
            return Math.PI * __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["half"];
        case __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Directions$2f$MoveDirection$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["MoveDirection"].bottomLeft:
            return Math.PI * __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["threeQuarter"];
        case __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Directions$2f$MoveDirection$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["MoveDirection"].left:
            return Math.PI;
        case __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Directions$2f$MoveDirection$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["MoveDirection"].topLeft:
            return -Math.PI * __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["threeQuarter"];
        case __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Directions$2f$MoveDirection$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["MoveDirection"].inside:
            return Math.atan2(center.y - position.y, center.x - position.x);
        case __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Directions$2f$MoveDirection$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["MoveDirection"].outside:
            return Math.atan2(position.y - center.y, position.x - center.x);
        default:
            return getRandom() * __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["doublePI"];
    }
}
function getParticleBaseVelocity(direction) {
    const baseVelocity = __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Vectors$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Vector"].origin;
    baseVelocity.length = 1;
    baseVelocity.angle = direction;
    return baseVelocity;
}
function collisionVelocity(v1, v2, m1, m2) {
    return __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Vectors$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Vector"].create(v1.x * (m1 - m2) / (m1 + m2) + v2.x * __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["double"] * m2 / (m1 + m2), v1.y);
}
function calcPositionFromSize(data) {
    return data.position?.x !== undefined && data.position.y !== undefined ? {
        x: data.position.x * data.size.width / __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["percentDenominator"],
        y: data.position.y * data.size.height / __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["percentDenominator"]
    } : undefined;
}
function calcPositionOrRandomFromSize(data) {
    return {
        x: (data.position?.x ?? getRandom() * __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["percentDenominator"]) * data.size.width / __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["percentDenominator"],
        y: (data.position?.y ?? getRandom() * __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["percentDenominator"]) * data.size.height / __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["percentDenominator"]
    };
}
function calcPositionOrRandomFromSizeRanged(data) {
    const position = {
        x: data.position?.x !== undefined ? getRangeValue(data.position.x) : undefined,
        y: data.position?.y !== undefined ? getRangeValue(data.position.y) : undefined
    };
    return calcPositionOrRandomFromSize({
        size: data.size,
        position
    });
}
function calcExactPositionOrRandomFromSize(data) {
    return {
        x: data.position?.x ?? getRandom() * data.size.width,
        y: data.position?.y ?? getRandom() * data.size.height
    };
}
function calcExactPositionOrRandomFromSizeRanged(data) {
    const position = {
        x: data.position?.x !== undefined ? getRangeValue(data.position.x) : undefined,
        y: data.position?.y !== undefined ? getRangeValue(data.position.y) : undefined
    };
    return calcExactPositionOrRandomFromSize({
        size: data.size,
        position
    });
}
function parseAlpha(input) {
    const defaultAlpha = 1;
    if (!input) {
        return defaultAlpha;
    }
    return input.endsWith("%") ? parseFloat(input) / __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["percentDenominator"] : parseFloat(input);
}
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Enums/Modes/AnimationMode.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "AnimationMode",
    ()=>AnimationMode
]);
var AnimationMode;
(function(AnimationMode) {
    AnimationMode["auto"] = "auto";
    AnimationMode["increase"] = "increase";
    AnimationMode["decrease"] = "decrease";
    AnimationMode["random"] = "random";
})(AnimationMode || (AnimationMode = {}));
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Enums/AnimationStatus.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "AnimationStatus",
    ()=>AnimationStatus
]);
var AnimationStatus;
(function(AnimationStatus) {
    AnimationStatus["increasing"] = "increasing";
    AnimationStatus["decreasing"] = "decreasing";
})(AnimationStatus || (AnimationStatus = {}));
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Enums/Types/DestroyType.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "DestroyType",
    ()=>DestroyType
]);
var DestroyType;
(function(DestroyType) {
    DestroyType["none"] = "none";
    DestroyType["max"] = "max";
    DestroyType["min"] = "min";
})(DestroyType || (DestroyType = {}));
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Enums/Directions/OutModeDirection.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "OutModeDirection",
    ()=>OutModeDirection
]);
var OutModeDirection;
(function(OutModeDirection) {
    OutModeDirection["bottom"] = "bottom";
    OutModeDirection["left"] = "left";
    OutModeDirection["right"] = "right";
    OutModeDirection["top"] = "top";
})(OutModeDirection || (OutModeDirection = {}));
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Enums/Modes/PixelMode.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "PixelMode",
    ()=>PixelMode
]);
var PixelMode;
(function(PixelMode) {
    PixelMode["precise"] = "precise";
    PixelMode["percent"] = "percent";
})(PixelMode || (PixelMode = {}));
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Enums/Types/StartValueType.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "StartValueType",
    ()=>StartValueType
]);
var StartValueType;
(function(StartValueType) {
    StartValueType["max"] = "max";
    StartValueType["min"] = "min";
    StartValueType["random"] = "random";
})(StartValueType || (StartValueType = {}));
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/Utils.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "areBoundsInside",
    ()=>areBoundsInside,
    "arrayRandomIndex",
    ()=>arrayRandomIndex,
    "calculateBounds",
    ()=>calculateBounds,
    "circleBounce",
    ()=>circleBounce,
    "circleBounceDataFromParticle",
    ()=>circleBounceDataFromParticle,
    "cloneStyle",
    ()=>cloneStyle,
    "deepExtend",
    ()=>deepExtend,
    "divMode",
    ()=>divMode,
    "divModeExecute",
    ()=>divModeExecute,
    "executeOnSingleOrMultiple",
    ()=>executeOnSingleOrMultiple,
    "findItemFromSingleOrMultiple",
    ()=>findItemFromSingleOrMultiple,
    "getFullScreenStyle",
    ()=>getFullScreenStyle,
    "getLogger",
    ()=>getLogger,
    "getPosition",
    ()=>getPosition,
    "getSize",
    ()=>getSize,
    "hasMatchMedia",
    ()=>hasMatchMedia,
    "initParticleNumericAnimationValue",
    ()=>initParticleNumericAnimationValue,
    "isDivModeEnabled",
    ()=>isDivModeEnabled,
    "isInArray",
    ()=>isInArray,
    "isPointInside",
    ()=>isPointInside,
    "isSsr",
    ()=>isSsr,
    "itemFromArray",
    ()=>itemFromArray,
    "itemFromSingleOrMultiple",
    ()=>itemFromSingleOrMultiple,
    "loadFont",
    ()=>loadFont,
    "rectBounce",
    ()=>rectBounce,
    "safeIntersectionObserver",
    ()=>safeIntersectionObserver,
    "safeMatchMedia",
    ()=>safeMatchMedia,
    "safeMutationObserver",
    ()=>safeMutationObserver,
    "setLogger",
    ()=>setLogger,
    "singleDivModeExecute",
    ()=>singleDivModeExecute,
    "updateAnimation",
    ()=>updateAnimation
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/NumberUtils.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Core/Utils/Constants.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/TypeUtils.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Modes$2f$AnimationMode$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Enums/Modes/AnimationMode.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$AnimationStatus$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Enums/AnimationStatus.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Types$2f$DestroyType$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Enums/Types/DestroyType.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Directions$2f$OutModeDirection$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Enums/Directions/OutModeDirection.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Modes$2f$PixelMode$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Enums/Modes/PixelMode.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Types$2f$StartValueType$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Enums/Types/StartValueType.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Vectors$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Core/Utils/Vectors.js [app-ssr] (ecmascript)");
;
;
;
;
;
;
;
;
;
;
const _logger = {
    debug: console.debug,
    error: console.error,
    info: console.info,
    log: console.log,
    verbose: console.log,
    warning: console.warn
};
function setLogger(logger) {
    _logger.debug = logger.debug || _logger.debug;
    _logger.error = logger.error || _logger.error;
    _logger.info = logger.info || _logger.info;
    _logger.log = logger.log || _logger.log;
    _logger.verbose = logger.verbose || _logger.verbose;
    _logger.warning = logger.warning || _logger.warning;
}
function getLogger() {
    return _logger;
}
function memoize(fn) {
    const cache = new Map();
    return (...args)=>{
        const key = JSON.stringify(args);
        if (cache.has(key)) {
            return cache.get(key);
        }
        const result = fn(...args);
        cache.set(key, result);
        return result;
    };
}
function rectSideBounce(data) {
    const res = {
        bounced: false
    }, { pSide, pOtherSide, rectSide, rectOtherSide, velocity, factor } = data;
    if (pOtherSide.min < rectOtherSide.min || pOtherSide.min > rectOtherSide.max || pOtherSide.max < rectOtherSide.min || pOtherSide.max > rectOtherSide.max) {
        return res;
    }
    if (pSide.max >= rectSide.min && pSide.max <= (rectSide.max + rectSide.min) * __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["half"] && velocity > __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["minVelocity"] || pSide.min <= rectSide.max && pSide.min > (rectSide.max + rectSide.min) * __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["half"] && velocity < __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["minVelocity"]) {
        res.velocity = velocity * -factor;
        res.bounced = true;
    }
    return res;
}
function checkSelector(element, selectors) {
    const res = executeOnSingleOrMultiple(selectors, (selector)=>{
        return element.matches(selector);
    });
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isArray"])(res) ? res.some((t)=>t) : res;
}
function isSsr() {
    return ("TURBOPACK compile-time value", "undefined") === "undefined" || !window || typeof window.document === "undefined" || !window.document;
}
function hasMatchMedia() {
    return !isSsr() && typeof matchMedia !== "undefined";
}
function safeMatchMedia(query) {
    if (!hasMatchMedia()) {
        return;
    }
    //TURBOPACK unreachable
    ;
}
function safeIntersectionObserver(callback) {
    if (isSsr() || typeof IntersectionObserver === "undefined") {
        return;
    }
    //TURBOPACK unreachable
    ;
}
function safeMutationObserver(callback) {
    if (isSsr() || typeof MutationObserver === "undefined") {
        return;
    }
    //TURBOPACK unreachable
    ;
}
function isInArray(value, array) {
    const invalidIndex = -1;
    return value === array || (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isArray"])(array) && array.indexOf(value) > invalidIndex;
}
async function loadFont(font, weight) {
    try {
        await document.fonts.load(`${weight ?? "400"} 36px '${font ?? "Verdana"}'`);
    } catch  {}
}
function arrayRandomIndex(array) {
    return Math.floor((0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getRandom"])() * array.length);
}
function itemFromArray(array, index, useIndex = true) {
    return array[index !== undefined && useIndex ? index % array.length : arrayRandomIndex(array)];
}
function isPointInside(point, size, offset, radius, direction) {
    const minRadius = 0;
    return areBoundsInside(calculateBounds(point, radius ?? minRadius), size, offset, direction);
}
function areBoundsInside(bounds, size, offset, direction) {
    let inside = true;
    if (!direction || direction === __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Directions$2f$OutModeDirection$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["OutModeDirection"].bottom) {
        inside = bounds.top < size.height + offset.x;
    }
    if (inside && (!direction || direction === __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Directions$2f$OutModeDirection$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["OutModeDirection"].left)) {
        inside = bounds.right > offset.x;
    }
    if (inside && (!direction || direction === __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Directions$2f$OutModeDirection$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["OutModeDirection"].right)) {
        inside = bounds.left < size.width + offset.y;
    }
    if (inside && (!direction || direction === __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Directions$2f$OutModeDirection$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["OutModeDirection"].top)) {
        inside = bounds.bottom > offset.y;
    }
    return inside;
}
function calculateBounds(point, radius) {
    return {
        bottom: point.y + radius,
        left: point.x - radius,
        right: point.x + radius,
        top: point.y - radius
    };
}
function deepExtend(destination, ...sources) {
    for (const source of sources){
        if (source === undefined || source === null) {
            continue;
        }
        if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isObject"])(source)) {
            destination = source;
            continue;
        }
        const sourceIsArray = Array.isArray(source);
        if (sourceIsArray && ((0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isObject"])(destination) || !destination || !Array.isArray(destination))) {
            destination = [];
        } else if (!sourceIsArray && ((0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isObject"])(destination) || !destination || Array.isArray(destination))) {
            destination = {};
        }
        for(const key in source){
            if (key === "__proto__") {
                continue;
            }
            const sourceDict = source, value = sourceDict[key], destDict = destination;
            destDict[key] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isObject"])(value) && Array.isArray(value) ? value.map((v)=>deepExtend(destDict[key], v)) : deepExtend(destDict[key], value);
        }
    }
    return destination;
}
function isDivModeEnabled(mode, divs) {
    return !!findItemFromSingleOrMultiple(divs, (t)=>t.enable && isInArray(mode, t.mode));
}
function divModeExecute(mode, divs, callback) {
    executeOnSingleOrMultiple(divs, (div)=>{
        const divMode = div.mode, divEnabled = div.enable;
        if (divEnabled && isInArray(mode, divMode)) {
            singleDivModeExecute(div, callback);
        }
    });
}
function singleDivModeExecute(div, callback) {
    const selectors = div.selectors;
    executeOnSingleOrMultiple(selectors, (selector)=>{
        callback(selector, div);
    });
}
function divMode(divs, element) {
    if (!element || !divs) {
        return;
    }
    return findItemFromSingleOrMultiple(divs, (div)=>{
        return checkSelector(element, div.selectors);
    });
}
function circleBounceDataFromParticle(p) {
    return {
        position: p.getPosition(),
        radius: p.getRadius(),
        mass: p.getMass(),
        velocity: p.velocity,
        factor: __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Vectors$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Vector"].create((0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getRangeValue"])(p.options.bounce.horizontal.value), (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getRangeValue"])(p.options.bounce.vertical.value))
    };
}
function circleBounce(p1, p2) {
    const { x: xVelocityDiff, y: yVelocityDiff } = p1.velocity.sub(p2.velocity), [pos1, pos2] = [
        p1.position,
        p2.position
    ], { dx: xDist, dy: yDist } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getDistances"])(pos2, pos1), minimumDistance = 0;
    if (xVelocityDiff * xDist + yVelocityDiff * yDist < minimumDistance) {
        return;
    }
    const angle = -Math.atan2(yDist, xDist), m1 = p1.mass, m2 = p2.mass, u1 = p1.velocity.rotate(angle), u2 = p2.velocity.rotate(angle), v1 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["collisionVelocity"])(u1, u2, m1, m2), v2 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["collisionVelocity"])(u2, u1, m1, m2), vFinal1 = v1.rotate(-angle), vFinal2 = v2.rotate(-angle);
    p1.velocity.x = vFinal1.x * p1.factor.x;
    p1.velocity.y = vFinal1.y * p1.factor.y;
    p2.velocity.x = vFinal2.x * p2.factor.x;
    p2.velocity.y = vFinal2.y * p2.factor.y;
}
function rectBounce(particle, divBounds) {
    const pPos = particle.getPosition(), size = particle.getRadius(), bounds = calculateBounds(pPos, size), bounceOptions = particle.options.bounce, resH = rectSideBounce({
        pSide: {
            min: bounds.left,
            max: bounds.right
        },
        pOtherSide: {
            min: bounds.top,
            max: bounds.bottom
        },
        rectSide: {
            min: divBounds.left,
            max: divBounds.right
        },
        rectOtherSide: {
            min: divBounds.top,
            max: divBounds.bottom
        },
        velocity: particle.velocity.x,
        factor: (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getRangeValue"])(bounceOptions.horizontal.value)
    });
    if (resH.bounced) {
        if (resH.velocity !== undefined) {
            particle.velocity.x = resH.velocity;
        }
        if (resH.position !== undefined) {
            particle.position.x = resH.position;
        }
    }
    const resV = rectSideBounce({
        pSide: {
            min: bounds.top,
            max: bounds.bottom
        },
        pOtherSide: {
            min: bounds.left,
            max: bounds.right
        },
        rectSide: {
            min: divBounds.top,
            max: divBounds.bottom
        },
        rectOtherSide: {
            min: divBounds.left,
            max: divBounds.right
        },
        velocity: particle.velocity.y,
        factor: (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getRangeValue"])(bounceOptions.vertical.value)
    });
    if (resV.bounced) {
        if (resV.velocity !== undefined) {
            particle.velocity.y = resV.velocity;
        }
        if (resV.position !== undefined) {
            particle.position.y = resV.position;
        }
    }
}
function executeOnSingleOrMultiple(obj, callback) {
    const defaultIndex = 0;
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isArray"])(obj) ? obj.map((item, index)=>callback(item, index)) : callback(obj, defaultIndex);
}
function itemFromSingleOrMultiple(obj, index, useIndex) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isArray"])(obj) ? itemFromArray(obj, index, useIndex) : obj;
}
function findItemFromSingleOrMultiple(obj, callback) {
    if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isArray"])(obj)) {
        return obj.find((t, index)=>callback(t, index));
    }
    const defaultIndex = 0;
    return callback(obj, defaultIndex) ? obj : undefined;
}
function initParticleNumericAnimationValue(options, pxRatio) {
    const valueRange = options.value, animationOptions = options.animation, res = {
        delayTime: (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getRangeValue"])(animationOptions.delay) * __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["millisecondsToSeconds"],
        enable: animationOptions.enable,
        value: (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getRangeValue"])(options.value) * pxRatio,
        max: (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getRangeMax"])(valueRange) * pxRatio,
        min: (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getRangeMin"])(valueRange) * pxRatio,
        loops: 0,
        maxLoops: (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getRangeValue"])(animationOptions.count),
        time: 0
    }, decayOffset = 1;
    if (animationOptions.enable) {
        res.decay = decayOffset - (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getRangeValue"])(animationOptions.decay);
        switch(animationOptions.mode){
            case __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Modes$2f$AnimationMode$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["AnimationMode"].increase:
                res.status = __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$AnimationStatus$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["AnimationStatus"].increasing;
                break;
            case __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Modes$2f$AnimationMode$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["AnimationMode"].decrease:
                res.status = __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$AnimationStatus$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["AnimationStatus"].decreasing;
                break;
            case __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Modes$2f$AnimationMode$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["AnimationMode"].random:
                res.status = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getRandom"])() >= __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["half"] ? __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$AnimationStatus$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["AnimationStatus"].increasing : __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$AnimationStatus$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["AnimationStatus"].decreasing;
                break;
        }
        const autoStatus = animationOptions.mode === __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Modes$2f$AnimationMode$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["AnimationMode"].auto;
        switch(animationOptions.startValue){
            case __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Types$2f$StartValueType$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["StartValueType"].min:
                res.value = res.min;
                if (autoStatus) {
                    res.status = __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$AnimationStatus$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["AnimationStatus"].increasing;
                }
                break;
            case __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Types$2f$StartValueType$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["StartValueType"].max:
                res.value = res.max;
                if (autoStatus) {
                    res.status = __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$AnimationStatus$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["AnimationStatus"].decreasing;
                }
                break;
            case __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Types$2f$StartValueType$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["StartValueType"].random:
            default:
                res.value = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["randomInRange"])(res);
                if (autoStatus) {
                    res.status = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getRandom"])() >= __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["half"] ? __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$AnimationStatus$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["AnimationStatus"].increasing : __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$AnimationStatus$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["AnimationStatus"].decreasing;
                }
                break;
        }
    }
    res.initialValue = res.value;
    return res;
}
function getPositionOrSize(positionOrSize, canvasSize) {
    const isPercent = positionOrSize.mode === __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Modes$2f$PixelMode$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["PixelMode"].percent;
    if (!isPercent) {
        const { mode: _, ...rest } = positionOrSize;
        return rest;
    }
    const isPosition = "x" in positionOrSize;
    if (isPosition) {
        return {
            x: positionOrSize.x / __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["percentDenominator"] * canvasSize.width,
            y: positionOrSize.y / __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["percentDenominator"] * canvasSize.height
        };
    } else {
        return {
            width: positionOrSize.width / __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["percentDenominator"] * canvasSize.width,
            height: positionOrSize.height / __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["percentDenominator"] * canvasSize.height
        };
    }
}
function getPosition(position, canvasSize) {
    return getPositionOrSize(position, canvasSize);
}
function getSize(size, canvasSize) {
    return getPositionOrSize(size, canvasSize);
}
function checkDestroy(particle, destroyType, value, minValue, maxValue) {
    switch(destroyType){
        case __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Types$2f$DestroyType$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["DestroyType"].max:
            if (value >= maxValue) {
                particle.destroy();
            }
            break;
        case __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Types$2f$DestroyType$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["DestroyType"].min:
            if (value <= minValue) {
                particle.destroy();
            }
            break;
    }
}
function updateAnimation(particle, data, changeDirection, destroyType, delta) {
    const minLoops = 0, minDelay = 0, identity = 1, minVelocity = 0, minDecay = 1;
    if (particle.destroyed || !data || !data.enable || (data.maxLoops ?? minLoops) > minLoops && (data.loops ?? minLoops) > (data.maxLoops ?? minLoops)) {
        return;
    }
    const velocity = (data.velocity ?? minVelocity) * delta.factor, minValue = data.min, maxValue = data.max, decay = data.decay ?? minDecay;
    if (!data.time) {
        data.time = 0;
    }
    if ((data.delayTime ?? minDelay) > minDelay && data.time < (data.delayTime ?? minDelay)) {
        data.time += delta.value;
    }
    if ((data.delayTime ?? minDelay) > minDelay && data.time < (data.delayTime ?? minDelay)) {
        return;
    }
    switch(data.status){
        case __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$AnimationStatus$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["AnimationStatus"].increasing:
            if (data.value >= maxValue) {
                if (changeDirection) {
                    data.status = __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$AnimationStatus$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["AnimationStatus"].decreasing;
                } else {
                    data.value -= maxValue;
                }
                if (!data.loops) {
                    data.loops = minLoops;
                }
                data.loops++;
            } else {
                data.value += velocity;
            }
            break;
        case __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$AnimationStatus$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["AnimationStatus"].decreasing:
            if (data.value <= minValue) {
                if (changeDirection) {
                    data.status = __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$AnimationStatus$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["AnimationStatus"].increasing;
                } else {
                    data.value += maxValue;
                }
                if (!data.loops) {
                    data.loops = minLoops;
                }
                data.loops++;
            } else {
                data.value -= velocity;
            }
    }
    if (data.velocity && decay !== identity) {
        data.velocity *= decay;
    }
    checkDestroy(particle, destroyType, data.value, minValue, maxValue);
    if (!particle.destroyed) {
        data.value = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["clamp"])(data.value, minValue, maxValue);
    }
}
function cloneStyle(style) {
    const clonedStyle = document.createElement("div").style;
    if (!style) {
        return clonedStyle;
    }
    for(const key in style){
        const styleKey = style[key];
        if (!Object.prototype.hasOwnProperty.call(style, key) || (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isNull"])(styleKey)) {
            continue;
        }
        const styleValue = style.getPropertyValue?.(styleKey);
        if (!styleValue) {
            continue;
        }
        const stylePriority = style.getPropertyPriority?.(styleKey);
        if (!stylePriority) {
            clonedStyle.setProperty?.(styleKey, styleValue);
        } else {
            clonedStyle.setProperty?.(styleKey, styleValue, stylePriority);
        }
    }
    return clonedStyle;
}
function computeFullScreenStyle(zIndex) {
    const fullScreenStyle = document.createElement("div").style, radix = 10, style = {
        width: "100%",
        height: "100%",
        margin: "0",
        padding: "0",
        borderWidth: "0",
        position: "fixed",
        zIndex: zIndex.toString(radix),
        "z-index": zIndex.toString(radix),
        top: "0",
        left: "0"
    };
    for(const key in style){
        const value = style[key];
        fullScreenStyle.setProperty(key, value);
    }
    return fullScreenStyle;
}
const getFullScreenStyle = memoize(computeFullScreenStyle);
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Enums/Types/AlterType.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "AlterType",
    ()=>AlterType
]);
var AlterType;
(function(AlterType) {
    AlterType["darken"] = "darken";
    AlterType["enlighten"] = "enlighten";
})(AlterType || (AlterType = {}));
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/ColorUtils.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "colorMix",
    ()=>colorMix,
    "colorToHsl",
    ()=>colorToHsl,
    "colorToRgb",
    ()=>colorToRgb,
    "getHslAnimationFromHsl",
    ()=>getHslAnimationFromHsl,
    "getHslFromAnimation",
    ()=>getHslFromAnimation,
    "getLinkColor",
    ()=>getLinkColor,
    "getLinkRandomColor",
    ()=>getLinkRandomColor,
    "getRandomRgbColor",
    ()=>getRandomRgbColor,
    "getStyleFromHsl",
    ()=>getStyleFromHsl,
    "getStyleFromRgb",
    ()=>getStyleFromRgb,
    "hslToRgb",
    ()=>hslToRgb,
    "hslaToRgba",
    ()=>hslaToRgba,
    "rangeColorToHsl",
    ()=>rangeColorToHsl,
    "rangeColorToRgb",
    ()=>rangeColorToRgb,
    "rgbToHsl",
    ()=>rgbToHsl,
    "stringToAlpha",
    ()=>stringToAlpha,
    "stringToRgb",
    ()=>stringToRgb,
    "updateColor",
    ()=>updateColor,
    "updateColorValue",
    ()=>updateColorValue
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/NumberUtils.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Core/Utils/Constants.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/TypeUtils.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$AnimationStatus$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Enums/AnimationStatus.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/Utils.js [app-ssr] (ecmascript)");
;
;
;
;
;
function stringToRgba(engine, input) {
    if (!input) {
        return;
    }
    for (const manager of engine.colorManagers.values()){
        if (input.startsWith(manager.stringPrefix)) {
            return manager.parseString(input);
        }
    }
}
function rangeColorToRgb(engine, input, index, useIndex = true) {
    if (!input) {
        return;
    }
    const color = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isString"])(input) ? {
        value: input
    } : input;
    if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isString"])(color.value)) {
        return colorToRgb(engine, color.value, index, useIndex);
    }
    if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isArray"])(color.value)) {
        return rangeColorToRgb(engine, {
            value: (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["itemFromArray"])(color.value, index, useIndex)
        });
    }
    for (const manager of engine.colorManagers.values()){
        const res = manager.handleRangeColor(color);
        if (res) {
            return res;
        }
    }
}
function colorToRgb(engine, input, index, useIndex = true) {
    if (!input) {
        return;
    }
    const color = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isString"])(input) ? {
        value: input
    } : input;
    if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isString"])(color.value)) {
        return color.value === __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["randomColorValue"] ? getRandomRgbColor() : stringToRgb(engine, color.value);
    }
    if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isArray"])(color.value)) {
        return colorToRgb(engine, {
            value: (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["itemFromArray"])(color.value, index, useIndex)
        });
    }
    for (const manager of engine.colorManagers.values()){
        const res = manager.handleColor(color);
        if (res) {
            return res;
        }
    }
}
function colorToHsl(engine, color, index, useIndex = true) {
    const rgb = colorToRgb(engine, color, index, useIndex);
    return rgb ? rgbToHsl(rgb) : undefined;
}
function rangeColorToHsl(engine, color, index, useIndex = true) {
    const rgb = rangeColorToRgb(engine, color, index, useIndex);
    return rgb ? rgbToHsl(rgb) : undefined;
}
function rgbToHsl(color) {
    const r1 = color.r / __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["rgbMax"], g1 = color.g / __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["rgbMax"], b1 = color.b / __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["rgbMax"], max = Math.max(r1, g1, b1), min = Math.min(r1, g1, b1), res = {
        h: __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["hMin"],
        l: (max + min) * __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["half"],
        s: __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["sMin"]
    };
    if (max !== min) {
        res.s = res.l < __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["half"] ? (max - min) / (max + min) : (max - min) / (__TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["double"] - max - min);
        res.h = r1 === max ? (g1 - b1) / (max - min) : res.h = g1 === max ? __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["double"] + (b1 - r1) / (max - min) : __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["double"] * __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["double"] + (r1 - g1) / (max - min);
    }
    res.l *= __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["lMax"];
    res.s *= __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["sMax"];
    res.h *= __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["hPhase"];
    if (res.h < __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["hMin"]) {
        res.h += __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["hMax"];
    }
    if (res.h >= __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["hMax"]) {
        res.h -= __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["hMax"];
    }
    return res;
}
function stringToAlpha(engine, input) {
    return stringToRgba(engine, input)?.a;
}
function stringToRgb(engine, input) {
    return stringToRgba(engine, input);
}
function hslToRgb(hsl) {
    const h = (hsl.h % __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["hMax"] + __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["hMax"]) % __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["hMax"], s = Math.max(__TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["sMin"], Math.min(__TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["sMax"], hsl.s)), l = Math.max(__TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["lMin"], Math.min(__TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["lMax"], hsl.l)), hNormalized = h / __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["hMax"], sNormalized = s / __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["sMax"], lNormalized = l / __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["lMax"];
    if (s === __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["sMin"]) {
        const grayscaleValue = Math.round(lNormalized * __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["rgbFactor"]);
        return {
            r: grayscaleValue,
            g: grayscaleValue,
            b: grayscaleValue
        };
    }
    const channel = (temp1, temp2, temp3)=>{
        const temp3Min = 0, temp3Max = 1;
        if (temp3 < temp3Min) {
            temp3++;
        }
        if (temp3 > temp3Max) {
            temp3--;
        }
        if (temp3 * __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["sextuple"] < temp3Max) {
            return temp1 + (temp2 - temp1) * __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["sextuple"] * temp3;
        }
        if (temp3 * __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["double"] < temp3Max) {
            return temp2;
        }
        if (temp3 * __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["triple"] < temp3Max * __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["double"]) {
            const temp3Offset = __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["double"] / __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["triple"];
            return temp1 + (temp2 - temp1) * (temp3Offset - temp3) * __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["sextuple"];
        }
        return temp1;
    }, temp1 = lNormalized < __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["half"] ? lNormalized * (__TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["sNormalizedOffset"] + sNormalized) : lNormalized + sNormalized - lNormalized * sNormalized, temp2 = __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["double"] * lNormalized - temp1, phaseThird = __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["phaseNumerator"] / __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["triple"], red = Math.min(__TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["rgbFactor"], __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["rgbFactor"] * channel(temp2, temp1, hNormalized + phaseThird)), green = Math.min(__TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["rgbFactor"], __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["rgbFactor"] * channel(temp2, temp1, hNormalized)), blue = Math.min(__TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["rgbFactor"], __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["rgbFactor"] * channel(temp2, temp1, hNormalized - phaseThird));
    return {
        r: Math.round(red),
        g: Math.round(green),
        b: Math.round(blue)
    };
}
function hslaToRgba(hsla) {
    const rgbResult = hslToRgb(hsla);
    return {
        a: hsla.a,
        b: rgbResult.b,
        g: rgbResult.g,
        r: rgbResult.r
    };
}
function getRandomRgbColor(min) {
    const fixedMin = min ?? __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["defaultRgbMin"], fixedMax = __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["rgbMax"] + __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["identity"];
    return {
        b: Math.floor((0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["randomInRange"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["setRangeValue"])(fixedMin, fixedMax))),
        g: Math.floor((0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["randomInRange"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["setRangeValue"])(fixedMin, fixedMax))),
        r: Math.floor((0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["randomInRange"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["setRangeValue"])(fixedMin, fixedMax)))
    };
}
function getStyleFromRgb(color, opacity) {
    return `rgba(${color.r}, ${color.g}, ${color.b}, ${opacity ?? __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["defaultOpacity"]})`;
}
function getStyleFromHsl(color, opacity) {
    return `hsla(${color.h}, ${color.s}%, ${color.l}%, ${opacity ?? __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["defaultOpacity"]})`;
}
function colorMix(color1, color2, size1, size2) {
    let rgb1 = color1, rgb2 = color2;
    if (rgb1.r === undefined) {
        rgb1 = hslToRgb(color1);
    }
    if (rgb2.r === undefined) {
        rgb2 = hslToRgb(color2);
    }
    return {
        b: (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["mix"])(rgb1.b, rgb2.b, size1, size2),
        g: (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["mix"])(rgb1.g, rgb2.g, size1, size2),
        r: (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["mix"])(rgb1.r, rgb2.r, size1, size2)
    };
}
function getLinkColor(p1, p2, linkColor) {
    if (linkColor === __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["randomColorValue"]) {
        return getRandomRgbColor();
    } else if (linkColor === __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["midColorValue"]) {
        const sourceColor = p1.getFillColor() ?? p1.getStrokeColor(), destColor = p2?.getFillColor() ?? p2?.getStrokeColor();
        if (sourceColor && destColor && p2) {
            return colorMix(sourceColor, destColor, p1.getRadius(), p2.getRadius());
        } else {
            const hslColor = sourceColor ?? destColor;
            if (hslColor) {
                return hslToRgb(hslColor);
            }
        }
    } else {
        return linkColor;
    }
}
function getLinkRandomColor(engine, optColor, blink, consent) {
    const color = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isString"])(optColor) ? optColor : optColor.value;
    if (color === __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["randomColorValue"]) {
        if (consent) {
            return rangeColorToRgb(engine, {
                value: color
            });
        }
        if (blink) {
            return __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["randomColorValue"];
        }
        return __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["midColorValue"];
    } else if (color === __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["midColorValue"]) {
        return __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["midColorValue"];
    } else {
        return rangeColorToRgb(engine, {
            value: color
        });
    }
}
function getHslFromAnimation(animation) {
    return animation !== undefined ? {
        h: animation.h.value,
        s: animation.s.value,
        l: animation.l.value
    } : undefined;
}
function getHslAnimationFromHsl(hsl, animationOptions, reduceFactor) {
    const resColor = {
        h: {
            enable: false,
            value: hsl.h
        },
        s: {
            enable: false,
            value: hsl.s
        },
        l: {
            enable: false,
            value: hsl.l
        }
    };
    if (animationOptions) {
        setColorAnimation(resColor.h, animationOptions.h, reduceFactor);
        setColorAnimation(resColor.s, animationOptions.s, reduceFactor);
        setColorAnimation(resColor.l, animationOptions.l, reduceFactor);
    }
    return resColor;
}
function setColorAnimation(colorValue, colorAnimation, reduceFactor) {
    colorValue.enable = colorAnimation.enable;
    if (colorValue.enable) {
        colorValue.velocity = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getRangeValue"])(colorAnimation.speed) / __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["percentDenominator"] * reduceFactor;
        colorValue.decay = __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["decayOffset"] - (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getRangeValue"])(colorAnimation.decay);
        colorValue.status = __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$AnimationStatus$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["AnimationStatus"].increasing;
        colorValue.loops = __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["defaultLoops"];
        colorValue.maxLoops = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getRangeValue"])(colorAnimation.count);
        colorValue.time = __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["defaultTime"];
        colorValue.delayTime = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getRangeValue"])(colorAnimation.delay) * __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["millisecondsToSeconds"];
        if (!colorAnimation.sync) {
            colorValue.velocity *= (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getRandom"])();
            colorValue.value *= (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getRandom"])();
        }
        colorValue.initialValue = colorValue.value;
        colorValue.offset = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["setRangeValue"])(colorAnimation.offset);
    } else {
        colorValue.velocity = __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["defaultVelocity"];
    }
}
function updateColorValue(data, range, decrease, delta) {
    const minLoops = 0, minDelay = 0, identity = 1, minVelocity = 0, minOffset = 0, velocityFactor = 3.6;
    if (!data || !data.enable || (data.maxLoops ?? minLoops) > minLoops && (data.loops ?? minLoops) > (data.maxLoops ?? minLoops)) {
        return;
    }
    if (!data.time) {
        data.time = 0;
    }
    if ((data.delayTime ?? minDelay) > minDelay && data.time < (data.delayTime ?? minDelay)) {
        data.time += delta.value;
    }
    if ((data.delayTime ?? minDelay) > minDelay && data.time < (data.delayTime ?? minDelay)) {
        return;
    }
    const offset = data.offset ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["randomInRange"])(data.offset) : minOffset, velocity = (data.velocity ?? minVelocity) * delta.factor + offset * velocityFactor, decay = data.decay ?? identity, max = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getRangeMax"])(range), min = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getRangeMin"])(range);
    if (!decrease || data.status === __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$AnimationStatus$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["AnimationStatus"].increasing) {
        data.value += velocity;
        if (data.value > max) {
            if (!data.loops) {
                data.loops = 0;
            }
            data.loops++;
            if (decrease) {
                data.status = __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$AnimationStatus$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["AnimationStatus"].decreasing;
            } else {
                data.value -= max;
            }
        }
    } else {
        data.value -= velocity;
        const minValue = 0;
        if (data.value < minValue) {
            if (!data.loops) {
                data.loops = 0;
            }
            data.loops++;
            data.status = __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$AnimationStatus$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["AnimationStatus"].increasing;
        }
    }
    if (data.velocity && decay !== identity) {
        data.velocity *= decay;
    }
    data.value = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["clamp"])(data.value, min, max);
}
function updateColor(color, delta) {
    if (!color) {
        return;
    }
    const { h, s, l } = color, ranges = {
        h: {
            min: 0,
            max: 360
        },
        s: {
            min: 0,
            max: 100
        },
        l: {
            min: 0,
            max: 100
        }
    };
    if (h) {
        updateColorValue(h, ranges.h, false, delta);
    }
    if (s) {
        updateColorValue(s, ranges.s, true, delta);
    }
    if (l) {
        updateColorValue(l, ranges.l, true, delta);
    }
}
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/CanvasUtils.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "alterHsl",
    ()=>alterHsl,
    "clear",
    ()=>clear,
    "drawEffect",
    ()=>drawEffect,
    "drawLine",
    ()=>drawLine,
    "drawParticle",
    ()=>drawParticle,
    "drawParticlePlugin",
    ()=>drawParticlePlugin,
    "drawPlugin",
    ()=>drawPlugin,
    "drawShape",
    ()=>drawShape,
    "drawShapeAfterDraw",
    ()=>drawShapeAfterDraw,
    "paintBase",
    ()=>paintBase,
    "paintImage",
    ()=>paintImage
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Core/Utils/Constants.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Types$2f$AlterType$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Enums/Types/AlterType.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$ColorUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/ColorUtils.js [app-ssr] (ecmascript)");
;
;
;
function drawLine(context, begin, end) {
    context.beginPath();
    context.moveTo(begin.x, begin.y);
    context.lineTo(end.x, end.y);
    context.closePath();
}
function paintBase(context, dimension, baseColor) {
    context.fillStyle = baseColor ?? "rgba(0,0,0,0)";
    context.fillRect(__TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["originPoint"].x, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["originPoint"].y, dimension.width, dimension.height);
}
function paintImage(context, dimension, image, opacity) {
    if (!image) {
        return;
    }
    context.globalAlpha = opacity;
    context.drawImage(image, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["originPoint"].x, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["originPoint"].y, dimension.width, dimension.height);
    context.globalAlpha = 1;
}
function clear(context, dimension) {
    context.clearRect(__TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["originPoint"].x, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["originPoint"].y, dimension.width, dimension.height);
}
function drawParticle(data) {
    const { container, context, particle, delta, colorStyles, backgroundMask, composite, radius, opacity, shadow, transform } = data, pos = particle.getPosition(), angle = particle.rotation + (particle.pathRotation ? particle.velocity.angle : __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["defaultAngle"]), rotateData = {
        sin: Math.sin(angle),
        cos: Math.cos(angle)
    }, rotating = !!angle, transformData = {
        a: rotateData.cos * (transform.a ?? __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["defaultTransform"].a),
        b: rotating ? rotateData.sin * (transform.b ?? __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["identity"]) : transform.b ?? __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["defaultTransform"].b,
        c: rotating ? -rotateData.sin * (transform.c ?? __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["identity"]) : transform.c ?? __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["defaultTransform"].c,
        d: rotateData.cos * (transform.d ?? __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["defaultTransform"].d)
    };
    context.setTransform(transformData.a, transformData.b, transformData.c, transformData.d, pos.x, pos.y);
    if (backgroundMask) {
        context.globalCompositeOperation = composite;
    }
    const shadowColor = particle.shadowColor;
    if (shadow.enable && shadowColor) {
        context.shadowBlur = shadow.blur;
        context.shadowColor = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$ColorUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getStyleFromRgb"])(shadowColor);
        context.shadowOffsetX = shadow.offset.x;
        context.shadowOffsetY = shadow.offset.y;
    }
    if (colorStyles.fill) {
        context.fillStyle = colorStyles.fill;
    }
    const strokeWidth = particle.strokeWidth ?? __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["minStrokeWidth"];
    context.lineWidth = strokeWidth;
    if (colorStyles.stroke) {
        context.strokeStyle = colorStyles.stroke;
    }
    const drawData = {
        container,
        context,
        particle,
        radius,
        opacity,
        delta,
        transformData,
        strokeWidth
    };
    drawShape(drawData);
    drawShapeAfterDraw(drawData);
    drawEffect(drawData);
    context.globalCompositeOperation = "source-over";
    context.resetTransform();
}
function drawEffect(data) {
    const { container, context, particle, radius, opacity, delta, transformData } = data;
    if (!particle.effect) {
        return;
    }
    const drawer = container.effectDrawers.get(particle.effect);
    if (!drawer) {
        return;
    }
    drawer.draw({
        context,
        particle,
        radius,
        opacity,
        delta,
        pixelRatio: container.retina.pixelRatio,
        transformData: {
            ...transformData
        }
    });
}
function drawShape(data) {
    const { container, context, particle, radius, opacity, delta, strokeWidth, transformData } = data;
    if (!particle.shape) {
        return;
    }
    const drawer = container.shapeDrawers.get(particle.shape);
    if (!drawer) {
        return;
    }
    context.beginPath();
    drawer.draw({
        context,
        particle,
        radius,
        opacity,
        delta,
        pixelRatio: container.retina.pixelRatio,
        transformData: {
            ...transformData
        }
    });
    if (particle.shapeClose) {
        context.closePath();
    }
    if (strokeWidth > __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["minStrokeWidth"]) {
        context.stroke();
    }
    if (particle.shapeFill) {
        context.fill();
    }
}
function drawShapeAfterDraw(data) {
    const { container, context, particle, radius, opacity, delta, transformData } = data;
    if (!particle.shape) {
        return;
    }
    const drawer = container.shapeDrawers.get(particle.shape);
    if (!drawer?.afterDraw) {
        return;
    }
    drawer.afterDraw({
        context,
        particle,
        radius,
        opacity,
        delta,
        pixelRatio: container.retina.pixelRatio,
        transformData: {
            ...transformData
        }
    });
}
function drawPlugin(context, plugin, delta) {
    if (!plugin.draw) {
        return;
    }
    plugin.draw(context, delta);
}
function drawParticlePlugin(context, plugin, particle, delta) {
    if (!plugin.drawParticle) {
        return;
    }
    plugin.drawParticle(context, particle, delta);
}
function alterHsl(color, type, value) {
    return {
        h: color.h,
        s: color.s,
        l: color.l + (type === __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Types$2f$AlterType$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["AlterType"].darken ? -__TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["lFactor"] : __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["lFactor"]) * value
    };
}
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Core/Canvas.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Canvas",
    ()=>Canvas
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$CanvasUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/CanvasUtils.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/Utils.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Core/Utils/Constants.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$ColorUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/ColorUtils.js [app-ssr] (ecmascript)");
;
;
;
;
function setTransformValue(factor, newFactor, key) {
    const newValue = newFactor[key];
    if (newValue !== undefined) {
        factor[key] = (factor[key] ?? __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["defaultTransformValue"]) * newValue;
    }
}
function setStyle(canvas, style, important = false) {
    if (!style) {
        return;
    }
    const element = canvas;
    if (!element) {
        return;
    }
    const elementStyle = element.style;
    if (!elementStyle) {
        return;
    }
    const keys = new Set();
    for(const key in elementStyle){
        if (!Object.prototype.hasOwnProperty.call(elementStyle, key)) {
            continue;
        }
        keys.add(elementStyle[key]);
    }
    for(const key in style){
        if (!Object.prototype.hasOwnProperty.call(style, key)) {
            continue;
        }
        keys.add(style[key]);
    }
    for (const key of keys){
        const value = style.getPropertyValue(key);
        if (!value) {
            elementStyle.removeProperty(key);
        } else {
            elementStyle.setProperty(key, value, important ? "important" : "");
        }
    }
}
class Canvas {
    constructor(container, engine){
        this.container = container;
        this._applyPostDrawUpdaters = (particle)=>{
            for (const updater of this._postDrawUpdaters){
                updater.afterDraw?.(particle);
            }
        };
        this._applyPreDrawUpdaters = (ctx, particle, radius, zOpacity, colorStyles, transform)=>{
            for (const updater of this._preDrawUpdaters){
                if (updater.getColorStyles) {
                    const { fill, stroke } = updater.getColorStyles(particle, ctx, radius, zOpacity);
                    if (fill) {
                        colorStyles.fill = fill;
                    }
                    if (stroke) {
                        colorStyles.stroke = stroke;
                    }
                }
                if (updater.getTransformValues) {
                    const updaterTransform = updater.getTransformValues(particle);
                    for(const key in updaterTransform){
                        setTransformValue(transform, updaterTransform, key);
                    }
                }
                updater.beforeDraw?.(particle);
            }
        };
        this._applyResizePlugins = ()=>{
            for (const plugin of this._resizePlugins){
                plugin.resize?.();
            }
        };
        this._getPluginParticleColors = (particle)=>{
            let fColor, sColor;
            for (const plugin of this._colorPlugins){
                if (!fColor && plugin.particleFillColor) {
                    fColor = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$ColorUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["rangeColorToHsl"])(this._engine, plugin.particleFillColor(particle));
                }
                if (!sColor && plugin.particleStrokeColor) {
                    sColor = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$ColorUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["rangeColorToHsl"])(this._engine, plugin.particleStrokeColor(particle));
                }
                if (fColor && sColor) {
                    break;
                }
            }
            return [
                fColor,
                sColor
            ];
        };
        this._initCover = async ()=>{
            const options = this.container.actualOptions, cover = options.backgroundMask.cover, color = cover.color;
            if (color) {
                const coverRgb = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$ColorUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["rangeColorToRgb"])(this._engine, color);
                if (coverRgb) {
                    const coverColor = {
                        ...coverRgb,
                        a: cover.opacity
                    };
                    this._coverColorStyle = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$ColorUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getStyleFromRgb"])(coverColor, coverColor.a);
                }
            } else {
                await new Promise((resolve, reject)=>{
                    if (!cover.image) {
                        return;
                    }
                    const img = document.createElement("img");
                    img.addEventListener("load", ()=>{
                        this._coverImage = {
                            image: img,
                            opacity: cover.opacity
                        };
                        resolve();
                    });
                    img.addEventListener("error", (evt)=>{
                        reject(evt.error);
                    });
                    img.src = cover.image;
                });
            }
        };
        this._initStyle = ()=>{
            const element = this.element, options = this.container.actualOptions;
            if (!element) {
                return;
            }
            if (this._fullScreen) {
                this._setFullScreenStyle();
            } else {
                this._resetOriginalStyle();
            }
            for(const key in options.style){
                if (!key || !options.style || !Object.prototype.hasOwnProperty.call(options.style, key)) {
                    continue;
                }
                const value = options.style[key];
                if (!value) {
                    continue;
                }
                element.style.setProperty(key, value, "important");
            }
        };
        this._initTrail = async ()=>{
            const options = this.container.actualOptions, trail = options.particles.move.trail, trailFill = trail.fill;
            if (!trail.enable) {
                return;
            }
            const opacity = __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["inverseFactorNumerator"] / trail.length;
            if (trailFill.color) {
                const fillColor = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$ColorUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["rangeColorToRgb"])(this._engine, trailFill.color);
                if (!fillColor) {
                    return;
                }
                this._trailFill = {
                    color: {
                        ...fillColor
                    },
                    opacity
                };
            } else {
                await new Promise((resolve, reject)=>{
                    if (!trailFill.image) {
                        return;
                    }
                    const img = document.createElement("img");
                    img.addEventListener("load", ()=>{
                        this._trailFill = {
                            image: img,
                            opacity
                        };
                        resolve();
                    });
                    img.addEventListener("error", (evt)=>{
                        reject(evt.error);
                    });
                    img.src = trailFill.image;
                });
            }
        };
        this._paintBase = (baseColor)=>{
            this.draw((ctx)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$CanvasUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["paintBase"])(ctx, this.size, baseColor));
        };
        this._paintImage = (image, opacity)=>{
            this.draw((ctx)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$CanvasUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["paintImage"])(ctx, this.size, image, opacity));
        };
        this._repairStyle = ()=>{
            const element = this.element;
            if (!element) {
                return;
            }
            this._safeMutationObserver((observer)=>observer.disconnect());
            this._initStyle();
            this.initBackground();
            const pointerEvents = this._pointerEvents;
            element.style.pointerEvents = pointerEvents;
            element.setAttribute("pointer-events", pointerEvents);
            this._safeMutationObserver((observer)=>{
                if (!element || !(element instanceof Node)) {
                    return;
                }
                observer.observe(element, {
                    attributes: true
                });
            });
        };
        this._resetOriginalStyle = ()=>{
            const element = this.element, originalStyle = this._originalStyle;
            if (!element || !originalStyle) {
                return;
            }
            setStyle(element, originalStyle, true);
        };
        this._safeMutationObserver = (callback)=>{
            if (!this._mutationObserver) {
                return;
            }
            callback(this._mutationObserver);
        };
        this._setFullScreenStyle = ()=>{
            const element = this.element;
            if (!element) {
                return;
            }
            setStyle(element, (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getFullScreenStyle"])(this.container.actualOptions.fullScreen.zIndex), true);
        };
        this._engine = engine;
        this._standardSize = {
            height: 0,
            width: 0
        };
        const pxRatio = container.retina.pixelRatio, stdSize = this._standardSize;
        this.size = {
            height: stdSize.height * pxRatio,
            width: stdSize.width * pxRatio
        };
        this._context = null;
        this._generated = false;
        this._preDrawUpdaters = [];
        this._postDrawUpdaters = [];
        this._resizePlugins = [];
        this._colorPlugins = [];
        this._pointerEvents = "none";
    }
    get _fullScreen() {
        return this.container.actualOptions.fullScreen.enable;
    }
    clear() {
        const options = this.container.actualOptions, trail = options.particles.move.trail, trailFill = this._trailFill;
        if (options.backgroundMask.enable) {
            this.paint();
        } else if (trail.enable && trail.length > __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["minimumLength"] && trailFill) {
            if (trailFill.color) {
                this._paintBase((0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$ColorUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getStyleFromRgb"])(trailFill.color, trailFill.opacity));
            } else if (trailFill.image) {
                this._paintImage(trailFill.image, trailFill.opacity);
            }
        } else if (options.clear) {
            this.draw((ctx)=>{
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$CanvasUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["clear"])(ctx, this.size);
            });
        }
    }
    destroy() {
        this.stop();
        if (this._generated) {
            const element = this.element;
            element?.remove();
            this.element = undefined;
        } else {
            this._resetOriginalStyle();
        }
        this._preDrawUpdaters = [];
        this._postDrawUpdaters = [];
        this._resizePlugins = [];
        this._colorPlugins = [];
    }
    draw(cb) {
        const ctx = this._context;
        if (!ctx) {
            return;
        }
        return cb(ctx);
    }
    drawAsync(cb) {
        const ctx = this._context;
        if (!ctx) {
            return undefined;
        }
        return cb(ctx);
    }
    drawParticle(particle, delta) {
        if (particle.spawning || particle.destroyed) {
            return;
        }
        const radius = particle.getRadius();
        if (radius <= __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["minimumSize"]) {
            return;
        }
        const pfColor = particle.getFillColor(), psColor = particle.getStrokeColor() ?? pfColor;
        let [fColor, sColor] = this._getPluginParticleColors(particle);
        if (!fColor) {
            fColor = pfColor;
        }
        if (!sColor) {
            sColor = psColor;
        }
        if (!fColor && !sColor) {
            return;
        }
        this.draw((ctx)=>{
            const container = this.container, options = container.actualOptions, zIndexOptions = particle.options.zIndex, zIndexFactor = __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["zIndexFactorOffset"] - particle.zIndexFactor, zOpacityFactor = zIndexFactor ** zIndexOptions.opacityRate, opacity = particle.bubble.opacity ?? particle.opacity?.value ?? __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["defaultOpacity"], strokeOpacity = particle.strokeOpacity ?? opacity, zOpacity = opacity * zOpacityFactor, zStrokeOpacity = strokeOpacity * zOpacityFactor, transform = {}, colorStyles = {
                fill: fColor ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$ColorUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getStyleFromHsl"])(fColor, zOpacity) : undefined
            };
            colorStyles.stroke = sColor ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$ColorUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getStyleFromHsl"])(sColor, zStrokeOpacity) : colorStyles.fill;
            this._applyPreDrawUpdaters(ctx, particle, radius, zOpacity, colorStyles, transform);
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$CanvasUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["drawParticle"])({
                container,
                context: ctx,
                particle,
                delta,
                colorStyles,
                backgroundMask: options.backgroundMask.enable,
                composite: options.backgroundMask.composite,
                radius: radius * zIndexFactor ** zIndexOptions.sizeRate,
                opacity: zOpacity,
                shadow: particle.options.shadow,
                transform
            });
            this._applyPostDrawUpdaters(particle);
        });
    }
    drawParticlePlugin(plugin, particle, delta) {
        this.draw((ctx)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$CanvasUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["drawParticlePlugin"])(ctx, plugin, particle, delta));
    }
    drawPlugin(plugin, delta) {
        this.draw((ctx)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$CanvasUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["drawPlugin"])(ctx, plugin, delta));
    }
    async init() {
        this._safeMutationObserver((obs)=>obs.disconnect());
        this._mutationObserver = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["safeMutationObserver"])((records)=>{
            for (const record of records){
                if (record.type === "attributes" && record.attributeName === "style") {
                    this._repairStyle();
                }
            }
        });
        this.resize();
        this._initStyle();
        await this._initCover();
        try {
            await this._initTrail();
        } catch (e) {
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getLogger"])().error(e);
        }
        this.initBackground();
        this._safeMutationObserver((obs)=>{
            if (!this.element || !(this.element instanceof Node)) {
                return;
            }
            obs.observe(this.element, {
                attributes: true
            });
        });
        this.initUpdaters();
        this.initPlugins();
        this.paint();
    }
    initBackground() {
        const options = this.container.actualOptions, background = options.background, element = this.element;
        if (!element) {
            return;
        }
        const elementStyle = element.style;
        if (!elementStyle) {
            return;
        }
        if (background.color) {
            const color = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$ColorUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["rangeColorToRgb"])(this._engine, background.color);
            elementStyle.backgroundColor = color ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$ColorUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getStyleFromRgb"])(color, background.opacity) : "";
        } else {
            elementStyle.backgroundColor = "";
        }
        elementStyle.backgroundImage = background.image || "";
        elementStyle.backgroundPosition = background.position || "";
        elementStyle.backgroundRepeat = background.repeat || "";
        elementStyle.backgroundSize = background.size || "";
    }
    initPlugins() {
        this._resizePlugins = [];
        for (const plugin of this.container.plugins.values()){
            if (plugin.resize) {
                this._resizePlugins.push(plugin);
            }
            if (plugin.particleFillColor ?? plugin.particleStrokeColor) {
                this._colorPlugins.push(plugin);
            }
        }
    }
    initUpdaters() {
        this._preDrawUpdaters = [];
        this._postDrawUpdaters = [];
        for (const updater of this.container.particles.updaters){
            if (updater.afterDraw) {
                this._postDrawUpdaters.push(updater);
            }
            if (updater.getColorStyles ?? updater.getTransformValues ?? updater.beforeDraw) {
                this._preDrawUpdaters.push(updater);
            }
        }
    }
    loadCanvas(canvas) {
        if (this._generated && this.element) {
            this.element.remove();
        }
        this._generated = canvas.dataset && __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["generatedAttribute"] in canvas.dataset ? canvas.dataset[__TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["generatedAttribute"]] === "true" : this._generated;
        this.element = canvas;
        this.element.ariaHidden = "true";
        this._originalStyle = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cloneStyle"])(this.element.style);
        const standardSize = this._standardSize;
        standardSize.height = canvas.offsetHeight;
        standardSize.width = canvas.offsetWidth;
        const pxRatio = this.container.retina.pixelRatio, retinaSize = this.size;
        canvas.height = retinaSize.height = standardSize.height * pxRatio;
        canvas.width = retinaSize.width = standardSize.width * pxRatio;
        this._context = this.element.getContext("2d");
        this._safeMutationObserver((obs)=>obs.disconnect());
        this.container.retina.init();
        this.initBackground();
        this._safeMutationObserver((obs)=>{
            if (!this.element || !(this.element instanceof Node)) {
                return;
            }
            obs.observe(this.element, {
                attributes: true
            });
        });
    }
    paint() {
        const options = this.container.actualOptions;
        this.draw((ctx)=>{
            if (options.backgroundMask.enable && options.backgroundMask.cover) {
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$CanvasUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["clear"])(ctx, this.size);
                if (this._coverImage) {
                    this._paintImage(this._coverImage.image, this._coverImage.opacity);
                } else if (this._coverColorStyle) {
                    this._paintBase(this._coverColorStyle);
                } else {
                    this._paintBase();
                }
            } else {
                this._paintBase();
            }
        });
    }
    resize() {
        if (!this.element) {
            return false;
        }
        const container = this.container, currentSize = container.canvas._standardSize, newSize = {
            width: this.element.offsetWidth,
            height: this.element.offsetHeight
        }, pxRatio = container.retina.pixelRatio, retinaSize = {
            width: newSize.width * pxRatio,
            height: newSize.height * pxRatio
        };
        if (newSize.height === currentSize.height && newSize.width === currentSize.width && retinaSize.height === this.element.height && retinaSize.width === this.element.width) {
            return false;
        }
        const oldSize = {
            ...currentSize
        };
        currentSize.height = newSize.height;
        currentSize.width = newSize.width;
        const canvasSize = this.size;
        this.element.width = canvasSize.width = retinaSize.width;
        this.element.height = canvasSize.height = retinaSize.height;
        if (this.container.started) {
            container.particles.setResizeFactor({
                width: currentSize.width / oldSize.width,
                height: currentSize.height / oldSize.height
            });
        }
        return true;
    }
    setPointerEvents(type) {
        const element = this.element;
        if (!element) {
            return;
        }
        this._pointerEvents = type;
        this._repairStyle();
    }
    stop() {
        this._safeMutationObserver((obs)=>obs.disconnect());
        this._mutationObserver = undefined;
        this.draw((ctx)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$CanvasUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["clear"])(ctx, this.size));
    }
    async windowResize() {
        if (!this.element || !this.resize()) {
            return;
        }
        const container = this.container, needsRefresh = container.updateActualOptions();
        container.particles.setDensity();
        this._applyResizePlugins();
        if (needsRefresh) {
            await container.refresh();
        }
    }
}
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Enums/InteractivityDetect.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "InteractivityDetect",
    ()=>InteractivityDetect
]);
var InteractivityDetect;
(function(InteractivityDetect) {
    InteractivityDetect["canvas"] = "canvas";
    InteractivityDetect["parent"] = "parent";
    InteractivityDetect["window"] = "window";
})(InteractivityDetect || (InteractivityDetect = {}));
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Core/Utils/EventListeners.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "EventListeners",
    ()=>EventListeners
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Core/Utils/Constants.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/Utils.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$InteractivityDetect$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Enums/InteractivityDetect.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/TypeUtils.js [app-ssr] (ecmascript)");
;
;
;
;
function manageListener(element, event, handler, add, options) {
    if (add) {
        let addOptions = {
            passive: true
        };
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isBoolean"])(options)) {
            addOptions.capture = options;
        } else if (options !== undefined) {
            addOptions = options;
        }
        element.addEventListener(event, handler, addOptions);
    } else {
        const removeOptions = options;
        element.removeEventListener(event, handler, removeOptions);
    }
}
class EventListeners {
    constructor(container){
        this.container = container;
        this._doMouseTouchClick = (e)=>{
            const container = this.container, options = container.actualOptions;
            if (this._canPush) {
                const mouseInteractivity = container.interactivity.mouse, mousePos = mouseInteractivity.position;
                if (!mousePos) {
                    return;
                }
                mouseInteractivity.clickPosition = {
                    ...mousePos
                };
                mouseInteractivity.clickTime = new Date().getTime();
                const onClick = options.interactivity.events.onClick;
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["executeOnSingleOrMultiple"])(onClick.mode, (mode)=>this.container.handleClickMode(mode));
            }
            if (e.type === "touchend") {
                setTimeout(()=>this._mouseTouchFinish(), __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["touchDelay"]);
            }
        };
        this._handleThemeChange = (e)=>{
            const mediaEvent = e, container = this.container, options = container.options, defaultThemes = options.defaultThemes, themeName = mediaEvent.matches ? defaultThemes.dark : defaultThemes.light, theme = options.themes.find((theme)=>theme.name === themeName);
            if (theme?.default.auto) {
                void container.loadTheme(themeName);
            }
        };
        this._handleVisibilityChange = ()=>{
            const container = this.container, options = container.actualOptions;
            this._mouseTouchFinish();
            if (!options.pauseOnBlur) {
                return;
            }
            if (document?.hidden) {
                container.pageHidden = true;
                container.pause();
            } else {
                container.pageHidden = false;
                if (container.animationStatus) {
                    void container.play(true);
                } else {
                    void container.draw(true);
                }
            }
        };
        this._handleWindowResize = ()=>{
            if (this._resizeTimeout) {
                clearTimeout(this._resizeTimeout);
                delete this._resizeTimeout;
            }
            const handleResize = async ()=>{
                const canvas = this.container.canvas;
                await canvas?.windowResize();
            };
            this._resizeTimeout = setTimeout(()=>void handleResize(), this.container.actualOptions.interactivity.events.resize.delay * __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["millisecondsToSeconds"]);
        };
        this._manageInteractivityListeners = (mouseLeaveTmpEvent, add)=>{
            const handlers = this._handlers, container = this.container, options = container.actualOptions, interactivityEl = container.interactivity.element;
            if (!interactivityEl) {
                return;
            }
            const html = interactivityEl, canvas = container.canvas;
            canvas.setPointerEvents(html === canvas.element ? "initial" : "none");
            if (!(options.interactivity.events.onHover.enable || options.interactivity.events.onClick.enable)) {
                return;
            }
            manageListener(interactivityEl, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["mouseMoveEvent"], handlers.mouseMove, add);
            manageListener(interactivityEl, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["touchStartEvent"], handlers.touchStart, add);
            manageListener(interactivityEl, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["touchMoveEvent"], handlers.touchMove, add);
            if (!options.interactivity.events.onClick.enable) {
                manageListener(interactivityEl, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["touchEndEvent"], handlers.touchEnd, add);
            } else {
                manageListener(interactivityEl, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["touchEndEvent"], handlers.touchEndClick, add);
                manageListener(interactivityEl, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["mouseUpEvent"], handlers.mouseUp, add);
                manageListener(interactivityEl, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["mouseDownEvent"], handlers.mouseDown, add);
            }
            manageListener(interactivityEl, mouseLeaveTmpEvent, handlers.mouseLeave, add);
            manageListener(interactivityEl, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["touchCancelEvent"], handlers.touchCancel, add);
        };
        this._manageListeners = (add)=>{
            const handlers = this._handlers, container = this.container, options = container.actualOptions, detectType = options.interactivity.detectsOn, canvasEl = container.canvas.element;
            let mouseLeaveTmpEvent = __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["mouseLeaveEvent"];
            if (detectType === __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$InteractivityDetect$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["InteractivityDetect"].window) {
                container.interactivity.element = window;
                mouseLeaveTmpEvent = __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["mouseOutEvent"];
            } else if (detectType === __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$InteractivityDetect$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["InteractivityDetect"].parent && canvasEl) {
                container.interactivity.element = canvasEl.parentElement ?? canvasEl.parentNode;
            } else {
                container.interactivity.element = canvasEl;
            }
            this._manageMediaMatch(add);
            this._manageResize(add);
            this._manageInteractivityListeners(mouseLeaveTmpEvent, add);
            if (document) {
                manageListener(document, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["visibilityChangeEvent"], handlers.visibilityChange, add, false);
            }
        };
        this._manageMediaMatch = (add)=>{
            const handlers = this._handlers, mediaMatch = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["safeMatchMedia"])("(prefers-color-scheme: dark)");
            if (!mediaMatch) {
                return;
            }
            if (mediaMatch.addEventListener !== undefined) {
                manageListener(mediaMatch, "change", handlers.themeChange, add);
                return;
            }
            if (mediaMatch.addListener === undefined) {
                return;
            }
            if (add) {
                mediaMatch.addListener(handlers.oldThemeChange);
            } else {
                mediaMatch.removeListener(handlers.oldThemeChange);
            }
        };
        this._manageResize = (add)=>{
            const handlers = this._handlers, container = this.container, options = container.actualOptions;
            if (!options.interactivity.events.resize) {
                return;
            }
            if (typeof ResizeObserver === "undefined") {
                manageListener(window, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["resizeEvent"], handlers.resize, add);
                return;
            }
            const canvasEl = container.canvas.element;
            if (this._resizeObserver && !add) {
                if (canvasEl) {
                    this._resizeObserver.unobserve(canvasEl);
                }
                this._resizeObserver.disconnect();
                delete this._resizeObserver;
            } else if (!this._resizeObserver && add && canvasEl) {
                this._resizeObserver = new ResizeObserver((entries)=>{
                    const entry = entries.find((e)=>e.target === canvasEl);
                    if (!entry) {
                        return;
                    }
                    this._handleWindowResize();
                });
                this._resizeObserver.observe(canvasEl);
            }
        };
        this._mouseDown = ()=>{
            const { interactivity } = this.container;
            if (!interactivity) {
                return;
            }
            const { mouse } = interactivity;
            mouse.clicking = true;
            mouse.downPosition = mouse.position;
        };
        this._mouseTouchClick = (e)=>{
            const container = this.container, options = container.actualOptions, { mouse } = container.interactivity;
            mouse.inside = true;
            let handled = false;
            const mousePosition = mouse.position;
            if (!mousePosition || !options.interactivity.events.onClick.enable) {
                return;
            }
            for (const plugin of container.plugins.values()){
                if (!plugin.clickPositionValid) {
                    continue;
                }
                handled = plugin.clickPositionValid(mousePosition);
                if (handled) {
                    break;
                }
            }
            if (!handled) {
                this._doMouseTouchClick(e);
            }
            mouse.clicking = false;
        };
        this._mouseTouchFinish = ()=>{
            const interactivity = this.container.interactivity;
            if (!interactivity) {
                return;
            }
            const mouse = interactivity.mouse;
            delete mouse.position;
            delete mouse.clickPosition;
            delete mouse.downPosition;
            interactivity.status = __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["mouseLeaveEvent"];
            mouse.inside = false;
            mouse.clicking = false;
        };
        this._mouseTouchMove = (e)=>{
            const container = this.container, options = container.actualOptions, interactivity = container.interactivity, canvasEl = container.canvas.element;
            if (!interactivity?.element) {
                return;
            }
            interactivity.mouse.inside = true;
            let pos;
            if (e.type.startsWith("pointer")) {
                this._canPush = true;
                const mouseEvent = e;
                if (interactivity.element === window) {
                    if (canvasEl) {
                        const clientRect = canvasEl.getBoundingClientRect();
                        pos = {
                            x: mouseEvent.clientX - clientRect.left,
                            y: mouseEvent.clientY - clientRect.top
                        };
                    }
                } else if (options.interactivity.detectsOn === __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$InteractivityDetect$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["InteractivityDetect"].parent) {
                    const source = mouseEvent.target, target = mouseEvent.currentTarget;
                    if (source && target && canvasEl) {
                        const sourceRect = source.getBoundingClientRect(), targetRect = target.getBoundingClientRect(), canvasRect = canvasEl.getBoundingClientRect();
                        pos = {
                            x: mouseEvent.offsetX + __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["double"] * sourceRect.left - (targetRect.left + canvasRect.left),
                            y: mouseEvent.offsetY + __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["double"] * sourceRect.top - (targetRect.top + canvasRect.top)
                        };
                    } else {
                        pos = {
                            x: mouseEvent.offsetX ?? mouseEvent.clientX,
                            y: mouseEvent.offsetY ?? mouseEvent.clientY
                        };
                    }
                } else if (mouseEvent.target === canvasEl) {
                    pos = {
                        x: mouseEvent.offsetX ?? mouseEvent.clientX,
                        y: mouseEvent.offsetY ?? mouseEvent.clientY
                    };
                }
            } else {
                this._canPush = e.type !== "touchmove";
                if (canvasEl) {
                    const touchEvent = e, lastTouch = touchEvent.touches[touchEvent.touches.length - __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["lengthOffset"]], canvasRect = canvasEl.getBoundingClientRect();
                    pos = {
                        x: lastTouch.clientX - (canvasRect.left ?? __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["minCoordinate"]),
                        y: lastTouch.clientY - (canvasRect.top ?? __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["minCoordinate"])
                    };
                }
            }
            const pxRatio = container.retina.pixelRatio;
            if (pos) {
                pos.x *= pxRatio;
                pos.y *= pxRatio;
            }
            interactivity.mouse.position = pos;
            interactivity.status = __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["mouseMoveEvent"];
        };
        this._touchEnd = (e)=>{
            const evt = e, touches = Array.from(evt.changedTouches);
            for (const touch of touches){
                this._touches.delete(touch.identifier);
            }
            this._mouseTouchFinish();
        };
        this._touchEndClick = (e)=>{
            const evt = e, touches = Array.from(evt.changedTouches);
            for (const touch of touches){
                this._touches.delete(touch.identifier);
            }
            this._mouseTouchClick(e);
        };
        this._touchStart = (e)=>{
            const evt = e, touches = Array.from(evt.changedTouches);
            for (const touch of touches){
                this._touches.set(touch.identifier, performance.now());
            }
            this._mouseTouchMove(e);
        };
        this._canPush = true;
        this._touches = new Map();
        this._handlers = {
            mouseDown: ()=>this._mouseDown(),
            mouseLeave: ()=>this._mouseTouchFinish(),
            mouseMove: (e)=>this._mouseTouchMove(e),
            mouseUp: (e)=>this._mouseTouchClick(e),
            touchStart: (e)=>this._touchStart(e),
            touchMove: (e)=>this._mouseTouchMove(e),
            touchEnd: (e)=>this._touchEnd(e),
            touchCancel: (e)=>this._touchEnd(e),
            touchEndClick: (e)=>this._touchEndClick(e),
            visibilityChange: ()=>this._handleVisibilityChange(),
            themeChange: (e)=>this._handleThemeChange(e),
            oldThemeChange: (e)=>this._handleThemeChange(e),
            resize: ()=>{
                this._handleWindowResize();
            }
        };
    }
    addListeners() {
        this._manageListeners(true);
    }
    removeListeners() {
        this._manageListeners(false);
    }
}
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Enums/Types/EventType.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "EventType",
    ()=>EventType
]);
var EventType;
(function(EventType) {
    EventType["configAdded"] = "configAdded";
    EventType["containerInit"] = "containerInit";
    EventType["particlesSetup"] = "particlesSetup";
    EventType["containerStarted"] = "containerStarted";
    EventType["containerStopped"] = "containerStopped";
    EventType["containerDestroyed"] = "containerDestroyed";
    EventType["containerPaused"] = "containerPaused";
    EventType["containerPlay"] = "containerPlay";
    EventType["containerBuilt"] = "containerBuilt";
    EventType["particleAdded"] = "particleAdded";
    EventType["particleDestroyed"] = "particleDestroyed";
    EventType["particleRemoved"] = "particleRemoved";
})(EventType || (EventType = {}));
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Classes/OptionsColor.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "OptionsColor",
    ()=>OptionsColor
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/TypeUtils.js [app-ssr] (ecmascript)");
;
class OptionsColor {
    constructor(){
        this.value = "";
    }
    static create(source, data) {
        const color = new OptionsColor();
        color.load(source);
        if (data !== undefined) {
            if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isString"])(data) || (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isArray"])(data)) {
                color.load({
                    value: data
                });
            } else {
                color.load(data);
            }
        }
        return color;
    }
    load(data) {
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isNull"])(data)) {
            return;
        }
        if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isNull"])(data.value)) {
            this.value = data.value;
        }
    }
}
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Classes/Background/Background.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Background",
    ()=>Background
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$OptionsColor$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Classes/OptionsColor.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/TypeUtils.js [app-ssr] (ecmascript)");
;
;
class Background {
    constructor(){
        this.color = new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$OptionsColor$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["OptionsColor"]();
        this.color.value = "";
        this.image = "";
        this.position = "";
        this.repeat = "";
        this.size = "";
        this.opacity = 1;
    }
    load(data) {
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isNull"])(data)) {
            return;
        }
        if (data.color !== undefined) {
            this.color = __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$OptionsColor$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["OptionsColor"].create(this.color, data.color);
        }
        if (data.image !== undefined) {
            this.image = data.image;
        }
        if (data.position !== undefined) {
            this.position = data.position;
        }
        if (data.repeat !== undefined) {
            this.repeat = data.repeat;
        }
        if (data.size !== undefined) {
            this.size = data.size;
        }
        if (data.opacity !== undefined) {
            this.opacity = data.opacity;
        }
    }
}
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Classes/BackgroundMask/BackgroundMaskCover.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "BackgroundMaskCover",
    ()=>BackgroundMaskCover
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$OptionsColor$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Classes/OptionsColor.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/TypeUtils.js [app-ssr] (ecmascript)");
;
;
class BackgroundMaskCover {
    constructor(){
        this.opacity = 1;
    }
    load(data) {
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isNull"])(data)) {
            return;
        }
        if (data.color !== undefined) {
            this.color = __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$OptionsColor$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["OptionsColor"].create(this.color, data.color);
        }
        if (data.image !== undefined) {
            this.image = data.image;
        }
        if (data.opacity !== undefined) {
            this.opacity = data.opacity;
        }
    }
}
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Classes/BackgroundMask/BackgroundMask.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "BackgroundMask",
    ()=>BackgroundMask
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/TypeUtils.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$BackgroundMask$2f$BackgroundMaskCover$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Classes/BackgroundMask/BackgroundMaskCover.js [app-ssr] (ecmascript)");
;
;
class BackgroundMask {
    constructor(){
        this.composite = "destination-out";
        this.cover = new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$BackgroundMask$2f$BackgroundMaskCover$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["BackgroundMaskCover"]();
        this.enable = false;
    }
    load(data) {
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isNull"])(data)) {
            return;
        }
        if (data.composite !== undefined) {
            this.composite = data.composite;
        }
        if (data.cover !== undefined) {
            const cover = data.cover, color = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isString"])(data.cover) ? {
                color: data.cover
            } : data.cover;
            this.cover.load(cover.color !== undefined || cover.image !== undefined ? cover : {
                color: color
            });
        }
        if (data.enable !== undefined) {
            this.enable = data.enable;
        }
    }
}
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Classes/FullScreen/FullScreen.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "FullScreen",
    ()=>FullScreen
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/TypeUtils.js [app-ssr] (ecmascript)");
;
class FullScreen {
    constructor(){
        this.enable = true;
        this.zIndex = 0;
    }
    load(data) {
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isNull"])(data)) {
            return;
        }
        if (data.enable !== undefined) {
            this.enable = data.enable;
        }
        if (data.zIndex !== undefined) {
            this.zIndex = data.zIndex;
        }
    }
}
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Classes/Interactivity/Events/ClickEvent.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ClickEvent",
    ()=>ClickEvent
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/TypeUtils.js [app-ssr] (ecmascript)");
;
class ClickEvent {
    constructor(){
        this.enable = false;
        this.mode = [];
    }
    load(data) {
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isNull"])(data)) {
            return;
        }
        if (data.enable !== undefined) {
            this.enable = data.enable;
        }
        if (data.mode !== undefined) {
            this.mode = data.mode;
        }
    }
}
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Enums/Types/DivType.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "DivType",
    ()=>DivType
]);
var DivType;
(function(DivType) {
    DivType["circle"] = "circle";
    DivType["rectangle"] = "rectangle";
})(DivType || (DivType = {}));
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Classes/Interactivity/Events/DivEvent.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "DivEvent",
    ()=>DivEvent
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Types$2f$DivType$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Enums/Types/DivType.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/TypeUtils.js [app-ssr] (ecmascript)");
;
;
class DivEvent {
    constructor(){
        this.selectors = [];
        this.enable = false;
        this.mode = [];
        this.type = __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Types$2f$DivType$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["DivType"].circle;
    }
    load(data) {
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isNull"])(data)) {
            return;
        }
        if (data.selectors !== undefined) {
            this.selectors = data.selectors;
        }
        if (data.enable !== undefined) {
            this.enable = data.enable;
        }
        if (data.mode !== undefined) {
            this.mode = data.mode;
        }
        if (data.type !== undefined) {
            this.type = data.type;
        }
    }
}
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Classes/Interactivity/Events/Parallax.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Parallax",
    ()=>Parallax
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/TypeUtils.js [app-ssr] (ecmascript)");
;
class Parallax {
    constructor(){
        this.enable = false;
        this.force = 2;
        this.smooth = 10;
    }
    load(data) {
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isNull"])(data)) {
            return;
        }
        if (data.enable !== undefined) {
            this.enable = data.enable;
        }
        if (data.force !== undefined) {
            this.force = data.force;
        }
        if (data.smooth !== undefined) {
            this.smooth = data.smooth;
        }
    }
}
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Classes/Interactivity/Events/HoverEvent.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "HoverEvent",
    ()=>HoverEvent
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$Interactivity$2f$Events$2f$Parallax$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Classes/Interactivity/Events/Parallax.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/TypeUtils.js [app-ssr] (ecmascript)");
;
;
class HoverEvent {
    constructor(){
        this.enable = false;
        this.mode = [];
        this.parallax = new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$Interactivity$2f$Events$2f$Parallax$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Parallax"]();
    }
    load(data) {
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isNull"])(data)) {
            return;
        }
        if (data.enable !== undefined) {
            this.enable = data.enable;
        }
        if (data.mode !== undefined) {
            this.mode = data.mode;
        }
        this.parallax.load(data.parallax);
    }
}
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Classes/Interactivity/Events/ResizeEvent.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ResizeEvent",
    ()=>ResizeEvent
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/TypeUtils.js [app-ssr] (ecmascript)");
;
class ResizeEvent {
    constructor(){
        this.delay = 0.5;
        this.enable = true;
    }
    load(data) {
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isNull"])(data)) {
            return;
        }
        if (data.delay !== undefined) {
            this.delay = data.delay;
        }
        if (data.enable !== undefined) {
            this.enable = data.enable;
        }
    }
}
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Classes/Interactivity/Events/Events.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Events",
    ()=>Events
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$Interactivity$2f$Events$2f$ClickEvent$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Classes/Interactivity/Events/ClickEvent.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$Interactivity$2f$Events$2f$DivEvent$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Classes/Interactivity/Events/DivEvent.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$Interactivity$2f$Events$2f$HoverEvent$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Classes/Interactivity/Events/HoverEvent.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$Interactivity$2f$Events$2f$ResizeEvent$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Classes/Interactivity/Events/ResizeEvent.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/Utils.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/TypeUtils.js [app-ssr] (ecmascript)");
;
;
;
;
;
;
class Events {
    constructor(){
        this.onClick = new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$Interactivity$2f$Events$2f$ClickEvent$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ClickEvent"]();
        this.onDiv = new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$Interactivity$2f$Events$2f$DivEvent$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["DivEvent"]();
        this.onHover = new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$Interactivity$2f$Events$2f$HoverEvent$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["HoverEvent"]();
        this.resize = new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$Interactivity$2f$Events$2f$ResizeEvent$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ResizeEvent"]();
    }
    load(data) {
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isNull"])(data)) {
            return;
        }
        this.onClick.load(data.onClick);
        const onDiv = data.onDiv;
        if (onDiv !== undefined) {
            this.onDiv = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["executeOnSingleOrMultiple"])(onDiv, (t)=>{
                const tmp = new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$Interactivity$2f$Events$2f$DivEvent$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["DivEvent"]();
                tmp.load(t);
                return tmp;
            });
        }
        this.onHover.load(data.onHover);
        this.resize.load(data.resize);
    }
}
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Classes/Interactivity/Modes/Modes.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Modes",
    ()=>Modes
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/TypeUtils.js [app-ssr] (ecmascript)");
;
class Modes {
    constructor(engine, container){
        this._engine = engine;
        this._container = container;
    }
    load(data) {
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isNull"])(data)) {
            return;
        }
        if (!this._container) {
            return;
        }
        const interactors = this._engine.interactors.get(this._container);
        if (!interactors) {
            return;
        }
        for (const interactor of interactors){
            if (!interactor.loadModeOptions) {
                continue;
            }
            interactor.loadModeOptions(this, data);
        }
    }
}
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Classes/Interactivity/Interactivity.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Interactivity",
    ()=>Interactivity
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$Interactivity$2f$Events$2f$Events$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Classes/Interactivity/Events/Events.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$InteractivityDetect$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Enums/InteractivityDetect.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$Interactivity$2f$Modes$2f$Modes$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Classes/Interactivity/Modes/Modes.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/TypeUtils.js [app-ssr] (ecmascript)");
;
;
;
;
class Interactivity {
    constructor(engine, container){
        this.detectsOn = __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$InteractivityDetect$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["InteractivityDetect"].window;
        this.events = new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$Interactivity$2f$Events$2f$Events$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Events"]();
        this.modes = new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$Interactivity$2f$Modes$2f$Modes$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Modes"](engine, container);
    }
    load(data) {
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isNull"])(data)) {
            return;
        }
        const detectsOn = data.detectsOn;
        if (detectsOn !== undefined) {
            this.detectsOn = detectsOn;
        }
        this.events.load(data.events);
        this.modes.load(data.modes);
    }
}
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Classes/ManualParticle.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ManualParticle",
    ()=>ManualParticle
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Modes$2f$PixelMode$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Enums/Modes/PixelMode.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/Utils.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/TypeUtils.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Core/Utils/Constants.js [app-ssr] (ecmascript)");
;
;
;
;
class ManualParticle {
    load(data) {
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isNull"])(data)) {
            return;
        }
        if (data.position) {
            this.position = {
                x: data.position.x ?? __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["manualDefaultPosition"],
                y: data.position.y ?? __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["manualDefaultPosition"],
                mode: data.position.mode ?? __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Modes$2f$PixelMode$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["PixelMode"].percent
            };
        }
        if (data.options) {
            this.options = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["deepExtend"])({}, data.options);
        }
    }
}
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Enums/Modes/ResponsiveMode.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ResponsiveMode",
    ()=>ResponsiveMode
]);
var ResponsiveMode;
(function(ResponsiveMode) {
    ResponsiveMode["screen"] = "screen";
    ResponsiveMode["canvas"] = "canvas";
})(ResponsiveMode || (ResponsiveMode = {}));
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Classes/Responsive.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Responsive",
    ()=>Responsive
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Modes$2f$ResponsiveMode$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Enums/Modes/ResponsiveMode.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/Utils.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/TypeUtils.js [app-ssr] (ecmascript)");
;
;
;
class Responsive {
    constructor(){
        this.maxWidth = Infinity;
        this.options = {};
        this.mode = __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Modes$2f$ResponsiveMode$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ResponsiveMode"].canvas;
    }
    load(data) {
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isNull"])(data)) {
            return;
        }
        if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isNull"])(data.maxWidth)) {
            this.maxWidth = data.maxWidth;
        }
        if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isNull"])(data.mode)) {
            if (data.mode === __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Modes$2f$ResponsiveMode$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ResponsiveMode"].screen) {
                this.mode = __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Modes$2f$ResponsiveMode$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ResponsiveMode"].screen;
            } else {
                this.mode = __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Modes$2f$ResponsiveMode$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ResponsiveMode"].canvas;
            }
        }
        if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isNull"])(data.options)) {
            this.options = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["deepExtend"])({}, data.options);
        }
    }
}
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Enums/Modes/ThemeMode.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ThemeMode",
    ()=>ThemeMode
]);
var ThemeMode;
(function(ThemeMode) {
    ThemeMode["any"] = "any";
    ThemeMode["dark"] = "dark";
    ThemeMode["light"] = "light";
})(ThemeMode || (ThemeMode = {}));
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Classes/Theme/ThemeDefault.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ThemeDefault",
    ()=>ThemeDefault
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Modes$2f$ThemeMode$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Enums/Modes/ThemeMode.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/TypeUtils.js [app-ssr] (ecmascript)");
;
;
class ThemeDefault {
    constructor(){
        this.auto = false;
        this.mode = __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Modes$2f$ThemeMode$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ThemeMode"].any;
        this.value = false;
    }
    load(data) {
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isNull"])(data)) {
            return;
        }
        if (data.auto !== undefined) {
            this.auto = data.auto;
        }
        if (data.mode !== undefined) {
            this.mode = data.mode;
        }
        if (data.value !== undefined) {
            this.value = data.value;
        }
    }
}
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Classes/Theme/Theme.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Theme",
    ()=>Theme
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$Theme$2f$ThemeDefault$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Classes/Theme/ThemeDefault.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/Utils.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/TypeUtils.js [app-ssr] (ecmascript)");
;
;
;
class Theme {
    constructor(){
        this.name = "";
        this.default = new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$Theme$2f$ThemeDefault$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ThemeDefault"]();
    }
    load(data) {
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isNull"])(data)) {
            return;
        }
        if (data.name !== undefined) {
            this.name = data.name;
        }
        this.default.load(data.default);
        if (data.options !== undefined) {
            this.options = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["deepExtend"])({}, data.options);
        }
    }
}
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Classes/AnimationOptions.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "AnimationOptions",
    ()=>AnimationOptions,
    "RangedAnimationOptions",
    ()=>RangedAnimationOptions
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Modes$2f$AnimationMode$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Enums/Modes/AnimationMode.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Types$2f$StartValueType$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Enums/Types/StartValueType.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/TypeUtils.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/NumberUtils.js [app-ssr] (ecmascript)");
;
;
;
;
class AnimationOptions {
    constructor(){
        this.count = 0;
        this.enable = false;
        this.speed = 1;
        this.decay = 0;
        this.delay = 0;
        this.sync = false;
    }
    load(data) {
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isNull"])(data)) {
            return;
        }
        if (data.count !== undefined) {
            this.count = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["setRangeValue"])(data.count);
        }
        if (data.enable !== undefined) {
            this.enable = data.enable;
        }
        if (data.speed !== undefined) {
            this.speed = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["setRangeValue"])(data.speed);
        }
        if (data.decay !== undefined) {
            this.decay = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["setRangeValue"])(data.decay);
        }
        if (data.delay !== undefined) {
            this.delay = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["setRangeValue"])(data.delay);
        }
        if (data.sync !== undefined) {
            this.sync = data.sync;
        }
    }
}
class RangedAnimationOptions extends AnimationOptions {
    constructor(){
        super();
        this.mode = __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Modes$2f$AnimationMode$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["AnimationMode"].auto;
        this.startValue = __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Types$2f$StartValueType$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["StartValueType"].random;
    }
    load(data) {
        super.load(data);
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isNull"])(data)) {
            return;
        }
        if (data.mode !== undefined) {
            this.mode = data.mode;
        }
        if (data.startValue !== undefined) {
            this.startValue = data.startValue;
        }
    }
}
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Classes/ColorAnimation.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ColorAnimation",
    ()=>ColorAnimation
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$AnimationOptions$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Classes/AnimationOptions.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/TypeUtils.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/NumberUtils.js [app-ssr] (ecmascript)");
;
;
;
class ColorAnimation extends __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$AnimationOptions$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["AnimationOptions"] {
    constructor(){
        super();
        this.offset = 0;
        this.sync = true;
    }
    load(data) {
        super.load(data);
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isNull"])(data)) {
            return;
        }
        if (data.offset !== undefined) {
            this.offset = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["setRangeValue"])(data.offset);
        }
    }
}
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Classes/HslAnimation.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "HslAnimation",
    ()=>HslAnimation
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$ColorAnimation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Classes/ColorAnimation.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/TypeUtils.js [app-ssr] (ecmascript)");
;
;
class HslAnimation {
    constructor(){
        this.h = new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$ColorAnimation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ColorAnimation"]();
        this.s = new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$ColorAnimation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ColorAnimation"]();
        this.l = new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$ColorAnimation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ColorAnimation"]();
    }
    load(data) {
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isNull"])(data)) {
            return;
        }
        this.h.load(data.h);
        this.s.load(data.s);
        this.l.load(data.l);
    }
}
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Classes/AnimatableColor.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "AnimatableColor",
    ()=>AnimatableColor
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/TypeUtils.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$HslAnimation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Classes/HslAnimation.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$OptionsColor$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Classes/OptionsColor.js [app-ssr] (ecmascript)");
;
;
;
class AnimatableColor extends __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$OptionsColor$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["OptionsColor"] {
    constructor(){
        super();
        this.animation = new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$HslAnimation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["HslAnimation"]();
    }
    static create(source, data) {
        const color = new AnimatableColor();
        color.load(source);
        if (data !== undefined) {
            if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isString"])(data) || (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isArray"])(data)) {
                color.load({
                    value: data
                });
            } else {
                color.load(data);
            }
        }
        return color;
    }
    load(data) {
        super.load(data);
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isNull"])(data)) {
            return;
        }
        const colorAnimation = data.animation;
        if (colorAnimation !== undefined) {
            if (colorAnimation.enable !== undefined) {
                this.animation.h.load(colorAnimation);
            } else {
                this.animation.load(data.animation);
            }
        }
    }
}
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Enums/Modes/CollisionMode.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "CollisionMode",
    ()=>CollisionMode
]);
var CollisionMode;
(function(CollisionMode) {
    CollisionMode["absorb"] = "absorb";
    CollisionMode["bounce"] = "bounce";
    CollisionMode["destroy"] = "destroy";
})(CollisionMode || (CollisionMode = {}));
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Classes/Particles/Collisions/CollisionsAbsorb.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "CollisionsAbsorb",
    ()=>CollisionsAbsorb
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/TypeUtils.js [app-ssr] (ecmascript)");
;
class CollisionsAbsorb {
    constructor(){
        this.speed = 2;
    }
    load(data) {
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isNull"])(data)) {
            return;
        }
        if (data.speed !== undefined) {
            this.speed = data.speed;
        }
    }
}
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Classes/Particles/Collisions/CollisionsOverlap.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "CollisionsOverlap",
    ()=>CollisionsOverlap
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/TypeUtils.js [app-ssr] (ecmascript)");
;
class CollisionsOverlap {
    constructor(){
        this.enable = true;
        this.retries = 0;
    }
    load(data) {
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isNull"])(data)) {
            return;
        }
        if (data.enable !== undefined) {
            this.enable = data.enable;
        }
        if (data.retries !== undefined) {
            this.retries = data.retries;
        }
    }
}
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Classes/ValueWithRandom.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "AnimationValueWithRandom",
    ()=>AnimationValueWithRandom,
    "RangedAnimationValueWithRandom",
    ()=>RangedAnimationValueWithRandom,
    "ValueWithRandom",
    ()=>ValueWithRandom
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$AnimationOptions$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Classes/AnimationOptions.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/TypeUtils.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/NumberUtils.js [app-ssr] (ecmascript)");
;
;
;
class ValueWithRandom {
    constructor(){
        this.value = 0;
    }
    load(data) {
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isNull"])(data)) {
            return;
        }
        if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isNull"])(data.value)) {
            this.value = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["setRangeValue"])(data.value);
        }
    }
}
class AnimationValueWithRandom extends ValueWithRandom {
    constructor(){
        super();
        this.animation = new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$AnimationOptions$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["AnimationOptions"]();
    }
    load(data) {
        super.load(data);
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isNull"])(data)) {
            return;
        }
        const animation = data.animation;
        if (animation !== undefined) {
            this.animation.load(animation);
        }
    }
}
class RangedAnimationValueWithRandom extends AnimationValueWithRandom {
    constructor(){
        super();
        this.animation = new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$AnimationOptions$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["RangedAnimationOptions"]();
    }
    load(data) {
        super.load(data);
    }
}
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Classes/Particles/Bounce/ParticlesBounceFactor.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ParticlesBounceFactor",
    ()=>ParticlesBounceFactor
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$ValueWithRandom$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Classes/ValueWithRandom.js [app-ssr] (ecmascript)");
;
class ParticlesBounceFactor extends __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$ValueWithRandom$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ValueWithRandom"] {
    constructor(){
        super();
        this.value = 1;
    }
}
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Classes/Particles/Bounce/ParticlesBounce.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ParticlesBounce",
    ()=>ParticlesBounce
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$Particles$2f$Bounce$2f$ParticlesBounceFactor$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Classes/Particles/Bounce/ParticlesBounceFactor.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/TypeUtils.js [app-ssr] (ecmascript)");
;
;
class ParticlesBounce {
    constructor(){
        this.horizontal = new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$Particles$2f$Bounce$2f$ParticlesBounceFactor$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ParticlesBounceFactor"]();
        this.vertical = new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$Particles$2f$Bounce$2f$ParticlesBounceFactor$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ParticlesBounceFactor"]();
    }
    load(data) {
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isNull"])(data)) {
            return;
        }
        this.horizontal.load(data.horizontal);
        this.vertical.load(data.vertical);
    }
}
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Classes/Particles/Collisions/Collisions.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Collisions",
    ()=>Collisions
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Modes$2f$CollisionMode$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Enums/Modes/CollisionMode.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$Particles$2f$Collisions$2f$CollisionsAbsorb$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Classes/Particles/Collisions/CollisionsAbsorb.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$Particles$2f$Collisions$2f$CollisionsOverlap$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Classes/Particles/Collisions/CollisionsOverlap.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$Particles$2f$Bounce$2f$ParticlesBounce$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Classes/Particles/Bounce/ParticlesBounce.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/TypeUtils.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/NumberUtils.js [app-ssr] (ecmascript)");
;
;
;
;
;
;
class Collisions {
    constructor(){
        this.absorb = new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$Particles$2f$Collisions$2f$CollisionsAbsorb$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["CollisionsAbsorb"]();
        this.bounce = new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$Particles$2f$Bounce$2f$ParticlesBounce$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ParticlesBounce"]();
        this.enable = false;
        this.maxSpeed = 50;
        this.mode = __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Modes$2f$CollisionMode$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["CollisionMode"].bounce;
        this.overlap = new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$Particles$2f$Collisions$2f$CollisionsOverlap$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["CollisionsOverlap"]();
    }
    load(data) {
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isNull"])(data)) {
            return;
        }
        this.absorb.load(data.absorb);
        this.bounce.load(data.bounce);
        if (data.enable !== undefined) {
            this.enable = data.enable;
        }
        if (data.maxSpeed !== undefined) {
            this.maxSpeed = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["setRangeValue"])(data.maxSpeed);
        }
        if (data.mode !== undefined) {
            this.mode = data.mode;
        }
        this.overlap.load(data.overlap);
    }
}
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Classes/Particles/Effect/Effect.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Effect",
    ()=>Effect
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/Utils.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/TypeUtils.js [app-ssr] (ecmascript)");
;
;
class Effect {
    constructor(){
        this.close = true;
        this.fill = true;
        this.options = {};
        this.type = [];
    }
    load(data) {
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isNull"])(data)) {
            return;
        }
        const options = data.options;
        if (options !== undefined) {
            for(const effect in options){
                const item = options[effect];
                if (item) {
                    this.options[effect] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["deepExtend"])(this.options[effect] ?? {}, item);
                }
            }
        }
        if (data.close !== undefined) {
            this.close = data.close;
        }
        if (data.fill !== undefined) {
            this.fill = data.fill;
        }
        if (data.type !== undefined) {
            this.type = data.type;
        }
    }
}
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Classes/Particles/Move/MoveAngle.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "MoveAngle",
    ()=>MoveAngle
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/TypeUtils.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/NumberUtils.js [app-ssr] (ecmascript)");
;
;
class MoveAngle {
    constructor(){
        this.offset = 0;
        this.value = 90;
    }
    load(data) {
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isNull"])(data)) {
            return;
        }
        if (data.offset !== undefined) {
            this.offset = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["setRangeValue"])(data.offset);
        }
        if (data.value !== undefined) {
            this.value = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["setRangeValue"])(data.value);
        }
    }
}
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Classes/Particles/Move/MoveAttract.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "MoveAttract",
    ()=>MoveAttract
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/TypeUtils.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/NumberUtils.js [app-ssr] (ecmascript)");
;
;
class MoveAttract {
    constructor(){
        this.distance = 200;
        this.enable = false;
        this.rotate = {
            x: 3000,
            y: 3000
        };
    }
    load(data) {
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isNull"])(data)) {
            return;
        }
        if (data.distance !== undefined) {
            this.distance = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["setRangeValue"])(data.distance);
        }
        if (data.enable !== undefined) {
            this.enable = data.enable;
        }
        if (data.rotate) {
            const rotateX = data.rotate.x;
            if (rotateX !== undefined) {
                this.rotate.x = rotateX;
            }
            const rotateY = data.rotate.y;
            if (rotateY !== undefined) {
                this.rotate.y = rotateY;
            }
        }
    }
}
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Classes/Particles/Move/MoveCenter.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "MoveCenter",
    ()=>MoveCenter
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Modes$2f$PixelMode$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Enums/Modes/PixelMode.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/TypeUtils.js [app-ssr] (ecmascript)");
;
;
class MoveCenter {
    constructor(){
        this.x = 50;
        this.y = 50;
        this.mode = __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Modes$2f$PixelMode$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["PixelMode"].percent;
        this.radius = 0;
    }
    load(data) {
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isNull"])(data)) {
            return;
        }
        if (data.x !== undefined) {
            this.x = data.x;
        }
        if (data.y !== undefined) {
            this.y = data.y;
        }
        if (data.mode !== undefined) {
            this.mode = data.mode;
        }
        if (data.radius !== undefined) {
            this.radius = data.radius;
        }
    }
}
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Classes/Particles/Move/MoveGravity.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "MoveGravity",
    ()=>MoveGravity
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/TypeUtils.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/NumberUtils.js [app-ssr] (ecmascript)");
;
;
class MoveGravity {
    constructor(){
        this.acceleration = 9.81;
        this.enable = false;
        this.inverse = false;
        this.maxSpeed = 50;
    }
    load(data) {
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isNull"])(data)) {
            return;
        }
        if (data.acceleration !== undefined) {
            this.acceleration = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["setRangeValue"])(data.acceleration);
        }
        if (data.enable !== undefined) {
            this.enable = data.enable;
        }
        if (data.inverse !== undefined) {
            this.inverse = data.inverse;
        }
        if (data.maxSpeed !== undefined) {
            this.maxSpeed = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["setRangeValue"])(data.maxSpeed);
        }
    }
}
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Classes/Particles/Move/Path/MovePath.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "MovePath",
    ()=>MovePath
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$ValueWithRandom$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Classes/ValueWithRandom.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/Utils.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/TypeUtils.js [app-ssr] (ecmascript)");
;
;
;
class MovePath {
    constructor(){
        this.clamp = true;
        this.delay = new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$ValueWithRandom$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ValueWithRandom"]();
        this.enable = false;
        this.options = {};
    }
    load(data) {
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isNull"])(data)) {
            return;
        }
        if (data.clamp !== undefined) {
            this.clamp = data.clamp;
        }
        this.delay.load(data.delay);
        if (data.enable !== undefined) {
            this.enable = data.enable;
        }
        this.generator = data.generator;
        if (data.options) {
            this.options = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["deepExtend"])(this.options, data.options);
        }
    }
}
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Classes/Particles/Move/MoveTrailFill.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "MoveTrailFill",
    ()=>MoveTrailFill
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$OptionsColor$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Classes/OptionsColor.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/TypeUtils.js [app-ssr] (ecmascript)");
;
;
class MoveTrailFill {
    load(data) {
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isNull"])(data)) {
            return;
        }
        if (data.color !== undefined) {
            this.color = __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$OptionsColor$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["OptionsColor"].create(this.color, data.color);
        }
        if (data.image !== undefined) {
            this.image = data.image;
        }
    }
}
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Classes/Particles/Move/MoveTrail.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "MoveTrail",
    ()=>MoveTrail
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$Particles$2f$Move$2f$MoveTrailFill$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Classes/Particles/Move/MoveTrailFill.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/TypeUtils.js [app-ssr] (ecmascript)");
;
;
class MoveTrail {
    constructor(){
        this.enable = false;
        this.length = 10;
        this.fill = new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$Particles$2f$Move$2f$MoveTrailFill$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["MoveTrailFill"]();
    }
    load(data) {
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isNull"])(data)) {
            return;
        }
        if (data.enable !== undefined) {
            this.enable = data.enable;
        }
        if (data.fill !== undefined) {
            this.fill.load(data.fill);
        }
        if (data.length !== undefined) {
            this.length = data.length;
        }
    }
}
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Enums/Modes/OutMode.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "OutMode",
    ()=>OutMode
]);
var OutMode;
(function(OutMode) {
    OutMode["bounce"] = "bounce";
    OutMode["none"] = "none";
    OutMode["out"] = "out";
    OutMode["destroy"] = "destroy";
    OutMode["split"] = "split";
})(OutMode || (OutMode = {}));
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Classes/Particles/Move/OutModes.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "OutModes",
    ()=>OutModes
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Modes$2f$OutMode$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Enums/Modes/OutMode.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/TypeUtils.js [app-ssr] (ecmascript)");
;
;
class OutModes {
    constructor(){
        this.default = __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Modes$2f$OutMode$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["OutMode"].out;
    }
    load(data) {
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isNull"])(data)) {
            return;
        }
        if (data.default !== undefined) {
            this.default = data.default;
        }
        this.bottom = data.bottom ?? data.default;
        this.left = data.left ?? data.default;
        this.right = data.right ?? data.default;
        this.top = data.top ?? data.default;
    }
}
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Classes/Particles/Move/Spin.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Spin",
    ()=>Spin
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/Utils.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/TypeUtils.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/NumberUtils.js [app-ssr] (ecmascript)");
;
;
;
class Spin {
    constructor(){
        this.acceleration = 0;
        this.enable = false;
    }
    load(data) {
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isNull"])(data)) {
            return;
        }
        if (data.acceleration !== undefined) {
            this.acceleration = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["setRangeValue"])(data.acceleration);
        }
        if (data.enable !== undefined) {
            this.enable = data.enable;
        }
        if (data.position) {
            this.position = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["deepExtend"])({}, data.position);
        }
    }
}
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Classes/Particles/Move/Move.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Move",
    ()=>Move
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Directions$2f$MoveDirection$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Enums/Directions/MoveDirection.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/TypeUtils.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$Particles$2f$Move$2f$MoveAngle$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Classes/Particles/Move/MoveAngle.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$Particles$2f$Move$2f$MoveAttract$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Classes/Particles/Move/MoveAttract.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$Particles$2f$Move$2f$MoveCenter$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Classes/Particles/Move/MoveCenter.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$Particles$2f$Move$2f$MoveGravity$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Classes/Particles/Move/MoveGravity.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$Particles$2f$Move$2f$Path$2f$MovePath$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Classes/Particles/Move/Path/MovePath.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$Particles$2f$Move$2f$MoveTrail$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Classes/Particles/Move/MoveTrail.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$Particles$2f$Move$2f$OutModes$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Classes/Particles/Move/OutModes.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$Particles$2f$Move$2f$Spin$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Classes/Particles/Move/Spin.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/NumberUtils.js [app-ssr] (ecmascript)");
;
;
;
;
;
;
;
;
;
;
;
class Move {
    constructor(){
        this.angle = new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$Particles$2f$Move$2f$MoveAngle$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["MoveAngle"]();
        this.attract = new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$Particles$2f$Move$2f$MoveAttract$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["MoveAttract"]();
        this.center = new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$Particles$2f$Move$2f$MoveCenter$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["MoveCenter"]();
        this.decay = 0;
        this.distance = {};
        this.direction = __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Directions$2f$MoveDirection$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["MoveDirection"].none;
        this.drift = 0;
        this.enable = false;
        this.gravity = new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$Particles$2f$Move$2f$MoveGravity$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["MoveGravity"]();
        this.path = new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$Particles$2f$Move$2f$Path$2f$MovePath$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["MovePath"]();
        this.outModes = new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$Particles$2f$Move$2f$OutModes$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["OutModes"]();
        this.random = false;
        this.size = false;
        this.speed = 2;
        this.spin = new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$Particles$2f$Move$2f$Spin$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Spin"]();
        this.straight = false;
        this.trail = new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$Particles$2f$Move$2f$MoveTrail$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["MoveTrail"]();
        this.vibrate = false;
        this.warp = false;
    }
    load(data) {
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isNull"])(data)) {
            return;
        }
        this.angle.load((0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isNumber"])(data.angle) ? {
            value: data.angle
        } : data.angle);
        this.attract.load(data.attract);
        this.center.load(data.center);
        if (data.decay !== undefined) {
            this.decay = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["setRangeValue"])(data.decay);
        }
        if (data.direction !== undefined) {
            this.direction = data.direction;
        }
        if (data.distance !== undefined) {
            this.distance = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isNumber"])(data.distance) ? {
                horizontal: data.distance,
                vertical: data.distance
            } : {
                ...data.distance
            };
        }
        if (data.drift !== undefined) {
            this.drift = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["setRangeValue"])(data.drift);
        }
        if (data.enable !== undefined) {
            this.enable = data.enable;
        }
        this.gravity.load(data.gravity);
        const outModes = data.outModes;
        if (outModes !== undefined) {
            if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isObject"])(outModes)) {
                this.outModes.load(outModes);
            } else {
                this.outModes.load({
                    default: outModes
                });
            }
        }
        this.path.load(data.path);
        if (data.random !== undefined) {
            this.random = data.random;
        }
        if (data.size !== undefined) {
            this.size = data.size;
        }
        if (data.speed !== undefined) {
            this.speed = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["setRangeValue"])(data.speed);
        }
        this.spin.load(data.spin);
        if (data.straight !== undefined) {
            this.straight = data.straight;
        }
        this.trail.load(data.trail);
        if (data.vibrate !== undefined) {
            this.vibrate = data.vibrate;
        }
        if (data.warp !== undefined) {
            this.warp = data.warp;
        }
    }
}
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Classes/Particles/Opacity/OpacityAnimation.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "OpacityAnimation",
    ()=>OpacityAnimation
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Types$2f$DestroyType$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Enums/Types/DestroyType.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$AnimationOptions$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Classes/AnimationOptions.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/TypeUtils.js [app-ssr] (ecmascript)");
;
;
;
class OpacityAnimation extends __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$AnimationOptions$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["RangedAnimationOptions"] {
    constructor(){
        super();
        this.destroy = __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Types$2f$DestroyType$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["DestroyType"].none;
        this.speed = 2;
    }
    load(data) {
        super.load(data);
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isNull"])(data)) {
            return;
        }
        if (data.destroy !== undefined) {
            this.destroy = data.destroy;
        }
    }
}
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Classes/Particles/Opacity/Opacity.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Opacity",
    ()=>Opacity
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$Particles$2f$Opacity$2f$OpacityAnimation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Classes/Particles/Opacity/OpacityAnimation.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$ValueWithRandom$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Classes/ValueWithRandom.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/TypeUtils.js [app-ssr] (ecmascript)");
;
;
;
class Opacity extends __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$ValueWithRandom$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["RangedAnimationValueWithRandom"] {
    constructor(){
        super();
        this.animation = new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$Particles$2f$Opacity$2f$OpacityAnimation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["OpacityAnimation"]();
        this.value = 1;
    }
    load(data) {
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isNull"])(data)) {
            return;
        }
        super.load(data);
        const animation = data.animation;
        if (animation !== undefined) {
            this.animation.load(animation);
        }
    }
}
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Classes/Particles/Number/ParticlesDensity.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ParticlesDensity",
    ()=>ParticlesDensity
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/TypeUtils.js [app-ssr] (ecmascript)");
;
class ParticlesDensity {
    constructor(){
        this.enable = false;
        this.width = 1920;
        this.height = 1080;
    }
    load(data) {
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isNull"])(data)) {
            return;
        }
        if (data.enable !== undefined) {
            this.enable = data.enable;
        }
        const width = data.width;
        if (width !== undefined) {
            this.width = width;
        }
        const height = data.height;
        if (height !== undefined) {
            this.height = height;
        }
    }
}
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Enums/Modes/LimitMode.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "LimitMode",
    ()=>LimitMode
]);
var LimitMode;
(function(LimitMode) {
    LimitMode["delete"] = "delete";
    LimitMode["wait"] = "wait";
})(LimitMode || (LimitMode = {}));
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Classes/Particles/Number/ParticlesNumberLimit.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ParticlesNumberLimit",
    ()=>ParticlesNumberLimit
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Modes$2f$LimitMode$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Enums/Modes/LimitMode.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/TypeUtils.js [app-ssr] (ecmascript)");
;
;
class ParticlesNumberLimit {
    constructor(){
        this.mode = __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Modes$2f$LimitMode$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["LimitMode"].delete;
        this.value = 0;
    }
    load(data) {
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isNull"])(data)) {
            return;
        }
        if (data.mode !== undefined) {
            this.mode = data.mode;
        }
        if (data.value !== undefined) {
            this.value = data.value;
        }
    }
}
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Classes/Particles/Number/ParticlesNumber.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ParticlesNumber",
    ()=>ParticlesNumber
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$Particles$2f$Number$2f$ParticlesDensity$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Classes/Particles/Number/ParticlesDensity.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$Particles$2f$Number$2f$ParticlesNumberLimit$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Classes/Particles/Number/ParticlesNumberLimit.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/TypeUtils.js [app-ssr] (ecmascript)");
;
;
;
class ParticlesNumber {
    constructor(){
        this.density = new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$Particles$2f$Number$2f$ParticlesDensity$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ParticlesDensity"]();
        this.limit = new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$Particles$2f$Number$2f$ParticlesNumberLimit$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ParticlesNumberLimit"]();
        this.value = 0;
    }
    load(data) {
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isNull"])(data)) {
            return;
        }
        this.density.load(data.density);
        this.limit.load(data.limit);
        if (data.value !== undefined) {
            this.value = data.value;
        }
    }
}
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Classes/Particles/Shadow.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Shadow",
    ()=>Shadow
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$OptionsColor$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Classes/OptionsColor.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/TypeUtils.js [app-ssr] (ecmascript)");
;
;
class Shadow {
    constructor(){
        this.blur = 0;
        this.color = new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$OptionsColor$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["OptionsColor"]();
        this.enable = false;
        this.offset = {
            x: 0,
            y: 0
        };
        this.color.value = "#000";
    }
    load(data) {
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isNull"])(data)) {
            return;
        }
        if (data.blur !== undefined) {
            this.blur = data.blur;
        }
        this.color = __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$OptionsColor$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["OptionsColor"].create(this.color, data.color);
        if (data.enable !== undefined) {
            this.enable = data.enable;
        }
        if (data.offset === undefined) {
            return;
        }
        if (data.offset.x !== undefined) {
            this.offset.x = data.offset.x;
        }
        if (data.offset.y !== undefined) {
            this.offset.y = data.offset.y;
        }
    }
}
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Classes/Particles/Shape/Shape.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Shape",
    ()=>Shape
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/Utils.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/TypeUtils.js [app-ssr] (ecmascript)");
;
;
class Shape {
    constructor(){
        this.close = true;
        this.fill = true;
        this.options = {};
        this.type = "circle";
    }
    load(data) {
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isNull"])(data)) {
            return;
        }
        const options = data.options;
        if (options !== undefined) {
            for(const shape in options){
                const item = options[shape];
                if (item) {
                    this.options[shape] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["deepExtend"])(this.options[shape] ?? {}, item);
                }
            }
        }
        if (data.close !== undefined) {
            this.close = data.close;
        }
        if (data.fill !== undefined) {
            this.fill = data.fill;
        }
        if (data.type !== undefined) {
            this.type = data.type;
        }
    }
}
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Classes/Particles/Size/SizeAnimation.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "SizeAnimation",
    ()=>SizeAnimation
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Types$2f$DestroyType$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Enums/Types/DestroyType.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$AnimationOptions$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Classes/AnimationOptions.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/TypeUtils.js [app-ssr] (ecmascript)");
;
;
;
class SizeAnimation extends __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$AnimationOptions$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["RangedAnimationOptions"] {
    constructor(){
        super();
        this.destroy = __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Types$2f$DestroyType$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["DestroyType"].none;
        this.speed = 5;
    }
    load(data) {
        super.load(data);
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isNull"])(data)) {
            return;
        }
        if (data.destroy !== undefined) {
            this.destroy = data.destroy;
        }
    }
}
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Classes/Particles/Size/Size.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Size",
    ()=>Size
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$ValueWithRandom$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Classes/ValueWithRandom.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$Particles$2f$Size$2f$SizeAnimation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Classes/Particles/Size/SizeAnimation.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/TypeUtils.js [app-ssr] (ecmascript)");
;
;
;
class Size extends __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$ValueWithRandom$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["RangedAnimationValueWithRandom"] {
    constructor(){
        super();
        this.animation = new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$Particles$2f$Size$2f$SizeAnimation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["SizeAnimation"]();
        this.value = 3;
    }
    load(data) {
        super.load(data);
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isNull"])(data)) {
            return;
        }
        const animation = data.animation;
        if (animation !== undefined) {
            this.animation.load(animation);
        }
    }
}
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Classes/Particles/Stroke.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Stroke",
    ()=>Stroke
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$AnimatableColor$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Classes/AnimatableColor.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/TypeUtils.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/NumberUtils.js [app-ssr] (ecmascript)");
;
;
;
class Stroke {
    constructor(){
        this.width = 0;
    }
    load(data) {
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isNull"])(data)) {
            return;
        }
        if (data.color !== undefined) {
            this.color = __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$AnimatableColor$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["AnimatableColor"].create(this.color, data.color);
        }
        if (data.width !== undefined) {
            this.width = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["setRangeValue"])(data.width);
        }
        if (data.opacity !== undefined) {
            this.opacity = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["setRangeValue"])(data.opacity);
        }
    }
}
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Classes/Particles/ZIndex/ZIndex.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ZIndex",
    ()=>ZIndex
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$ValueWithRandom$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Classes/ValueWithRandom.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/TypeUtils.js [app-ssr] (ecmascript)");
;
;
class ZIndex extends __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$ValueWithRandom$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ValueWithRandom"] {
    constructor(){
        super();
        this.opacityRate = 1;
        this.sizeRate = 1;
        this.velocityRate = 1;
    }
    load(data) {
        super.load(data);
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isNull"])(data)) {
            return;
        }
        if (data.opacityRate !== undefined) {
            this.opacityRate = data.opacityRate;
        }
        if (data.sizeRate !== undefined) {
            this.sizeRate = data.sizeRate;
        }
        if (data.velocityRate !== undefined) {
            this.velocityRate = data.velocityRate;
        }
    }
}
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Classes/Particles/ParticlesOptions.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ParticlesOptions",
    ()=>ParticlesOptions
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/Utils.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$AnimatableColor$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Classes/AnimatableColor.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$Particles$2f$Collisions$2f$Collisions$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Classes/Particles/Collisions/Collisions.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$Particles$2f$Effect$2f$Effect$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Classes/Particles/Effect/Effect.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$Particles$2f$Move$2f$Move$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Classes/Particles/Move/Move.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$Particles$2f$Opacity$2f$Opacity$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Classes/Particles/Opacity/Opacity.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$Particles$2f$Bounce$2f$ParticlesBounce$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Classes/Particles/Bounce/ParticlesBounce.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$Particles$2f$Number$2f$ParticlesNumber$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Classes/Particles/Number/ParticlesNumber.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$Particles$2f$Shadow$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Classes/Particles/Shadow.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$Particles$2f$Shape$2f$Shape$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Classes/Particles/Shape/Shape.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$Particles$2f$Size$2f$Size$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Classes/Particles/Size/Size.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$Particles$2f$Stroke$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Classes/Particles/Stroke.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$Particles$2f$ZIndex$2f$ZIndex$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Classes/Particles/ZIndex/ZIndex.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/TypeUtils.js [app-ssr] (ecmascript)");
;
;
;
;
;
;
;
;
;
;
;
;
;
;
class ParticlesOptions {
    constructor(engine, container){
        this._engine = engine;
        this._container = container;
        this.bounce = new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$Particles$2f$Bounce$2f$ParticlesBounce$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ParticlesBounce"]();
        this.collisions = new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$Particles$2f$Collisions$2f$Collisions$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Collisions"]();
        this.color = new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$AnimatableColor$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["AnimatableColor"]();
        this.color.value = "#fff";
        this.effect = new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$Particles$2f$Effect$2f$Effect$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Effect"]();
        this.groups = {};
        this.move = new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$Particles$2f$Move$2f$Move$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Move"]();
        this.number = new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$Particles$2f$Number$2f$ParticlesNumber$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ParticlesNumber"]();
        this.opacity = new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$Particles$2f$Opacity$2f$Opacity$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Opacity"]();
        this.reduceDuplicates = false;
        this.shadow = new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$Particles$2f$Shadow$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Shadow"]();
        this.shape = new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$Particles$2f$Shape$2f$Shape$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Shape"]();
        this.size = new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$Particles$2f$Size$2f$Size$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Size"]();
        this.stroke = new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$Particles$2f$Stroke$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Stroke"]();
        this.zIndex = new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$Particles$2f$ZIndex$2f$ZIndex$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ZIndex"]();
    }
    load(data) {
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isNull"])(data)) {
            return;
        }
        if (data.groups !== undefined) {
            for (const group of Object.keys(data.groups)){
                if (!Object.hasOwn(data.groups, group)) {
                    continue;
                }
                const item = data.groups[group];
                if (item !== undefined) {
                    this.groups[group] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["deepExtend"])(this.groups[group] ?? {}, item);
                }
            }
        }
        if (data.reduceDuplicates !== undefined) {
            this.reduceDuplicates = data.reduceDuplicates;
        }
        this.bounce.load(data.bounce);
        this.color.load(__TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$AnimatableColor$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["AnimatableColor"].create(this.color, data.color));
        this.effect.load(data.effect);
        this.move.load(data.move);
        this.number.load(data.number);
        this.opacity.load(data.opacity);
        this.shape.load(data.shape);
        this.size.load(data.size);
        this.shadow.load(data.shadow);
        this.zIndex.load(data.zIndex);
        this.collisions.load(data.collisions);
        if (data.interactivity !== undefined) {
            this.interactivity = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["deepExtend"])({}, data.interactivity);
        }
        const strokeToLoad = data.stroke;
        if (strokeToLoad) {
            this.stroke = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["executeOnSingleOrMultiple"])(strokeToLoad, (t)=>{
                const tmp = new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$Particles$2f$Stroke$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Stroke"]();
                tmp.load(t);
                return tmp;
            });
        }
        if (this._container) {
            const updaters = this._engine.updaters.get(this._container);
            if (updaters) {
                for (const updater of updaters){
                    if (updater.loadOptions) {
                        updater.loadOptions(this, data);
                    }
                }
            }
            const interactors = this._engine.interactors.get(this._container);
            if (interactors) {
                for (const interactor of interactors){
                    if (interactor.loadParticlesOptions) {
                        interactor.loadParticlesOptions(this, data);
                    }
                }
            }
        }
    }
}
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/OptionsUtils.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "loadOptions",
    ()=>loadOptions,
    "loadParticlesOptions",
    ()=>loadParticlesOptions
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$Particles$2f$ParticlesOptions$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Classes/Particles/ParticlesOptions.js [app-ssr] (ecmascript)");
;
function loadOptions(options, ...sourceOptionsArr) {
    for (const sourceOptions of sourceOptionsArr){
        options.load(sourceOptions);
    }
}
function loadParticlesOptions(engine, container, ...sourceOptionsArr) {
    const options = new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$Particles$2f$ParticlesOptions$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ParticlesOptions"](engine, container);
    loadOptions(options, ...sourceOptionsArr);
    return options;
}
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Classes/Options.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Options",
    ()=>Options
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/Utils.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/TypeUtils.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$Background$2f$Background$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Classes/Background/Background.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$BackgroundMask$2f$BackgroundMask$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Classes/BackgroundMask/BackgroundMask.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$FullScreen$2f$FullScreen$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Classes/FullScreen/FullScreen.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$Interactivity$2f$Interactivity$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Classes/Interactivity/Interactivity.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$ManualParticle$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Classes/ManualParticle.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$Responsive$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Classes/Responsive.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Modes$2f$ResponsiveMode$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Enums/Modes/ResponsiveMode.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$Theme$2f$Theme$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Classes/Theme/Theme.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Modes$2f$ThemeMode$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Enums/Modes/ThemeMode.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$OptionsUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/OptionsUtils.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/NumberUtils.js [app-ssr] (ecmascript)");
;
;
;
;
;
;
;
;
;
;
;
;
;
class Options {
    constructor(engine, container){
        this._findDefaultTheme = (mode)=>{
            return this.themes.find((theme)=>theme.default.value && theme.default.mode === mode) ?? this.themes.find((theme)=>theme.default.value && theme.default.mode === __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Modes$2f$ThemeMode$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ThemeMode"].any);
        };
        this._importPreset = (preset)=>{
            this.load(this._engine.getPreset(preset));
        };
        this._engine = engine;
        this._container = container;
        this.autoPlay = true;
        this.background = new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$Background$2f$Background$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Background"]();
        this.backgroundMask = new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$BackgroundMask$2f$BackgroundMask$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["BackgroundMask"]();
        this.clear = true;
        this.defaultThemes = {};
        this.delay = 0;
        this.fullScreen = new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$FullScreen$2f$FullScreen$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["FullScreen"]();
        this.detectRetina = true;
        this.duration = 0;
        this.fpsLimit = 120;
        this.interactivity = new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$Interactivity$2f$Interactivity$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Interactivity"](engine, container);
        this.manualParticles = [];
        this.particles = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$OptionsUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["loadParticlesOptions"])(this._engine, this._container);
        this.pauseOnBlur = true;
        this.pauseOnOutsideViewport = true;
        this.responsive = [];
        this.smooth = false;
        this.style = {};
        this.themes = [];
        this.zLayers = 100;
    }
    load(data) {
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isNull"])(data)) {
            return;
        }
        if (data.preset !== undefined) {
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["executeOnSingleOrMultiple"])(data.preset, (preset)=>this._importPreset(preset));
        }
        if (data.autoPlay !== undefined) {
            this.autoPlay = data.autoPlay;
        }
        if (data.clear !== undefined) {
            this.clear = data.clear;
        }
        if (data.key !== undefined) {
            this.key = data.key;
        }
        if (data.name !== undefined) {
            this.name = data.name;
        }
        if (data.delay !== undefined) {
            this.delay = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["setRangeValue"])(data.delay);
        }
        const detectRetina = data.detectRetina;
        if (detectRetina !== undefined) {
            this.detectRetina = detectRetina;
        }
        if (data.duration !== undefined) {
            this.duration = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["setRangeValue"])(data.duration);
        }
        const fpsLimit = data.fpsLimit;
        if (fpsLimit !== undefined) {
            this.fpsLimit = fpsLimit;
        }
        if (data.pauseOnBlur !== undefined) {
            this.pauseOnBlur = data.pauseOnBlur;
        }
        if (data.pauseOnOutsideViewport !== undefined) {
            this.pauseOnOutsideViewport = data.pauseOnOutsideViewport;
        }
        if (data.zLayers !== undefined) {
            this.zLayers = data.zLayers;
        }
        this.background.load(data.background);
        const fullScreen = data.fullScreen;
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isBoolean"])(fullScreen)) {
            this.fullScreen.enable = fullScreen;
        } else {
            this.fullScreen.load(fullScreen);
        }
        this.backgroundMask.load(data.backgroundMask);
        this.interactivity.load(data.interactivity);
        if (data.manualParticles) {
            this.manualParticles = data.manualParticles.map((t)=>{
                const tmp = new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$ManualParticle$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ManualParticle"]();
                tmp.load(t);
                return tmp;
            });
        }
        this.particles.load(data.particles);
        this.style = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["deepExtend"])(this.style, data.style);
        this._engine.loadOptions(this, data);
        if (data.smooth !== undefined) {
            this.smooth = data.smooth;
        }
        const interactors = this._engine.interactors.get(this._container);
        if (interactors) {
            for (const interactor of interactors){
                if (interactor.loadOptions) {
                    interactor.loadOptions(this, data);
                }
            }
        }
        if (data.responsive !== undefined) {
            for (const responsive of data.responsive){
                const optResponsive = new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$Responsive$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Responsive"]();
                optResponsive.load(responsive);
                this.responsive.push(optResponsive);
            }
        }
        this.responsive.sort((a, b)=>a.maxWidth - b.maxWidth);
        if (data.themes !== undefined) {
            for (const theme of data.themes){
                const existingTheme = this.themes.find((t)=>t.name === theme.name);
                if (!existingTheme) {
                    const optTheme = new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$Theme$2f$Theme$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Theme"]();
                    optTheme.load(theme);
                    this.themes.push(optTheme);
                } else {
                    existingTheme.load(theme);
                }
            }
        }
        this.defaultThemes.dark = this._findDefaultTheme(__TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Modes$2f$ThemeMode$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ThemeMode"].dark)?.name;
        this.defaultThemes.light = this._findDefaultTheme(__TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Modes$2f$ThemeMode$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ThemeMode"].light)?.name;
    }
    setResponsive(width, pxRatio, defaultOptions) {
        this.load(defaultOptions);
        const responsiveOptions = this.responsive.find((t)=>t.mode === __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Modes$2f$ResponsiveMode$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ResponsiveMode"].screen && screen ? t.maxWidth > screen.availWidth : t.maxWidth * pxRatio > width);
        this.load(responsiveOptions?.options);
        return responsiveOptions?.maxWidth;
    }
    setTheme(name) {
        if (name) {
            const chosenTheme = this.themes.find((theme)=>theme.name === name);
            if (chosenTheme) {
                this.load(chosenTheme.options);
            }
        } else {
            const mediaMatch = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["safeMatchMedia"])("(prefers-color-scheme: dark)"), clientDarkMode = mediaMatch?.matches, defaultTheme = this._findDefaultTheme(clientDarkMode ? __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Modes$2f$ThemeMode$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ThemeMode"].dark : __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Modes$2f$ThemeMode$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ThemeMode"].light);
            if (defaultTheme) {
                this.load(defaultTheme.options);
            }
        }
    }
}
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Enums/Types/InteractorType.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "InteractorType",
    ()=>InteractorType
]);
var InteractorType;
(function(InteractorType) {
    InteractorType["external"] = "external";
    InteractorType["particles"] = "particles";
})(InteractorType || (InteractorType = {}));
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Core/Utils/InteractionManager.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "InteractionManager",
    ()=>InteractionManager
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Types$2f$InteractorType$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Enums/Types/InteractorType.js [app-ssr] (ecmascript)");
;
class InteractionManager {
    constructor(engine, container){
        this.container = container;
        this._engine = engine;
        this._interactors = [];
        this._externalInteractors = [];
        this._particleInteractors = [];
    }
    externalInteract(delta) {
        for (const interactor of this._externalInteractors){
            if (interactor.isEnabled()) {
                interactor.interact(delta);
            }
        }
    }
    handleClickMode(mode) {
        for (const interactor of this._externalInteractors){
            interactor.handleClickMode?.(mode);
        }
    }
    async init() {
        this._interactors = await this._engine.getInteractors(this.container, true);
        this._externalInteractors = [];
        this._particleInteractors = [];
        for (const interactor of this._interactors){
            switch(interactor.type){
                case __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Types$2f$InteractorType$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["InteractorType"].external:
                    this._externalInteractors.push(interactor);
                    break;
                case __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Types$2f$InteractorType$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["InteractorType"].particles:
                    this._particleInteractors.push(interactor);
                    break;
            }
            interactor.init();
        }
    }
    particlesInteract(particle, delta) {
        for (const interactor of this._externalInteractors){
            interactor.clear(particle, delta);
        }
        for (const interactor of this._particleInteractors){
            if (interactor.isEnabled(particle)) {
                interactor.interact(particle, delta);
            }
        }
    }
    reset(particle) {
        for (const interactor of this._externalInteractors){
            if (interactor.isEnabled()) {
                interactor.reset(particle);
            }
        }
        for (const interactor of this._particleInteractors){
            if (interactor.isEnabled(particle)) {
                interactor.reset(particle);
            }
        }
    }
}
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Enums/Types/ParticleOutType.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ParticleOutType",
    ()=>ParticleOutType
]);
var ParticleOutType;
(function(ParticleOutType) {
    ParticleOutType["normal"] = "normal";
    ParticleOutType["inside"] = "inside";
    ParticleOutType["outside"] = "outside";
})(ParticleOutType || (ParticleOutType = {}));
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Core/Particle.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Particle",
    ()=>Particle
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Vectors$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Core/Utils/Vectors.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/NumberUtils.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Core/Utils/Constants.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/Utils.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$ColorUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/ColorUtils.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Types$2f$EventType$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Enums/Types/EventType.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$Interactivity$2f$Interactivity$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Classes/Interactivity/Interactivity.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Directions$2f$MoveDirection$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Enums/Directions/MoveDirection.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Modes$2f$OutMode$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Enums/Modes/OutMode.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Types$2f$ParticleOutType$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Enums/Types/ParticleOutType.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Modes$2f$PixelMode$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Enums/Modes/PixelMode.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$CanvasUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/CanvasUtils.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$OptionsUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/OptionsUtils.js [app-ssr] (ecmascript)");
;
;
;
;
;
;
;
;
;
;
;
;
;
function loadEffectData(effect, effectOptions, id, reduceDuplicates) {
    const effectData = effectOptions.options[effect];
    if (!effectData) {
        return;
    }
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["deepExtend"])({
        close: effectOptions.close,
        fill: effectOptions.fill
    }, (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["itemFromSingleOrMultiple"])(effectData, id, reduceDuplicates));
}
function loadShapeData(shape, shapeOptions, id, reduceDuplicates) {
    const shapeData = shapeOptions.options[shape];
    if (!shapeData) {
        return;
    }
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["deepExtend"])({
        close: shapeOptions.close,
        fill: shapeOptions.fill
    }, (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["itemFromSingleOrMultiple"])(shapeData, id, reduceDuplicates));
}
function fixOutMode(data) {
    if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isInArray"])(data.outMode, data.checkModes)) {
        return;
    }
    const diameter = data.radius * __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["double"];
    if (data.coord > data.maxCoord - diameter) {
        data.setCb(-data.radius);
    } else if (data.coord < diameter) {
        data.setCb(data.radius);
    }
}
class Particle {
    constructor(engine, container){
        this.container = container;
        this._calcPosition = (container, position, zIndex, tryCount = __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["defaultRetryCount"])=>{
            for (const plugin of container.plugins.values()){
                const pluginPos = plugin.particlePosition !== undefined ? plugin.particlePosition(position, this) : undefined;
                if (pluginPos) {
                    return __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Vectors$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Vector3d"].create(pluginPos.x, pluginPos.y, zIndex);
                }
            }
            const canvasSize = container.canvas.size, exactPosition = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["calcExactPositionOrRandomFromSize"])({
                size: canvasSize,
                position: position
            }), pos = __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Vectors$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Vector3d"].create(exactPosition.x, exactPosition.y, zIndex), radius = this.getRadius(), outModes = this.options.move.outModes, fixHorizontal = (outMode)=>{
                fixOutMode({
                    outMode,
                    checkModes: [
                        __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Modes$2f$OutMode$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["OutMode"].bounce
                    ],
                    coord: pos.x,
                    maxCoord: container.canvas.size.width,
                    setCb: (value)=>pos.x += value,
                    radius
                });
            }, fixVertical = (outMode)=>{
                fixOutMode({
                    outMode,
                    checkModes: [
                        __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Modes$2f$OutMode$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["OutMode"].bounce
                    ],
                    coord: pos.y,
                    maxCoord: container.canvas.size.height,
                    setCb: (value)=>pos.y += value,
                    radius
                });
            };
            fixHorizontal(outModes.left ?? outModes.default);
            fixHorizontal(outModes.right ?? outModes.default);
            fixVertical(outModes.top ?? outModes.default);
            fixVertical(outModes.bottom ?? outModes.default);
            if (this._checkOverlap(pos, tryCount)) {
                return this._calcPosition(container, undefined, zIndex, tryCount + __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["tryCountIncrement"]);
            }
            return pos;
        };
        this._calculateVelocity = ()=>{
            const baseVelocity = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getParticleBaseVelocity"])(this.direction), res = baseVelocity.copy(), moveOptions = this.options.move;
            if (moveOptions.direction === __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Directions$2f$MoveDirection$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["MoveDirection"].inside || moveOptions.direction === __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Directions$2f$MoveDirection$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["MoveDirection"].outside) {
                return res;
            }
            const rad = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["degToRad"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getRangeValue"])(moveOptions.angle.value)), radOffset = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["degToRad"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getRangeValue"])(moveOptions.angle.offset)), range = {
                left: radOffset - rad * __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["half"],
                right: radOffset + rad * __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["half"]
            };
            if (!moveOptions.straight) {
                res.angle += (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["randomInRange"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["setRangeValue"])(range.left, range.right));
            }
            if (moveOptions.random && typeof moveOptions.speed === "number") {
                res.length *= (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getRandom"])();
            }
            return res;
        };
        this._checkOverlap = (pos, tryCount = __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["defaultRetryCount"])=>{
            const collisionsOptions = this.options.collisions, radius = this.getRadius();
            if (!collisionsOptions.enable) {
                return false;
            }
            const overlapOptions = collisionsOptions.overlap;
            if (overlapOptions.enable) {
                return false;
            }
            const retries = overlapOptions.retries;
            if (retries >= __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["minRetries"] && tryCount > retries) {
                throw new Error(`${__TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["errorPrefix"]} particle is overlapping and can't be placed`);
            }
            return !!this.container.particles.find((particle)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getDistance"])(pos, particle.position) < radius + particle.getRadius());
        };
        this._getRollColor = (color)=>{
            if (!color || !this.roll || !this.backColor && !this.roll.alter) {
                return color;
            }
            const backFactor = this.roll.horizontal && this.roll.vertical ? __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["double"] * __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["rollFactor"] : __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["rollFactor"], backSum = this.roll.horizontal ? Math.PI * __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["half"] : __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["none"], rolled = Math.floor(((this.roll.angle ?? __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["none"]) + backSum) / (Math.PI / backFactor)) % __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["double"];
            if (!rolled) {
                return color;
            }
            if (this.backColor) {
                return this.backColor;
            }
            if (this.roll.alter) {
                return (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$CanvasUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["alterHsl"])(color, this.roll.alter.type, this.roll.alter.value);
            }
            return color;
        };
        this._initPosition = (position)=>{
            const container = this.container, zIndexValue = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getRangeValue"])(this.options.zIndex.value);
            this.position = this._calcPosition(container, position, (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["clamp"])(zIndexValue, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["minZ"], container.zLayers));
            this.initialPosition = this.position.copy();
            const canvasSize = container.canvas.size;
            this.moveCenter = {
                ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getPosition"])(this.options.move.center, canvasSize),
                radius: this.options.move.center.radius ?? __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["defaultRadius"],
                mode: this.options.move.center.mode ?? __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Modes$2f$PixelMode$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["PixelMode"].percent
            };
            this.direction = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getParticleDirectionAngle"])(this.options.move.direction, this.position, this.moveCenter);
            switch(this.options.move.direction){
                case __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Directions$2f$MoveDirection$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["MoveDirection"].inside:
                    this.outType = __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Types$2f$ParticleOutType$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ParticleOutType"].inside;
                    break;
                case __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Directions$2f$MoveDirection$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["MoveDirection"].outside:
                    this.outType = __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Types$2f$ParticleOutType$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ParticleOutType"].outside;
                    break;
            }
            this.offset = __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Vectors$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Vector"].origin;
        };
        this._engine = engine;
    }
    destroy(override) {
        if (this.unbreakable || this.destroyed) {
            return;
        }
        this.destroyed = true;
        this.bubble.inRange = false;
        this.slow.inRange = false;
        const container = this.container, pathGenerator = this.pathGenerator, shapeDrawer = container.shapeDrawers.get(this.shape);
        shapeDrawer?.particleDestroy?.(this);
        for (const plugin of container.plugins.values()){
            plugin.particleDestroyed?.(this, override);
        }
        for (const updater of container.particles.updaters){
            updater.particleDestroyed?.(this, override);
        }
        pathGenerator?.reset(this);
        this._engine.dispatchEvent(__TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Types$2f$EventType$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["EventType"].particleDestroyed, {
            container: this.container,
            data: {
                particle: this
            }
        });
    }
    draw(delta) {
        const container = this.container, canvas = container.canvas;
        for (const plugin of container.plugins.values()){
            canvas.drawParticlePlugin(plugin, this, delta);
        }
        canvas.drawParticle(this, delta);
    }
    getFillColor() {
        return this._getRollColor(this.bubble.color ?? (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$ColorUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getHslFromAnimation"])(this.color));
    }
    getMass() {
        return this.getRadius() ** __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["squareExp"] * Math.PI * __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["half"];
    }
    getPosition() {
        return {
            x: this.position.x + this.offset.x,
            y: this.position.y + this.offset.y,
            z: this.position.z
        };
    }
    getRadius() {
        return this.bubble.radius ?? this.size.value;
    }
    getStrokeColor() {
        return this._getRollColor(this.bubble.color ?? (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$ColorUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getHslFromAnimation"])(this.strokeColor));
    }
    init(id, position, overrideOptions, group) {
        const container = this.container, engine = this._engine;
        this.id = id;
        this.group = group;
        this.effectClose = true;
        this.effectFill = true;
        this.shapeClose = true;
        this.shapeFill = true;
        this.pathRotation = false;
        this.lastPathTime = 0;
        this.destroyed = false;
        this.unbreakable = false;
        this.isRotating = false;
        this.rotation = 0;
        this.misplaced = false;
        this.retina = {
            maxDistance: {}
        };
        this.outType = __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Types$2f$ParticleOutType$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ParticleOutType"].normal;
        this.ignoresResizeRatio = true;
        const pxRatio = container.retina.pixelRatio, mainOptions = container.actualOptions, particlesOptions = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$OptionsUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["loadParticlesOptions"])(this._engine, container, mainOptions.particles), { reduceDuplicates } = particlesOptions, effectType = particlesOptions.effect.type, shapeType = particlesOptions.shape.type;
        this.effect = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["itemFromSingleOrMultiple"])(effectType, this.id, reduceDuplicates);
        this.shape = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["itemFromSingleOrMultiple"])(shapeType, this.id, reduceDuplicates);
        const effectOptions = particlesOptions.effect, shapeOptions = particlesOptions.shape;
        if (overrideOptions) {
            if (overrideOptions.effect?.type) {
                const overrideEffectType = overrideOptions.effect.type, effect = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["itemFromSingleOrMultiple"])(overrideEffectType, this.id, reduceDuplicates);
                if (effect) {
                    this.effect = effect;
                    effectOptions.load(overrideOptions.effect);
                }
            }
            if (overrideOptions.shape?.type) {
                const overrideShapeType = overrideOptions.shape.type, shape = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["itemFromSingleOrMultiple"])(overrideShapeType, this.id, reduceDuplicates);
                if (shape) {
                    this.shape = shape;
                    shapeOptions.load(overrideOptions.shape);
                }
            }
        }
        if (this.effect === __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["randomColorValue"]) {
            const availableEffects = [
                ...this.container.effectDrawers.keys()
            ];
            this.effect = availableEffects[Math.floor((0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getRandom"])() * availableEffects.length)];
        }
        if (this.shape === __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["randomColorValue"]) {
            const availableShapes = [
                ...this.container.shapeDrawers.keys()
            ];
            this.shape = availableShapes[Math.floor((0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getRandom"])() * availableShapes.length)];
        }
        this.effectData = loadEffectData(this.effect, effectOptions, this.id, reduceDuplicates);
        this.shapeData = loadShapeData(this.shape, shapeOptions, this.id, reduceDuplicates);
        particlesOptions.load(overrideOptions);
        const effectData = this.effectData;
        if (effectData) {
            particlesOptions.load(effectData.particles);
        }
        const shapeData = this.shapeData;
        if (shapeData) {
            particlesOptions.load(shapeData.particles);
        }
        const interactivity = new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$Interactivity$2f$Interactivity$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Interactivity"](engine, container);
        interactivity.load(container.actualOptions.interactivity);
        interactivity.load(particlesOptions.interactivity);
        this.interactivity = interactivity;
        this.effectFill = effectData?.fill ?? particlesOptions.effect.fill;
        this.effectClose = effectData?.close ?? particlesOptions.effect.close;
        this.shapeFill = shapeData?.fill ?? particlesOptions.shape.fill;
        this.shapeClose = shapeData?.close ?? particlesOptions.shape.close;
        this.options = particlesOptions;
        const pathOptions = this.options.move.path;
        this.pathDelay = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getRangeValue"])(pathOptions.delay.value) * __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["millisecondsToSeconds"];
        if (pathOptions.generator) {
            this.pathGenerator = this._engine.getPathGenerator(pathOptions.generator);
            if (this.pathGenerator && container.addPath(pathOptions.generator, this.pathGenerator)) {
                this.pathGenerator.init(container);
            }
        }
        container.retina.initParticle(this);
        this.size = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["initParticleNumericAnimationValue"])(this.options.size, pxRatio);
        this.bubble = {
            inRange: false
        };
        this.slow = {
            inRange: false,
            factor: 1
        };
        this._initPosition(position);
        this.initialVelocity = this._calculateVelocity();
        this.velocity = this.initialVelocity.copy();
        this.moveDecay = __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["decayOffset"] - (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getRangeValue"])(this.options.move.decay);
        const particles = container.particles;
        particles.setLastZIndex(this.position.z);
        this.zIndexFactor = this.position.z / container.zLayers;
        this.sides = 24;
        let effectDrawer = container.effectDrawers.get(this.effect);
        if (!effectDrawer) {
            effectDrawer = this._engine.getEffectDrawer(this.effect);
            if (effectDrawer) {
                container.effectDrawers.set(this.effect, effectDrawer);
            }
        }
        if (effectDrawer?.loadEffect) {
            effectDrawer.loadEffect(this);
        }
        let shapeDrawer = container.shapeDrawers.get(this.shape);
        if (!shapeDrawer) {
            shapeDrawer = this._engine.getShapeDrawer(this.shape);
            if (shapeDrawer) {
                container.shapeDrawers.set(this.shape, shapeDrawer);
            }
        }
        if (shapeDrawer?.loadShape) {
            shapeDrawer.loadShape(this);
        }
        const sideCountFunc = shapeDrawer?.getSidesCount;
        if (sideCountFunc) {
            this.sides = sideCountFunc(this);
        }
        this.spawning = false;
        this.shadowColor = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$ColorUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["rangeColorToRgb"])(this._engine, this.options.shadow.color);
        for (const updater of particles.updaters){
            updater.init(this);
        }
        for (const mover of particles.movers){
            mover.init?.(this);
        }
        effectDrawer?.particleInit?.(container, this);
        shapeDrawer?.particleInit?.(container, this);
        for (const plugin of container.plugins.values()){
            plugin.particleCreated?.(this);
        }
    }
    isInsideCanvas() {
        const radius = this.getRadius(), canvasSize = this.container.canvas.size, position = this.position;
        return position.x >= -radius && position.y >= -radius && position.y <= canvasSize.height + radius && position.x <= canvasSize.width + radius;
    }
    isVisible() {
        return !this.destroyed && !this.spawning && this.isInsideCanvas();
    }
    reset() {
        for (const updater of this.container.particles.updaters){
            updater.reset?.(this);
        }
    }
}
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Core/Utils/Point.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Point",
    ()=>Point
]);
class Point {
    constructor(position, particle){
        this.position = position;
        this.particle = particle;
    }
}
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Types/RangeType.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "RangeType",
    ()=>RangeType
]);
var RangeType;
(function(RangeType) {
    RangeType["circle"] = "circle";
    RangeType["rectangle"] = "rectangle";
})(RangeType || (RangeType = {}));
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Core/Utils/Ranges.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "BaseRange",
    ()=>BaseRange,
    "Circle",
    ()=>Circle,
    "Rectangle",
    ()=>Rectangle
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Types$2f$RangeType$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Types/RangeType.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/NumberUtils.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Core/Utils/Constants.js [app-ssr] (ecmascript)");
;
;
;
class BaseRange {
    constructor(x, y, type){
        this.position = {
            x: x,
            y: y
        };
        this.type = type;
    }
}
class Circle extends BaseRange {
    constructor(x, y, radius){
        super(x, y, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Types$2f$RangeType$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["RangeType"].circle);
        this.radius = radius;
    }
    contains(point) {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getDistance"])(point, this.position) <= this.radius;
    }
    intersects(range) {
        const pos1 = this.position, pos2 = range.position, distPos = {
            x: Math.abs(pos2.x - pos1.x),
            y: Math.abs(pos2.y - pos1.y)
        }, r = this.radius;
        if (range instanceof Circle || range.type === __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Types$2f$RangeType$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["RangeType"].circle) {
            const circleRange = range, rSum = r + circleRange.radius, dist = Math.sqrt(distPos.x ** __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["squareExp"] + distPos.y ** __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["squareExp"]);
            return rSum > dist;
        } else if (range instanceof Rectangle || range.type === __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Types$2f$RangeType$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["RangeType"].rectangle) {
            const rectRange = range, { width, height } = rectRange.size, edges = Math.pow(distPos.x - width, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["squareExp"]) + Math.pow(distPos.y - height, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["squareExp"]);
            return edges <= r ** __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["squareExp"] || distPos.x <= r + width && distPos.y <= r + height || distPos.x <= width || distPos.y <= height;
        }
        return false;
    }
}
class Rectangle extends BaseRange {
    constructor(x, y, width, height){
        super(x, y, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Types$2f$RangeType$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["RangeType"].rectangle);
        this.size = {
            height: height,
            width: width
        };
    }
    contains(point) {
        const w = this.size.width, h = this.size.height, pos = this.position;
        return point.x >= pos.x && point.x <= pos.x + w && point.y >= pos.y && point.y <= pos.y + h;
    }
    intersects(range) {
        if (range instanceof Circle) {
            return range.intersects(this);
        }
        const w = this.size.width, h = this.size.height, pos1 = this.position, pos2 = range.position, size2 = range instanceof Rectangle ? range.size : {
            width: 0,
            height: 0
        }, w2 = size2.width, h2 = size2.height;
        return pos2.x < pos1.x + w && pos2.x + w2 > pos1.x && pos2.y < pos1.y + h && pos2.y + h2 > pos1.y;
    }
}
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Core/Utils/QuadTree.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "QuadTree",
    ()=>QuadTree
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Ranges$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Core/Utils/Ranges.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Core/Utils/Constants.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/NumberUtils.js [app-ssr] (ecmascript)");
;
;
;
class QuadTree {
    constructor(rectangle, capacity){
        this.rectangle = rectangle;
        this.capacity = capacity;
        this._subdivide = ()=>{
            const { x, y } = this.rectangle.position, { width, height } = this.rectangle.size, { capacity } = this;
            for(let i = 0; i < __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["subdivideCount"]; i++){
                const fixedIndex = i % __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["double"];
                this._subs.push(new QuadTree(new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Ranges$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Rectangle"](x + width * __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["half"] * fixedIndex, y + height * __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["half"] * (Math.round(i * __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["half"]) - fixedIndex), width * __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["half"], height * __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["half"]), capacity));
            }
            this._divided = true;
        };
        this._points = [];
        this._divided = false;
        this._subs = [];
    }
    insert(point) {
        if (!this.rectangle.contains(point.position)) {
            return false;
        }
        if (this._points.length < this.capacity) {
            this._points.push(point);
            return true;
        }
        if (!this._divided) {
            this._subdivide();
        }
        return this._subs.some((sub)=>sub.insert(point));
    }
    query(range, check) {
        const res = [];
        if (!range.intersects(this.rectangle)) {
            return [];
        }
        for (const p of this._points){
            if (!range.contains(p.position) && (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getDistance"])(range.position, p.position) > p.particle.getRadius() && (!check || check(p.particle))) {
                continue;
            }
            res.push(p.particle);
        }
        if (this._divided) {
            for (const sub of this._subs){
                res.push(...sub.query(range, check));
            }
        }
        return res;
    }
    queryCircle(position, radius, check) {
        return this.query(new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Ranges$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Circle"](position.x, position.y, radius), check);
    }
    queryRectangle(position, size, check) {
        return this.query(new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Ranges$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Rectangle"](position.x, position.y, size.width, size.height), check);
    }
}
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Core/Particles.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Particles",
    ()=>Particles
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Core/Utils/Constants.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/Utils.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Types$2f$EventType$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Enums/Types/EventType.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$InteractionManager$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Core/Utils/InteractionManager.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Modes$2f$LimitMode$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Enums/Modes/LimitMode.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Particle$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Core/Particle.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Point$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Core/Utils/Point.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$QuadTree$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Core/Utils/QuadTree.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Ranges$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Core/Utils/Ranges.js [app-ssr] (ecmascript)");
;
;
;
;
;
;
;
;
;
const qTreeRectangle = (canvasSize)=>{
    const { height, width } = canvasSize;
    return new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Ranges$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Rectangle"](__TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["posOffset"] * width, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["posOffset"] * height, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["sizeFactor"] * width, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["sizeFactor"] * height);
};
class Particles {
    constructor(engine, container){
        this._addToPool = (...particles)=>{
            this._pool.push(...particles);
        };
        this._applyDensity = (options, manualCount, group, groupOptions)=>{
            const numberOptions = options.number;
            if (!options.number.density?.enable) {
                if (group === undefined) {
                    this._limit = numberOptions.limit.value;
                } else if (groupOptions?.number.limit?.value ?? numberOptions.limit.value) {
                    this._groupLimits.set(group, groupOptions?.number.limit?.value ?? numberOptions.limit.value);
                }
                return;
            }
            const densityFactor = this._initDensityFactor(numberOptions.density), optParticlesNumber = numberOptions.value, optParticlesLimit = numberOptions.limit.value > __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["minLimit"] ? numberOptions.limit.value : optParticlesNumber, particlesNumber = Math.min(optParticlesNumber, optParticlesLimit) * densityFactor + manualCount, particlesCount = Math.min(this.count, this.filter((t)=>t.group === group).length);
            if (group === undefined) {
                this._limit = numberOptions.limit.value * densityFactor;
            } else {
                this._groupLimits.set(group, numberOptions.limit.value * densityFactor);
            }
            if (particlesCount < particlesNumber) {
                this.push(Math.abs(particlesNumber - particlesCount), undefined, options, group);
            } else if (particlesCount > particlesNumber) {
                this.removeQuantity(particlesCount - particlesNumber, group);
            }
        };
        this._initDensityFactor = (densityOptions)=>{
            const container = this._container;
            if (!container.canvas.element || !densityOptions.enable) {
                return __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["defaultDensityFactor"];
            }
            const canvas = container.canvas.element, pxRatio = container.retina.pixelRatio;
            return canvas.width * canvas.height / (densityOptions.height * densityOptions.width * pxRatio ** __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["squareExp"]);
        };
        this._pushParticle = (position, overrideOptions, group, initializer)=>{
            try {
                let particle = this._pool.pop();
                if (!particle) {
                    particle = new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Particle$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Particle"](this._engine, this._container);
                }
                particle.init(this._nextId, position, overrideOptions, group);
                let canAdd = true;
                if (initializer) {
                    canAdd = initializer(particle);
                }
                if (!canAdd) {
                    return;
                }
                this._array.push(particle);
                this._zArray.push(particle);
                this._nextId++;
                this._engine.dispatchEvent(__TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Types$2f$EventType$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["EventType"].particleAdded, {
                    container: this._container,
                    data: {
                        particle
                    }
                });
                return particle;
            } catch (e) {
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getLogger"])().warning(`${__TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["errorPrefix"]} adding particle: ${e}`);
            }
        };
        this._removeParticle = (index, group, override)=>{
            const particle = this._array[index];
            if (!particle || particle.group !== group) {
                return false;
            }
            const zIdx = this._zArray.indexOf(particle);
            this._array.splice(index, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["deleteCount"]);
            this._zArray.splice(zIdx, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["deleteCount"]);
            particle.destroy(override);
            this._engine.dispatchEvent(__TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Types$2f$EventType$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["EventType"].particleRemoved, {
                container: this._container,
                data: {
                    particle
                }
            });
            this._addToPool(particle);
            return true;
        };
        this._engine = engine;
        this._container = container;
        this._nextId = 0;
        this._array = [];
        this._zArray = [];
        this._pool = [];
        this._limit = 0;
        this._groupLimits = new Map();
        this._needsSort = false;
        this._lastZIndex = 0;
        this._interactionManager = new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$InteractionManager$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["InteractionManager"](engine, container);
        this._pluginsInitialized = false;
        const canvasSize = container.canvas.size;
        this.quadTree = new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$QuadTree$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["QuadTree"](qTreeRectangle(canvasSize), __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["qTreeCapacity"]);
        this.movers = [];
        this.updaters = [];
    }
    get count() {
        return this._array.length;
    }
    addManualParticles() {
        const container = this._container, options = container.actualOptions;
        options.manualParticles.forEach((p)=>this.addParticle(p.position ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getPosition"])(p.position, container.canvas.size) : undefined, p.options));
    }
    addParticle(position, overrideOptions, group, initializer) {
        const limitMode = this._container.actualOptions.particles.number.limit.mode, limit = group === undefined ? this._limit : this._groupLimits.get(group) ?? this._limit, currentCount = this.count;
        if (limit > __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["minLimit"]) {
            switch(limitMode){
                case __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Modes$2f$LimitMode$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["LimitMode"].delete:
                    {
                        const countToRemove = currentCount + __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["countOffset"] - limit;
                        if (countToRemove > __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["minCount"]) {
                            this.removeQuantity(countToRemove);
                        }
                        break;
                    }
                case __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Modes$2f$LimitMode$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["LimitMode"].wait:
                    if (currentCount >= limit) {
                        return;
                    }
                    break;
            }
        }
        return this._pushParticle(position, overrideOptions, group, initializer);
    }
    clear() {
        this._array = [];
        this._zArray = [];
        this._pluginsInitialized = false;
    }
    destroy() {
        this._array = [];
        this._zArray = [];
        this.movers = [];
        this.updaters = [];
    }
    draw(delta) {
        const container = this._container, canvas = container.canvas;
        canvas.clear();
        this.update(delta);
        for (const plugin of container.plugins.values()){
            canvas.drawPlugin(plugin, delta);
        }
        for (const p of this._zArray){
            p.draw(delta);
        }
    }
    filter(condition) {
        return this._array.filter(condition);
    }
    find(condition) {
        return this._array.find(condition);
    }
    get(index) {
        return this._array[index];
    }
    handleClickMode(mode) {
        this._interactionManager.handleClickMode(mode);
    }
    async init() {
        const container = this._container, options = container.actualOptions;
        this._lastZIndex = 0;
        this._needsSort = false;
        await this.initPlugins();
        let handled = false;
        for (const plugin of container.plugins.values()){
            handled = plugin.particlesInitialization?.() ?? handled;
            if (handled) {
                break;
            }
        }
        this.addManualParticles();
        if (!handled) {
            const particlesOptions = options.particles, groups = particlesOptions.groups;
            for(const group in groups){
                const groupOptions = groups[group];
                for(let i = this.count, j = 0; j < groupOptions.number?.value && i < particlesOptions.number.value; i++, j++){
                    this.addParticle(undefined, groupOptions, group);
                }
            }
            for(let i = this.count; i < particlesOptions.number.value; i++){
                this.addParticle();
            }
        }
    }
    async initPlugins() {
        if (this._pluginsInitialized) {
            return;
        }
        const container = this._container;
        this.movers = await this._engine.getMovers(container, true);
        this.updaters = await this._engine.getUpdaters(container, true);
        await this._interactionManager.init();
        for (const pathGenerator of container.pathGenerators.values()){
            pathGenerator.init(container);
        }
    }
    push(nb, mouse, overrideOptions, group) {
        for(let i = 0; i < nb; i++){
            this.addParticle(mouse?.position, overrideOptions, group);
        }
    }
    async redraw() {
        this.clear();
        await this.init();
        this.draw({
            value: 0,
            factor: 0
        });
    }
    remove(particle, group, override) {
        this.removeAt(this._array.indexOf(particle), undefined, group, override);
    }
    removeAt(index, quantity = __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["defaultRemoveQuantity"], group, override) {
        if (index < __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["minIndex"] || index > this.count) {
            return;
        }
        let deleted = 0;
        for(let i = index; deleted < quantity && i < this.count; i++){
            if (this._removeParticle(i, group, override)) {
                i--;
                deleted++;
            }
        }
    }
    removeQuantity(quantity, group) {
        this.removeAt(__TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["minIndex"], quantity, group);
    }
    setDensity() {
        const options = this._container.actualOptions, groups = options.particles.groups, manualCount = options.manualParticles.length;
        for(const group in groups){
            this._applyDensity(groups[group], manualCount, group);
        }
        this._applyDensity(options.particles, manualCount);
    }
    setLastZIndex(zIndex) {
        this._lastZIndex = zIndex;
        this._needsSort = this._needsSort || this._lastZIndex < zIndex;
    }
    setResizeFactor(factor) {
        this._resizeFactor = factor;
    }
    update(delta) {
        const container = this._container, particlesToDelete = new Set();
        this.quadTree = new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$QuadTree$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["QuadTree"](qTreeRectangle(container.canvas.size), __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["qTreeCapacity"]);
        for (const pathGenerator of container.pathGenerators.values()){
            pathGenerator.update();
        }
        for (const plugin of container.plugins.values()){
            plugin.update?.(delta);
        }
        const resizeFactor = this._resizeFactor;
        for (const particle of this._array){
            if (resizeFactor && !particle.ignoresResizeRatio) {
                particle.position.x *= resizeFactor.width;
                particle.position.y *= resizeFactor.height;
                particle.initialPosition.x *= resizeFactor.width;
                particle.initialPosition.y *= resizeFactor.height;
            }
            particle.ignoresResizeRatio = false;
            this._interactionManager.reset(particle);
            for (const plugin of this._container.plugins.values()){
                if (particle.destroyed) {
                    break;
                }
                plugin.particleUpdate?.(particle, delta);
            }
            for (const mover of this.movers){
                if (mover.isEnabled(particle)) {
                    mover.move(particle, delta);
                }
            }
            if (particle.destroyed) {
                particlesToDelete.add(particle);
                continue;
            }
            this.quadTree.insert(new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Point$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Point"](particle.getPosition(), particle));
        }
        if (particlesToDelete.size) {
            const checkDelete = (p)=>!particlesToDelete.has(p);
            this._array = this.filter(checkDelete);
            this._zArray = this._zArray.filter(checkDelete);
            for (const particle of particlesToDelete){
                this._engine.dispatchEvent(__TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Types$2f$EventType$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["EventType"].particleRemoved, {
                    container: this._container,
                    data: {
                        particle
                    }
                });
            }
            this._addToPool(...particlesToDelete);
        }
        this._interactionManager.externalInteract(delta);
        for (const particle of this._array){
            for (const updater of this.updaters){
                updater.update(particle, delta);
            }
            if (!particle.destroyed && !particle.spawning) {
                this._interactionManager.particlesInteract(particle, delta);
            }
        }
        delete this._resizeFactor;
        if (this._needsSort) {
            const zArray = this._zArray;
            zArray.sort((a, b)=>b.position.z - a.position.z || a.id - b.id);
            this._lastZIndex = zArray[zArray.length - __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["lengthOffset"]].position.z;
            this._needsSort = false;
        }
    }
}
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Core/Retina.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Retina",
    ()=>Retina
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Core/Utils/Constants.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/NumberUtils.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/Utils.js [app-ssr] (ecmascript)");
;
;
;
class Retina {
    constructor(container){
        this.container = container;
        this.pixelRatio = __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["defaultRatio"];
        this.reduceFactor = __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["defaultReduceFactor"];
    }
    init() {
        const container = this.container, options = container.actualOptions;
        this.pixelRatio = !options.detectRetina || (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isSsr"])() ? __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["defaultRatio"] : devicePixelRatio;
        this.reduceFactor = __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["defaultReduceFactor"];
        const ratio = this.pixelRatio, canvas = container.canvas;
        if (canvas.element) {
            const element = canvas.element;
            canvas.size.width = element.offsetWidth * ratio;
            canvas.size.height = element.offsetHeight * ratio;
        }
        const particles = options.particles, moveOptions = particles.move;
        this.maxSpeed = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getRangeValue"])(moveOptions.gravity.maxSpeed) * ratio;
        this.sizeAnimationSpeed = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getRangeValue"])(particles.size.animation.speed) * ratio;
    }
    initParticle(particle) {
        const options = particle.options, ratio = this.pixelRatio, moveOptions = options.move, moveDistance = moveOptions.distance, props = particle.retina;
        props.moveDrift = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getRangeValue"])(moveOptions.drift) * ratio;
        props.moveSpeed = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getRangeValue"])(moveOptions.speed) * ratio;
        props.sizeAnimationSpeed = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getRangeValue"])(options.size.animation.speed) * ratio;
        const maxDistance = props.maxDistance;
        maxDistance.horizontal = moveDistance.horizontal !== undefined ? moveDistance.horizontal * ratio : undefined;
        maxDistance.vertical = moveDistance.vertical !== undefined ? moveDistance.vertical * ratio : undefined;
        props.maxSpeed = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getRangeValue"])(moveOptions.gravity.maxSpeed) * ratio;
    }
}
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Core/Container.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Container",
    ()=>Container
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/NumberUtils.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Core/Utils/Constants.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/Utils.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Canvas$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Core/Canvas.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$EventListeners$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Core/Utils/EventListeners.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Types$2f$EventType$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Enums/Types/EventType.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$Options$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Classes/Options.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Particles$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Core/Particles.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Retina$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Core/Retina.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$OptionsUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/OptionsUtils.js [app-ssr] (ecmascript)");
;
;
;
;
;
;
;
;
;
;
function guardCheck(container) {
    return container && !container.destroyed;
}
function initDelta(value, fpsLimit = __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["defaultFps"], smooth = false) {
    return {
        value,
        factor: smooth ? __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["defaultFps"] / fpsLimit : __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["defaultFps"] * value / __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["millisecondsToSeconds"]
    };
}
function loadContainerOptions(engine, container, ...sourceOptionsArr) {
    const options = new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$Options$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Options"](engine, container);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$OptionsUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["loadOptions"])(options, ...sourceOptionsArr);
    return options;
}
class Container {
    constructor(engine, id, sourceOptions){
        this._intersectionManager = (entries)=>{
            if (!guardCheck(this) || !this.actualOptions.pauseOnOutsideViewport) {
                return;
            }
            for (const entry of entries){
                if (entry.target !== this.interactivity.element) {
                    continue;
                }
                if (entry.isIntersecting) {
                    void this.play();
                } else {
                    this.pause();
                }
            }
        };
        this._nextFrame = (timestamp)=>{
            try {
                if (!this._smooth && this._lastFrameTime !== undefined && timestamp < this._lastFrameTime + __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["millisecondsToSeconds"] / this.fpsLimit) {
                    this.draw(false);
                    return;
                }
                this._lastFrameTime ??= timestamp;
                const delta = initDelta(timestamp - this._lastFrameTime, this.fpsLimit, this._smooth);
                this.addLifeTime(delta.value);
                this._lastFrameTime = timestamp;
                if (delta.value > __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["millisecondsToSeconds"]) {
                    this.draw(false);
                    return;
                }
                this.particles.draw(delta);
                if (!this.alive()) {
                    this.destroy();
                    return;
                }
                if (this.animationStatus) {
                    this.draw(false);
                }
            } catch (e) {
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getLogger"])().error(`${__TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["errorPrefix"]} in animation loop`, e);
            }
        };
        this._engine = engine;
        this.id = Symbol(id);
        this.fpsLimit = 120;
        this._smooth = false;
        this._delay = 0;
        this._duration = 0;
        this._lifeTime = 0;
        this._firstStart = true;
        this.started = false;
        this.destroyed = false;
        this._paused = true;
        this._lastFrameTime = 0;
        this.zLayers = 100;
        this.pageHidden = false;
        this._clickHandlers = new Map();
        this._sourceOptions = sourceOptions;
        this._initialSourceOptions = sourceOptions;
        this.retina = new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Retina$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Retina"](this);
        this.canvas = new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Canvas$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Canvas"](this, this._engine);
        this.particles = new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Particles$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Particles"](this._engine, this);
        this.pathGenerators = new Map();
        this.interactivity = {
            mouse: {
                clicking: false,
                inside: false
            }
        };
        this.plugins = new Map();
        this.effectDrawers = new Map();
        this.shapeDrawers = new Map();
        this._options = loadContainerOptions(this._engine, this);
        this.actualOptions = loadContainerOptions(this._engine, this);
        this._eventListeners = new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$EventListeners$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["EventListeners"](this);
        this._intersectionObserver = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["safeIntersectionObserver"])((entries)=>this._intersectionManager(entries));
        this._engine.dispatchEvent(__TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Types$2f$EventType$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["EventType"].containerBuilt, {
            container: this
        });
    }
    get animationStatus() {
        return !this._paused && !this.pageHidden && guardCheck(this);
    }
    get options() {
        return this._options;
    }
    get sourceOptions() {
        return this._sourceOptions;
    }
    addClickHandler(callback) {
        if (!guardCheck(this)) {
            return;
        }
        const el = this.interactivity.element;
        if (!el) {
            return;
        }
        const clickOrTouchHandler = (e, pos, radius)=>{
            if (!guardCheck(this)) {
                return;
            }
            const pxRatio = this.retina.pixelRatio, posRetina = {
                x: pos.x * pxRatio,
                y: pos.y * pxRatio
            }, particles = this.particles.quadTree.queryCircle(posRetina, radius * pxRatio);
            callback(e, particles);
        }, clickHandler = (e)=>{
            if (!guardCheck(this)) {
                return;
            }
            const mouseEvent = e, pos = {
                x: mouseEvent.offsetX || mouseEvent.clientX,
                y: mouseEvent.offsetY || mouseEvent.clientY
            };
            clickOrTouchHandler(e, pos, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["clickRadius"]);
        }, touchStartHandler = ()=>{
            if (!guardCheck(this)) {
                return;
            }
            touched = true;
            touchMoved = false;
        }, touchMoveHandler = ()=>{
            if (!guardCheck(this)) {
                return;
            }
            touchMoved = true;
        }, touchEndHandler = (e)=>{
            if (!guardCheck(this)) {
                return;
            }
            if (touched && !touchMoved) {
                const touchEvent = e;
                let lastTouch = touchEvent.touches[touchEvent.touches.length - __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["touchEndLengthOffset"]];
                if (!lastTouch) {
                    lastTouch = touchEvent.changedTouches[touchEvent.changedTouches.length - __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["touchEndLengthOffset"]];
                    if (!lastTouch) {
                        return;
                    }
                }
                const element = this.canvas.element, canvasRect = element ? element.getBoundingClientRect() : undefined, pos = {
                    x: lastTouch.clientX - (canvasRect ? canvasRect.left : __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["minCoordinate"]),
                    y: lastTouch.clientY - (canvasRect ? canvasRect.top : __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["minCoordinate"])
                };
                clickOrTouchHandler(e, pos, Math.max(lastTouch.radiusX, lastTouch.radiusY));
            }
            touched = false;
            touchMoved = false;
        }, touchCancelHandler = ()=>{
            if (!guardCheck(this)) {
                return;
            }
            touched = false;
            touchMoved = false;
        };
        let touched = false, touchMoved = false;
        this._clickHandlers.set("click", clickHandler);
        this._clickHandlers.set("touchstart", touchStartHandler);
        this._clickHandlers.set("touchmove", touchMoveHandler);
        this._clickHandlers.set("touchend", touchEndHandler);
        this._clickHandlers.set("touchcancel", touchCancelHandler);
        for (const [key, handler] of this._clickHandlers){
            el.addEventListener(key, handler);
        }
    }
    addLifeTime(value) {
        this._lifeTime += value;
    }
    addPath(key, generator, override = false) {
        if (!guardCheck(this) || !override && this.pathGenerators.has(key)) {
            return false;
        }
        this.pathGenerators.set(key, generator);
        return true;
    }
    alive() {
        return !this._duration || this._lifeTime <= this._duration;
    }
    clearClickHandlers() {
        if (!guardCheck(this)) {
            return;
        }
        for (const [key, handler] of this._clickHandlers){
            this.interactivity.element?.removeEventListener(key, handler);
        }
        this._clickHandlers.clear();
    }
    destroy(remove = true) {
        if (!guardCheck(this)) {
            return;
        }
        this.stop();
        this.clearClickHandlers();
        this.particles.destroy();
        this.canvas.destroy();
        for (const effectDrawer of this.effectDrawers.values()){
            effectDrawer.destroy?.(this);
        }
        for (const shapeDrawer of this.shapeDrawers.values()){
            shapeDrawer.destroy?.(this);
        }
        for (const key of this.effectDrawers.keys()){
            this.effectDrawers.delete(key);
        }
        for (const key of this.shapeDrawers.keys()){
            this.shapeDrawers.delete(key);
        }
        this._engine.clearPlugins(this);
        this.destroyed = true;
        if (remove) {
            const mainArr = this._engine.items, idx = mainArr.findIndex((t)=>t === this);
            if (idx >= __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["removeMinIndex"]) {
                mainArr.splice(idx, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["removeDeleteCount"]);
            }
        }
        this._engine.dispatchEvent(__TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Types$2f$EventType$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["EventType"].containerDestroyed, {
            container: this
        });
    }
    draw(force) {
        if (!guardCheck(this)) {
            return;
        }
        let refreshTime = force;
        const frame = (timestamp)=>{
            if (refreshTime) {
                this._lastFrameTime = undefined;
                refreshTime = false;
            }
            this._nextFrame(timestamp);
        };
        this._drawAnimationFrame = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["animate"])((timestamp)=>frame(timestamp));
    }
    async export(type, options = {}) {
        for (const plugin of this.plugins.values()){
            if (!plugin.export) {
                continue;
            }
            const res = await plugin.export(type, options);
            if (!res.supported) {
                continue;
            }
            return res.blob;
        }
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getLogger"])().error(`${__TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["errorPrefix"]} - Export plugin with type ${type} not found`);
    }
    handleClickMode(mode) {
        if (!guardCheck(this)) {
            return;
        }
        this.particles.handleClickMode(mode);
        for (const plugin of this.plugins.values()){
            plugin.handleClickMode?.(mode);
        }
    }
    async init() {
        if (!guardCheck(this)) {
            return;
        }
        const effects = this._engine.getSupportedEffects();
        for (const type of effects){
            const drawer = this._engine.getEffectDrawer(type);
            if (drawer) {
                this.effectDrawers.set(type, drawer);
            }
        }
        const shapes = this._engine.getSupportedShapes();
        for (const type of shapes){
            const drawer = this._engine.getShapeDrawer(type);
            if (drawer) {
                this.shapeDrawers.set(type, drawer);
            }
        }
        await this.particles.initPlugins();
        this._options = loadContainerOptions(this._engine, this, this._initialSourceOptions, this.sourceOptions);
        this.actualOptions = loadContainerOptions(this._engine, this, this._options);
        const availablePlugins = await this._engine.getAvailablePlugins(this);
        for (const [id, plugin] of availablePlugins){
            this.plugins.set(id, plugin);
        }
        this.retina.init();
        await this.canvas.init();
        this.updateActualOptions();
        this.canvas.initBackground();
        this.canvas.resize();
        const { zLayers, duration, delay, fpsLimit, smooth } = this.actualOptions;
        this.zLayers = zLayers;
        this._duration = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getRangeValue"])(duration) * __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["millisecondsToSeconds"];
        this._delay = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getRangeValue"])(delay) * __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["millisecondsToSeconds"];
        this._lifeTime = 0;
        this.fpsLimit = fpsLimit > __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["minFpsLimit"] ? fpsLimit : __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["defaultFpsLimit"];
        this._smooth = smooth;
        for (const drawer of this.effectDrawers.values()){
            await drawer.init?.(this);
        }
        for (const drawer of this.shapeDrawers.values()){
            await drawer.init?.(this);
        }
        for (const plugin of this.plugins.values()){
            await plugin.init?.();
        }
        this._engine.dispatchEvent(__TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Types$2f$EventType$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["EventType"].containerInit, {
            container: this
        });
        await this.particles.init();
        this.particles.setDensity();
        for (const plugin of this.plugins.values()){
            plugin.particlesSetup?.();
        }
        this._engine.dispatchEvent(__TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Types$2f$EventType$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["EventType"].particlesSetup, {
            container: this
        });
    }
    async loadTheme(name) {
        if (!guardCheck(this)) {
            return;
        }
        this._currentTheme = name;
        await this.refresh();
    }
    pause() {
        if (!guardCheck(this)) {
            return;
        }
        if (this._drawAnimationFrame !== undefined) {
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cancelAnimation"])(this._drawAnimationFrame);
            delete this._drawAnimationFrame;
        }
        if (this._paused) {
            return;
        }
        for (const plugin of this.plugins.values()){
            plugin.pause?.();
        }
        if (!this.pageHidden) {
            this._paused = true;
        }
        this._engine.dispatchEvent(__TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Types$2f$EventType$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["EventType"].containerPaused, {
            container: this
        });
    }
    play(force) {
        if (!guardCheck(this)) {
            return;
        }
        const needsUpdate = this._paused || force;
        if (this._firstStart && !this.actualOptions.autoPlay) {
            this._firstStart = false;
            return;
        }
        if (this._paused) {
            this._paused = false;
        }
        if (needsUpdate) {
            for (const plugin of this.plugins.values()){
                if (plugin.play) {
                    plugin.play();
                }
            }
        }
        this._engine.dispatchEvent(__TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Types$2f$EventType$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["EventType"].containerPlay, {
            container: this
        });
        this.draw(needsUpdate ?? false);
    }
    async refresh() {
        if (!guardCheck(this)) {
            return;
        }
        this.stop();
        return this.start();
    }
    async reset(sourceOptions) {
        if (!guardCheck(this)) {
            return;
        }
        this._initialSourceOptions = sourceOptions;
        this._sourceOptions = sourceOptions;
        this._options = loadContainerOptions(this._engine, this, this._initialSourceOptions, this.sourceOptions);
        this.actualOptions = loadContainerOptions(this._engine, this, this._options);
        return this.refresh();
    }
    async start() {
        if (!guardCheck(this) || this.started) {
            return;
        }
        await this.init();
        this.started = true;
        await new Promise((resolve)=>{
            const start = async ()=>{
                this._eventListeners.addListeners();
                if (this.interactivity.element instanceof HTMLElement && this._intersectionObserver) {
                    this._intersectionObserver.observe(this.interactivity.element);
                }
                for (const plugin of this.plugins.values()){
                    await plugin.start?.();
                }
                this._engine.dispatchEvent(__TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Types$2f$EventType$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["EventType"].containerStarted, {
                    container: this
                });
                this.play();
                resolve();
            };
            this._delayTimeout = setTimeout(()=>void start(), this._delay);
        });
    }
    stop() {
        if (!guardCheck(this) || !this.started) {
            return;
        }
        if (this._delayTimeout) {
            clearTimeout(this._delayTimeout);
            delete this._delayTimeout;
        }
        this._firstStart = true;
        this.started = false;
        this._eventListeners.removeListeners();
        this.pause();
        this.particles.clear();
        this.canvas.stop();
        if (this.interactivity.element instanceof HTMLElement && this._intersectionObserver) {
            this._intersectionObserver.unobserve(this.interactivity.element);
        }
        for (const plugin of this.plugins.values()){
            plugin.stop?.();
        }
        for (const key of this.plugins.keys()){
            this.plugins.delete(key);
        }
        this._sourceOptions = this._options;
        this._engine.dispatchEvent(__TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Types$2f$EventType$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["EventType"].containerStopped, {
            container: this
        });
    }
    updateActualOptions() {
        this.actualOptions.responsive = [];
        const newMaxWidth = this.actualOptions.setResponsive(this.canvas.size.width, this.retina.pixelRatio, this._options);
        this.actualOptions.setTheme(this._currentTheme);
        if (this._responsiveMaxWidth === newMaxWidth) {
            return false;
        }
        this._responsiveMaxWidth = newMaxWidth;
        return true;
    }
}
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/EventDispatcher.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "EventDispatcher",
    ()=>EventDispatcher
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Core/Utils/Constants.js [app-ssr] (ecmascript)");
;
class EventDispatcher {
    constructor(){
        this._listeners = new Map();
    }
    addEventListener(type, listener) {
        this.removeEventListener(type, listener);
        let arr = this._listeners.get(type);
        if (!arr) {
            arr = [];
            this._listeners.set(type, arr);
        }
        arr.push(listener);
    }
    dispatchEvent(type, args) {
        const listeners = this._listeners.get(type);
        listeners?.forEach((handler)=>handler(args));
    }
    hasEventListener(type) {
        return !!this._listeners.get(type);
    }
    removeAllEventListeners(type) {
        if (!type) {
            this._listeners = new Map();
        } else {
            this._listeners.delete(type);
        }
    }
    removeEventListener(type, listener) {
        const arr = this._listeners.get(type);
        if (!arr) {
            return;
        }
        const length = arr.length, idx = arr.indexOf(listener);
        if (idx < __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["minIndex"]) {
            return;
        }
        if (length === __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["deleteCount"]) {
            this._listeners.delete(type);
        } else {
            arr.splice(idx, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["deleteCount"]);
        }
    }
}
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Core/Engine.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Engine",
    ()=>Engine
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Core/Utils/Constants.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/Utils.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Container$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Core/Container.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$EventDispatcher$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/EventDispatcher.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Types$2f$EventType$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Enums/Types/EventType.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/NumberUtils.js [app-ssr] (ecmascript)");
;
;
;
;
;
;
async function getItemsFromInitializer(container, map, initializers, force = false) {
    let res = map.get(container);
    if (!res || force) {
        res = await Promise.all([
            ...initializers.values()
        ].map((t)=>t(container)));
        map.set(container, res);
    }
    return res;
}
async function getDataFromUrl(data) {
    const url = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["itemFromSingleOrMultiple"])(data.url, data.index);
    if (!url) {
        return data.fallback;
    }
    const response = await fetch(url);
    if (response.ok) {
        return await response.json();
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getLogger"])().error(`${__TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["errorPrefix"]} ${response.status} while retrieving config file`);
    return data.fallback;
}
const getCanvasFromContainer = (domContainer)=>{
    let canvasEl;
    if (domContainer instanceof HTMLCanvasElement || domContainer.tagName.toLowerCase() === __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["canvasTag"]) {
        canvasEl = domContainer;
        if (!canvasEl.dataset[__TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["generatedAttribute"]]) {
            canvasEl.dataset[__TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["generatedAttribute"]] = __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["generatedFalse"];
        }
    } else {
        const existingCanvases = domContainer.getElementsByTagName(__TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["canvasTag"]);
        if (existingCanvases.length) {
            canvasEl = existingCanvases[__TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["canvasFirstIndex"]];
            canvasEl.dataset[__TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["generatedAttribute"]] = __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["generatedFalse"];
        } else {
            canvasEl = document.createElement(__TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["canvasTag"]);
            canvasEl.dataset[__TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["generatedAttribute"]] = __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["generatedTrue"];
            domContainer.appendChild(canvasEl);
        }
    }
    const fullPercent = "100%";
    if (!canvasEl.style.width) {
        canvasEl.style.width = fullPercent;
    }
    if (!canvasEl.style.height) {
        canvasEl.style.height = fullPercent;
    }
    return canvasEl;
}, getDomContainer = (id, source)=>{
    let domContainer = source ?? document.getElementById(id);
    if (domContainer) {
        return domContainer;
    }
    domContainer = document.createElement("div");
    domContainer.id = id;
    domContainer.dataset[__TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["generatedAttribute"]] = __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["generatedTrue"];
    document.body.append(domContainer);
    return domContainer;
};
class Engine {
    constructor(){
        this._configs = new Map();
        this._domArray = [];
        this._eventDispatcher = new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$EventDispatcher$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["EventDispatcher"]();
        this._initialized = false;
        this.plugins = [];
        this.colorManagers = new Map();
        this.easingFunctions = new Map();
        this._initializers = {
            interactors: new Map(),
            movers: new Map(),
            updaters: new Map()
        };
        this.interactors = new Map();
        this.movers = new Map();
        this.updaters = new Map();
        this.presets = new Map();
        this.effectDrawers = new Map();
        this.shapeDrawers = new Map();
        this.pathGenerators = new Map();
    }
    get configs() {
        const res = {};
        for (const [name, config] of this._configs){
            res[name] = config;
        }
        return res;
    }
    get items() {
        return this._domArray;
    }
    get version() {
        return "3.9.1";
    }
    async addColorManager(manager, refresh = true) {
        this.colorManagers.set(manager.key, manager);
        await this.refresh(refresh);
    }
    addConfig(config) {
        const key = config.key ?? config.name ?? "default";
        this._configs.set(key, config);
        this._eventDispatcher.dispatchEvent(__TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Types$2f$EventType$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["EventType"].configAdded, {
            data: {
                name: key,
                config
            }
        });
    }
    async addEasing(name, easing, refresh = true) {
        if (this.getEasing(name)) {
            return;
        }
        this.easingFunctions.set(name, easing);
        await this.refresh(refresh);
    }
    async addEffect(effect, drawer, refresh = true) {
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["executeOnSingleOrMultiple"])(effect, (type)=>{
            if (!this.getEffectDrawer(type)) {
                this.effectDrawers.set(type, drawer);
            }
        });
        await this.refresh(refresh);
    }
    addEventListener(type, listener) {
        this._eventDispatcher.addEventListener(type, listener);
    }
    async addInteractor(name, interactorInitializer, refresh = true) {
        this._initializers.interactors.set(name, interactorInitializer);
        await this.refresh(refresh);
    }
    async addMover(name, moverInitializer, refresh = true) {
        this._initializers.movers.set(name, moverInitializer);
        await this.refresh(refresh);
    }
    async addParticleUpdater(name, updaterInitializer, refresh = true) {
        this._initializers.updaters.set(name, updaterInitializer);
        await this.refresh(refresh);
    }
    async addPathGenerator(name, generator, refresh = true) {
        if (!this.getPathGenerator(name)) {
            this.pathGenerators.set(name, generator);
        }
        await this.refresh(refresh);
    }
    async addPlugin(plugin, refresh = true) {
        if (!this.getPlugin(plugin.id)) {
            this.plugins.push(plugin);
        }
        await this.refresh(refresh);
    }
    async addPreset(preset, options, override = false, refresh = true) {
        if (override || !this.getPreset(preset)) {
            this.presets.set(preset, options);
        }
        await this.refresh(refresh);
    }
    async addShape(drawer, refresh = true) {
        for (const validType of drawer.validTypes){
            if (this.getShapeDrawer(validType)) {
                continue;
            }
            this.shapeDrawers.set(validType, drawer);
        }
        await this.refresh(refresh);
    }
    checkVersion(pluginVersion) {
        if (this.version === pluginVersion) {
            return;
        }
        throw new Error(`The tsParticles version is different from the loaded plugins version. Engine version: ${this.version}. Plugin version: ${pluginVersion}`);
    }
    clearPlugins(container) {
        this.updaters.delete(container);
        this.movers.delete(container);
        this.interactors.delete(container);
    }
    dispatchEvent(type, args) {
        this._eventDispatcher.dispatchEvent(type, args);
    }
    dom() {
        return this.items;
    }
    domItem(index) {
        return this.item(index);
    }
    async getAvailablePlugins(container) {
        const res = new Map();
        for (const plugin of this.plugins){
            if (plugin.needsPlugin(container.actualOptions)) {
                res.set(plugin.id, await plugin.getPlugin(container));
            }
        }
        return res;
    }
    getEasing(name) {
        return this.easingFunctions.get(name) ?? ((value)=>value);
    }
    getEffectDrawer(type) {
        return this.effectDrawers.get(type);
    }
    async getInteractors(container, force = false) {
        return getItemsFromInitializer(container, this.interactors, this._initializers.interactors, force);
    }
    async getMovers(container, force = false) {
        return getItemsFromInitializer(container, this.movers, this._initializers.movers, force);
    }
    getPathGenerator(type) {
        return this.pathGenerators.get(type);
    }
    getPlugin(plugin) {
        return this.plugins.find((t)=>t.id === plugin);
    }
    getPreset(preset) {
        return this.presets.get(preset);
    }
    getShapeDrawer(type) {
        return this.shapeDrawers.get(type);
    }
    getSupportedEffects() {
        return this.effectDrawers.keys();
    }
    getSupportedShapes() {
        return this.shapeDrawers.keys();
    }
    async getUpdaters(container, force = false) {
        return getItemsFromInitializer(container, this.updaters, this._initializers.updaters, force);
    }
    init() {
        if (this._initialized) {
            return;
        }
        this._initialized = true;
    }
    item(index) {
        const { items } = this, item = items[index];
        if (!item || item.destroyed) {
            items.splice(index, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["removeDeleteCount"]);
            return;
        }
        return item;
    }
    async load(params) {
        const id = params.id ?? params.element?.id ?? `tsparticles${Math.floor((0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getRandom"])() * __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["loadRandomFactor"])}`, { index, url } = params, options = url ? await getDataFromUrl({
            fallback: params.options,
            url,
            index
        }) : params.options, currentOptions = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["itemFromSingleOrMultiple"])(options, index), { items } = this, oldIndex = items.findIndex((v)=>v.id.description === id), newItem = new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Container$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Container"](this, id, currentOptions);
        if (oldIndex >= __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["loadMinIndex"]) {
            const old = this.item(oldIndex), deleteCount = old ? __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["one"] : __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["none"];
            if (old && !old.destroyed) {
                old.destroy(false);
            }
            items.splice(oldIndex, deleteCount, newItem);
        } else {
            items.push(newItem);
        }
        const domContainer = getDomContainer(id, params.element), canvasEl = getCanvasFromContainer(domContainer);
        newItem.canvas.loadCanvas(canvasEl);
        await newItem.start();
        return newItem;
    }
    loadOptions(options, sourceOptions) {
        this.plugins.forEach((plugin)=>plugin.loadOptions?.(options, sourceOptions));
    }
    loadParticlesOptions(container, options, ...sourceOptions) {
        const updaters = this.updaters.get(container);
        if (!updaters) {
            return;
        }
        updaters.forEach((updater)=>updater.loadOptions?.(options, ...sourceOptions));
    }
    async refresh(refresh = true) {
        if (!refresh) {
            return;
        }
        await Promise.all(this.items.map((t)=>t.refresh()));
    }
    removeEventListener(type, listener) {
        this._eventDispatcher.removeEventListener(type, listener);
    }
    setOnClickHandler(callback) {
        const { items } = this;
        if (!items.length) {
            throw new Error(`${__TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["errorPrefix"]} can only set click handlers after calling tsParticles.load()`);
        }
        items.forEach((item)=>item.addClickHandler(callback));
    }
}
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/init.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "init",
    ()=>init
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Engine$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Core/Engine.js [app-ssr] (ecmascript)");
;
function init() {
    const engine = new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Engine$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Engine"]();
    engine.init();
    return engine;
}
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Core/Utils/ExternalInteractorBase.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ExternalInteractorBase",
    ()=>ExternalInteractorBase
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Types$2f$InteractorType$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Enums/Types/InteractorType.js [app-ssr] (ecmascript)");
;
class ExternalInteractorBase {
    constructor(container){
        this.type = __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Types$2f$InteractorType$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["InteractorType"].external;
        this.container = container;
    }
}
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Core/Utils/ParticlesInteractorBase.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ParticlesInteractorBase",
    ()=>ParticlesInteractorBase
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Types$2f$InteractorType$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Enums/Types/InteractorType.js [app-ssr] (ecmascript)");
;
class ParticlesInteractorBase {
    constructor(container){
        this.type = __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Types$2f$InteractorType$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["InteractorType"].particles;
        this.container = container;
    }
}
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Enums/Directions/RotateDirection.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "RotateDirection",
    ()=>RotateDirection
]);
var RotateDirection;
(function(RotateDirection) {
    RotateDirection["clockwise"] = "clockwise";
    RotateDirection["counterClockwise"] = "counter-clockwise";
    RotateDirection["random"] = "random";
})(RotateDirection || (RotateDirection = {}));
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Enums/Types/GradientType.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "GradientType",
    ()=>GradientType
]);
var GradientType;
(function(GradientType) {
    GradientType["linear"] = "linear";
    GradientType["radial"] = "radial";
    GradientType["random"] = "random";
})(GradientType || (GradientType = {}));
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Enums/Types/EasingType.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "EasingType",
    ()=>EasingType
]);
var EasingType;
(function(EasingType) {
    EasingType["easeInBack"] = "ease-in-back";
    EasingType["easeInCirc"] = "ease-in-circ";
    EasingType["easeInCubic"] = "ease-in-cubic";
    EasingType["easeInLinear"] = "ease-in-linear";
    EasingType["easeInQuad"] = "ease-in-quad";
    EasingType["easeInQuart"] = "ease-in-quart";
    EasingType["easeInQuint"] = "ease-in-quint";
    EasingType["easeInExpo"] = "ease-in-expo";
    EasingType["easeInSine"] = "ease-in-sine";
    EasingType["easeOutBack"] = "ease-out-back";
    EasingType["easeOutCirc"] = "ease-out-circ";
    EasingType["easeOutCubic"] = "ease-out-cubic";
    EasingType["easeOutLinear"] = "ease-out-linear";
    EasingType["easeOutQuad"] = "ease-out-quad";
    EasingType["easeOutQuart"] = "ease-out-quart";
    EasingType["easeOutQuint"] = "ease-out-quint";
    EasingType["easeOutExpo"] = "ease-out-expo";
    EasingType["easeOutSine"] = "ease-out-sine";
    EasingType["easeInOutBack"] = "ease-in-out-back";
    EasingType["easeInOutCirc"] = "ease-in-out-circ";
    EasingType["easeInOutCubic"] = "ease-in-out-cubic";
    EasingType["easeInOutLinear"] = "ease-in-out-linear";
    EasingType["easeInOutQuad"] = "ease-in-out-quad";
    EasingType["easeInOutQuart"] = "ease-in-out-quart";
    EasingType["easeInOutQuint"] = "ease-in-out-quint";
    EasingType["easeInOutExpo"] = "ease-in-out-expo";
    EasingType["easeInOutSine"] = "ease-in-out-sine";
})(EasingType || (EasingType = {}));
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/exports.js [app-ssr] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Core/Utils/Constants.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$ExternalInteractorBase$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Core/Utils/ExternalInteractorBase.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$ParticlesInteractorBase$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Core/Utils/ParticlesInteractorBase.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Point$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Core/Utils/Point.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Ranges$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Core/Utils/Ranges.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Vectors$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Core/Utils/Vectors.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Directions$2f$MoveDirection$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Enums/Directions/MoveDirection.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Directions$2f$RotateDirection$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Enums/Directions/RotateDirection.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Directions$2f$OutModeDirection$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Enums/Directions/OutModeDirection.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Modes$2f$AnimationMode$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Enums/Modes/AnimationMode.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Modes$2f$CollisionMode$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Enums/Modes/CollisionMode.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Modes$2f$LimitMode$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Enums/Modes/LimitMode.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Modes$2f$OutMode$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Enums/Modes/OutMode.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Modes$2f$PixelMode$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Enums/Modes/PixelMode.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Modes$2f$ThemeMode$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Enums/Modes/ThemeMode.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Modes$2f$ResponsiveMode$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Enums/Modes/ResponsiveMode.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Types$2f$AlterType$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Enums/Types/AlterType.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Types$2f$DestroyType$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Enums/Types/DestroyType.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Types$2f$GradientType$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Enums/Types/GradientType.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Types$2f$InteractorType$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Enums/Types/InteractorType.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Types$2f$ParticleOutType$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Enums/Types/ParticleOutType.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Types$2f$StartValueType$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Enums/Types/StartValueType.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Types$2f$DivType$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Enums/Types/DivType.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Types$2f$EasingType$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Enums/Types/EasingType.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Types$2f$EventType$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Enums/Types/EventType.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$AnimationStatus$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Enums/AnimationStatus.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$InteractivityDetect$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Enums/InteractivityDetect.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$AnimatableColor$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Classes/AnimatableColor.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$AnimationOptions$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Classes/AnimationOptions.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$Background$2f$Background$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Classes/Background/Background.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$BackgroundMask$2f$BackgroundMask$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Classes/BackgroundMask/BackgroundMask.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$BackgroundMask$2f$BackgroundMaskCover$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Classes/BackgroundMask/BackgroundMaskCover.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$ColorAnimation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Classes/ColorAnimation.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$FullScreen$2f$FullScreen$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Classes/FullScreen/FullScreen.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$HslAnimation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Classes/HslAnimation.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$Interactivity$2f$Events$2f$ClickEvent$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Classes/Interactivity/Events/ClickEvent.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$Interactivity$2f$Events$2f$DivEvent$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Classes/Interactivity/Events/DivEvent.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$Interactivity$2f$Events$2f$Events$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Classes/Interactivity/Events/Events.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$Interactivity$2f$Events$2f$HoverEvent$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Classes/Interactivity/Events/HoverEvent.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$Interactivity$2f$Events$2f$Parallax$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Classes/Interactivity/Events/Parallax.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$Interactivity$2f$Events$2f$ResizeEvent$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Classes/Interactivity/Events/ResizeEvent.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$Interactivity$2f$Interactivity$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Classes/Interactivity/Interactivity.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$Interactivity$2f$Modes$2f$Modes$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Classes/Interactivity/Modes/Modes.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$ManualParticle$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Classes/ManualParticle.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$Options$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Classes/Options.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$OptionsColor$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Classes/OptionsColor.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$Particles$2f$Bounce$2f$ParticlesBounce$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Classes/Particles/Bounce/ParticlesBounce.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$Particles$2f$Bounce$2f$ParticlesBounceFactor$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Classes/Particles/Bounce/ParticlesBounceFactor.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$Particles$2f$Collisions$2f$Collisions$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Classes/Particles/Collisions/Collisions.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$Particles$2f$Collisions$2f$CollisionsAbsorb$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Classes/Particles/Collisions/CollisionsAbsorb.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$Particles$2f$Collisions$2f$CollisionsOverlap$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Classes/Particles/Collisions/CollisionsOverlap.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$Particles$2f$ParticlesOptions$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Classes/Particles/ParticlesOptions.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$Particles$2f$Shadow$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Classes/Particles/Shadow.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$Particles$2f$Stroke$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Classes/Particles/Stroke.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$Particles$2f$Move$2f$MoveAttract$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Classes/Particles/Move/MoveAttract.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$Particles$2f$Move$2f$Move$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Classes/Particles/Move/Move.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$Particles$2f$Move$2f$MoveAngle$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Classes/Particles/Move/MoveAngle.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$Particles$2f$Move$2f$MoveCenter$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Classes/Particles/Move/MoveCenter.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$Particles$2f$Move$2f$MoveGravity$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Classes/Particles/Move/MoveGravity.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$Particles$2f$Move$2f$OutModes$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Classes/Particles/Move/OutModes.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$Particles$2f$Move$2f$Path$2f$MovePath$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Classes/Particles/Move/Path/MovePath.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$Particles$2f$Move$2f$Spin$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Classes/Particles/Move/Spin.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$Particles$2f$Move$2f$MoveTrail$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Classes/Particles/Move/MoveTrail.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$Particles$2f$Number$2f$ParticlesNumber$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Classes/Particles/Number/ParticlesNumber.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$Particles$2f$Number$2f$ParticlesNumberLimit$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Classes/Particles/Number/ParticlesNumberLimit.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$Particles$2f$Number$2f$ParticlesDensity$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Classes/Particles/Number/ParticlesDensity.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$Particles$2f$Opacity$2f$Opacity$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Classes/Particles/Opacity/Opacity.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$Particles$2f$Opacity$2f$OpacityAnimation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Classes/Particles/Opacity/OpacityAnimation.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$Particles$2f$Shape$2f$Shape$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Classes/Particles/Shape/Shape.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$Particles$2f$Size$2f$Size$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Classes/Particles/Size/Size.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$Particles$2f$Size$2f$SizeAnimation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Classes/Particles/Size/SizeAnimation.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$Particles$2f$ZIndex$2f$ZIndex$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Classes/Particles/ZIndex/ZIndex.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$Responsive$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Classes/Responsive.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$Theme$2f$Theme$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Classes/Theme/Theme.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$Theme$2f$ThemeDefault$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Classes/Theme/ThemeDefault.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$ValueWithRandom$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Classes/ValueWithRandom.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$CanvasUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/CanvasUtils.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$ColorUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/ColorUtils.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/NumberUtils.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$OptionsUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/OptionsUtils.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/Utils.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/TypeUtils.js [app-ssr] (ecmascript)");
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Core/Interfaces/Colors.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
;
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Core/Interfaces/IBounds.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
;
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Core/Interfaces/IBubbleParticleData.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
;
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Core/Interfaces/ICircleBouncer.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
;
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Core/Interfaces/IColorManager.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
;
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Core/Interfaces/IContainerInteractivity.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
;
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Core/Interfaces/IContainerPlugin.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
;
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Core/Interfaces/ICoordinates.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
;
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Core/Interfaces/IDelta.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
;
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Core/Interfaces/IDimension.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
;
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Core/Interfaces/IDistance.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
;
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Core/Interfaces/IDrawParticleParams.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
;
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Core/Interfaces/IEffectDrawer.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
;
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Core/Interfaces/IExternalInteractor.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
;
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Core/Interfaces/IInteractor.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
;
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Core/Interfaces/ILoadParams.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
;
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Core/Interfaces/IMouseData.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
;
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Core/Interfaces/IMovePathGenerator.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
;
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Core/Interfaces/IParticleColorStyle.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
;
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Core/Interfaces/IParticleHslAnimation.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
;
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Core/Interfaces/IParticleLife.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
;
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Core/Interfaces/IParticleMover.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
;
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Core/Interfaces/IParticleRetinaProps.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
;
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Core/Interfaces/IParticleRoll.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
;
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Core/Interfaces/IParticleTransformValues.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
;
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Core/Interfaces/IParticleUpdater.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
;
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Core/Interfaces/IParticleValueAnimation.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
;
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Core/Interfaces/IParticlesInteractor.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
;
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Core/Interfaces/IPlugin.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
;
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Core/Interfaces/IPositionFromSizeParams.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
;
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Core/Interfaces/IRangeValue.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
;
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Core/Interfaces/IRectSideResult.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
;
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Core/Interfaces/IShapeDrawData.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
;
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Core/Interfaces/IShapeDrawer.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
;
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Core/Interfaces/IShapeValues.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
;
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Core/Interfaces/ISlowParticleData.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
;
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Core/Interfaces/ITrailFillData.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
;
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Interfaces/Background/IBackground.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
;
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Interfaces/BackgroundMask/IBackgroundMask.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
;
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Interfaces/BackgroundMask/IBackgroundMaskCover.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
;
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Interfaces/FullScreen/IFullScreen.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
;
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Interfaces/IAnimatable.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
;
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Interfaces/IAnimatableColor.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
;
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Interfaces/IAnimation.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
;
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Interfaces/IColorAnimation.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
;
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Interfaces/IHslAnimation.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
;
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Interfaces/IManualParticle.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
;
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Interfaces/IOptionLoader.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
;
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Interfaces/IOptions.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
;
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Interfaces/IOptionsColor.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
;
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Interfaces/IResponsive.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
;
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Interfaces/IValueWithRandom.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
;
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Interfaces/Interactivity/Events/IClickEvent.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
;
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Interfaces/Interactivity/Events/IDivEvent.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
;
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Interfaces/Interactivity/Events/IEvents.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
;
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Interfaces/Interactivity/Events/IHoverEvent.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
;
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Interfaces/Interactivity/Events/IParallax.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
;
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Interfaces/Interactivity/Events/IResizeEvent.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
;
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Interfaces/Interactivity/Modes/IModeDiv.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
;
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Interfaces/Interactivity/Modes/IModes.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
;
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Interfaces/Interactivity/IInteractivity.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
;
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Interfaces/Particles/Bounce/IParticlesBounce.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
;
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Interfaces/Particles/Collisions/ICollisions.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
;
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Interfaces/Particles/Collisions/ICollisionsAbsorb.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
;
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Interfaces/Particles/Collisions/ICollisionsOverlap.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
;
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Interfaces/Particles/Effect/IEffect.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
;
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Interfaces/Particles/IParticlesOptions.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
;
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Interfaces/Particles/IShadow.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
;
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Interfaces/Particles/IStroke.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
;
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Interfaces/Particles/Move/IMoveAttract.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
;
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Interfaces/Particles/Move/IMove.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
;
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Interfaces/Particles/Move/IMoveAngle.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
;
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Interfaces/Particles/Move/IMoveCenter.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
;
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Interfaces/Particles/Move/IMoveGravity.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
;
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Interfaces/Particles/Move/Path/IMovePath.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
;
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Interfaces/Particles/Move/IOutModes.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
;
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Interfaces/Particles/Move/ISpin.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
;
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Interfaces/Particles/Move/IMoveTrail.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
;
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Interfaces/Particles/Number/IParticlesDensity.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
;
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Interfaces/Particles/Number/IParticlesNumber.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
;
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Interfaces/Particles/Number/IParticlesNumberLimit.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
;
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Interfaces/Particles/Opacity/IOpacity.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
;
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Interfaces/Particles/Opacity/IOpacityAnimation.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
;
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Interfaces/Particles/Shape/IShape.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
;
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Interfaces/Particles/Size/ISize.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
;
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Interfaces/Particles/Size/ISizeAnimation.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
;
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Interfaces/Particles/ZIndex/IZIndex.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
;
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Interfaces/Theme/ITheme.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
;
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Interfaces/Theme/IThemeDefault.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
;
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Types/CustomEventArgs.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
;
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Types/CustomEventListener.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
;
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Types/ExportResult.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
;
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Types/ISourceOptions.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
;
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Types/ParticlesGroups.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
;
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Types/PathOptions.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
;
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Types/RangeValue.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
;
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Types/RecursivePartial.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
;
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Types/ShapeData.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
;
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/Types/SingleOrMultiple.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
;
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/export-types.js [app-ssr] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Interfaces$2f$Colors$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Core/Interfaces/Colors.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Interfaces$2f$IBounds$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Core/Interfaces/IBounds.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Interfaces$2f$IBubbleParticleData$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Core/Interfaces/IBubbleParticleData.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Interfaces$2f$ICircleBouncer$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Core/Interfaces/ICircleBouncer.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Interfaces$2f$IColorManager$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Core/Interfaces/IColorManager.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Interfaces$2f$IContainerInteractivity$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Core/Interfaces/IContainerInteractivity.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Interfaces$2f$IContainerPlugin$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Core/Interfaces/IContainerPlugin.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Interfaces$2f$ICoordinates$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Core/Interfaces/ICoordinates.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Interfaces$2f$IDelta$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Core/Interfaces/IDelta.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Interfaces$2f$IDimension$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Core/Interfaces/IDimension.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Interfaces$2f$IDistance$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Core/Interfaces/IDistance.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Interfaces$2f$IDrawParticleParams$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Core/Interfaces/IDrawParticleParams.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Interfaces$2f$IEffectDrawer$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Core/Interfaces/IEffectDrawer.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Interfaces$2f$IExternalInteractor$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Core/Interfaces/IExternalInteractor.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Interfaces$2f$IInteractor$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Core/Interfaces/IInteractor.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Interfaces$2f$ILoadParams$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Core/Interfaces/ILoadParams.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Interfaces$2f$IMouseData$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Core/Interfaces/IMouseData.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Interfaces$2f$IMovePathGenerator$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Core/Interfaces/IMovePathGenerator.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Interfaces$2f$IParticleColorStyle$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Core/Interfaces/IParticleColorStyle.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Interfaces$2f$IParticleHslAnimation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Core/Interfaces/IParticleHslAnimation.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Interfaces$2f$IParticleLife$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Core/Interfaces/IParticleLife.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Interfaces$2f$IParticleMover$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Core/Interfaces/IParticleMover.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Interfaces$2f$IParticleRetinaProps$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Core/Interfaces/IParticleRetinaProps.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Interfaces$2f$IParticleRoll$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Core/Interfaces/IParticleRoll.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Interfaces$2f$IParticleTransformValues$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Core/Interfaces/IParticleTransformValues.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Interfaces$2f$IParticleUpdater$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Core/Interfaces/IParticleUpdater.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Interfaces$2f$IParticleValueAnimation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Core/Interfaces/IParticleValueAnimation.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Interfaces$2f$IParticlesInteractor$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Core/Interfaces/IParticlesInteractor.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Interfaces$2f$IPlugin$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Core/Interfaces/IPlugin.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Interfaces$2f$IPositionFromSizeParams$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Core/Interfaces/IPositionFromSizeParams.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Interfaces$2f$IRangeValue$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Core/Interfaces/IRangeValue.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Interfaces$2f$IRectSideResult$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Core/Interfaces/IRectSideResult.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Interfaces$2f$IShapeDrawData$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Core/Interfaces/IShapeDrawData.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Interfaces$2f$IShapeDrawer$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Core/Interfaces/IShapeDrawer.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Interfaces$2f$IShapeValues$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Core/Interfaces/IShapeValues.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Interfaces$2f$ISlowParticleData$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Core/Interfaces/ISlowParticleData.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Interfaces$2f$ITrailFillData$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Core/Interfaces/ITrailFillData.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Interfaces$2f$Background$2f$IBackground$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Interfaces/Background/IBackground.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Interfaces$2f$BackgroundMask$2f$IBackgroundMask$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Interfaces/BackgroundMask/IBackgroundMask.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Interfaces$2f$BackgroundMask$2f$IBackgroundMaskCover$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Interfaces/BackgroundMask/IBackgroundMaskCover.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Interfaces$2f$FullScreen$2f$IFullScreen$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Interfaces/FullScreen/IFullScreen.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Interfaces$2f$IAnimatable$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Interfaces/IAnimatable.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Interfaces$2f$IAnimatableColor$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Interfaces/IAnimatableColor.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Interfaces$2f$IAnimation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Interfaces/IAnimation.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Interfaces$2f$IColorAnimation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Interfaces/IColorAnimation.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Interfaces$2f$IHslAnimation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Interfaces/IHslAnimation.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Interfaces$2f$IManualParticle$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Interfaces/IManualParticle.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Interfaces$2f$IOptionLoader$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Interfaces/IOptionLoader.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Interfaces$2f$IOptions$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Interfaces/IOptions.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Interfaces$2f$IOptionsColor$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Interfaces/IOptionsColor.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Interfaces$2f$IResponsive$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Interfaces/IResponsive.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Interfaces$2f$IValueWithRandom$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Interfaces/IValueWithRandom.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Interfaces$2f$Interactivity$2f$Events$2f$IClickEvent$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Interfaces/Interactivity/Events/IClickEvent.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Interfaces$2f$Interactivity$2f$Events$2f$IDivEvent$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Interfaces/Interactivity/Events/IDivEvent.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Interfaces$2f$Interactivity$2f$Events$2f$IEvents$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Interfaces/Interactivity/Events/IEvents.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Interfaces$2f$Interactivity$2f$Events$2f$IHoverEvent$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Interfaces/Interactivity/Events/IHoverEvent.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Interfaces$2f$Interactivity$2f$Events$2f$IParallax$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Interfaces/Interactivity/Events/IParallax.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Interfaces$2f$Interactivity$2f$Events$2f$IResizeEvent$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Interfaces/Interactivity/Events/IResizeEvent.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Interfaces$2f$Interactivity$2f$Modes$2f$IModeDiv$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Interfaces/Interactivity/Modes/IModeDiv.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Interfaces$2f$Interactivity$2f$Modes$2f$IModes$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Interfaces/Interactivity/Modes/IModes.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Interfaces$2f$Interactivity$2f$IInteractivity$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Interfaces/Interactivity/IInteractivity.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Interfaces$2f$Particles$2f$Bounce$2f$IParticlesBounce$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Interfaces/Particles/Bounce/IParticlesBounce.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Interfaces$2f$Particles$2f$Collisions$2f$ICollisions$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Interfaces/Particles/Collisions/ICollisions.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Interfaces$2f$Particles$2f$Collisions$2f$ICollisionsAbsorb$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Interfaces/Particles/Collisions/ICollisionsAbsorb.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Interfaces$2f$Particles$2f$Collisions$2f$ICollisionsOverlap$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Interfaces/Particles/Collisions/ICollisionsOverlap.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Interfaces$2f$Particles$2f$Effect$2f$IEffect$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Interfaces/Particles/Effect/IEffect.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Interfaces$2f$Particles$2f$IParticlesOptions$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Interfaces/Particles/IParticlesOptions.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Interfaces$2f$Particles$2f$IShadow$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Interfaces/Particles/IShadow.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Interfaces$2f$Particles$2f$IStroke$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Interfaces/Particles/IStroke.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Interfaces$2f$Particles$2f$Move$2f$IMoveAttract$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Interfaces/Particles/Move/IMoveAttract.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Interfaces$2f$Particles$2f$Move$2f$IMove$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Interfaces/Particles/Move/IMove.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Interfaces$2f$Particles$2f$Move$2f$IMoveAngle$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Interfaces/Particles/Move/IMoveAngle.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Interfaces$2f$Particles$2f$Move$2f$IMoveCenter$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Interfaces/Particles/Move/IMoveCenter.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Interfaces$2f$Particles$2f$Move$2f$IMoveGravity$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Interfaces/Particles/Move/IMoveGravity.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Interfaces$2f$Particles$2f$Move$2f$Path$2f$IMovePath$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Interfaces/Particles/Move/Path/IMovePath.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Interfaces$2f$Particles$2f$Move$2f$IOutModes$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Interfaces/Particles/Move/IOutModes.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Interfaces$2f$Particles$2f$Move$2f$ISpin$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Interfaces/Particles/Move/ISpin.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Interfaces$2f$Particles$2f$Move$2f$IMoveTrail$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Interfaces/Particles/Move/IMoveTrail.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Interfaces$2f$Particles$2f$Number$2f$IParticlesDensity$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Interfaces/Particles/Number/IParticlesDensity.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Interfaces$2f$Particles$2f$Number$2f$IParticlesNumber$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Interfaces/Particles/Number/IParticlesNumber.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Interfaces$2f$Particles$2f$Number$2f$IParticlesNumberLimit$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Interfaces/Particles/Number/IParticlesNumberLimit.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Interfaces$2f$Particles$2f$Opacity$2f$IOpacity$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Interfaces/Particles/Opacity/IOpacity.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Interfaces$2f$Particles$2f$Opacity$2f$IOpacityAnimation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Interfaces/Particles/Opacity/IOpacityAnimation.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Interfaces$2f$Particles$2f$Shape$2f$IShape$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Interfaces/Particles/Shape/IShape.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Interfaces$2f$Particles$2f$Size$2f$ISize$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Interfaces/Particles/Size/ISize.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Interfaces$2f$Particles$2f$Size$2f$ISizeAnimation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Interfaces/Particles/Size/ISizeAnimation.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Interfaces$2f$Particles$2f$ZIndex$2f$IZIndex$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Interfaces/Particles/ZIndex/IZIndex.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Interfaces$2f$Theme$2f$ITheme$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Interfaces/Theme/ITheme.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Interfaces$2f$Theme$2f$IThemeDefault$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Interfaces/Theme/IThemeDefault.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Types$2f$CustomEventArgs$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Types/CustomEventArgs.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Types$2f$CustomEventListener$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Types/CustomEventListener.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Types$2f$ExportResult$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Types/ExportResult.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Types$2f$ISourceOptions$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Types/ISourceOptions.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Types$2f$ParticlesGroups$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Types/ParticlesGroups.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Types$2f$PathOptions$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Types/PathOptions.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Types$2f$RangeValue$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Types/RangeValue.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Types$2f$RecursivePartial$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Types/RecursivePartial.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Types$2f$ShapeData$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Types/ShapeData.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Types$2f$SingleOrMultiple$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Types/SingleOrMultiple.js [app-ssr] (ecmascript)");
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
}),
"[project]/theitern/node_modules/@tsparticles/engine/esm/index.js [app-ssr] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "tsParticles",
    ()=>tsParticles
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$init$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/init.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/Utils.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$exports$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/exports.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$export$2d$types$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/export-types.js [app-ssr] (ecmascript) <locals>");
;
;
const tsParticles = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$init$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["init"])();
if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isSsr"])()) {
    window.tsParticles = tsParticles;
}
;
;
;
}),
"[project]/theitern/node_modules/@tsparticles/react/dist/Particles.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>f
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/index.js [app-ssr] (ecmascript) <locals>");
;
;
;
const f = (t)=>{
    const i = t.id ?? "tsparticles";
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        let e;
        return __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["tsParticles"].load({
            id: i,
            url: t.url,
            options: t.options
        }).then((l)=>{
            var a;
            e = l, (a = t.particlesLoaded) == null || a.call(t, l);
        }), ()=>{
            e == null || e.destroy();
        };
    }, [
        i,
        t,
        t.url,
        t.options
    ]), /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsx"])("div", {
        id: i,
        className: t.className
    });
};
;
}),
"[project]/theitern/node_modules/@tsparticles/react/dist/index.js [app-ssr] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "initParticlesEngine",
    ()=>n
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$react$2f$dist$2f$Particles$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/react/dist/Particles.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
;
;
;
;
async function n(t) {
    await t(__TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["tsParticles"]);
}
;
}),
"[project]/theitern/node_modules/@tsparticles/move-base/esm/Utils.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "applyDistance",
    ()=>applyDistance,
    "applyPath",
    ()=>applyPath,
    "getProximitySpeedFactor",
    ()=>getProximitySpeedFactor,
    "initSpin",
    ()=>initSpin,
    "move",
    ()=>move,
    "spin",
    ()=>spin
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Directions$2f$RotateDirection$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Enums/Directions/RotateDirection.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/NumberUtils.js [app-ssr] (ecmascript)");
;
const half = 0.5, double = 2, minVelocity = 0, identity = 1, moveSpeedFactor = 60, minSpinRadius = 0, spinFactor = 0.01, doublePI = Math.PI * double;
function applyDistance(particle) {
    const initialPosition = particle.initialPosition, { dx, dy } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getDistances"])(initialPosition, particle.position), dxFixed = Math.abs(dx), dyFixed = Math.abs(dy), { maxDistance } = particle.retina, hDistance = maxDistance.horizontal, vDistance = maxDistance.vertical;
    if (!hDistance && !vDistance) {
        return;
    }
    const hasHDistance = (hDistance && dxFixed >= hDistance) ?? false, hasVDistance = (vDistance && dyFixed >= vDistance) ?? false;
    if ((hasHDistance || hasVDistance) && !particle.misplaced) {
        particle.misplaced = !!hDistance && dxFixed > hDistance || !!vDistance && dyFixed > vDistance;
        if (hDistance) {
            particle.velocity.x = particle.velocity.y * half - particle.velocity.x;
        }
        if (vDistance) {
            particle.velocity.y = particle.velocity.x * half - particle.velocity.y;
        }
    } else if ((!hDistance || dxFixed < hDistance) && (!vDistance || dyFixed < vDistance) && particle.misplaced) {
        particle.misplaced = false;
    } else if (particle.misplaced) {
        const pos = particle.position, vel = particle.velocity;
        if (hDistance && (pos.x < initialPosition.x && vel.x < minVelocity || pos.x > initialPosition.x && vel.x > minVelocity)) {
            vel.x *= -(0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getRandom"])();
        }
        if (vDistance && (pos.y < initialPosition.y && vel.y < minVelocity || pos.y > initialPosition.y && vel.y > minVelocity)) {
            vel.y *= -(0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getRandom"])();
        }
    }
}
function move(particle, moveOptions, moveSpeed, maxSpeed, moveDrift, reduceFactor, delta) {
    applyPath(particle, delta);
    const gravityOptions = particle.gravity, gravityFactor = gravityOptions?.enable && gravityOptions.inverse ? -identity : identity;
    if (moveDrift && moveSpeed) {
        particle.velocity.x += moveDrift * delta.factor / (moveSpeedFactor * moveSpeed);
    }
    if (gravityOptions?.enable && moveSpeed) {
        particle.velocity.y += gravityFactor * (gravityOptions.acceleration * delta.factor) / (moveSpeedFactor * moveSpeed);
    }
    const decay = particle.moveDecay;
    particle.velocity.multTo(decay);
    const velocity = particle.velocity.mult(moveSpeed);
    if (gravityOptions?.enable && maxSpeed > minVelocity && (!gravityOptions.inverse && velocity.y >= minVelocity && velocity.y >= maxSpeed || gravityOptions.inverse && velocity.y <= minVelocity && velocity.y <= -maxSpeed)) {
        velocity.y = gravityFactor * maxSpeed;
        if (moveSpeed) {
            particle.velocity.y = velocity.y / moveSpeed;
        }
    }
    const zIndexOptions = particle.options.zIndex, zVelocityFactor = (identity - particle.zIndexFactor) ** zIndexOptions.velocityRate;
    velocity.multTo(zVelocityFactor);
    velocity.multTo(reduceFactor);
    const { position } = particle;
    position.addTo(velocity);
    if (moveOptions.vibrate) {
        position.x += Math.sin(position.x * Math.cos(position.y)) * reduceFactor;
        position.y += Math.cos(position.y * Math.sin(position.x)) * reduceFactor;
    }
}
function spin(particle, moveSpeed, reduceFactor) {
    const container = particle.container;
    if (!particle.spin) {
        return;
    }
    const spinClockwise = particle.spin.direction === __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Directions$2f$RotateDirection$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["RotateDirection"].clockwise, updateFunc = {
        x: spinClockwise ? Math.cos : Math.sin,
        y: spinClockwise ? Math.sin : Math.cos
    };
    particle.position.x = particle.spin.center.x + particle.spin.radius * updateFunc.x(particle.spin.angle) * reduceFactor;
    particle.position.y = particle.spin.center.y + particle.spin.radius * updateFunc.y(particle.spin.angle) * reduceFactor;
    particle.spin.radius += particle.spin.acceleration * reduceFactor;
    const maxCanvasSize = Math.max(container.canvas.size.width, container.canvas.size.height), halfMaxSize = maxCanvasSize * half;
    if (particle.spin.radius > halfMaxSize) {
        particle.spin.radius = halfMaxSize;
        particle.spin.acceleration *= -identity;
    } else if (particle.spin.radius < minSpinRadius) {
        particle.spin.radius = minSpinRadius;
        particle.spin.acceleration *= -identity;
    }
    particle.spin.angle += moveSpeed * spinFactor * (identity - particle.spin.radius / maxCanvasSize);
}
function applyPath(particle, delta) {
    const particlesOptions = particle.options, pathOptions = particlesOptions.move.path, pathEnabled = pathOptions.enable;
    if (!pathEnabled) {
        return;
    }
    if (particle.lastPathTime <= particle.pathDelay) {
        particle.lastPathTime += delta.value;
        return;
    }
    const path = particle.pathGenerator?.generate(particle, delta);
    if (path) {
        particle.velocity.addTo(path);
    }
    if (pathOptions.clamp) {
        particle.velocity.x = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["clamp"])(particle.velocity.x, -identity, identity);
        particle.velocity.y = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["clamp"])(particle.velocity.y, -identity, identity);
    }
    particle.lastPathTime -= particle.pathDelay;
}
function getProximitySpeedFactor(particle) {
    return particle.slow.inRange ? particle.slow.factor : identity;
}
function initSpin(particle) {
    const container = particle.container, options = particle.options, spinOptions = options.move.spin;
    if (!spinOptions.enable) {
        return;
    }
    const spinPos = spinOptions.position ?? {
        x: 50,
        y: 50
    }, spinFactor = 0.01, spinCenter = {
        x: spinPos.x * spinFactor * container.canvas.size.width,
        y: spinPos.y * spinFactor * container.canvas.size.height
    }, pos = particle.getPosition(), distance = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getDistance"])(pos, spinCenter), spinAcceleration = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getRangeValue"])(spinOptions.acceleration);
    particle.retina.spinAcceleration = spinAcceleration * container.retina.pixelRatio;
    particle.spin = {
        center: spinCenter,
        direction: particle.velocity.x >= minVelocity ? __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Directions$2f$RotateDirection$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["RotateDirection"].clockwise : __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Directions$2f$RotateDirection$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["RotateDirection"].counterClockwise,
        angle: (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getRandom"])() * doublePI,
        radius: distance,
        acceleration: particle.retina.spinAcceleration
    };
}
}),
"[project]/theitern/node_modules/@tsparticles/move-base/esm/BaseMover.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "BaseMover",
    ()=>BaseMover
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/NumberUtils.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$move$2d$base$2f$esm$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/move-base/esm/Utils.js [app-ssr] (ecmascript)");
;
;
const diffFactor = 2, defaultSizeFactor = 1, defaultDeltaFactor = 1;
class BaseMover {
    init(particle) {
        const options = particle.options, gravityOptions = options.move.gravity;
        particle.gravity = {
            enable: gravityOptions.enable,
            acceleration: (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getRangeValue"])(gravityOptions.acceleration),
            inverse: gravityOptions.inverse
        };
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$move$2d$base$2f$esm$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["initSpin"])(particle);
    }
    isEnabled(particle) {
        return !particle.destroyed && particle.options.move.enable;
    }
    move(particle, delta) {
        const particleOptions = particle.options, moveOptions = particleOptions.move;
        if (!moveOptions.enable) {
            return;
        }
        const container = particle.container, pxRatio = container.retina.pixelRatio;
        particle.retina.moveSpeed ??= (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getRangeValue"])(moveOptions.speed) * pxRatio;
        particle.retina.moveDrift ??= (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getRangeValue"])(particle.options.move.drift) * pxRatio;
        const slowFactor = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$move$2d$base$2f$esm$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getProximitySpeedFactor"])(particle), reduceFactor = container.retina.reduceFactor, baseSpeed = particle.retina.moveSpeed, moveDrift = particle.retina.moveDrift, maxSize = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getRangeMax"])(particleOptions.size.value) * pxRatio, sizeFactor = moveOptions.size ? particle.getRadius() / maxSize : defaultSizeFactor, deltaFactor = delta.factor || defaultDeltaFactor, moveSpeed = baseSpeed * sizeFactor * slowFactor * deltaFactor / diffFactor, maxSpeed = particle.retina.maxSpeed ?? container.retina.maxSpeed;
        if (moveOptions.spin.enable) {
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$move$2d$base$2f$esm$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["spin"])(particle, moveSpeed, reduceFactor);
        } else {
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$move$2d$base$2f$esm$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["move"])(particle, moveOptions, moveSpeed, maxSpeed, moveDrift, reduceFactor, delta);
        }
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$move$2d$base$2f$esm$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["applyDistance"])(particle);
    }
}
}),
"[project]/theitern/node_modules/@tsparticles/move-base/esm/index.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "loadBaseMover",
    ()=>loadBaseMover
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$move$2d$base$2f$esm$2f$BaseMover$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/move-base/esm/BaseMover.js [app-ssr] (ecmascript)");
;
async function loadBaseMover(engine, refresh = true) {
    engine.checkVersion("3.9.1");
    await engine.addMover("base", ()=>{
        return Promise.resolve(new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$move$2d$base$2f$esm$2f$BaseMover$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["BaseMover"]());
    }, refresh);
}
}),
"[project]/theitern/node_modules/@tsparticles/shape-circle/esm/Utils.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "drawCircle",
    ()=>drawCircle
]);
const double = 2, doublePI = Math.PI * double, minAngle = 0, origin = {
    x: 0,
    y: 0
};
function drawCircle(data) {
    const { context, particle, radius } = data;
    if (!particle.circleRange) {
        particle.circleRange = {
            min: minAngle,
            max: doublePI
        };
    }
    const circleRange = particle.circleRange;
    context.arc(origin.x, origin.y, radius, circleRange.min, circleRange.max, false);
}
}),
"[project]/theitern/node_modules/@tsparticles/shape-circle/esm/CircleDrawer.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "CircleDrawer",
    ()=>CircleDrawer
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/NumberUtils.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/TypeUtils.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$shape$2d$circle$2f$esm$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/shape-circle/esm/Utils.js [app-ssr] (ecmascript)");
;
;
const sides = 12, maxAngle = 360, minAngle = 0;
class CircleDrawer {
    constructor(){
        this.validTypes = [
            "circle"
        ];
    }
    draw(data) {
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$shape$2d$circle$2f$esm$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["drawCircle"])(data);
    }
    getSidesCount() {
        return sides;
    }
    particleInit(container, particle) {
        const shapeData = particle.shapeData, angle = shapeData?.angle ?? {
            max: maxAngle,
            min: minAngle
        };
        particle.circleRange = !(0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isObject"])(angle) ? {
            min: minAngle,
            max: (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["degToRad"])(angle)
        } : {
            min: (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["degToRad"])(angle.min),
            max: (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["degToRad"])(angle.max)
        };
    }
}
}),
"[project]/theitern/node_modules/@tsparticles/shape-circle/esm/index.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "loadCircleShape",
    ()=>loadCircleShape
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$shape$2d$circle$2f$esm$2f$CircleDrawer$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/shape-circle/esm/CircleDrawer.js [app-ssr] (ecmascript)");
;
async function loadCircleShape(engine, refresh = true) {
    engine.checkVersion("3.9.1");
    await engine.addShape(new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$shape$2d$circle$2f$esm$2f$CircleDrawer$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["CircleDrawer"](), refresh);
}
}),
"[project]/theitern/node_modules/@tsparticles/updater-color/esm/ColorUpdater.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ColorUpdater",
    ()=>ColorUpdater
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$ColorUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/ColorUtils.js [app-ssr] (ecmascript)");
;
class ColorUpdater {
    constructor(container, engine){
        this._container = container;
        this._engine = engine;
    }
    init(particle) {
        const hslColor = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$ColorUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["rangeColorToHsl"])(this._engine, particle.options.color, particle.id, particle.options.reduceDuplicates);
        if (hslColor) {
            particle.color = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$ColorUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getHslAnimationFromHsl"])(hslColor, particle.options.color.animation, this._container.retina.reduceFactor);
        }
    }
    isEnabled(particle) {
        const { h: hAnimation, s: sAnimation, l: lAnimation } = particle.options.color.animation, { color } = particle;
        return !particle.destroyed && !particle.spawning && (color?.h.value !== undefined && hAnimation.enable || color?.s.value !== undefined && sAnimation.enable || color?.l.value !== undefined && lAnimation.enable);
    }
    update(particle, delta) {
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$ColorUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["updateColor"])(particle.color, delta);
    }
}
}),
"[project]/theitern/node_modules/@tsparticles/updater-color/esm/index.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "loadColorUpdater",
    ()=>loadColorUpdater
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$updater$2d$color$2f$esm$2f$ColorUpdater$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/updater-color/esm/ColorUpdater.js [app-ssr] (ecmascript)");
;
async function loadColorUpdater(engine, refresh = true) {
    engine.checkVersion("3.9.1");
    await engine.addParticleUpdater("color", (container)=>{
        return Promise.resolve(new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$updater$2d$color$2f$esm$2f$ColorUpdater$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ColorUpdater"](container, engine));
    }, refresh);
}
}),
"[project]/theitern/node_modules/@tsparticles/plugin-hex-color/esm/HexColorManager.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "HexColorManager",
    ()=>HexColorManager
]);
var RgbIndexes;
(function(RgbIndexes) {
    RgbIndexes[RgbIndexes["r"] = 1] = "r";
    RgbIndexes[RgbIndexes["g"] = 2] = "g";
    RgbIndexes[RgbIndexes["b"] = 3] = "b";
    RgbIndexes[RgbIndexes["a"] = 4] = "a";
})(RgbIndexes || (RgbIndexes = {}));
const shorthandHexRegex = /^#?([a-f\d])([a-f\d])([a-f\d])([a-f\d])?$/i, hexRegex = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})?$/i, hexRadix = 16, defaultAlpha = 1, alphaFactor = 0xff;
class HexColorManager {
    constructor(){
        this.key = "hex";
        this.stringPrefix = "#";
    }
    handleColor(color) {
        return this._parseString(color.value);
    }
    handleRangeColor(color) {
        return this._parseString(color.value);
    }
    parseString(input) {
        return this._parseString(input);
    }
    _parseString(hexColor) {
        if (typeof hexColor !== "string") {
            return;
        }
        if (!hexColor?.startsWith(this.stringPrefix)) {
            return;
        }
        const hexFixed = hexColor.replace(shorthandHexRegex, (_, r, g, b, a)=>{
            return r + r + g + g + b + b + (a !== undefined ? a + a : "");
        }), result = hexRegex.exec(hexFixed);
        return result ? {
            a: result[RgbIndexes.a] !== undefined ? parseInt(result[RgbIndexes.a], hexRadix) / alphaFactor : defaultAlpha,
            b: parseInt(result[RgbIndexes.b], hexRadix),
            g: parseInt(result[RgbIndexes.g], hexRadix),
            r: parseInt(result[RgbIndexes.r], hexRadix)
        } : undefined;
    }
}
}),
"[project]/theitern/node_modules/@tsparticles/plugin-hex-color/esm/index.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "loadHexColorPlugin",
    ()=>loadHexColorPlugin
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$plugin$2d$hex$2d$color$2f$esm$2f$HexColorManager$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/plugin-hex-color/esm/HexColorManager.js [app-ssr] (ecmascript)");
;
async function loadHexColorPlugin(engine, refresh = true) {
    engine.checkVersion("3.9.1");
    await engine.addColorManager(new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$plugin$2d$hex$2d$color$2f$esm$2f$HexColorManager$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["HexColorManager"](), refresh);
}
}),
"[project]/theitern/node_modules/@tsparticles/plugin-hsl-color/esm/HslColorManager.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "HslColorManager",
    ()=>HslColorManager
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/NumberUtils.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$ColorUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/ColorUtils.js [app-ssr] (ecmascript)");
;
var HslIndexes;
(function(HslIndexes) {
    HslIndexes[HslIndexes["h"] = 1] = "h";
    HslIndexes[HslIndexes["s"] = 2] = "s";
    HslIndexes[HslIndexes["l"] = 3] = "l";
    HslIndexes[HslIndexes["a"] = 5] = "a";
})(HslIndexes || (HslIndexes = {}));
class HslColorManager {
    constructor(){
        this.key = "hsl";
        this.stringPrefix = "hsl";
    }
    handleColor(color) {
        const colorValue = color.value, hslColor = colorValue.hsl ?? color.value;
        if (hslColor.h !== undefined && hslColor.s !== undefined && hslColor.l !== undefined) {
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$ColorUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["hslToRgb"])(hslColor);
        }
    }
    handleRangeColor(color) {
        const colorValue = color.value, hslColor = colorValue.hsl ?? color.value;
        if (hslColor.h !== undefined && hslColor.l !== undefined) {
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$ColorUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["hslToRgb"])({
                h: (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getRangeValue"])(hslColor.h),
                l: (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getRangeValue"])(hslColor.l),
                s: (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getRangeValue"])(hslColor.s)
            });
        }
    }
    parseString(input) {
        if (!input.startsWith("hsl")) {
            return;
        }
        const regex = /hsla?\(\s*(\d+)\s*[\s,]\s*(\d+)%\s*[\s,]\s*(\d+)%\s*([\s,]\s*(0|1|0?\.\d+|(\d{1,3})%)\s*)?\)/i, result = regex.exec(input), minLength = 4, defaultAlpha = 1, radix = 10;
        return result ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$ColorUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["hslaToRgba"])({
            a: result.length > minLength ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["parseAlpha"])(result[HslIndexes.a]) : defaultAlpha,
            h: parseInt(result[HslIndexes.h], radix),
            l: parseInt(result[HslIndexes.l], radix),
            s: parseInt(result[HslIndexes.s], radix)
        }) : undefined;
    }
}
}),
"[project]/theitern/node_modules/@tsparticles/plugin-hsl-color/esm/index.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "loadHslColorPlugin",
    ()=>loadHslColorPlugin
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$plugin$2d$hsl$2d$color$2f$esm$2f$HslColorManager$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/plugin-hsl-color/esm/HslColorManager.js [app-ssr] (ecmascript)");
;
async function loadHslColorPlugin(engine, refresh = true) {
    engine.checkVersion("3.9.1");
    await engine.addColorManager(new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$plugin$2d$hsl$2d$color$2f$esm$2f$HslColorManager$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["HslColorManager"](), refresh);
}
}),
"[project]/theitern/node_modules/@tsparticles/updater-opacity/esm/OpacityUpdater.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "OpacityUpdater",
    ()=>OpacityUpdater
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/NumberUtils.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/Utils.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Core/Utils/Constants.js [app-ssr] (ecmascript)");
;
class OpacityUpdater {
    constructor(container){
        this.container = container;
    }
    init(particle) {
        const opacityOptions = particle.options.opacity, pxRatio = 1;
        particle.opacity = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["initParticleNumericAnimationValue"])(opacityOptions, pxRatio);
        const opacityAnimation = opacityOptions.animation;
        if (opacityAnimation.enable) {
            particle.opacity.velocity = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getRangeValue"])(opacityAnimation.speed) / __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["percentDenominator"] * this.container.retina.reduceFactor;
            if (!opacityAnimation.sync) {
                particle.opacity.velocity *= (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getRandom"])();
            }
        }
    }
    isEnabled(particle) {
        const none = 0;
        return !particle.destroyed && !particle.spawning && !!particle.opacity && particle.opacity.enable && ((particle.opacity.maxLoops ?? none) <= none || (particle.opacity.maxLoops ?? none) > none && (particle.opacity.loops ?? none) < (particle.opacity.maxLoops ?? none));
    }
    reset(particle) {
        if (particle.opacity) {
            particle.opacity.time = 0;
            particle.opacity.loops = 0;
        }
    }
    update(particle, delta) {
        if (!this.isEnabled(particle) || !particle.opacity) {
            return;
        }
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["updateAnimation"])(particle, particle.opacity, true, particle.options.opacity.animation.destroy, delta);
    }
}
}),
"[project]/theitern/node_modules/@tsparticles/updater-opacity/esm/index.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "loadOpacityUpdater",
    ()=>loadOpacityUpdater
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$updater$2d$opacity$2f$esm$2f$OpacityUpdater$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/updater-opacity/esm/OpacityUpdater.js [app-ssr] (ecmascript)");
;
async function loadOpacityUpdater(engine, refresh = true) {
    engine.checkVersion("3.9.1");
    await engine.addParticleUpdater("opacity", (container)=>{
        return Promise.resolve(new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$updater$2d$opacity$2f$esm$2f$OpacityUpdater$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["OpacityUpdater"](container));
    }, refresh);
}
}),
"[project]/theitern/node_modules/@tsparticles/updater-out-modes/esm/Utils.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "bounceHorizontal",
    ()=>bounceHorizontal,
    "bounceVertical",
    ()=>bounceVertical
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Modes$2f$OutMode$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Enums/Modes/OutMode.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Directions$2f$OutModeDirection$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Enums/Directions/OutModeDirection.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/NumberUtils.js [app-ssr] (ecmascript)");
;
const minVelocity = 0, boundsMin = 0;
function bounceHorizontal(data) {
    if (data.outMode !== __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Modes$2f$OutMode$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["OutMode"].bounce && data.outMode !== __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Modes$2f$OutMode$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["OutMode"].split || data.direction !== __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Directions$2f$OutModeDirection$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["OutModeDirection"].left && data.direction !== __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Directions$2f$OutModeDirection$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["OutModeDirection"].right) {
        return;
    }
    if (data.bounds.right < boundsMin && data.direction === __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Directions$2f$OutModeDirection$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["OutModeDirection"].left) {
        data.particle.position.x = data.size + data.offset.x;
    } else if (data.bounds.left > data.canvasSize.width && data.direction === __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Directions$2f$OutModeDirection$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["OutModeDirection"].right) {
        data.particle.position.x = data.canvasSize.width - data.size - data.offset.x;
    }
    const velocity = data.particle.velocity.x;
    let bounced = false;
    if (data.direction === __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Directions$2f$OutModeDirection$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["OutModeDirection"].right && data.bounds.right >= data.canvasSize.width && velocity > minVelocity || data.direction === __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Directions$2f$OutModeDirection$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["OutModeDirection"].left && data.bounds.left <= boundsMin && velocity < minVelocity) {
        const newVelocity = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getRangeValue"])(data.particle.options.bounce.horizontal.value);
        data.particle.velocity.x *= -newVelocity;
        bounced = true;
    }
    if (!bounced) {
        return;
    }
    const minPos = data.offset.x + data.size;
    if (data.bounds.right >= data.canvasSize.width && data.direction === __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Directions$2f$OutModeDirection$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["OutModeDirection"].right) {
        data.particle.position.x = data.canvasSize.width - minPos;
    } else if (data.bounds.left <= boundsMin && data.direction === __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Directions$2f$OutModeDirection$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["OutModeDirection"].left) {
        data.particle.position.x = minPos;
    }
    if (data.outMode === __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Modes$2f$OutMode$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["OutMode"].split) {
        data.particle.destroy();
    }
}
function bounceVertical(data) {
    if (data.outMode !== __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Modes$2f$OutMode$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["OutMode"].bounce && data.outMode !== __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Modes$2f$OutMode$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["OutMode"].split || data.direction !== __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Directions$2f$OutModeDirection$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["OutModeDirection"].bottom && data.direction !== __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Directions$2f$OutModeDirection$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["OutModeDirection"].top) {
        return;
    }
    if (data.bounds.bottom < boundsMin && data.direction === __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Directions$2f$OutModeDirection$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["OutModeDirection"].top) {
        data.particle.position.y = data.size + data.offset.y;
    } else if (data.bounds.top > data.canvasSize.height && data.direction === __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Directions$2f$OutModeDirection$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["OutModeDirection"].bottom) {
        data.particle.position.y = data.canvasSize.height - data.size - data.offset.y;
    }
    const velocity = data.particle.velocity.y;
    let bounced = false;
    if (data.direction === __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Directions$2f$OutModeDirection$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["OutModeDirection"].bottom && data.bounds.bottom >= data.canvasSize.height && velocity > minVelocity || data.direction === __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Directions$2f$OutModeDirection$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["OutModeDirection"].top && data.bounds.top <= boundsMin && velocity < minVelocity) {
        const newVelocity = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getRangeValue"])(data.particle.options.bounce.vertical.value);
        data.particle.velocity.y *= -newVelocity;
        bounced = true;
    }
    if (!bounced) {
        return;
    }
    const minPos = data.offset.y + data.size;
    if (data.bounds.bottom >= data.canvasSize.height && data.direction === __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Directions$2f$OutModeDirection$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["OutModeDirection"].bottom) {
        data.particle.position.y = data.canvasSize.height - minPos;
    } else if (data.bounds.top <= boundsMin && data.direction === __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Directions$2f$OutModeDirection$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["OutModeDirection"].top) {
        data.particle.position.y = minPos;
    }
    if (data.outMode === __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Modes$2f$OutMode$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["OutMode"].split) {
        data.particle.destroy();
    }
}
}),
"[project]/theitern/node_modules/@tsparticles/updater-out-modes/esm/BounceOutMode.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "BounceOutMode",
    ()=>BounceOutMode
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Modes$2f$OutMode$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Enums/Modes/OutMode.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/Utils.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$updater$2d$out$2d$modes$2f$esm$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/updater-out-modes/esm/Utils.js [app-ssr] (ecmascript)");
;
;
class BounceOutMode {
    constructor(container){
        this.container = container;
        this.modes = [
            __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Modes$2f$OutMode$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["OutMode"].bounce,
            __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Modes$2f$OutMode$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["OutMode"].split
        ];
    }
    update(particle, direction, delta, outMode) {
        if (!this.modes.includes(outMode)) {
            return;
        }
        const container = this.container;
        let handled = false;
        for (const plugin of container.plugins.values()){
            if (plugin.particleBounce !== undefined) {
                handled = plugin.particleBounce(particle, delta, direction);
            }
            if (handled) {
                break;
            }
        }
        if (handled) {
            return;
        }
        const pos = particle.getPosition(), offset = particle.offset, size = particle.getRadius(), bounds = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["calculateBounds"])(pos, size), canvasSize = container.canvas.size;
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$updater$2d$out$2d$modes$2f$esm$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["bounceHorizontal"])({
            particle,
            outMode,
            direction,
            bounds,
            canvasSize,
            offset,
            size
        });
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$updater$2d$out$2d$modes$2f$esm$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["bounceVertical"])({
            particle,
            outMode,
            direction,
            bounds,
            canvasSize,
            offset,
            size
        });
    }
}
}),
"[project]/theitern/node_modules/@tsparticles/updater-out-modes/esm/DestroyOutMode.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "DestroyOutMode",
    ()=>DestroyOutMode
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Modes$2f$OutMode$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Enums/Modes/OutMode.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Types$2f$ParticleOutType$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Enums/Types/ParticleOutType.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Vectors$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Core/Utils/Vectors.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/NumberUtils.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/Utils.js [app-ssr] (ecmascript)");
;
const minVelocity = 0;
class DestroyOutMode {
    constructor(container){
        this.container = container;
        this.modes = [
            __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Modes$2f$OutMode$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["OutMode"].destroy
        ];
    }
    update(particle, direction, _delta, outMode) {
        if (!this.modes.includes(outMode)) {
            return;
        }
        const container = this.container;
        switch(particle.outType){
            case __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Types$2f$ParticleOutType$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ParticleOutType"].normal:
            case __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Types$2f$ParticleOutType$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ParticleOutType"].outside:
                if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isPointInside"])(particle.position, container.canvas.size, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Vectors$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Vector"].origin, particle.getRadius(), direction)) {
                    return;
                }
                break;
            case __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Types$2f$ParticleOutType$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ParticleOutType"].inside:
                {
                    const { dx, dy } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getDistances"])(particle.position, particle.moveCenter), { x: vx, y: vy } = particle.velocity;
                    if (vx < minVelocity && dx > particle.moveCenter.radius || vy < minVelocity && dy > particle.moveCenter.radius || vx >= minVelocity && dx < -particle.moveCenter.radius || vy >= minVelocity && dy < -particle.moveCenter.radius) {
                        return;
                    }
                    break;
                }
        }
        container.particles.remove(particle, particle.group, true);
    }
}
}),
"[project]/theitern/node_modules/@tsparticles/updater-out-modes/esm/NoneOutMode.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "NoneOutMode",
    ()=>NoneOutMode
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Modes$2f$OutMode$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Enums/Modes/OutMode.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Directions$2f$OutModeDirection$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Enums/Directions/OutModeDirection.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Vectors$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Core/Utils/Vectors.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/Utils.js [app-ssr] (ecmascript)");
;
const minVelocity = 0;
class NoneOutMode {
    constructor(container){
        this.container = container;
        this.modes = [
            __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Modes$2f$OutMode$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["OutMode"].none
        ];
    }
    update(particle, direction, delta, outMode) {
        if (!this.modes.includes(outMode)) {
            return;
        }
        if ((particle.options.move.distance.horizontal && (direction === __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Directions$2f$OutModeDirection$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["OutModeDirection"].left || direction === __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Directions$2f$OutModeDirection$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["OutModeDirection"].right)) ?? (particle.options.move.distance.vertical && (direction === __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Directions$2f$OutModeDirection$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["OutModeDirection"].top || direction === __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Directions$2f$OutModeDirection$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["OutModeDirection"].bottom))) {
            return;
        }
        const gravityOptions = particle.options.move.gravity, container = this.container, canvasSize = container.canvas.size, pRadius = particle.getRadius();
        if (!gravityOptions.enable) {
            if (particle.velocity.y > minVelocity && particle.position.y <= canvasSize.height + pRadius || particle.velocity.y < minVelocity && particle.position.y >= -pRadius || particle.velocity.x > minVelocity && particle.position.x <= canvasSize.width + pRadius || particle.velocity.x < minVelocity && particle.position.x >= -pRadius) {
                return;
            }
            if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isPointInside"])(particle.position, container.canvas.size, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Vectors$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Vector"].origin, pRadius, direction)) {
                container.particles.remove(particle);
            }
        } else {
            const position = particle.position;
            if (!gravityOptions.inverse && position.y > canvasSize.height + pRadius && direction === __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Directions$2f$OutModeDirection$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["OutModeDirection"].bottom || gravityOptions.inverse && position.y < -pRadius && direction === __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Directions$2f$OutModeDirection$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["OutModeDirection"].top) {
                container.particles.remove(particle);
            }
        }
    }
}
}),
"[project]/theitern/node_modules/@tsparticles/updater-out-modes/esm/OutOutMode.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "OutOutMode",
    ()=>OutOutMode
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Modes$2f$OutMode$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Enums/Modes/OutMode.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Directions$2f$OutModeDirection$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Enums/Directions/OutModeDirection.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Types$2f$ParticleOutType$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Enums/Types/ParticleOutType.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Vectors$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Core/Utils/Vectors.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/Utils.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/NumberUtils.js [app-ssr] (ecmascript)");
;
const minVelocity = 0, minDistance = 0;
class OutOutMode {
    constructor(container){
        this.container = container;
        this.modes = [
            __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Modes$2f$OutMode$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["OutMode"].out
        ];
    }
    update(particle, direction, delta, outMode) {
        if (!this.modes.includes(outMode)) {
            return;
        }
        const container = this.container;
        switch(particle.outType){
            case __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Types$2f$ParticleOutType$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ParticleOutType"].inside:
                {
                    const { x: vx, y: vy } = particle.velocity;
                    const circVec = __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Vectors$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Vector"].origin;
                    circVec.length = particle.moveCenter.radius;
                    circVec.angle = particle.velocity.angle + Math.PI;
                    circVec.addTo(__TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Vectors$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Vector"].create(particle.moveCenter));
                    const { dx, dy } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getDistances"])(particle.position, circVec);
                    if (vx <= minVelocity && dx >= minDistance || vy <= minVelocity && dy >= minDistance || vx >= minVelocity && dx <= minDistance || vy >= minVelocity && dy <= minDistance) {
                        return;
                    }
                    particle.position.x = Math.floor((0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["randomInRange"])({
                        min: 0,
                        max: container.canvas.size.width
                    }));
                    particle.position.y = Math.floor((0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["randomInRange"])({
                        min: 0,
                        max: container.canvas.size.height
                    }));
                    const { dx: newDx, dy: newDy } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getDistances"])(particle.position, particle.moveCenter);
                    particle.direction = Math.atan2(-newDy, -newDx);
                    particle.velocity.angle = particle.direction;
                    break;
                }
            default:
                {
                    if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isPointInside"])(particle.position, container.canvas.size, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Vectors$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Vector"].origin, particle.getRadius(), direction)) {
                        return;
                    }
                    switch(particle.outType){
                        case __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Types$2f$ParticleOutType$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ParticleOutType"].outside:
                            {
                                particle.position.x = Math.floor((0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["randomInRange"])({
                                    min: -particle.moveCenter.radius,
                                    max: particle.moveCenter.radius
                                })) + particle.moveCenter.x;
                                particle.position.y = Math.floor((0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["randomInRange"])({
                                    min: -particle.moveCenter.radius,
                                    max: particle.moveCenter.radius
                                })) + particle.moveCenter.y;
                                const { dx, dy } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getDistances"])(particle.position, particle.moveCenter);
                                if (particle.moveCenter.radius) {
                                    particle.direction = Math.atan2(dy, dx);
                                    particle.velocity.angle = particle.direction;
                                }
                                break;
                            }
                        case __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Types$2f$ParticleOutType$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ParticleOutType"].normal:
                            {
                                const warp = particle.options.move.warp, canvasSize = container.canvas.size, newPos = {
                                    bottom: canvasSize.height + particle.getRadius() + particle.offset.y,
                                    left: -particle.getRadius() - particle.offset.x,
                                    right: canvasSize.width + particle.getRadius() + particle.offset.x,
                                    top: -particle.getRadius() - particle.offset.y
                                }, sizeValue = particle.getRadius(), nextBounds = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["calculateBounds"])(particle.position, sizeValue);
                                if (direction === __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Directions$2f$OutModeDirection$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["OutModeDirection"].right && nextBounds.left > canvasSize.width + particle.offset.x) {
                                    particle.position.x = newPos.left;
                                    particle.initialPosition.x = particle.position.x;
                                    if (!warp) {
                                        particle.position.y = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getRandom"])() * canvasSize.height;
                                        particle.initialPosition.y = particle.position.y;
                                    }
                                } else if (direction === __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Directions$2f$OutModeDirection$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["OutModeDirection"].left && nextBounds.right < -particle.offset.x) {
                                    particle.position.x = newPos.right;
                                    particle.initialPosition.x = particle.position.x;
                                    if (!warp) {
                                        particle.position.y = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getRandom"])() * canvasSize.height;
                                        particle.initialPosition.y = particle.position.y;
                                    }
                                }
                                if (direction === __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Directions$2f$OutModeDirection$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["OutModeDirection"].bottom && nextBounds.top > canvasSize.height + particle.offset.y) {
                                    if (!warp) {
                                        particle.position.x = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getRandom"])() * canvasSize.width;
                                        particle.initialPosition.x = particle.position.x;
                                    }
                                    particle.position.y = newPos.top;
                                    particle.initialPosition.y = particle.position.y;
                                } else if (direction === __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Directions$2f$OutModeDirection$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["OutModeDirection"].top && nextBounds.bottom < -particle.offset.y) {
                                    if (!warp) {
                                        particle.position.x = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getRandom"])() * canvasSize.width;
                                        particle.initialPosition.x = particle.position.x;
                                    }
                                    particle.position.y = newPos.bottom;
                                    particle.initialPosition.y = particle.position.y;
                                }
                                break;
                            }
                    }
                    break;
                }
        }
    }
}
}),
"[project]/theitern/node_modules/@tsparticles/updater-out-modes/esm/OutOfCanvasUpdater.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "OutOfCanvasUpdater",
    ()=>OutOfCanvasUpdater
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Modes$2f$OutMode$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Enums/Modes/OutMode.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Directions$2f$OutModeDirection$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Enums/Directions/OutModeDirection.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$updater$2d$out$2d$modes$2f$esm$2f$BounceOutMode$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/updater-out-modes/esm/BounceOutMode.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$updater$2d$out$2d$modes$2f$esm$2f$DestroyOutMode$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/updater-out-modes/esm/DestroyOutMode.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$updater$2d$out$2d$modes$2f$esm$2f$NoneOutMode$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/updater-out-modes/esm/NoneOutMode.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$updater$2d$out$2d$modes$2f$esm$2f$OutOutMode$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/updater-out-modes/esm/OutOutMode.js [app-ssr] (ecmascript)");
;
;
;
;
;
const checkOutMode = (outModes, outMode)=>{
    return outModes.default === outMode || outModes.bottom === outMode || outModes.left === outMode || outModes.right === outMode || outModes.top === outMode;
};
class OutOfCanvasUpdater {
    constructor(container){
        this._addUpdaterIfMissing = (particle, outMode, getUpdater)=>{
            const outModes = particle.options.move.outModes;
            if (!this.updaters.has(outMode) && checkOutMode(outModes, outMode)) {
                this.updaters.set(outMode, getUpdater(this.container));
            }
        };
        this._updateOutMode = (particle, delta, outMode, direction)=>{
            for (const updater of this.updaters.values()){
                updater.update(particle, direction, delta, outMode);
            }
        };
        this.container = container;
        this.updaters = new Map();
    }
    init(particle) {
        this._addUpdaterIfMissing(particle, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Modes$2f$OutMode$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["OutMode"].bounce, (container)=>new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$updater$2d$out$2d$modes$2f$esm$2f$BounceOutMode$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["BounceOutMode"](container));
        this._addUpdaterIfMissing(particle, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Modes$2f$OutMode$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["OutMode"].out, (container)=>new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$updater$2d$out$2d$modes$2f$esm$2f$OutOutMode$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["OutOutMode"](container));
        this._addUpdaterIfMissing(particle, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Modes$2f$OutMode$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["OutMode"].destroy, (container)=>new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$updater$2d$out$2d$modes$2f$esm$2f$DestroyOutMode$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["DestroyOutMode"](container));
        this._addUpdaterIfMissing(particle, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Modes$2f$OutMode$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["OutMode"].none, (container)=>new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$updater$2d$out$2d$modes$2f$esm$2f$NoneOutMode$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["NoneOutMode"](container));
    }
    isEnabled(particle) {
        return !particle.destroyed && !particle.spawning;
    }
    update(particle, delta) {
        const outModes = particle.options.move.outModes;
        this._updateOutMode(particle, delta, outModes.bottom ?? outModes.default, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Directions$2f$OutModeDirection$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["OutModeDirection"].bottom);
        this._updateOutMode(particle, delta, outModes.left ?? outModes.default, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Directions$2f$OutModeDirection$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["OutModeDirection"].left);
        this._updateOutMode(particle, delta, outModes.right ?? outModes.default, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Directions$2f$OutModeDirection$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["OutModeDirection"].right);
        this._updateOutMode(particle, delta, outModes.top ?? outModes.default, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Directions$2f$OutModeDirection$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["OutModeDirection"].top);
    }
}
}),
"[project]/theitern/node_modules/@tsparticles/updater-out-modes/esm/index.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "loadOutModesUpdater",
    ()=>loadOutModesUpdater
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$updater$2d$out$2d$modes$2f$esm$2f$OutOfCanvasUpdater$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/updater-out-modes/esm/OutOfCanvasUpdater.js [app-ssr] (ecmascript)");
;
async function loadOutModesUpdater(engine, refresh = true) {
    engine.checkVersion("3.9.1");
    await engine.addParticleUpdater("outModes", (container)=>{
        return Promise.resolve(new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$updater$2d$out$2d$modes$2f$esm$2f$OutOfCanvasUpdater$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["OutOfCanvasUpdater"](container));
    }, refresh);
}
}),
"[project]/theitern/node_modules/@tsparticles/plugin-rgb-color/esm/RgbColorManager.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "RgbColorManager",
    ()=>RgbColorManager
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/NumberUtils.js [app-ssr] (ecmascript)");
;
var RgbIndexes;
(function(RgbIndexes) {
    RgbIndexes[RgbIndexes["r"] = 1] = "r";
    RgbIndexes[RgbIndexes["g"] = 2] = "g";
    RgbIndexes[RgbIndexes["b"] = 3] = "b";
    RgbIndexes[RgbIndexes["a"] = 5] = "a";
})(RgbIndexes || (RgbIndexes = {}));
class RgbColorManager {
    constructor(){
        this.key = "rgb";
        this.stringPrefix = "rgb";
    }
    handleColor(color) {
        const colorValue = color.value, rgbColor = colorValue.rgb ?? color.value;
        if (rgbColor.r !== undefined) {
            return rgbColor;
        }
    }
    handleRangeColor(color) {
        const colorValue = color.value, rgbColor = colorValue.rgb ?? color.value;
        if (rgbColor.r !== undefined) {
            return {
                r: (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getRangeValue"])(rgbColor.r),
                g: (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getRangeValue"])(rgbColor.g),
                b: (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getRangeValue"])(rgbColor.b)
            };
        }
    }
    parseString(input) {
        if (!input.startsWith(this.stringPrefix)) {
            return;
        }
        const regex = /rgba?\(\s*(\d{1,3})\s*[\s,]\s*(\d{1,3})\s*[\s,]\s*(\d{1,3})\s*([\s,]\s*(0|1|0?\.\d+|(\d{1,3})%)\s*)?\)/i, result = regex.exec(input), radix = 10, minLength = 4, defaultAlpha = 1;
        return result ? {
            a: result.length > minLength ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["parseAlpha"])(result[RgbIndexes.a]) : defaultAlpha,
            b: parseInt(result[RgbIndexes.b], radix),
            g: parseInt(result[RgbIndexes.g], radix),
            r: parseInt(result[RgbIndexes.r], radix)
        } : undefined;
    }
}
}),
"[project]/theitern/node_modules/@tsparticles/plugin-rgb-color/esm/index.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "loadRgbColorPlugin",
    ()=>loadRgbColorPlugin
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$plugin$2d$rgb$2d$color$2f$esm$2f$RgbColorManager$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/plugin-rgb-color/esm/RgbColorManager.js [app-ssr] (ecmascript)");
;
async function loadRgbColorPlugin(engine, refresh = true) {
    engine.checkVersion("3.9.1");
    await engine.addColorManager(new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$plugin$2d$rgb$2d$color$2f$esm$2f$RgbColorManager$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["RgbColorManager"](), refresh);
}
}),
"[project]/theitern/node_modules/@tsparticles/updater-size/esm/SizeUpdater.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "SizeUpdater",
    ()=>SizeUpdater
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/NumberUtils.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Core/Utils/Constants.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/Utils.js [app-ssr] (ecmascript)");
;
const minLoops = 0;
class SizeUpdater {
    init(particle) {
        const container = particle.container, sizeOptions = particle.options.size, sizeAnimation = sizeOptions.animation;
        if (sizeAnimation.enable) {
            particle.size.velocity = (particle.retina.sizeAnimationSpeed ?? container.retina.sizeAnimationSpeed) / __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["percentDenominator"] * container.retina.reduceFactor;
            if (!sizeAnimation.sync) {
                particle.size.velocity *= (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getRandom"])();
            }
        }
    }
    isEnabled(particle) {
        return !particle.destroyed && !particle.spawning && particle.size.enable && ((particle.size.maxLoops ?? minLoops) <= minLoops || (particle.size.maxLoops ?? minLoops) > minLoops && (particle.size.loops ?? minLoops) < (particle.size.maxLoops ?? minLoops));
    }
    reset(particle) {
        particle.size.loops = minLoops;
    }
    update(particle, delta) {
        if (!this.isEnabled(particle)) {
            return;
        }
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["updateAnimation"])(particle, particle.size, true, particle.options.size.animation.destroy, delta);
    }
}
}),
"[project]/theitern/node_modules/@tsparticles/updater-size/esm/index.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "loadSizeUpdater",
    ()=>loadSizeUpdater
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$updater$2d$size$2f$esm$2f$SizeUpdater$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/updater-size/esm/SizeUpdater.js [app-ssr] (ecmascript)");
;
async function loadSizeUpdater(engine, refresh = true) {
    engine.checkVersion("3.9.1");
    await engine.addParticleUpdater("size", ()=>{
        return Promise.resolve(new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$updater$2d$size$2f$esm$2f$SizeUpdater$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["SizeUpdater"]());
    }, refresh);
}
}),
"[project]/theitern/node_modules/@tsparticles/basic/esm/index.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "loadBasic",
    ()=>loadBasic
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$move$2d$base$2f$esm$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/move-base/esm/index.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$shape$2d$circle$2f$esm$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/shape-circle/esm/index.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$updater$2d$color$2f$esm$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/updater-color/esm/index.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$plugin$2d$hex$2d$color$2f$esm$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/plugin-hex-color/esm/index.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$plugin$2d$hsl$2d$color$2f$esm$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/plugin-hsl-color/esm/index.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$updater$2d$opacity$2f$esm$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/updater-opacity/esm/index.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$updater$2d$out$2d$modes$2f$esm$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/updater-out-modes/esm/index.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$plugin$2d$rgb$2d$color$2f$esm$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/plugin-rgb-color/esm/index.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$updater$2d$size$2f$esm$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/updater-size/esm/index.js [app-ssr] (ecmascript)");
;
;
;
;
;
;
;
;
;
async function loadBasic(engine, refresh = true) {
    engine.checkVersion("3.9.1");
    await (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$plugin$2d$hex$2d$color$2f$esm$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["loadHexColorPlugin"])(engine, false);
    await (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$plugin$2d$hsl$2d$color$2f$esm$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["loadHslColorPlugin"])(engine, false);
    await (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$plugin$2d$rgb$2d$color$2f$esm$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["loadRgbColorPlugin"])(engine, false);
    await (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$move$2d$base$2f$esm$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["loadBaseMover"])(engine, false);
    await (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$shape$2d$circle$2f$esm$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["loadCircleShape"])(engine, false);
    await (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$updater$2d$color$2f$esm$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["loadColorUpdater"])(engine, false);
    await (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$updater$2d$opacity$2f$esm$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["loadOpacityUpdater"])(engine, false);
    await (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$updater$2d$out$2d$modes$2f$esm$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["loadOutModesUpdater"])(engine, false);
    await (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$updater$2d$size$2f$esm$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["loadSizeUpdater"])(engine, false);
    await engine.refresh(refresh);
}
}),
"[project]/theitern/node_modules/@tsparticles/plugin-easing-quad/esm/index.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "loadEasingQuadPlugin",
    ()=>loadEasingQuadPlugin
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Types$2f$EasingType$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Enums/Types/EasingType.js [app-ssr] (ecmascript)");
;
async function loadEasingQuadPlugin(engine, refresh = true) {
    engine.checkVersion("3.9.1");
    await engine.addEasing(__TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Types$2f$EasingType$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["EasingType"].easeInQuad, (value)=>value ** 2, false);
    await engine.addEasing(__TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Types$2f$EasingType$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["EasingType"].easeOutQuad, (value)=>1 - (1 - value) ** 2, false);
    await engine.addEasing(__TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Types$2f$EasingType$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["EasingType"].easeInOutQuad, (value)=>value < 0.5 ? 2 * value ** 2 : 1 - (-2 * value + 2) ** 2 / 2, false);
    await engine.refresh(refresh);
}
}),
"[project]/theitern/node_modules/@tsparticles/shape-emoji/esm/Utils.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "drawEmoji",
    ()=>drawEmoji
]);
function drawEmoji(data, image) {
    const { context, opacity } = data, half = 0.5, previousAlpha = context.globalAlpha;
    if (!image) {
        return;
    }
    const diameter = image.width, radius = diameter * half;
    context.globalAlpha = opacity;
    context.drawImage(image, -radius, -radius, diameter, diameter);
    context.globalAlpha = previousAlpha;
}
}),
"[project]/theitern/node_modules/@tsparticles/shape-emoji/esm/EmojiDrawer.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "EmojiDrawer",
    ()=>EmojiDrawer
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/Utils.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/NumberUtils.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$shape$2d$emoji$2f$esm$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/shape-emoji/esm/Utils.js [app-ssr] (ecmascript)");
;
;
const defaultFont = '"Twemoji Mozilla", Apple Color Emoji, "Segoe UI Emoji", "Noto Color Emoji", "EmojiOne Color"', noPadding = 0;
class EmojiDrawer {
    constructor(){
        this.validTypes = [
            "emoji"
        ];
        this._emojiShapeDict = new Map();
    }
    destroy() {
        for (const [key, data] of this._emojiShapeDict){
            if (data instanceof ImageBitmap) {
                data?.close();
            }
            this._emojiShapeDict.delete(key);
        }
    }
    draw(data) {
        const key = data.particle.emojiDataKey;
        if (!key) {
            return;
        }
        const image = this._emojiShapeDict.get(key);
        if (!image) {
            return;
        }
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$shape$2d$emoji$2f$esm$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["drawEmoji"])(data, image);
    }
    async init(container) {
        const options = container.actualOptions, { validTypes } = this;
        if (!validTypes.find((t)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isInArray"])(t, options.particles.shape.type))) {
            return;
        }
        const promises = [
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["loadFont"])(defaultFont)
        ], shapeOptions = validTypes.map((t)=>options.particles.shape.options[t]).find((t)=>!!t);
        if (shapeOptions) {
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["executeOnSingleOrMultiple"])(shapeOptions, (shape)=>{
                if (shape.font) {
                    promises.push((0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["loadFont"])(shape.font));
                }
            });
        }
        await Promise.all(promises);
    }
    particleDestroy(particle) {
        particle.emojiDataKey = undefined;
    }
    particleInit(_container, particle) {
        const double = 2, shapeData = particle.shapeData;
        if (!shapeData?.value) {
            return;
        }
        const emoji = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["itemFromSingleOrMultiple"])(shapeData.value, particle.randomIndexData);
        if (!emoji) {
            return;
        }
        const emojiOptions = typeof emoji === "string" ? {
            font: shapeData.font ?? defaultFont,
            padding: shapeData.padding ?? noPadding,
            value: emoji
        } : {
            font: defaultFont,
            padding: noPadding,
            ...shapeData,
            ...emoji
        }, font = emojiOptions.font, value = emojiOptions.value;
        const key = `${value}_${font}`;
        if (this._emojiShapeDict.has(key)) {
            particle.emojiDataKey = key;
            return;
        }
        const padding = emojiOptions.padding * double, maxSize = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getRangeMax"])(particle.size.value), fullSize = maxSize + padding, canvasSize = fullSize * double;
        let image;
        if (typeof OffscreenCanvas !== "undefined") {
            const canvas = new OffscreenCanvas(canvasSize, canvasSize), context = canvas.getContext("2d");
            if (!context) {
                return;
            }
            context.font = `400 ${maxSize * double}px ${font}`;
            context.textBaseline = "middle";
            context.textAlign = "center";
            context.fillText(value, fullSize, fullSize);
            image = canvas.transferToImageBitmap();
        } else {
            const canvas = document.createElement("canvas");
            canvas.width = canvasSize;
            canvas.height = canvasSize;
            const context = canvas.getContext("2d");
            if (!context) {
                return;
            }
            context.font = `400 ${maxSize * double}px ${font}`;
            context.textBaseline = "middle";
            context.textAlign = "center";
            context.fillText(value, fullSize, fullSize);
            image = canvas;
        }
        this._emojiShapeDict.set(key, image);
        particle.emojiDataKey = key;
    }
}
}),
"[project]/theitern/node_modules/@tsparticles/shape-emoji/esm/index.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "loadEmojiShape",
    ()=>loadEmojiShape
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$shape$2d$emoji$2f$esm$2f$EmojiDrawer$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/shape-emoji/esm/EmojiDrawer.js [app-ssr] (ecmascript)");
;
async function loadEmojiShape(engine, refresh = true) {
    engine.checkVersion("3.9.1");
    await engine.addShape(new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$shape$2d$emoji$2f$esm$2f$EmojiDrawer$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["EmojiDrawer"](), refresh);
}
}),
"[project]/theitern/node_modules/@tsparticles/interaction-external-attract/esm/Utils.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "clickAttract",
    ()=>clickAttract,
    "hoverAttract",
    ()=>hoverAttract
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Ranges$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Core/Utils/Ranges.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Vectors$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Core/Utils/Vectors.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/NumberUtils.js [app-ssr] (ecmascript)");
;
const minFactor = 1, identity = 1, minRadius = 0;
function processAttract(engine, container, position, attractRadius, area, queryCb) {
    const attractOptions = container.actualOptions.interactivity.modes.attract;
    if (!attractOptions) {
        return;
    }
    const query = container.particles.quadTree.query(area, queryCb);
    for (const particle of query){
        const { dx, dy, distance } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getDistances"])(particle.position, position), velocity = attractOptions.speed * attractOptions.factor, attractFactor = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["clamp"])(engine.getEasing(attractOptions.easing)(identity - distance / attractRadius) * velocity, minFactor, attractOptions.maxSpeed), normVec = __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Vectors$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Vector"].create(!distance ? velocity : dx / distance * attractFactor, !distance ? velocity : dy / distance * attractFactor);
        particle.position.subFrom(normVec);
    }
}
function clickAttract(engine, container, enabledCb) {
    if (!container.attract) {
        container.attract = {
            particles: []
        };
    }
    const { attract } = container;
    if (!attract.finish) {
        if (!attract.count) {
            attract.count = 0;
        }
        attract.count++;
        if (attract.count === container.particles.count) {
            attract.finish = true;
        }
    }
    if (attract.clicking) {
        const mousePos = container.interactivity.mouse.clickPosition, attractRadius = container.retina.attractModeDistance;
        if (!attractRadius || attractRadius < minRadius || !mousePos) {
            return;
        }
        processAttract(engine, container, mousePos, attractRadius, new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Ranges$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Circle"](mousePos.x, mousePos.y, attractRadius), (p)=>enabledCb(p));
    } else if (attract.clicking === false) {
        attract.particles = [];
    }
}
function hoverAttract(engine, container, enabledCb) {
    const mousePos = container.interactivity.mouse.position, attractRadius = container.retina.attractModeDistance;
    if (!attractRadius || attractRadius < minRadius || !mousePos) {
        return;
    }
    processAttract(engine, container, mousePos, attractRadius, new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Ranges$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Circle"](mousePos.x, mousePos.y, attractRadius), (p)=>enabledCb(p));
}
}),
"[project]/theitern/node_modules/@tsparticles/interaction-external-attract/esm/Options/Classes/Attract.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Attract",
    ()=>Attract
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Types$2f$EasingType$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Enums/Types/EasingType.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/TypeUtils.js [app-ssr] (ecmascript)");
;
class Attract {
    constructor(){
        this.distance = 200;
        this.duration = 0.4;
        this.easing = __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Types$2f$EasingType$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["EasingType"].easeOutQuad;
        this.factor = 1;
        this.maxSpeed = 50;
        this.speed = 1;
    }
    load(data) {
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isNull"])(data)) {
            return;
        }
        if (data.distance !== undefined) {
            this.distance = data.distance;
        }
        if (data.duration !== undefined) {
            this.duration = data.duration;
        }
        if (data.easing !== undefined) {
            this.easing = data.easing;
        }
        if (data.factor !== undefined) {
            this.factor = data.factor;
        }
        if (data.maxSpeed !== undefined) {
            this.maxSpeed = data.maxSpeed;
        }
        if (data.speed !== undefined) {
            this.speed = data.speed;
        }
    }
}
}),
"[project]/theitern/node_modules/@tsparticles/interaction-external-attract/esm/Attractor.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Attractor",
    ()=>Attractor
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$ExternalInteractorBase$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Core/Utils/ExternalInteractorBase.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/Utils.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Core/Utils/Constants.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$interaction$2d$external$2d$attract$2f$esm$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/interaction-external-attract/esm/Utils.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$interaction$2d$external$2d$attract$2f$esm$2f$Options$2f$Classes$2f$Attract$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/interaction-external-attract/esm/Options/Classes/Attract.js [app-ssr] (ecmascript)");
;
;
;
const attractMode = "attract";
class Attractor extends __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$ExternalInteractorBase$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ExternalInteractorBase"] {
    constructor(engine, container){
        super(container);
        this._engine = engine;
        if (!container.attract) {
            container.attract = {
                particles: []
            };
        }
        this.handleClickMode = (mode)=>{
            const options = this.container.actualOptions, attract = options.interactivity.modes.attract;
            if (!attract || mode !== attractMode) {
                return;
            }
            if (!container.attract) {
                container.attract = {
                    particles: []
                };
            }
            container.attract.clicking = true;
            container.attract.count = 0;
            for (const particle of container.attract.particles){
                if (!this.isEnabled(particle)) {
                    continue;
                }
                particle.velocity.setTo(particle.initialVelocity);
            }
            container.attract.particles = [];
            container.attract.finish = false;
            setTimeout(()=>{
                if (container.destroyed) {
                    return;
                }
                if (!container.attract) {
                    container.attract = {
                        particles: []
                    };
                }
                container.attract.clicking = false;
            }, attract.duration * __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["millisecondsToSeconds"]);
        };
    }
    clear() {}
    init() {
        const container = this.container, attract = container.actualOptions.interactivity.modes.attract;
        if (!attract) {
            return;
        }
        container.retina.attractModeDistance = attract.distance * container.retina.pixelRatio;
    }
    interact() {
        const container = this.container, options = container.actualOptions, mouseMoveStatus = container.interactivity.status === __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["mouseMoveEvent"], events = options.interactivity.events, { enable: hoverEnabled, mode: hoverMode } = events.onHover, { enable: clickEnabled, mode: clickMode } = events.onClick;
        if (mouseMoveStatus && hoverEnabled && (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isInArray"])(attractMode, hoverMode)) {
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$interaction$2d$external$2d$attract$2f$esm$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["hoverAttract"])(this._engine, this.container, (p)=>this.isEnabled(p));
        } else if (clickEnabled && (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isInArray"])(attractMode, clickMode)) {
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$interaction$2d$external$2d$attract$2f$esm$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["clickAttract"])(this._engine, this.container, (p)=>this.isEnabled(p));
        }
    }
    isEnabled(particle) {
        const container = this.container, options = container.actualOptions, mouse = container.interactivity.mouse, events = (particle?.interactivity ?? options.interactivity).events;
        if ((!mouse.position || !events.onHover.enable) && (!mouse.clickPosition || !events.onClick.enable)) {
            return false;
        }
        const hoverMode = events.onHover.mode, clickMode = events.onClick.mode;
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isInArray"])(attractMode, hoverMode) || (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isInArray"])(attractMode, clickMode);
    }
    loadModeOptions(options, ...sources) {
        if (!options.attract) {
            options.attract = new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$interaction$2d$external$2d$attract$2f$esm$2f$Options$2f$Classes$2f$Attract$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Attract"]();
        }
        for (const source of sources){
            options.attract.load(source?.attract);
        }
    }
    reset() {}
}
}),
"[project]/theitern/node_modules/@tsparticles/interaction-external-attract/esm/Options/Interfaces/IAttract.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
;
}),
"[project]/theitern/node_modules/@tsparticles/interaction-external-attract/esm/index.js [app-ssr] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "loadExternalAttractInteraction",
    ()=>loadExternalAttractInteraction
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$interaction$2d$external$2d$attract$2f$esm$2f$Attractor$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/interaction-external-attract/esm/Attractor.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$interaction$2d$external$2d$attract$2f$esm$2f$Options$2f$Classes$2f$Attract$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/interaction-external-attract/esm/Options/Classes/Attract.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$interaction$2d$external$2d$attract$2f$esm$2f$Options$2f$Interfaces$2f$IAttract$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/interaction-external-attract/esm/Options/Interfaces/IAttract.js [app-ssr] (ecmascript)");
;
async function loadExternalAttractInteraction(engine, refresh = true) {
    engine.checkVersion("3.9.1");
    await engine.addInteractor("externalAttract", (container)=>{
        return Promise.resolve(new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$interaction$2d$external$2d$attract$2f$esm$2f$Attractor$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Attractor"](engine, container));
    }, refresh);
}
;
;
}),
"[project]/theitern/node_modules/@tsparticles/interaction-external-bounce/esm/Utils.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "divBounce",
    ()=>divBounce,
    "mouseBounce",
    ()=>mouseBounce
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Ranges$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Core/Utils/Ranges.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Types$2f$DivType$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Enums/Types/DivType.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Vectors$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Core/Utils/Vectors.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/Utils.js [app-ssr] (ecmascript)");
;
const squareExp = 2, half = 0.5, halfPI = Math.PI * half, double = 2, toleranceFactor = 10, minRadius = 0;
function processBounce(container, position, radius, area, enabledCb) {
    const query = container.particles.quadTree.query(area, enabledCb);
    for (const particle of query){
        if (area instanceof __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Ranges$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Circle"]) {
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["circleBounce"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["circleBounceDataFromParticle"])(particle), {
                position,
                radius,
                mass: radius ** squareExp * halfPI,
                velocity: __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Vectors$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Vector"].origin,
                factor: __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Vectors$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Vector"].origin
            });
        } else if (area instanceof __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Ranges$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Rectangle"]) {
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["rectBounce"])(particle, (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["calculateBounds"])(position, radius));
        }
    }
}
function singleSelectorBounce(container, selector, div, bounceCb) {
    const query = document.querySelectorAll(selector);
    if (!query.length) {
        return;
    }
    query.forEach((item)=>{
        const elem = item, pxRatio = container.retina.pixelRatio, pos = {
            x: (elem.offsetLeft + elem.offsetWidth * half) * pxRatio,
            y: (elem.offsetTop + elem.offsetHeight * half) * pxRatio
        }, radius = elem.offsetWidth * half * pxRatio, tolerance = toleranceFactor * pxRatio, area = div.type === __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Types$2f$DivType$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["DivType"].circle ? new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Ranges$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Circle"](pos.x, pos.y, radius + tolerance) : new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Ranges$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Rectangle"](elem.offsetLeft * pxRatio - tolerance, elem.offsetTop * pxRatio - tolerance, elem.offsetWidth * pxRatio + tolerance * double, elem.offsetHeight * pxRatio + tolerance * double);
        bounceCb(pos, radius, area);
    });
}
function divBounce(container, divs, bounceMode, enabledCb) {
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["divModeExecute"])(bounceMode, divs, (selector, div)=>singleSelectorBounce(container, selector, div, (pos, radius, area)=>processBounce(container, pos, radius, area, enabledCb)));
}
function mouseBounce(container, enabledCb) {
    const pxRatio = container.retina.pixelRatio, tolerance = toleranceFactor * pxRatio, mousePos = container.interactivity.mouse.position, radius = container.retina.bounceModeDistance;
    if (!radius || radius < minRadius || !mousePos) {
        return;
    }
    processBounce(container, mousePos, radius, new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Ranges$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Circle"](mousePos.x, mousePos.y, radius + tolerance), enabledCb);
}
}),
"[project]/theitern/node_modules/@tsparticles/interaction-external-bounce/esm/Options/Classes/Bounce.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Bounce",
    ()=>Bounce
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/TypeUtils.js [app-ssr] (ecmascript)");
;
class Bounce {
    constructor(){
        this.distance = 200;
    }
    load(data) {
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isNull"])(data)) {
            return;
        }
        if (data.distance !== undefined) {
            this.distance = data.distance;
        }
    }
}
}),
"[project]/theitern/node_modules/@tsparticles/interaction-external-bounce/esm/Bouncer.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Bouncer",
    ()=>Bouncer
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$ExternalInteractorBase$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Core/Utils/ExternalInteractorBase.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/Utils.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Core/Utils/Constants.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$interaction$2d$external$2d$bounce$2f$esm$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/interaction-external-bounce/esm/Utils.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$interaction$2d$external$2d$bounce$2f$esm$2f$Options$2f$Classes$2f$Bounce$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/interaction-external-bounce/esm/Options/Classes/Bounce.js [app-ssr] (ecmascript)");
;
;
;
const bounceMode = "bounce";
class Bouncer extends __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$ExternalInteractorBase$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ExternalInteractorBase"] {
    constructor(container){
        super(container);
    }
    clear() {}
    init() {
        const container = this.container, bounce = container.actualOptions.interactivity.modes.bounce;
        if (!bounce) {
            return;
        }
        container.retina.bounceModeDistance = bounce.distance * container.retina.pixelRatio;
    }
    interact() {
        const container = this.container, options = container.actualOptions, events = options.interactivity.events, mouseMoveStatus = container.interactivity.status === __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["mouseMoveEvent"], hoverEnabled = events.onHover.enable, hoverMode = events.onHover.mode, divs = events.onDiv;
        if (mouseMoveStatus && hoverEnabled && (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isInArray"])(bounceMode, hoverMode)) {
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$interaction$2d$external$2d$bounce$2f$esm$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["mouseBounce"])(this.container, (p)=>this.isEnabled(p));
        } else {
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$interaction$2d$external$2d$bounce$2f$esm$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["divBounce"])(this.container, divs, bounceMode, (p)=>this.isEnabled(p));
        }
    }
    isEnabled(particle) {
        const container = this.container, options = container.actualOptions, mouse = container.interactivity.mouse, events = (particle?.interactivity ?? options.interactivity).events, divs = events.onDiv;
        return !!mouse.position && events.onHover.enable && (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isInArray"])(bounceMode, events.onHover.mode) || (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isDivModeEnabled"])(bounceMode, divs);
    }
    loadModeOptions(options, ...sources) {
        if (!options.bounce) {
            options.bounce = new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$interaction$2d$external$2d$bounce$2f$esm$2f$Options$2f$Classes$2f$Bounce$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Bounce"]();
        }
        for (const source of sources){
            options.bounce.load(source?.bounce);
        }
    }
    reset() {}
}
}),
"[project]/theitern/node_modules/@tsparticles/interaction-external-bounce/esm/Options/Interfaces/IBounce.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
;
}),
"[project]/theitern/node_modules/@tsparticles/interaction-external-bounce/esm/index.js [app-ssr] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "loadExternalBounceInteraction",
    ()=>loadExternalBounceInteraction
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$interaction$2d$external$2d$bounce$2f$esm$2f$Bouncer$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/interaction-external-bounce/esm/Bouncer.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$interaction$2d$external$2d$bounce$2f$esm$2f$Options$2f$Classes$2f$Bounce$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/interaction-external-bounce/esm/Options/Classes/Bounce.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$interaction$2d$external$2d$bounce$2f$esm$2f$Options$2f$Interfaces$2f$IBounce$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/interaction-external-bounce/esm/Options/Interfaces/IBounce.js [app-ssr] (ecmascript)");
;
async function loadExternalBounceInteraction(engine, refresh = true) {
    engine.checkVersion("3.9.1");
    await engine.addInteractor("externalBounce", (container)=>{
        return Promise.resolve(new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$interaction$2d$external$2d$bounce$2f$esm$2f$Bouncer$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Bouncer"](container));
    }, refresh);
}
;
;
}),
"[project]/theitern/node_modules/@tsparticles/interaction-external-bubble/esm/Options/Classes/BubbleBase.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "BubbleBase",
    ()=>BubbleBase
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$OptionsColor$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Classes/OptionsColor.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/Utils.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/TypeUtils.js [app-ssr] (ecmascript)");
;
class BubbleBase {
    constructor(){
        this.distance = 200;
        this.duration = 0.4;
        this.mix = false;
    }
    load(data) {
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isNull"])(data)) {
            return;
        }
        if (data.distance !== undefined) {
            this.distance = data.distance;
        }
        if (data.duration !== undefined) {
            this.duration = data.duration;
        }
        if (data.mix !== undefined) {
            this.mix = data.mix;
        }
        if (data.opacity !== undefined) {
            this.opacity = data.opacity;
        }
        if (data.color !== undefined) {
            const sourceColor = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isArray"])(this.color) ? undefined : this.color;
            this.color = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["executeOnSingleOrMultiple"])(data.color, (color)=>{
                return __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$OptionsColor$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["OptionsColor"].create(sourceColor, color);
            });
        }
        if (data.size !== undefined) {
            this.size = data.size;
        }
    }
}
}),
"[project]/theitern/node_modules/@tsparticles/interaction-external-bubble/esm/Options/Classes/BubbleDiv.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "BubbleDiv",
    ()=>BubbleDiv
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/TypeUtils.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$interaction$2d$external$2d$bubble$2f$esm$2f$Options$2f$Classes$2f$BubbleBase$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/interaction-external-bubble/esm/Options/Classes/BubbleBase.js [app-ssr] (ecmascript)");
;
;
class BubbleDiv extends __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$interaction$2d$external$2d$bubble$2f$esm$2f$Options$2f$Classes$2f$BubbleBase$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["BubbleBase"] {
    constructor(){
        super();
        this.selectors = [];
    }
    load(data) {
        super.load(data);
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isNull"])(data)) {
            return;
        }
        if (data.selectors !== undefined) {
            this.selectors = data.selectors;
        }
    }
}
}),
"[project]/theitern/node_modules/@tsparticles/interaction-external-bubble/esm/Options/Classes/Bubble.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Bubble",
    ()=>Bubble
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/Utils.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/TypeUtils.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$interaction$2d$external$2d$bubble$2f$esm$2f$Options$2f$Classes$2f$BubbleBase$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/interaction-external-bubble/esm/Options/Classes/BubbleBase.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$interaction$2d$external$2d$bubble$2f$esm$2f$Options$2f$Classes$2f$BubbleDiv$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/interaction-external-bubble/esm/Options/Classes/BubbleDiv.js [app-ssr] (ecmascript)");
;
;
;
class Bubble extends __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$interaction$2d$external$2d$bubble$2f$esm$2f$Options$2f$Classes$2f$BubbleBase$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["BubbleBase"] {
    load(data) {
        super.load(data);
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isNull"])(data)) {
            return;
        }
        this.divs = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["executeOnSingleOrMultiple"])(data.divs, (div)=>{
            const tmp = new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$interaction$2d$external$2d$bubble$2f$esm$2f$Options$2f$Classes$2f$BubbleDiv$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["BubbleDiv"]();
            tmp.load(div);
            return tmp;
        });
    }
}
}),
"[project]/theitern/node_modules/@tsparticles/interaction-external-bubble/esm/Enums.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ProcessBubbleType",
    ()=>ProcessBubbleType
]);
var ProcessBubbleType;
(function(ProcessBubbleType) {
    ProcessBubbleType["color"] = "color";
    ProcessBubbleType["opacity"] = "opacity";
    ProcessBubbleType["size"] = "size";
})(ProcessBubbleType || (ProcessBubbleType = {}));
}),
"[project]/theitern/node_modules/@tsparticles/interaction-external-bubble/esm/Utils.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "calculateBubbleValue",
    ()=>calculateBubbleValue
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/NumberUtils.js [app-ssr] (ecmascript)");
;
function calculateBubbleValue(particleValue, modeValue, optionsValue, ratio) {
    if (modeValue >= optionsValue) {
        const value = particleValue + (modeValue - optionsValue) * ratio;
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["clamp"])(value, particleValue, modeValue);
    } else if (modeValue < optionsValue) {
        const value = particleValue - (optionsValue - modeValue) * ratio;
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["clamp"])(value, modeValue, particleValue);
    }
}
}),
"[project]/theitern/node_modules/@tsparticles/interaction-external-bubble/esm/Bubbler.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Bubbler",
    ()=>Bubbler
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Ranges$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Core/Utils/Ranges.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Types$2f$DivType$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Enums/Types/DivType.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$ExternalInteractorBase$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Core/Utils/ExternalInteractorBase.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$ColorUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/ColorUtils.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/Utils.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/NumberUtils.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Core/Utils/Constants.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$interaction$2d$external$2d$bubble$2f$esm$2f$Options$2f$Classes$2f$Bubble$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/interaction-external-bubble/esm/Options/Classes/Bubble.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$interaction$2d$external$2d$bubble$2f$esm$2f$Enums$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/interaction-external-bubble/esm/Enums.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$interaction$2d$external$2d$bubble$2f$esm$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/interaction-external-bubble/esm/Utils.js [app-ssr] (ecmascript)");
;
;
;
;
const bubbleMode = "bubble", minDistance = 0, defaultClickTime = 0, double = 2, defaultOpacity = 1, ratioOffset = 1, defaultBubbleValue = 0, minRatio = 0, half = 0.5, defaultRatio = 1;
class Bubbler extends __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$ExternalInteractorBase$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ExternalInteractorBase"] {
    constructor(container, engine){
        super(container);
        this._clickBubble = ()=>{
            const container = this.container, options = container.actualOptions, mouseClickPos = container.interactivity.mouse.clickPosition, bubbleOptions = options.interactivity.modes.bubble;
            if (!bubbleOptions || !mouseClickPos) {
                return;
            }
            if (!container.bubble) {
                container.bubble = {};
            }
            const distance = container.retina.bubbleModeDistance;
            if (!distance || distance < minDistance) {
                return;
            }
            const query = container.particles.quadTree.queryCircle(mouseClickPos, distance, (p)=>this.isEnabled(p)), { bubble } = container;
            for (const particle of query){
                if (!bubble.clicking) {
                    continue;
                }
                particle.bubble.inRange = !bubble.durationEnd;
                const pos = particle.getPosition(), distMouse = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getDistance"])(pos, mouseClickPos), timeSpent = (new Date().getTime() - (container.interactivity.mouse.clickTime ?? defaultClickTime)) / __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["millisecondsToSeconds"];
                if (timeSpent > bubbleOptions.duration) {
                    bubble.durationEnd = true;
                }
                if (timeSpent > bubbleOptions.duration * double) {
                    bubble.clicking = false;
                    bubble.durationEnd = false;
                }
                const sizeData = {
                    bubbleObj: {
                        optValue: container.retina.bubbleModeSize,
                        value: particle.bubble.radius
                    },
                    particlesObj: {
                        optValue: (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getRangeMax"])(particle.options.size.value) * container.retina.pixelRatio,
                        value: particle.size.value
                    },
                    type: __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$interaction$2d$external$2d$bubble$2f$esm$2f$Enums$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ProcessBubbleType"].size
                };
                this._process(particle, distMouse, timeSpent, sizeData);
                const opacityData = {
                    bubbleObj: {
                        optValue: bubbleOptions.opacity,
                        value: particle.bubble.opacity
                    },
                    particlesObj: {
                        optValue: (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getRangeMax"])(particle.options.opacity.value),
                        value: particle.opacity?.value ?? defaultOpacity
                    },
                    type: __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$interaction$2d$external$2d$bubble$2f$esm$2f$Enums$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ProcessBubbleType"].opacity
                };
                this._process(particle, distMouse, timeSpent, opacityData);
                if (!bubble.durationEnd && distMouse <= distance) {
                    this._hoverBubbleColor(particle, distMouse);
                } else {
                    delete particle.bubble.color;
                }
            }
        };
        this._hoverBubble = ()=>{
            const container = this.container, mousePos = container.interactivity.mouse.position, distance = container.retina.bubbleModeDistance;
            if (!distance || distance < minDistance || !mousePos) {
                return;
            }
            const query = container.particles.quadTree.queryCircle(mousePos, distance, (p)=>this.isEnabled(p));
            for (const particle of query){
                particle.bubble.inRange = true;
                const pos = particle.getPosition(), pointDistance = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getDistance"])(pos, mousePos), ratio = ratioOffset - pointDistance / distance;
                if (pointDistance <= distance) {
                    if (ratio >= minRatio && container.interactivity.status === __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["mouseMoveEvent"]) {
                        this._hoverBubbleSize(particle, ratio);
                        this._hoverBubbleOpacity(particle, ratio);
                        this._hoverBubbleColor(particle, ratio);
                    }
                } else {
                    this.reset(particle);
                }
                if (container.interactivity.status === __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["mouseLeaveEvent"]) {
                    this.reset(particle);
                }
            }
        };
        this._hoverBubbleColor = (particle, ratio, divBubble)=>{
            const options = this.container.actualOptions, bubbleOptions = divBubble ?? options.interactivity.modes.bubble;
            if (!bubbleOptions) {
                return;
            }
            if (!particle.bubble.finalColor) {
                const modeColor = bubbleOptions.color;
                if (!modeColor) {
                    return;
                }
                const bubbleColor = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["itemFromSingleOrMultiple"])(modeColor);
                particle.bubble.finalColor = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$ColorUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["rangeColorToHsl"])(this._engine, bubbleColor);
            }
            if (!particle.bubble.finalColor) {
                return;
            }
            if (bubbleOptions.mix) {
                particle.bubble.color = undefined;
                const pColor = particle.getFillColor();
                particle.bubble.color = pColor ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$ColorUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["rgbToHsl"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$ColorUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["colorMix"])(pColor, particle.bubble.finalColor, ratioOffset - ratio, ratio)) : particle.bubble.finalColor;
            } else {
                particle.bubble.color = particle.bubble.finalColor;
            }
        };
        this._hoverBubbleOpacity = (particle, ratio, divBubble)=>{
            const container = this.container, options = container.actualOptions, modeOpacity = divBubble?.opacity ?? options.interactivity.modes.bubble?.opacity;
            if (!modeOpacity) {
                return;
            }
            const optOpacity = particle.options.opacity.value, pOpacity = particle.opacity?.value ?? defaultOpacity, opacity = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$interaction$2d$external$2d$bubble$2f$esm$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["calculateBubbleValue"])(pOpacity, modeOpacity, (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getRangeMax"])(optOpacity), ratio);
            if (opacity !== undefined) {
                particle.bubble.opacity = opacity;
            }
        };
        this._hoverBubbleSize = (particle, ratio, divBubble)=>{
            const container = this.container, modeSize = divBubble?.size ? divBubble.size * container.retina.pixelRatio : container.retina.bubbleModeSize;
            if (modeSize === undefined) {
                return;
            }
            const optSize = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getRangeMax"])(particle.options.size.value) * container.retina.pixelRatio, pSize = particle.size.value, size = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$interaction$2d$external$2d$bubble$2f$esm$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["calculateBubbleValue"])(pSize, modeSize, optSize, ratio);
            if (size !== undefined) {
                particle.bubble.radius = size;
            }
        };
        this._process = (particle, distMouse, timeSpent, data)=>{
            const container = this.container, bubbleParam = data.bubbleObj.optValue, options = container.actualOptions, bubbleOptions = options.interactivity.modes.bubble;
            if (!bubbleOptions || bubbleParam === undefined) {
                return;
            }
            const bubbleDuration = bubbleOptions.duration, bubbleDistance = container.retina.bubbleModeDistance, particlesParam = data.particlesObj.optValue, pObjBubble = data.bubbleObj.value, pObj = data.particlesObj.value ?? defaultBubbleValue, type = data.type;
            if (!bubbleDistance || bubbleDistance < minDistance || bubbleParam === particlesParam) {
                return;
            }
            if (!container.bubble) {
                container.bubble = {};
            }
            if (container.bubble.durationEnd) {
                if (pObjBubble) {
                    if (type === __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$interaction$2d$external$2d$bubble$2f$esm$2f$Enums$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ProcessBubbleType"].size) {
                        delete particle.bubble.radius;
                    }
                    if (type === __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$interaction$2d$external$2d$bubble$2f$esm$2f$Enums$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ProcessBubbleType"].opacity) {
                        delete particle.bubble.opacity;
                    }
                }
            } else {
                if (distMouse <= bubbleDistance) {
                    const obj = pObjBubble ?? pObj;
                    if (obj !== bubbleParam) {
                        const value = pObj - timeSpent * (pObj - bubbleParam) / bubbleDuration;
                        if (type === __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$interaction$2d$external$2d$bubble$2f$esm$2f$Enums$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ProcessBubbleType"].size) {
                            particle.bubble.radius = value;
                        }
                        if (type === __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$interaction$2d$external$2d$bubble$2f$esm$2f$Enums$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ProcessBubbleType"].opacity) {
                            particle.bubble.opacity = value;
                        }
                    }
                } else {
                    if (type === __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$interaction$2d$external$2d$bubble$2f$esm$2f$Enums$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ProcessBubbleType"].size) {
                        delete particle.bubble.radius;
                    }
                    if (type === __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$interaction$2d$external$2d$bubble$2f$esm$2f$Enums$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ProcessBubbleType"].opacity) {
                        delete particle.bubble.opacity;
                    }
                }
            }
        };
        this._singleSelectorHover = (delta, selector, div)=>{
            const container = this.container, selectors = document.querySelectorAll(selector), bubble = container.actualOptions.interactivity.modes.bubble;
            if (!bubble || !selectors.length) {
                return;
            }
            selectors.forEach((item)=>{
                const elem = item, pxRatio = container.retina.pixelRatio, pos = {
                    x: (elem.offsetLeft + elem.offsetWidth * half) * pxRatio,
                    y: (elem.offsetTop + elem.offsetHeight * half) * pxRatio
                }, repulseRadius = elem.offsetWidth * half * pxRatio, area = div.type === __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Types$2f$DivType$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["DivType"].circle ? new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Ranges$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Circle"](pos.x, pos.y, repulseRadius) : new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Ranges$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Rectangle"](elem.offsetLeft * pxRatio, elem.offsetTop * pxRatio, elem.offsetWidth * pxRatio, elem.offsetHeight * pxRatio), query = container.particles.quadTree.query(area, (p)=>this.isEnabled(p));
                for (const particle of query){
                    if (!area.contains(particle.getPosition())) {
                        continue;
                    }
                    particle.bubble.inRange = true;
                    const divs = bubble.divs, divBubble = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["divMode"])(divs, elem);
                    if (!particle.bubble.div || particle.bubble.div !== elem) {
                        this.clear(particle, delta, true);
                        particle.bubble.div = elem;
                    }
                    this._hoverBubbleSize(particle, defaultRatio, divBubble);
                    this._hoverBubbleOpacity(particle, defaultRatio, divBubble);
                    this._hoverBubbleColor(particle, defaultRatio, divBubble);
                }
            });
        };
        this._engine = engine;
        if (!container.bubble) {
            container.bubble = {};
        }
        this.handleClickMode = (mode)=>{
            if (mode !== bubbleMode) {
                return;
            }
            if (!container.bubble) {
                container.bubble = {};
            }
            container.bubble.clicking = true;
        };
    }
    clear(particle, delta, force) {
        if (particle.bubble.inRange && !force) {
            return;
        }
        delete particle.bubble.div;
        delete particle.bubble.opacity;
        delete particle.bubble.radius;
        delete particle.bubble.color;
    }
    init() {
        const container = this.container, bubble = container.actualOptions.interactivity.modes.bubble;
        if (!bubble) {
            return;
        }
        container.retina.bubbleModeDistance = bubble.distance * container.retina.pixelRatio;
        if (bubble.size !== undefined) {
            container.retina.bubbleModeSize = bubble.size * container.retina.pixelRatio;
        }
    }
    interact(delta) {
        const options = this.container.actualOptions, events = options.interactivity.events, onHover = events.onHover, onClick = events.onClick, hoverEnabled = onHover.enable, hoverMode = onHover.mode, clickEnabled = onClick.enable, clickMode = onClick.mode, divs = events.onDiv;
        if (hoverEnabled && (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isInArray"])(bubbleMode, hoverMode)) {
            this._hoverBubble();
        } else if (clickEnabled && (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isInArray"])(bubbleMode, clickMode)) {
            this._clickBubble();
        } else {
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["divModeExecute"])(bubbleMode, divs, (selector, div)=>this._singleSelectorHover(delta, selector, div));
        }
    }
    isEnabled(particle) {
        const container = this.container, options = container.actualOptions, mouse = container.interactivity.mouse, events = (particle?.interactivity ?? options.interactivity).events, { onClick, onDiv, onHover } = events, divBubble = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isDivModeEnabled"])(bubbleMode, onDiv);
        if (!(divBubble || onHover.enable && !!mouse.position || onClick.enable && mouse.clickPosition)) {
            return false;
        }
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isInArray"])(bubbleMode, onHover.mode) || (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isInArray"])(bubbleMode, onClick.mode) || divBubble;
    }
    loadModeOptions(options, ...sources) {
        if (!options.bubble) {
            options.bubble = new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$interaction$2d$external$2d$bubble$2f$esm$2f$Options$2f$Classes$2f$Bubble$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Bubble"]();
        }
        for (const source of sources){
            options.bubble.load(source?.bubble);
        }
    }
    reset(particle) {
        particle.bubble.inRange = false;
    }
}
}),
"[project]/theitern/node_modules/@tsparticles/interaction-external-bubble/esm/Options/Interfaces/IBubbleBase.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
;
}),
"[project]/theitern/node_modules/@tsparticles/interaction-external-bubble/esm/Options/Interfaces/IBubbleDiv.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
;
}),
"[project]/theitern/node_modules/@tsparticles/interaction-external-bubble/esm/Options/Interfaces/IBubble.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
;
}),
"[project]/theitern/node_modules/@tsparticles/interaction-external-bubble/esm/index.js [app-ssr] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "loadExternalBubbleInteraction",
    ()=>loadExternalBubbleInteraction
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$interaction$2d$external$2d$bubble$2f$esm$2f$Bubbler$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/interaction-external-bubble/esm/Bubbler.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$interaction$2d$external$2d$bubble$2f$esm$2f$Options$2f$Classes$2f$BubbleBase$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/interaction-external-bubble/esm/Options/Classes/BubbleBase.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$interaction$2d$external$2d$bubble$2f$esm$2f$Options$2f$Classes$2f$BubbleDiv$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/interaction-external-bubble/esm/Options/Classes/BubbleDiv.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$interaction$2d$external$2d$bubble$2f$esm$2f$Options$2f$Classes$2f$Bubble$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/interaction-external-bubble/esm/Options/Classes/Bubble.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$interaction$2d$external$2d$bubble$2f$esm$2f$Options$2f$Interfaces$2f$IBubbleBase$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/interaction-external-bubble/esm/Options/Interfaces/IBubbleBase.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$interaction$2d$external$2d$bubble$2f$esm$2f$Options$2f$Interfaces$2f$IBubbleDiv$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/interaction-external-bubble/esm/Options/Interfaces/IBubbleDiv.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$interaction$2d$external$2d$bubble$2f$esm$2f$Options$2f$Interfaces$2f$IBubble$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/interaction-external-bubble/esm/Options/Interfaces/IBubble.js [app-ssr] (ecmascript)");
;
async function loadExternalBubbleInteraction(engine, refresh = true) {
    engine.checkVersion("3.9.1");
    await engine.addInteractor("externalBubble", (container)=>{
        return Promise.resolve(new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$interaction$2d$external$2d$bubble$2f$esm$2f$Bubbler$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Bubbler"](container, engine));
    }, refresh);
}
;
;
;
;
;
;
}),
"[project]/theitern/node_modules/@tsparticles/interaction-external-connect/esm/Options/Classes/ConnectLinks.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ConnectLinks",
    ()=>ConnectLinks
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/TypeUtils.js [app-ssr] (ecmascript)");
;
class ConnectLinks {
    constructor(){
        this.opacity = 0.5;
    }
    load(data) {
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isNull"])(data)) {
            return;
        }
        if (data.opacity !== undefined) {
            this.opacity = data.opacity;
        }
    }
}
}),
"[project]/theitern/node_modules/@tsparticles/interaction-external-connect/esm/Options/Classes/Connect.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Connect",
    ()=>Connect
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/TypeUtils.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$interaction$2d$external$2d$connect$2f$esm$2f$Options$2f$Classes$2f$ConnectLinks$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/interaction-external-connect/esm/Options/Classes/ConnectLinks.js [app-ssr] (ecmascript)");
;
;
class Connect {
    constructor(){
        this.distance = 80;
        this.links = new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$interaction$2d$external$2d$connect$2f$esm$2f$Options$2f$Classes$2f$ConnectLinks$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ConnectLinks"]();
        this.radius = 60;
    }
    load(data) {
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isNull"])(data)) {
            return;
        }
        if (data.distance !== undefined) {
            this.distance = data.distance;
        }
        this.links.load(data.links);
        if (data.radius !== undefined) {
            this.radius = data.radius;
        }
    }
}
}),
"[project]/theitern/node_modules/@tsparticles/interaction-external-connect/esm/Utils.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "drawConnectLine",
    ()=>drawConnectLine,
    "drawConnection",
    ()=>drawConnection,
    "gradient",
    ()=>gradient,
    "lineStyle",
    ()=>lineStyle
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/NumberUtils.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$ColorUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/ColorUtils.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$CanvasUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/CanvasUtils.js [app-ssr] (ecmascript)");
;
const gradientMin = 0, gradientMax = 1, defaultLinksWidth = 0;
function gradient(context, p1, p2, opacity) {
    const gradStop = Math.floor(p2.getRadius() / p1.getRadius()), color1 = p1.getFillColor(), color2 = p2.getFillColor();
    if (!color1 || !color2) {
        return;
    }
    const sourcePos = p1.getPosition(), destPos = p2.getPosition(), midRgb = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$ColorUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["colorMix"])(color1, color2, p1.getRadius(), p2.getRadius()), grad = context.createLinearGradient(sourcePos.x, sourcePos.y, destPos.x, destPos.y);
    grad.addColorStop(gradientMin, (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$ColorUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getStyleFromHsl"])(color1, opacity));
    grad.addColorStop((0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["clamp"])(gradStop, gradientMin, gradientMax), (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$ColorUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getStyleFromRgb"])(midRgb, opacity));
    grad.addColorStop(gradientMax, (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$ColorUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getStyleFromHsl"])(color2, opacity));
    return grad;
}
function drawConnectLine(context, width, lineStyle, begin, end) {
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$CanvasUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["drawLine"])(context, begin, end);
    context.lineWidth = width;
    context.strokeStyle = lineStyle;
    context.stroke();
}
function lineStyle(container, ctx, p1, p2) {
    const options = container.actualOptions, connectOptions = options.interactivity.modes.connect;
    if (!connectOptions) {
        return;
    }
    return gradient(ctx, p1, p2, connectOptions.links.opacity);
}
function drawConnection(container, p1, p2) {
    container.canvas.draw((ctx)=>{
        const ls = lineStyle(container, ctx, p1, p2);
        if (!ls) {
            return;
        }
        const pos1 = p1.getPosition(), pos2 = p2.getPosition();
        drawConnectLine(ctx, p1.retina.linksWidth ?? defaultLinksWidth, ls, pos1, pos2);
    });
}
}),
"[project]/theitern/node_modules/@tsparticles/interaction-external-connect/esm/Connector.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Connector",
    ()=>Connector
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$ExternalInteractorBase$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Core/Utils/ExternalInteractorBase.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/Utils.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$interaction$2d$external$2d$connect$2f$esm$2f$Options$2f$Classes$2f$Connect$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/interaction-external-connect/esm/Options/Classes/Connect.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$interaction$2d$external$2d$connect$2f$esm$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/interaction-external-connect/esm/Utils.js [app-ssr] (ecmascript)");
;
;
;
const connectMode = "connect", minDistance = 0;
class Connector extends __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$ExternalInteractorBase$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ExternalInteractorBase"] {
    constructor(container){
        super(container);
    }
    clear() {}
    init() {
        const container = this.container, connect = container.actualOptions.interactivity.modes.connect;
        if (!connect) {
            return;
        }
        container.retina.connectModeDistance = connect.distance * container.retina.pixelRatio;
        container.retina.connectModeRadius = connect.radius * container.retina.pixelRatio;
    }
    interact() {
        const container = this.container, options = container.actualOptions;
        if (options.interactivity.events.onHover.enable && container.interactivity.status === "pointermove") {
            const mousePos = container.interactivity.mouse.position, { connectModeDistance, connectModeRadius } = container.retina;
            if (!connectModeDistance || connectModeDistance < minDistance || !connectModeRadius || connectModeRadius < minDistance || !mousePos) {
                return;
            }
            const distance = Math.abs(connectModeRadius), query = container.particles.quadTree.queryCircle(mousePos, distance, (p)=>this.isEnabled(p));
            query.forEach((p1, i)=>{
                const pos1 = p1.getPosition(), indexOffset = 1;
                for (const p2 of query.slice(i + indexOffset)){
                    const pos2 = p2.getPosition(), distMax = Math.abs(connectModeDistance), xDiff = Math.abs(pos1.x - pos2.x), yDiff = Math.abs(pos1.y - pos2.y);
                    if (xDiff < distMax && yDiff < distMax) {
                        (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$interaction$2d$external$2d$connect$2f$esm$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["drawConnection"])(container, p1, p2);
                    }
                }
            });
        }
    }
    isEnabled(particle) {
        const container = this.container, mouse = container.interactivity.mouse, events = (particle?.interactivity ?? container.actualOptions.interactivity).events;
        if (!(events.onHover.enable && mouse.position)) {
            return false;
        }
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isInArray"])(connectMode, events.onHover.mode);
    }
    loadModeOptions(options, ...sources) {
        if (!options.connect) {
            options.connect = new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$interaction$2d$external$2d$connect$2f$esm$2f$Options$2f$Classes$2f$Connect$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Connect"]();
        }
        for (const source of sources){
            options.connect.load(source?.connect);
        }
    }
    reset() {}
}
}),
"[project]/theitern/node_modules/@tsparticles/interaction-external-connect/esm/Options/Interfaces/IConnect.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
;
}),
"[project]/theitern/node_modules/@tsparticles/interaction-external-connect/esm/Options/Interfaces/IConnectLinks.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
;
}),
"[project]/theitern/node_modules/@tsparticles/interaction-external-connect/esm/index.js [app-ssr] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "loadExternalConnectInteraction",
    ()=>loadExternalConnectInteraction
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$interaction$2d$external$2d$connect$2f$esm$2f$Connector$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/interaction-external-connect/esm/Connector.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$interaction$2d$external$2d$connect$2f$esm$2f$Options$2f$Classes$2f$Connect$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/interaction-external-connect/esm/Options/Classes/Connect.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$interaction$2d$external$2d$connect$2f$esm$2f$Options$2f$Classes$2f$ConnectLinks$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/interaction-external-connect/esm/Options/Classes/ConnectLinks.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$interaction$2d$external$2d$connect$2f$esm$2f$Options$2f$Interfaces$2f$IConnect$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/interaction-external-connect/esm/Options/Interfaces/IConnect.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$interaction$2d$external$2d$connect$2f$esm$2f$Options$2f$Interfaces$2f$IConnectLinks$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/interaction-external-connect/esm/Options/Interfaces/IConnectLinks.js [app-ssr] (ecmascript)");
;
async function loadExternalConnectInteraction(engine, refresh = true) {
    engine.checkVersion("3.9.1");
    await engine.addInteractor("externalConnect", (container)=>{
        return Promise.resolve(new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$interaction$2d$external$2d$connect$2f$esm$2f$Connector$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Connector"](container));
    }, refresh);
}
;
;
;
;
}),
"[project]/theitern/node_modules/@tsparticles/interaction-external-grab/esm/Options/Classes/GrabLinks.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "GrabLinks",
    ()=>GrabLinks
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$OptionsColor$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Classes/OptionsColor.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/TypeUtils.js [app-ssr] (ecmascript)");
;
class GrabLinks {
    constructor(){
        this.blink = false;
        this.consent = false;
        this.opacity = 1;
    }
    load(data) {
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isNull"])(data)) {
            return;
        }
        if (data.blink !== undefined) {
            this.blink = data.blink;
        }
        if (data.color !== undefined) {
            this.color = __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$OptionsColor$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["OptionsColor"].create(this.color, data.color);
        }
        if (data.consent !== undefined) {
            this.consent = data.consent;
        }
        if (data.opacity !== undefined) {
            this.opacity = data.opacity;
        }
    }
}
}),
"[project]/theitern/node_modules/@tsparticles/interaction-external-grab/esm/Options/Classes/Grab.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Grab",
    ()=>Grab
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/TypeUtils.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$interaction$2d$external$2d$grab$2f$esm$2f$Options$2f$Classes$2f$GrabLinks$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/interaction-external-grab/esm/Options/Classes/GrabLinks.js [app-ssr] (ecmascript)");
;
;
class Grab {
    constructor(){
        this.distance = 100;
        this.links = new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$interaction$2d$external$2d$grab$2f$esm$2f$Options$2f$Classes$2f$GrabLinks$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["GrabLinks"]();
    }
    load(data) {
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isNull"])(data)) {
            return;
        }
        if (data.distance !== undefined) {
            this.distance = data.distance;
        }
        this.links.load(data.links);
    }
}
}),
"[project]/theitern/node_modules/@tsparticles/interaction-external-grab/esm/Utils.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "drawGrab",
    ()=>drawGrab,
    "drawGrabLine",
    ()=>drawGrabLine
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$CanvasUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/CanvasUtils.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$ColorUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/ColorUtils.js [app-ssr] (ecmascript)");
;
const defaultWidth = 0;
function drawGrabLine(context, width, begin, end, colorLine, opacity) {
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$CanvasUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["drawLine"])(context, begin, end);
    context.strokeStyle = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$ColorUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getStyleFromRgb"])(colorLine, opacity);
    context.lineWidth = width;
    context.stroke();
}
function drawGrab(container, particle, lineColor, opacity, mousePos) {
    container.canvas.draw((ctx)=>{
        const beginPos = particle.getPosition();
        drawGrabLine(ctx, particle.retina.linksWidth ?? defaultWidth, beginPos, mousePos, lineColor, opacity);
    });
}
}),
"[project]/theitern/node_modules/@tsparticles/interaction-external-grab/esm/Grabber.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Grabber",
    ()=>Grabber
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$ExternalInteractorBase$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Core/Utils/ExternalInteractorBase.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/NumberUtils.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$ColorUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/ColorUtils.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/Utils.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Core/Utils/Constants.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$interaction$2d$external$2d$grab$2f$esm$2f$Options$2f$Classes$2f$Grab$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/interaction-external-grab/esm/Options/Classes/Grab.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$interaction$2d$external$2d$grab$2f$esm$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/interaction-external-grab/esm/Utils.js [app-ssr] (ecmascript)");
;
;
;
const grabMode = "grab", minDistance = 0, minOpacity = 0;
class Grabber extends __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$ExternalInteractorBase$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ExternalInteractorBase"] {
    constructor(container, engine){
        super(container);
        this._engine = engine;
    }
    clear() {}
    init() {
        const container = this.container, grab = container.actualOptions.interactivity.modes.grab;
        if (!grab) {
            return;
        }
        container.retina.grabModeDistance = grab.distance * container.retina.pixelRatio;
    }
    interact() {
        const container = this.container, options = container.actualOptions, interactivity = options.interactivity;
        if (!interactivity.modes.grab || !interactivity.events.onHover.enable || container.interactivity.status !== __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["mouseMoveEvent"]) {
            return;
        }
        const mousePos = container.interactivity.mouse.position;
        if (!mousePos) {
            return;
        }
        const distance = container.retina.grabModeDistance;
        if (!distance || distance < minDistance) {
            return;
        }
        const query = container.particles.quadTree.queryCircle(mousePos, distance, (p)=>this.isEnabled(p));
        for (const particle of query){
            const pos = particle.getPosition(), pointDistance = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getDistance"])(pos, mousePos);
            if (pointDistance > distance) {
                continue;
            }
            const grabLineOptions = interactivity.modes.grab.links, lineOpacity = grabLineOptions.opacity, opacityLine = lineOpacity - pointDistance * lineOpacity / distance;
            if (opacityLine <= minOpacity) {
                continue;
            }
            const optColor = grabLineOptions.color ?? particle.options.links?.color;
            if (!container.particles.grabLineColor && optColor) {
                const linksOptions = interactivity.modes.grab.links;
                container.particles.grabLineColor = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$ColorUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getLinkRandomColor"])(this._engine, optColor, linksOptions.blink, linksOptions.consent);
            }
            const colorLine = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$ColorUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getLinkColor"])(particle, undefined, container.particles.grabLineColor);
            if (!colorLine) {
                continue;
            }
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$interaction$2d$external$2d$grab$2f$esm$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["drawGrab"])(container, particle, colorLine, opacityLine, mousePos);
        }
    }
    isEnabled(particle) {
        const container = this.container, mouse = container.interactivity.mouse, events = (particle?.interactivity ?? container.actualOptions.interactivity).events;
        return events.onHover.enable && !!mouse.position && (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isInArray"])(grabMode, events.onHover.mode);
    }
    loadModeOptions(options, ...sources) {
        if (!options.grab) {
            options.grab = new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$interaction$2d$external$2d$grab$2f$esm$2f$Options$2f$Classes$2f$Grab$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Grab"]();
        }
        for (const source of sources){
            options.grab.load(source?.grab);
        }
    }
    reset() {}
}
}),
"[project]/theitern/node_modules/@tsparticles/interaction-external-grab/esm/Options/Interfaces/IGrab.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
;
}),
"[project]/theitern/node_modules/@tsparticles/interaction-external-grab/esm/Options/Interfaces/IGrabLinks.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
;
}),
"[project]/theitern/node_modules/@tsparticles/interaction-external-grab/esm/index.js [app-ssr] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "loadExternalGrabInteraction",
    ()=>loadExternalGrabInteraction
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$interaction$2d$external$2d$grab$2f$esm$2f$Grabber$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/interaction-external-grab/esm/Grabber.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$interaction$2d$external$2d$grab$2f$esm$2f$Options$2f$Classes$2f$Grab$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/interaction-external-grab/esm/Options/Classes/Grab.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$interaction$2d$external$2d$grab$2f$esm$2f$Options$2f$Classes$2f$GrabLinks$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/interaction-external-grab/esm/Options/Classes/GrabLinks.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$interaction$2d$external$2d$grab$2f$esm$2f$Options$2f$Interfaces$2f$IGrab$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/interaction-external-grab/esm/Options/Interfaces/IGrab.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$interaction$2d$external$2d$grab$2f$esm$2f$Options$2f$Interfaces$2f$IGrabLinks$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/interaction-external-grab/esm/Options/Interfaces/IGrabLinks.js [app-ssr] (ecmascript)");
;
async function loadExternalGrabInteraction(engine, refresh = true) {
    engine.checkVersion("3.9.1");
    await engine.addInteractor("externalGrab", (container)=>{
        return Promise.resolve(new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$interaction$2d$external$2d$grab$2f$esm$2f$Grabber$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Grabber"](container, engine));
    }, refresh);
}
;
;
;
;
}),
"[project]/theitern/node_modules/@tsparticles/interaction-external-pause/esm/Pauser.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Pauser",
    ()=>Pauser
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$ExternalInteractorBase$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Core/Utils/ExternalInteractorBase.js [app-ssr] (ecmascript)");
;
const pauseMode = "pause";
class Pauser extends __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$ExternalInteractorBase$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ExternalInteractorBase"] {
    constructor(container){
        super(container);
        this.handleClickMode = (mode)=>{
            if (mode !== pauseMode) {
                return;
            }
            const container = this.container;
            if (container.animationStatus) {
                container.pause();
            } else {
                container.play();
            }
        };
    }
    clear() {}
    init() {}
    interact() {}
    isEnabled() {
        return true;
    }
    reset() {}
}
}),
"[project]/theitern/node_modules/@tsparticles/interaction-external-pause/esm/index.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "loadExternalPauseInteraction",
    ()=>loadExternalPauseInteraction
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$interaction$2d$external$2d$pause$2f$esm$2f$Pauser$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/interaction-external-pause/esm/Pauser.js [app-ssr] (ecmascript)");
;
async function loadExternalPauseInteraction(engine, refresh = true) {
    engine.checkVersion("3.9.1");
    await engine.addInteractor("externalPause", (container)=>{
        return Promise.resolve(new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$interaction$2d$external$2d$pause$2f$esm$2f$Pauser$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Pauser"](container));
    }, refresh);
}
}),
"[project]/theitern/node_modules/@tsparticles/interaction-external-push/esm/Options/Classes/Push.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Push",
    ()=>Push
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/Utils.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/TypeUtils.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/NumberUtils.js [app-ssr] (ecmascript)");
;
class Push {
    constructor(){
        this.default = true;
        this.groups = [];
        this.quantity = 4;
    }
    load(data) {
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isNull"])(data)) {
            return;
        }
        if (data.default !== undefined) {
            this.default = data.default;
        }
        if (data.groups !== undefined) {
            this.groups = data.groups.map((t)=>t);
        }
        if (!this.groups.length) {
            this.default = true;
        }
        const quantity = data.quantity;
        if (quantity !== undefined) {
            this.quantity = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["setRangeValue"])(quantity);
        }
        this.particles = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["executeOnSingleOrMultiple"])(data.particles, (particles)=>{
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["deepExtend"])({}, particles);
        });
    }
}
}),
"[project]/theitern/node_modules/@tsparticles/interaction-external-push/esm/Pusher.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Pusher",
    ()=>Pusher
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$ExternalInteractorBase$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Core/Utils/ExternalInteractorBase.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/Utils.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/NumberUtils.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$interaction$2d$external$2d$push$2f$esm$2f$Options$2f$Classes$2f$Push$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/interaction-external-push/esm/Options/Classes/Push.js [app-ssr] (ecmascript)");
;
;
const pushMode = "push", minQuantity = 0;
class Pusher extends __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$ExternalInteractorBase$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ExternalInteractorBase"] {
    constructor(container){
        super(container);
        this.handleClickMode = (mode)=>{
            if (mode !== pushMode) {
                return;
            }
            const container = this.container, options = container.actualOptions, pushOptions = options.interactivity.modes.push;
            if (!pushOptions) {
                return;
            }
            const quantity = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getRangeValue"])(pushOptions.quantity);
            if (quantity <= minQuantity) {
                return;
            }
            const group = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["itemFromArray"])([
                undefined,
                ...pushOptions.groups
            ]), groupOptions = group !== undefined ? container.actualOptions.particles.groups[group] : undefined, particlesOptions = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["itemFromSingleOrMultiple"])(pushOptions.particles), overrideOptions = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["deepExtend"])(groupOptions, particlesOptions);
            void container.particles.push(quantity, container.interactivity.mouse, overrideOptions, group);
        };
    }
    clear() {}
    init() {}
    interact() {}
    isEnabled() {
        return true;
    }
    loadModeOptions(options, ...sources) {
        if (!options.push) {
            options.push = new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$interaction$2d$external$2d$push$2f$esm$2f$Options$2f$Classes$2f$Push$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Push"]();
        }
        for (const source of sources){
            options.push.load(source?.push);
        }
    }
    reset() {}
}
}),
"[project]/theitern/node_modules/@tsparticles/interaction-external-push/esm/Options/Interfaces/IPush.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
;
}),
"[project]/theitern/node_modules/@tsparticles/interaction-external-push/esm/index.js [app-ssr] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "loadExternalPushInteraction",
    ()=>loadExternalPushInteraction
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$interaction$2d$external$2d$push$2f$esm$2f$Pusher$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/interaction-external-push/esm/Pusher.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$interaction$2d$external$2d$push$2f$esm$2f$Options$2f$Classes$2f$Push$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/interaction-external-push/esm/Options/Classes/Push.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$interaction$2d$external$2d$push$2f$esm$2f$Options$2f$Interfaces$2f$IPush$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/interaction-external-push/esm/Options/Interfaces/IPush.js [app-ssr] (ecmascript)");
;
async function loadExternalPushInteraction(engine, refresh = true) {
    engine.checkVersion("3.9.1");
    await engine.addInteractor("externalPush", (container)=>{
        return Promise.resolve(new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$interaction$2d$external$2d$push$2f$esm$2f$Pusher$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Pusher"](container));
    }, refresh);
}
;
;
}),
"[project]/theitern/node_modules/@tsparticles/interaction-external-remove/esm/Options/Classes/Remove.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Remove",
    ()=>Remove
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/TypeUtils.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/NumberUtils.js [app-ssr] (ecmascript)");
;
class Remove {
    constructor(){
        this.quantity = 2;
    }
    load(data) {
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isNull"])(data)) {
            return;
        }
        const quantity = data.quantity;
        if (quantity !== undefined) {
            this.quantity = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["setRangeValue"])(quantity);
        }
    }
}
}),
"[project]/theitern/node_modules/@tsparticles/interaction-external-remove/esm/Remover.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Remover",
    ()=>Remover
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$ExternalInteractorBase$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Core/Utils/ExternalInteractorBase.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/NumberUtils.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$interaction$2d$external$2d$remove$2f$esm$2f$Options$2f$Classes$2f$Remove$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/interaction-external-remove/esm/Options/Classes/Remove.js [app-ssr] (ecmascript)");
;
;
const removeMode = "remove";
class Remover extends __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$ExternalInteractorBase$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ExternalInteractorBase"] {
    constructor(container){
        super(container);
        this.handleClickMode = (mode)=>{
            const container = this.container, options = container.actualOptions;
            if (!options.interactivity.modes.remove || mode !== removeMode) {
                return;
            }
            const removeNb = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getRangeValue"])(options.interactivity.modes.remove.quantity);
            container.particles.removeQuantity(removeNb);
        };
    }
    clear() {}
    init() {}
    interact() {}
    isEnabled() {
        return true;
    }
    loadModeOptions(options, ...sources) {
        if (!options.remove) {
            options.remove = new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$interaction$2d$external$2d$remove$2f$esm$2f$Options$2f$Classes$2f$Remove$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Remove"]();
        }
        for (const source of sources){
            options.remove.load(source?.remove);
        }
    }
    reset() {}
}
}),
"[project]/theitern/node_modules/@tsparticles/interaction-external-remove/esm/Options/Interfaces/IRemove.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
;
}),
"[project]/theitern/node_modules/@tsparticles/interaction-external-remove/esm/index.js [app-ssr] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "loadExternalRemoveInteraction",
    ()=>loadExternalRemoveInteraction
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$interaction$2d$external$2d$remove$2f$esm$2f$Remover$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/interaction-external-remove/esm/Remover.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$interaction$2d$external$2d$remove$2f$esm$2f$Options$2f$Classes$2f$Remove$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/interaction-external-remove/esm/Options/Classes/Remove.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$interaction$2d$external$2d$remove$2f$esm$2f$Options$2f$Interfaces$2f$IRemove$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/interaction-external-remove/esm/Options/Interfaces/IRemove.js [app-ssr] (ecmascript)");
;
async function loadExternalRemoveInteraction(engine, refresh = true) {
    engine.checkVersion("3.9.1");
    await engine.addInteractor("externalRemove", (container)=>{
        return Promise.resolve(new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$interaction$2d$external$2d$remove$2f$esm$2f$Remover$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Remover"](container));
    }, refresh);
}
;
;
}),
"[project]/theitern/node_modules/@tsparticles/interaction-external-repulse/esm/Options/Classes/RepulseBase.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "RepulseBase",
    ()=>RepulseBase
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Types$2f$EasingType$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Enums/Types/EasingType.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/TypeUtils.js [app-ssr] (ecmascript)");
;
class RepulseBase {
    constructor(){
        this.distance = 200;
        this.duration = 0.4;
        this.factor = 100;
        this.speed = 1;
        this.maxSpeed = 50;
        this.easing = __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Types$2f$EasingType$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["EasingType"].easeOutQuad;
    }
    load(data) {
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isNull"])(data)) {
            return;
        }
        if (data.distance !== undefined) {
            this.distance = data.distance;
        }
        if (data.duration !== undefined) {
            this.duration = data.duration;
        }
        if (data.easing !== undefined) {
            this.easing = data.easing;
        }
        if (data.factor !== undefined) {
            this.factor = data.factor;
        }
        if (data.speed !== undefined) {
            this.speed = data.speed;
        }
        if (data.maxSpeed !== undefined) {
            this.maxSpeed = data.maxSpeed;
        }
    }
}
}),
"[project]/theitern/node_modules/@tsparticles/interaction-external-repulse/esm/Options/Classes/RepulseDiv.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "RepulseDiv",
    ()=>RepulseDiv
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/TypeUtils.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$interaction$2d$external$2d$repulse$2f$esm$2f$Options$2f$Classes$2f$RepulseBase$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/interaction-external-repulse/esm/Options/Classes/RepulseBase.js [app-ssr] (ecmascript)");
;
;
class RepulseDiv extends __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$interaction$2d$external$2d$repulse$2f$esm$2f$Options$2f$Classes$2f$RepulseBase$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["RepulseBase"] {
    constructor(){
        super();
        this.selectors = [];
    }
    load(data) {
        super.load(data);
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isNull"])(data)) {
            return;
        }
        if (data.selectors !== undefined) {
            this.selectors = data.selectors;
        }
    }
}
}),
"[project]/theitern/node_modules/@tsparticles/interaction-external-repulse/esm/Options/Classes/Repulse.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Repulse",
    ()=>Repulse
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/Utils.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/TypeUtils.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$interaction$2d$external$2d$repulse$2f$esm$2f$Options$2f$Classes$2f$RepulseBase$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/interaction-external-repulse/esm/Options/Classes/RepulseBase.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$interaction$2d$external$2d$repulse$2f$esm$2f$Options$2f$Classes$2f$RepulseDiv$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/interaction-external-repulse/esm/Options/Classes/RepulseDiv.js [app-ssr] (ecmascript)");
;
;
;
class Repulse extends __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$interaction$2d$external$2d$repulse$2f$esm$2f$Options$2f$Classes$2f$RepulseBase$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["RepulseBase"] {
    load(data) {
        super.load(data);
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isNull"])(data)) {
            return;
        }
        this.divs = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["executeOnSingleOrMultiple"])(data.divs, (div)=>{
            const tmp = new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$interaction$2d$external$2d$repulse$2f$esm$2f$Options$2f$Classes$2f$RepulseDiv$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["RepulseDiv"]();
            tmp.load(div);
            return tmp;
        });
    }
}
}),
"[project]/theitern/node_modules/@tsparticles/interaction-external-repulse/esm/Repulser.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Repulser",
    ()=>Repulser
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Ranges$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Core/Utils/Ranges.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Types$2f$DivType$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Enums/Types/DivType.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$ExternalInteractorBase$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Core/Utils/ExternalInteractorBase.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Vectors$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Core/Utils/Vectors.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/NumberUtils.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/Utils.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Core/Utils/Constants.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$interaction$2d$external$2d$repulse$2f$esm$2f$Options$2f$Classes$2f$Repulse$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/interaction-external-repulse/esm/Options/Classes/Repulse.js [app-ssr] (ecmascript)");
;
;
const repulseMode = "repulse", minDistance = 0, repulseRadiusFactor = 6, repulseRadiusPower = 3, squarePower = 2, minRadius = 0, minSpeed = 0, easingOffset = 1, half = 0.5;
class Repulser extends __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$ExternalInteractorBase$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ExternalInteractorBase"] {
    constructor(engine, container){
        super(container);
        this._clickRepulse = ()=>{
            const container = this.container, repulseOptions = container.actualOptions.interactivity.modes.repulse;
            if (!repulseOptions) {
                return;
            }
            const repulse = container.repulse ?? {
                particles: []
            };
            if (!repulse.finish) {
                if (!repulse.count) {
                    repulse.count = 0;
                }
                repulse.count++;
                if (repulse.count === container.particles.count) {
                    repulse.finish = true;
                }
            }
            if (repulse.clicking) {
                const repulseDistance = container.retina.repulseModeDistance;
                if (!repulseDistance || repulseDistance < minDistance) {
                    return;
                }
                const repulseRadius = Math.pow(repulseDistance / repulseRadiusFactor, repulseRadiusPower), mouseClickPos = container.interactivity.mouse.clickPosition;
                if (mouseClickPos === undefined) {
                    return;
                }
                const range = new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Ranges$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Circle"](mouseClickPos.x, mouseClickPos.y, repulseRadius), query = container.particles.quadTree.query(range, (p)=>this.isEnabled(p));
                for (const particle of query){
                    const { dx, dy, distance } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getDistances"])(mouseClickPos, particle.position), d = distance ** squarePower, velocity = repulseOptions.speed, force = -repulseRadius * velocity / d;
                    if (d <= repulseRadius) {
                        repulse.particles.push(particle);
                        const vect = __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Vectors$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Vector"].create(dx, dy);
                        vect.length = force;
                        particle.velocity.setTo(vect);
                    }
                }
            } else if (repulse.clicking === false) {
                for (const particle of repulse.particles){
                    particle.velocity.setTo(particle.initialVelocity);
                }
                repulse.particles = [];
            }
        };
        this._hoverRepulse = ()=>{
            const container = this.container, mousePos = container.interactivity.mouse.position, repulseRadius = container.retina.repulseModeDistance;
            if (!repulseRadius || repulseRadius < minRadius || !mousePos) {
                return;
            }
            this._processRepulse(mousePos, repulseRadius, new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Ranges$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Circle"](mousePos.x, mousePos.y, repulseRadius));
        };
        this._processRepulse = (position, repulseRadius, area, divRepulse)=>{
            const container = this.container, query = container.particles.quadTree.query(area, (p)=>this.isEnabled(p)), repulseOptions = container.actualOptions.interactivity.modes.repulse;
            if (!repulseOptions) {
                return;
            }
            const { easing, speed, factor, maxSpeed } = repulseOptions, easingFunc = this._engine.getEasing(easing), velocity = (divRepulse?.speed ?? speed) * factor;
            for (const particle of query){
                const { dx, dy, distance } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getDistances"])(particle.position, position), repulseFactor = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["clamp"])(easingFunc(easingOffset - distance / repulseRadius) * velocity, minSpeed, maxSpeed), normVec = __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Vectors$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Vector"].create(!distance ? velocity : dx / distance * repulseFactor, !distance ? velocity : dy / distance * repulseFactor);
                particle.position.addTo(normVec);
            }
        };
        this._singleSelectorRepulse = (selector, div)=>{
            const container = this.container, repulse = container.actualOptions.interactivity.modes.repulse;
            if (!repulse) {
                return;
            }
            const query = document.querySelectorAll(selector);
            if (!query.length) {
                return;
            }
            query.forEach((item)=>{
                const elem = item, pxRatio = container.retina.pixelRatio, pos = {
                    x: (elem.offsetLeft + elem.offsetWidth * half) * pxRatio,
                    y: (elem.offsetTop + elem.offsetHeight * half) * pxRatio
                }, repulseRadius = elem.offsetWidth * half * pxRatio, area = div.type === __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Types$2f$DivType$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["DivType"].circle ? new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Ranges$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Circle"](pos.x, pos.y, repulseRadius) : new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Ranges$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Rectangle"](elem.offsetLeft * pxRatio, elem.offsetTop * pxRatio, elem.offsetWidth * pxRatio, elem.offsetHeight * pxRatio), divs = repulse.divs, divRepulse = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["divMode"])(divs, elem);
                this._processRepulse(pos, repulseRadius, area, divRepulse);
            });
        };
        this._engine = engine;
        if (!container.repulse) {
            container.repulse = {
                particles: []
            };
        }
        this.handleClickMode = (mode)=>{
            const options = this.container.actualOptions, repulseOpts = options.interactivity.modes.repulse;
            if (!repulseOpts || mode !== repulseMode) {
                return;
            }
            if (!container.repulse) {
                container.repulse = {
                    particles: []
                };
            }
            const repulse = container.repulse;
            repulse.clicking = true;
            repulse.count = 0;
            for (const particle of container.repulse.particles){
                if (!this.isEnabled(particle)) {
                    continue;
                }
                particle.velocity.setTo(particle.initialVelocity);
            }
            repulse.particles = [];
            repulse.finish = false;
            setTimeout(()=>{
                if (container.destroyed) {
                    return;
                }
                repulse.clicking = false;
            }, repulseOpts.duration * __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["millisecondsToSeconds"]);
        };
    }
    clear() {}
    init() {
        const container = this.container, repulse = container.actualOptions.interactivity.modes.repulse;
        if (!repulse) {
            return;
        }
        container.retina.repulseModeDistance = repulse.distance * container.retina.pixelRatio;
    }
    interact() {
        const container = this.container, options = container.actualOptions, mouseMoveStatus = container.interactivity.status === __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["mouseMoveEvent"], events = options.interactivity.events, hover = events.onHover, hoverEnabled = hover.enable, hoverMode = hover.mode, click = events.onClick, clickEnabled = click.enable, clickMode = click.mode, divs = events.onDiv;
        if (mouseMoveStatus && hoverEnabled && (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isInArray"])(repulseMode, hoverMode)) {
            this._hoverRepulse();
        } else if (clickEnabled && (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isInArray"])(repulseMode, clickMode)) {
            this._clickRepulse();
        } else {
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["divModeExecute"])(repulseMode, divs, (selector, div)=>this._singleSelectorRepulse(selector, div));
        }
    }
    isEnabled(particle) {
        const container = this.container, options = container.actualOptions, mouse = container.interactivity.mouse, events = (particle?.interactivity ?? options.interactivity).events, divs = events.onDiv, hover = events.onHover, click = events.onClick, divRepulse = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isDivModeEnabled"])(repulseMode, divs);
        if (!(divRepulse || hover.enable && !!mouse.position || click.enable && mouse.clickPosition)) {
            return false;
        }
        const hoverMode = hover.mode, clickMode = click.mode;
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isInArray"])(repulseMode, hoverMode) || (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isInArray"])(repulseMode, clickMode) || divRepulse;
    }
    loadModeOptions(options, ...sources) {
        if (!options.repulse) {
            options.repulse = new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$interaction$2d$external$2d$repulse$2f$esm$2f$Options$2f$Classes$2f$Repulse$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Repulse"]();
        }
        for (const source of sources){
            options.repulse.load(source?.repulse);
        }
    }
    reset() {}
}
}),
"[project]/theitern/node_modules/@tsparticles/interaction-external-repulse/esm/Options/Interfaces/IRepulseBase.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
;
}),
"[project]/theitern/node_modules/@tsparticles/interaction-external-repulse/esm/Options/Interfaces/IRepulseDiv.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
;
}),
"[project]/theitern/node_modules/@tsparticles/interaction-external-repulse/esm/Options/Interfaces/IRepulse.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
;
}),
"[project]/theitern/node_modules/@tsparticles/interaction-external-repulse/esm/index.js [app-ssr] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "loadExternalRepulseInteraction",
    ()=>loadExternalRepulseInteraction
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$interaction$2d$external$2d$repulse$2f$esm$2f$Repulser$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/interaction-external-repulse/esm/Repulser.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$interaction$2d$external$2d$repulse$2f$esm$2f$Options$2f$Classes$2f$RepulseBase$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/interaction-external-repulse/esm/Options/Classes/RepulseBase.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$interaction$2d$external$2d$repulse$2f$esm$2f$Options$2f$Classes$2f$RepulseDiv$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/interaction-external-repulse/esm/Options/Classes/RepulseDiv.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$interaction$2d$external$2d$repulse$2f$esm$2f$Options$2f$Classes$2f$Repulse$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/interaction-external-repulse/esm/Options/Classes/Repulse.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$interaction$2d$external$2d$repulse$2f$esm$2f$Options$2f$Interfaces$2f$IRepulseBase$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/interaction-external-repulse/esm/Options/Interfaces/IRepulseBase.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$interaction$2d$external$2d$repulse$2f$esm$2f$Options$2f$Interfaces$2f$IRepulseDiv$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/interaction-external-repulse/esm/Options/Interfaces/IRepulseDiv.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$interaction$2d$external$2d$repulse$2f$esm$2f$Options$2f$Interfaces$2f$IRepulse$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/interaction-external-repulse/esm/Options/Interfaces/IRepulse.js [app-ssr] (ecmascript)");
;
async function loadExternalRepulseInteraction(engine, refresh = true) {
    engine.checkVersion("3.9.1");
    await engine.addInteractor("externalRepulse", (container)=>{
        return Promise.resolve(new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$interaction$2d$external$2d$repulse$2f$esm$2f$Repulser$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Repulser"](engine, container));
    }, refresh);
}
;
;
;
;
;
;
}),
"[project]/theitern/node_modules/@tsparticles/interaction-external-slow/esm/Options/Classes/Slow.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Slow",
    ()=>Slow
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/TypeUtils.js [app-ssr] (ecmascript)");
;
class Slow {
    constructor(){
        this.factor = 3;
        this.radius = 200;
    }
    load(data) {
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isNull"])(data)) {
            return;
        }
        if (data.factor !== undefined) {
            this.factor = data.factor;
        }
        if (data.radius !== undefined) {
            this.radius = data.radius;
        }
    }
}
}),
"[project]/theitern/node_modules/@tsparticles/interaction-external-slow/esm/Slower.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Slower",
    ()=>Slower
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$ExternalInteractorBase$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Core/Utils/ExternalInteractorBase.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/NumberUtils.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/Utils.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$interaction$2d$external$2d$slow$2f$esm$2f$Options$2f$Classes$2f$Slow$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/interaction-external-slow/esm/Options/Classes/Slow.js [app-ssr] (ecmascript)");
;
;
const slowMode = "slow", minRadius = 0;
class Slower extends __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$ExternalInteractorBase$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ExternalInteractorBase"] {
    constructor(container){
        super(container);
    }
    clear(particle, delta, force) {
        if (particle.slow.inRange && !force) {
            return;
        }
        particle.slow.factor = 1;
    }
    init() {
        const container = this.container, slow = container.actualOptions.interactivity.modes.slow;
        if (!slow) {
            return;
        }
        container.retina.slowModeRadius = slow.radius * container.retina.pixelRatio;
    }
    interact() {}
    isEnabled(particle) {
        const container = this.container, mouse = container.interactivity.mouse, events = (particle?.interactivity ?? container.actualOptions.interactivity).events;
        return events.onHover.enable && !!mouse.position && (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isInArray"])(slowMode, events.onHover.mode);
    }
    loadModeOptions(options, ...sources) {
        if (!options.slow) {
            options.slow = new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$interaction$2d$external$2d$slow$2f$esm$2f$Options$2f$Classes$2f$Slow$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Slow"]();
        }
        for (const source of sources){
            options.slow.load(source?.slow);
        }
    }
    reset(particle) {
        particle.slow.inRange = false;
        const container = this.container, options = container.actualOptions, mousePos = container.interactivity.mouse.position, radius = container.retina.slowModeRadius, slowOptions = options.interactivity.modes.slow;
        if (!slowOptions || !radius || radius < minRadius || !mousePos) {
            return;
        }
        const particlePos = particle.getPosition(), dist = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getDistance"])(mousePos, particlePos), proximityFactor = dist / radius, slowFactor = slowOptions.factor, { slow } = particle;
        if (dist > radius) {
            return;
        }
        slow.inRange = true;
        slow.factor = proximityFactor / slowFactor;
    }
}
}),
"[project]/theitern/node_modules/@tsparticles/interaction-external-slow/esm/Options/Interfaces/ISlow.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
;
}),
"[project]/theitern/node_modules/@tsparticles/interaction-external-slow/esm/index.js [app-ssr] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "loadExternalSlowInteraction",
    ()=>loadExternalSlowInteraction
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$interaction$2d$external$2d$slow$2f$esm$2f$Slower$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/interaction-external-slow/esm/Slower.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$interaction$2d$external$2d$slow$2f$esm$2f$Options$2f$Classes$2f$Slow$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/interaction-external-slow/esm/Options/Classes/Slow.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$interaction$2d$external$2d$slow$2f$esm$2f$Options$2f$Interfaces$2f$ISlow$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/interaction-external-slow/esm/Options/Interfaces/ISlow.js [app-ssr] (ecmascript)");
;
async function loadExternalSlowInteraction(engine, refresh = true) {
    engine.checkVersion("3.9.1");
    await engine.addInteractor("externalSlow", (container)=>{
        return Promise.resolve(new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$interaction$2d$external$2d$slow$2f$esm$2f$Slower$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Slower"](container));
    }, refresh);
}
;
;
}),
"[project]/theitern/node_modules/@tsparticles/shape-image/esm/Utils.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "downloadSvgImage",
    ()=>downloadSvgImage,
    "loadImage",
    ()=>loadImage,
    "replaceImageColor",
    ()=>replaceImageColor
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Core/Utils/Constants.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/Utils.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$ColorUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/ColorUtils.js [app-ssr] (ecmascript)");
;
const stringStart = 0, defaultOpacity = 1;
const currentColorRegex = /(#(?:[0-9a-f]{2}){2,4}|(#[0-9a-f]{3})|(rgb|hsl)a?\((-?\d+%?[,\s]+){2,3}\s*[\d.]+%?\))|currentcolor/gi;
function replaceColorSvg(imageShape, color, opacity) {
    const { svgData } = imageShape;
    if (!svgData) {
        return "";
    }
    const colorStyle = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$ColorUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getStyleFromHsl"])(color, opacity);
    if (svgData.includes("fill")) {
        return svgData.replace(currentColorRegex, ()=>colorStyle);
    }
    const preFillIndex = svgData.indexOf(">");
    return `${svgData.substring(stringStart, preFillIndex)} fill="${colorStyle}"${svgData.substring(preFillIndex)}`;
}
async function loadImage(image) {
    return new Promise((resolve)=>{
        image.loading = true;
        const img = new Image();
        image.element = img;
        img.addEventListener("load", ()=>{
            image.loading = false;
            resolve();
        });
        img.addEventListener("error", ()=>{
            image.element = undefined;
            image.error = true;
            image.loading = false;
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getLogger"])().error(`${__TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["errorPrefix"]} loading image: ${image.source}`);
            resolve();
        });
        img.src = image.source;
    });
}
async function downloadSvgImage(image) {
    if (image.type !== "svg") {
        await loadImage(image);
        return;
    }
    image.loading = true;
    const response = await fetch(image.source);
    if (!response.ok) {
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getLogger"])().error(`${__TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["errorPrefix"]} Image not found`);
        image.error = true;
    } else {
        image.svgData = await response.text();
    }
    image.loading = false;
}
function replaceImageColor(image, imageData, color, particle) {
    const svgColoredData = replaceColorSvg(image, color, particle.opacity?.value ?? defaultOpacity), imageRes = {
        color,
        gif: imageData.gif,
        data: {
            ...image,
            svgData: svgColoredData
        },
        loaded: false,
        ratio: imageData.width / imageData.height,
        replaceColor: imageData.replaceColor,
        source: imageData.src
    };
    return new Promise((resolve)=>{
        const svg = new Blob([
            svgColoredData
        ], {
            type: "image/svg+xml"
        }), domUrl = URL || window.URL || window.webkitURL || window, url = domUrl.createObjectURL(svg), img = new Image();
        img.addEventListener("load", ()=>{
            imageRes.loaded = true;
            imageRes.element = img;
            resolve(imageRes);
            domUrl.revokeObjectURL(url);
        });
        const errorHandler = async ()=>{
            domUrl.revokeObjectURL(url);
            const img2 = {
                ...image,
                error: false,
                loading: true
            };
            await loadImage(img2);
            imageRes.loaded = true;
            imageRes.element = img2.element;
            resolve(imageRes);
        };
        img.addEventListener("error", ()=>void errorHandler());
        img.src = url;
    });
}
}),
"[project]/theitern/node_modules/@tsparticles/shape-image/esm/GifUtils/Constants.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "InterlaceOffsets",
    ()=>InterlaceOffsets,
    "InterlaceSteps",
    ()=>InterlaceSteps
]);
const InterlaceOffsets = [
    0,
    4,
    2,
    1
];
const InterlaceSteps = [
    8,
    8,
    4,
    2
];
}),
"[project]/theitern/node_modules/@tsparticles/shape-image/esm/GifUtils/ByteStream.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ByteStream",
    ()=>ByteStream
]);
class ByteStream {
    constructor(bytes){
        this.pos = 0;
        this.data = new Uint8ClampedArray(bytes);
    }
    getString(count) {
        const slice = this.data.slice(this.pos, this.pos + count);
        this.pos += slice.length;
        return slice.reduce((acc, curr)=>acc + String.fromCharCode(curr), "");
    }
    nextByte() {
        return this.data[this.pos++];
    }
    nextTwoBytes() {
        const increment = 2, previous = 1, shift = 8;
        this.pos += increment;
        return this.data[this.pos - increment] + (this.data[this.pos - previous] << shift);
    }
    readSubBlocks() {
        let blockString = "", size = 0;
        const minCount = 0, emptySize = 0;
        do {
            size = this.data[this.pos++];
            for(let count = size; --count >= minCount; blockString += String.fromCharCode(this.data[this.pos++])){}
        }while (size !== emptySize)
        return blockString;
    }
    readSubBlocksBin() {
        let size = this.data[this.pos], len = 0;
        const emptySize = 0, increment = 1;
        for(let offset = 0; size !== emptySize; offset += size + increment, size = this.data[this.pos + offset]){
            len += size;
        }
        const blockData = new Uint8Array(len);
        size = this.data[this.pos++];
        for(let i = 0; size !== emptySize; size = this.data[this.pos++]){
            for(let count = size; --count >= emptySize; blockData[i++] = this.data[this.pos++]){}
        }
        return blockData;
    }
    skipSubBlocks() {
        for(const increment = 1, noData = 0; this.data[this.pos] !== noData; this.pos += this.data[this.pos] + increment){}
        this.pos++;
    }
}
}),
"[project]/theitern/node_modules/@tsparticles/shape-image/esm/GifUtils/Enums/DisposalMethod.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "DisposalMethod",
    ()=>DisposalMethod
]);
var DisposalMethod;
(function(DisposalMethod) {
    DisposalMethod[DisposalMethod["Replace"] = 0] = "Replace";
    DisposalMethod[DisposalMethod["Combine"] = 1] = "Combine";
    DisposalMethod[DisposalMethod["RestoreBackground"] = 2] = "RestoreBackground";
    DisposalMethod[DisposalMethod["RestorePrevious"] = 3] = "RestorePrevious";
    DisposalMethod[DisposalMethod["UndefinedA"] = 4] = "UndefinedA";
    DisposalMethod[DisposalMethod["UndefinedB"] = 5] = "UndefinedB";
    DisposalMethod[DisposalMethod["UndefinedC"] = 6] = "UndefinedC";
    DisposalMethod[DisposalMethod["UndefinedD"] = 7] = "UndefinedD";
})(DisposalMethod || (DisposalMethod = {}));
}),
"[project]/theitern/node_modules/@tsparticles/shape-image/esm/GifUtils/Types/GIFDataHeaders.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "GIFDataHeaders",
    ()=>GIFDataHeaders
]);
var GIFDataHeaders;
(function(GIFDataHeaders) {
    GIFDataHeaders[GIFDataHeaders["Extension"] = 33] = "Extension";
    GIFDataHeaders[GIFDataHeaders["ApplicationExtension"] = 255] = "ApplicationExtension";
    GIFDataHeaders[GIFDataHeaders["GraphicsControlExtension"] = 249] = "GraphicsControlExtension";
    GIFDataHeaders[GIFDataHeaders["PlainTextExtension"] = 1] = "PlainTextExtension";
    GIFDataHeaders[GIFDataHeaders["CommentExtension"] = 254] = "CommentExtension";
    GIFDataHeaders[GIFDataHeaders["Image"] = 44] = "Image";
    GIFDataHeaders[GIFDataHeaders["EndOfFile"] = 59] = "EndOfFile";
})(GIFDataHeaders || (GIFDataHeaders = {}));
}),
"[project]/theitern/node_modules/@tsparticles/shape-image/esm/GifUtils/Utils.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "decodeGIF",
    ()=>decodeGIF,
    "drawGif",
    ()=>drawGif,
    "getGIFLoopAmount",
    ()=>getGIFLoopAmount,
    "loadGifImage",
    ()=>loadGifImage
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$shape$2d$image$2f$esm$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/shape-image/esm/Utils.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$shape$2d$image$2f$esm$2f$GifUtils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/shape-image/esm/GifUtils/Constants.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$shape$2d$image$2f$esm$2f$GifUtils$2f$ByteStream$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/shape-image/esm/GifUtils/ByteStream.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$shape$2d$image$2f$esm$2f$GifUtils$2f$Enums$2f$DisposalMethod$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/shape-image/esm/GifUtils/Enums/DisposalMethod.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$shape$2d$image$2f$esm$2f$GifUtils$2f$Types$2f$GIFDataHeaders$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/shape-image/esm/GifUtils/Types/GIFDataHeaders.js [app-ssr] (ecmascript)");
;
;
;
;
;
const origin = {
    x: 0,
    y: 0
}, defaultFrame = 0, half = 0.5, initialTime = 0, firstIndex = 0, defaultLoopCount = 0;
function parseColorTable(byteStream, count) {
    const colors = [];
    for(let i = 0; i < count; i++){
        colors.push({
            r: byteStream.data[byteStream.pos],
            g: byteStream.data[byteStream.pos + 1],
            b: byteStream.data[byteStream.pos + 2]
        });
        byteStream.pos += 3;
    }
    return colors;
}
function parseExtensionBlock(byteStream, gif, getFrameIndex, getTransparencyIndex) {
    switch(byteStream.nextByte()){
        case __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$shape$2d$image$2f$esm$2f$GifUtils$2f$Types$2f$GIFDataHeaders$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["GIFDataHeaders"].GraphicsControlExtension:
            {
                const frame = gif.frames[getFrameIndex(false)];
                byteStream.pos++;
                const packedByte = byteStream.nextByte();
                frame.GCreserved = (packedByte & 0xe0) >>> 5;
                frame.disposalMethod = (packedByte & 0x1c) >>> 2;
                frame.userInputDelayFlag = (packedByte & 2) === 2;
                const transparencyFlag = (packedByte & 1) === 1;
                frame.delayTime = byteStream.nextTwoBytes() * 0xa;
                const transparencyIndex = byteStream.nextByte();
                if (transparencyFlag) {
                    getTransparencyIndex(transparencyIndex);
                }
                byteStream.pos++;
                break;
            }
        case __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$shape$2d$image$2f$esm$2f$GifUtils$2f$Types$2f$GIFDataHeaders$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["GIFDataHeaders"].ApplicationExtension:
            {
                byteStream.pos++;
                const applicationExtension = {
                    identifier: byteStream.getString(8),
                    authenticationCode: byteStream.getString(3),
                    data: byteStream.readSubBlocksBin()
                };
                gif.applicationExtensions.push(applicationExtension);
                break;
            }
        case __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$shape$2d$image$2f$esm$2f$GifUtils$2f$Types$2f$GIFDataHeaders$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["GIFDataHeaders"].CommentExtension:
            {
                gif.comments.push([
                    getFrameIndex(false),
                    byteStream.readSubBlocks()
                ]);
                break;
            }
        case __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$shape$2d$image$2f$esm$2f$GifUtils$2f$Types$2f$GIFDataHeaders$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["GIFDataHeaders"].PlainTextExtension:
            {
                if (gif.globalColorTable.length === 0) {
                    throw new EvalError("plain text extension without global color table");
                }
                byteStream.pos++;
                gif.frames[getFrameIndex(false)].plainTextData = {
                    left: byteStream.nextTwoBytes(),
                    top: byteStream.nextTwoBytes(),
                    width: byteStream.nextTwoBytes(),
                    height: byteStream.nextTwoBytes(),
                    charSize: {
                        width: byteStream.nextTwoBytes(),
                        height: byteStream.nextTwoBytes()
                    },
                    foregroundColor: byteStream.nextByte(),
                    backgroundColor: byteStream.nextByte(),
                    text: byteStream.readSubBlocks()
                };
                break;
            }
        default:
            byteStream.skipSubBlocks();
            break;
    }
}
async function parseImageBlock(byteStream, gif, avgAlpha, getFrameIndex, getTransparencyIndex, progressCallback) {
    const frame = gif.frames[getFrameIndex(true)];
    frame.left = byteStream.nextTwoBytes();
    frame.top = byteStream.nextTwoBytes();
    frame.width = byteStream.nextTwoBytes();
    frame.height = byteStream.nextTwoBytes();
    const packedByte = byteStream.nextByte(), localColorTableFlag = (packedByte & 0x80) === 0x80, interlacedFlag = (packedByte & 0x40) === 0x40;
    frame.sortFlag = (packedByte & 0x20) === 0x20;
    frame.reserved = (packedByte & 0x18) >>> 3;
    const localColorCount = 1 << (packedByte & 7) + 1;
    if (localColorTableFlag) {
        frame.localColorTable = parseColorTable(byteStream, localColorCount);
    }
    const getColor = (index)=>{
        const { r, g, b } = (localColorTableFlag ? frame.localColorTable : gif.globalColorTable)[index];
        if (index !== getTransparencyIndex(null)) {
            return {
                r,
                g,
                b,
                a: 255
            };
        }
        return {
            r,
            g,
            b,
            a: avgAlpha ? ~~((r + g + b) / 3) : 0
        };
    };
    const image = (()=>{
        try {
            return new ImageData(frame.width, frame.height, {
                colorSpace: "srgb"
            });
        } catch (error) {
            if (error instanceof DOMException && error.name === "IndexSizeError") {
                return null;
            }
            throw error;
        }
    })();
    if (image == null) {
        throw new EvalError("GIF frame size is to large");
    }
    const minCodeSize = byteStream.nextByte(), imageData = byteStream.readSubBlocksBin(), clearCode = 1 << minCodeSize;
    const readBits = (pos, len)=>{
        const bytePos = pos >>> 3, bitPos = pos & 7;
        return (imageData[bytePos] + (imageData[bytePos + 1] << 8) + (imageData[bytePos + 2] << 16) & (1 << len) - 1 << bitPos) >>> bitPos;
    };
    if (interlacedFlag) {
        for(let code = 0, size = minCodeSize + 1, pos = 0, dic = [
            [
                0
            ]
        ], pass = 0; pass < 4; pass++){
            if (__TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$shape$2d$image$2f$esm$2f$GifUtils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["InterlaceOffsets"][pass] < frame.height) {
                let pixelPos = 0, lineIndex = 0, exit = false;
                while(!exit){
                    const last = code;
                    code = readBits(pos, size);
                    pos += size + 1;
                    if (code === clearCode) {
                        size = minCodeSize + 1;
                        dic.length = clearCode + 2;
                        for(let i = 0; i < dic.length; i++){
                            dic[i] = i < clearCode ? [
                                i
                            ] : [];
                        }
                    } else {
                        if (code >= dic.length) {
                            dic.push(dic[last].concat(dic[last][0]));
                        } else if (last !== clearCode) {
                            dic.push(dic[last].concat(dic[code][0]));
                        }
                        for (const item of dic[code]){
                            const { r, g, b, a } = getColor(item);
                            image.data.set([
                                r,
                                g,
                                b,
                                a
                            ], __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$shape$2d$image$2f$esm$2f$GifUtils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["InterlaceOffsets"][pass] * frame.width + __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$shape$2d$image$2f$esm$2f$GifUtils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["InterlaceSteps"][pass] * lineIndex + pixelPos % (frame.width * 4));
                            pixelPos += 4;
                        }
                        if (dic.length === 1 << size && size < 0xc) {
                            size++;
                        }
                    }
                    if (pixelPos === frame.width * 4 * (lineIndex + 1)) {
                        lineIndex++;
                        if (__TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$shape$2d$image$2f$esm$2f$GifUtils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["InterlaceOffsets"][pass] + __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$shape$2d$image$2f$esm$2f$GifUtils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["InterlaceSteps"][pass] * lineIndex >= frame.height) {
                            exit = true;
                        }
                    }
                }
            }
            progressCallback?.(byteStream.pos / (byteStream.data.length - 1), getFrameIndex(false) + 1, image, {
                x: frame.left,
                y: frame.top
            }, {
                width: gif.width,
                height: gif.height
            });
        }
        frame.image = image;
        frame.bitmap = await createImageBitmap(image);
    } else {
        let code = 0, size = minCodeSize + 1, pos = 0, pixelPos = -4, exit = false;
        const dic = [
            [
                0
            ]
        ];
        while(!exit){
            const last = code;
            code = readBits(pos, size);
            pos += size;
            if (code === clearCode) {
                size = minCodeSize + 1;
                dic.length = clearCode + 2;
                for(let i = 0; i < dic.length; i++){
                    dic[i] = i < clearCode ? [
                        i
                    ] : [];
                }
            } else {
                if (code === clearCode + 1) {
                    exit = true;
                    break;
                }
                if (code >= dic.length) {
                    dic.push(dic[last].concat(dic[last][0]));
                } else if (last !== clearCode) {
                    dic.push(dic[last].concat(dic[code][0]));
                }
                for (const item of dic[code]){
                    const { r, g, b, a } = getColor(item);
                    image.data.set([
                        r,
                        g,
                        b,
                        a
                    ], pixelPos += 4);
                }
                if (dic.length >= 1 << size && size < 0xc) {
                    size++;
                }
            }
        }
        frame.image = image;
        frame.bitmap = await createImageBitmap(image);
        progressCallback?.((byteStream.pos + 1) / byteStream.data.length, getFrameIndex(false) + 1, frame.image, {
            x: frame.left,
            y: frame.top
        }, {
            width: gif.width,
            height: gif.height
        });
    }
}
async function parseBlock(byteStream, gif, avgAlpha, getFrameIndex, getTransparencyIndex, progressCallback) {
    switch(byteStream.nextByte()){
        case __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$shape$2d$image$2f$esm$2f$GifUtils$2f$Types$2f$GIFDataHeaders$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["GIFDataHeaders"].EndOfFile:
            return true;
        case __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$shape$2d$image$2f$esm$2f$GifUtils$2f$Types$2f$GIFDataHeaders$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["GIFDataHeaders"].Image:
            await parseImageBlock(byteStream, gif, avgAlpha, getFrameIndex, getTransparencyIndex, progressCallback);
            break;
        case __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$shape$2d$image$2f$esm$2f$GifUtils$2f$Types$2f$GIFDataHeaders$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["GIFDataHeaders"].Extension:
            parseExtensionBlock(byteStream, gif, getFrameIndex, getTransparencyIndex);
            break;
        default:
            throw new EvalError("undefined block found");
    }
    return false;
}
function getGIFLoopAmount(gif) {
    for (const extension of gif.applicationExtensions){
        if (extension.identifier + extension.authenticationCode !== "NETSCAPE2.0") {
            continue;
        }
        return extension.data[1] + (extension.data[2] << 8);
    }
    return NaN;
}
async function decodeGIF(gifURL, progressCallback, avgAlpha) {
    if (!avgAlpha) avgAlpha = false;
    const res = await fetch(gifURL);
    if (!res.ok && res.status === 404) {
        throw new EvalError("file not found");
    }
    const buffer = await res.arrayBuffer();
    const gif = {
        width: 0,
        height: 0,
        totalTime: 0,
        colorRes: 0,
        pixelAspectRatio: 0,
        frames: [],
        sortFlag: false,
        globalColorTable: [],
        backgroundImage: new ImageData(1, 1, {
            colorSpace: "srgb"
        }),
        comments: [],
        applicationExtensions: []
    }, byteStream = new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$shape$2d$image$2f$esm$2f$GifUtils$2f$ByteStream$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ByteStream"](new Uint8ClampedArray(buffer));
    if (byteStream.getString(6) !== "GIF89a") {
        throw new Error("not a supported GIF file");
    }
    gif.width = byteStream.nextTwoBytes();
    gif.height = byteStream.nextTwoBytes();
    const packedByte = byteStream.nextByte(), globalColorTableFlag = (packedByte & 0x80) === 0x80;
    gif.colorRes = (packedByte & 0x70) >>> 4;
    gif.sortFlag = (packedByte & 8) === 8;
    const globalColorCount = 1 << (packedByte & 7) + 1, backgroundColorIndex = byteStream.nextByte();
    gif.pixelAspectRatio = byteStream.nextByte();
    if (gif.pixelAspectRatio !== 0) {
        gif.pixelAspectRatio = (gif.pixelAspectRatio + 0xf) / 0x40;
    }
    if (globalColorTableFlag) {
        gif.globalColorTable = parseColorTable(byteStream, globalColorCount);
    }
    const backgroundImage = (()=>{
        try {
            return new ImageData(gif.width, gif.height, {
                colorSpace: "srgb"
            });
        } catch (error) {
            if (error instanceof DOMException && error.name === "IndexSizeError") {
                return null;
            }
            throw error;
        }
    })();
    if (backgroundImage == null) {
        throw new Error("GIF frame size is to large");
    }
    const { r, g, b } = gif.globalColorTable[backgroundColorIndex];
    backgroundImage.data.set(globalColorTableFlag ? [
        r,
        g,
        b,
        255
    ] : [
        0,
        0,
        0,
        0
    ]);
    for(let i = 4; i < backgroundImage.data.length; i *= 2){
        backgroundImage.data.copyWithin(i, 0, i);
    }
    gif.backgroundImage = backgroundImage;
    let frameIndex = -1, incrementFrameIndex = true, transparencyIndex = -1;
    const getframeIndex = (increment)=>{
        if (increment) {
            incrementFrameIndex = true;
        }
        return frameIndex;
    };
    const getTransparencyIndex = (newValue)=>{
        if (newValue != null) {
            transparencyIndex = newValue;
        }
        return transparencyIndex;
    };
    try {
        do {
            if (incrementFrameIndex) {
                gif.frames.push({
                    left: 0,
                    top: 0,
                    width: 0,
                    height: 0,
                    disposalMethod: __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$shape$2d$image$2f$esm$2f$GifUtils$2f$Enums$2f$DisposalMethod$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["DisposalMethod"].Replace,
                    image: new ImageData(1, 1, {
                        colorSpace: "srgb"
                    }),
                    plainTextData: null,
                    userInputDelayFlag: false,
                    delayTime: 0,
                    sortFlag: false,
                    localColorTable: [],
                    reserved: 0,
                    GCreserved: 0
                });
                frameIndex++;
                transparencyIndex = -1;
                incrementFrameIndex = false;
            }
        }while (!await parseBlock(byteStream, gif, avgAlpha, getframeIndex, getTransparencyIndex, progressCallback))
        gif.frames.length--;
        for (const frame of gif.frames){
            if (frame.userInputDelayFlag && frame.delayTime === 0) {
                gif.totalTime = Infinity;
                break;
            }
            gif.totalTime += frame.delayTime;
        }
        return gif;
    } catch (error) {
        if (error instanceof EvalError) {
            throw new Error(`error while parsing frame ${frameIndex} "${error.message}"`);
        }
        throw error;
    }
}
function drawGif(data) {
    const { context, radius, particle, delta } = data, image = particle.image;
    if (!image?.gifData || !image.gif) {
        return;
    }
    const offscreenCanvas = new OffscreenCanvas(image.gifData.width, image.gifData.height), offscreenContext = offscreenCanvas.getContext("2d");
    if (!offscreenContext) {
        throw new Error("could not create offscreen canvas context");
    }
    offscreenContext.imageSmoothingQuality = "low";
    offscreenContext.imageSmoothingEnabled = false;
    offscreenContext.clearRect(origin.x, origin.y, offscreenCanvas.width, offscreenCanvas.height);
    if (particle.gifLoopCount === undefined) {
        particle.gifLoopCount = image.gifLoopCount ?? defaultLoopCount;
    }
    let frameIndex = particle.gifFrame ?? defaultFrame;
    const pos = {
        x: -image.gifData.width * half,
        y: -image.gifData.height * half
    }, frame = image.gifData.frames[frameIndex];
    if (particle.gifTime === undefined) {
        particle.gifTime = initialTime;
    }
    if (!frame.bitmap) {
        return;
    }
    context.scale(radius / image.gifData.width, radius / image.gifData.height);
    switch(frame.disposalMethod){
        case __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$shape$2d$image$2f$esm$2f$GifUtils$2f$Enums$2f$DisposalMethod$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["DisposalMethod"].UndefinedA:
        case __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$shape$2d$image$2f$esm$2f$GifUtils$2f$Enums$2f$DisposalMethod$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["DisposalMethod"].UndefinedB:
        case __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$shape$2d$image$2f$esm$2f$GifUtils$2f$Enums$2f$DisposalMethod$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["DisposalMethod"].UndefinedC:
        case __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$shape$2d$image$2f$esm$2f$GifUtils$2f$Enums$2f$DisposalMethod$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["DisposalMethod"].UndefinedD:
        case __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$shape$2d$image$2f$esm$2f$GifUtils$2f$Enums$2f$DisposalMethod$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["DisposalMethod"].Replace:
            offscreenContext.drawImage(frame.bitmap, frame.left, frame.top);
            context.drawImage(offscreenCanvas, pos.x, pos.y);
            offscreenContext.clearRect(origin.x, origin.y, offscreenCanvas.width, offscreenCanvas.height);
            break;
        case __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$shape$2d$image$2f$esm$2f$GifUtils$2f$Enums$2f$DisposalMethod$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["DisposalMethod"].Combine:
            offscreenContext.drawImage(frame.bitmap, frame.left, frame.top);
            context.drawImage(offscreenCanvas, pos.x, pos.y);
            break;
        case __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$shape$2d$image$2f$esm$2f$GifUtils$2f$Enums$2f$DisposalMethod$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["DisposalMethod"].RestoreBackground:
            offscreenContext.drawImage(frame.bitmap, frame.left, frame.top);
            context.drawImage(offscreenCanvas, pos.x, pos.y);
            offscreenContext.clearRect(origin.x, origin.y, offscreenCanvas.width, offscreenCanvas.height);
            if (!image.gifData.globalColorTable.length) {
                offscreenContext.putImageData(image.gifData.frames[firstIndex].image, pos.x + frame.left, pos.y + frame.top);
            } else {
                offscreenContext.putImageData(image.gifData.backgroundImage, pos.x, pos.y);
            }
            break;
        case __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$shape$2d$image$2f$esm$2f$GifUtils$2f$Enums$2f$DisposalMethod$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["DisposalMethod"].RestorePrevious:
            {
                const previousImageData = offscreenContext.getImageData(origin.x, origin.y, offscreenCanvas.width, offscreenCanvas.height);
                offscreenContext.drawImage(frame.bitmap, frame.left, frame.top);
                context.drawImage(offscreenCanvas, pos.x, pos.y);
                offscreenContext.clearRect(origin.x, origin.y, offscreenCanvas.width, offscreenCanvas.height);
                offscreenContext.putImageData(previousImageData, origin.x, origin.y);
            }
            break;
    }
    particle.gifTime += delta.value;
    if (particle.gifTime > frame.delayTime) {
        particle.gifTime -= frame.delayTime;
        if (++frameIndex >= image.gifData.frames.length) {
            if (--particle.gifLoopCount <= defaultLoopCount) {
                return;
            }
            frameIndex = firstIndex;
            offscreenContext.clearRect(origin.x, origin.y, offscreenCanvas.width, offscreenCanvas.height);
        }
        particle.gifFrame = frameIndex;
    }
    context.scale(image.gifData.width / radius, image.gifData.height / radius);
}
async function loadGifImage(image) {
    if (image.type !== "gif") {
        await (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$shape$2d$image$2f$esm$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["loadImage"])(image);
        return;
    }
    image.loading = true;
    try {
        image.gifData = await decodeGIF(image.source);
        image.gifLoopCount = getGIFLoopAmount(image.gifData) ?? defaultLoopCount;
        if (!image.gifLoopCount) {
            image.gifLoopCount = Infinity;
        }
    } catch  {
        image.error = true;
    }
    image.loading = false;
}
}),
"[project]/theitern/node_modules/@tsparticles/shape-image/esm/ImageDrawer.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ImageDrawer",
    ()=>ImageDrawer
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Core/Utils/Constants.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$shape$2d$image$2f$esm$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/shape-image/esm/Utils.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$shape$2d$image$2f$esm$2f$GifUtils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/shape-image/esm/GifUtils/Utils.js [app-ssr] (ecmascript)");
;
;
;
const double = 2, defaultAlpha = 1, sides = 12, defaultRatio = 1;
class ImageDrawer {
    constructor(engine){
        this.validTypes = [
            "image",
            "images"
        ];
        this.loadImageShape = async (imageShape)=>{
            if (!this._engine.loadImage) {
                throw new Error(`${__TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["errorPrefix"]} image shape not initialized`);
            }
            await this._engine.loadImage({
                gif: imageShape.gif,
                name: imageShape.name,
                replaceColor: imageShape.replaceColor ?? false,
                src: imageShape.src
            });
        };
        this._engine = engine;
    }
    addImage(image) {
        if (!this._engine.images) {
            this._engine.images = [];
        }
        this._engine.images.push(image);
    }
    draw(data) {
        const { context, radius, particle, opacity } = data, image = particle.image, element = image?.element;
        if (!image) {
            return;
        }
        context.globalAlpha = opacity;
        if (image.gif && image.gifData) {
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$shape$2d$image$2f$esm$2f$GifUtils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["drawGif"])(data);
        } else if (element) {
            const ratio = image.ratio, pos = {
                x: -radius,
                y: -radius
            }, diameter = radius * double;
            context.drawImage(element, pos.x, pos.y, diameter, diameter / ratio);
        }
        context.globalAlpha = defaultAlpha;
    }
    getSidesCount() {
        return sides;
    }
    async init(container) {
        const options = container.actualOptions;
        if (!options.preload || !this._engine.loadImage) {
            return;
        }
        for (const imageData of options.preload){
            await this._engine.loadImage(imageData);
        }
    }
    loadShape(particle) {
        if (particle.shape !== "image" && particle.shape !== "images") {
            return;
        }
        if (!this._engine.images) {
            this._engine.images = [];
        }
        const imageData = particle.shapeData;
        if (!imageData) {
            return;
        }
        const image = this._engine.images.find((t)=>t.name === imageData.name || t.source === imageData.src);
        if (!image) {
            void this.loadImageShape(imageData).then(()=>{
                this.loadShape(particle);
            });
        }
    }
    particleInit(container, particle) {
        if (particle.shape !== "image" && particle.shape !== "images") {
            return;
        }
        if (!this._engine.images) {
            this._engine.images = [];
        }
        const images = this._engine.images, imageData = particle.shapeData;
        if (!imageData) {
            return;
        }
        const color = particle.getFillColor(), image = images.find((t)=>t.name === imageData.name || t.source === imageData.src);
        if (!image) {
            return;
        }
        const replaceColor = imageData.replaceColor ?? image.replaceColor;
        if (image.loading) {
            setTimeout(()=>{
                this.particleInit(container, particle);
            });
            return;
        }
        void (async ()=>{
            let imageRes;
            if (image.svgData && color) {
                imageRes = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$shape$2d$image$2f$esm$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["replaceImageColor"])(image, imageData, color, particle);
            } else {
                imageRes = {
                    color,
                    data: image,
                    element: image.element,
                    gif: image.gif,
                    gifData: image.gifData,
                    gifLoopCount: image.gifLoopCount,
                    loaded: true,
                    ratio: imageData.width && imageData.height ? imageData.width / imageData.height : image.ratio ?? defaultRatio,
                    replaceColor: replaceColor,
                    source: imageData.src
                };
            }
            if (!imageRes.ratio) {
                imageRes.ratio = 1;
            }
            const fill = imageData.fill ?? particle.shapeFill, close = imageData.close ?? particle.shapeClose, imageShape = {
                image: imageRes,
                fill,
                close
            };
            particle.image = imageShape.image;
            particle.shapeFill = imageShape.fill;
            particle.shapeClose = imageShape.close;
        })();
    }
}
}),
"[project]/theitern/node_modules/@tsparticles/shape-image/esm/Options/Classes/Preload.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Preload",
    ()=>Preload
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/TypeUtils.js [app-ssr] (ecmascript)");
;
class Preload {
    constructor(){
        this.src = "";
        this.gif = false;
    }
    load(data) {
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isNull"])(data)) {
            return;
        }
        if (data.gif !== undefined) {
            this.gif = data.gif;
        }
        if (data.height !== undefined) {
            this.height = data.height;
        }
        if (data.name !== undefined) {
            this.name = data.name;
        }
        if (data.replaceColor !== undefined) {
            this.replaceColor = data.replaceColor;
        }
        if (data.src !== undefined) {
            this.src = data.src;
        }
        if (data.width !== undefined) {
            this.width = data.width;
        }
    }
}
}),
"[project]/theitern/node_modules/@tsparticles/shape-image/esm/ImagePreloader.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ImagePreloaderPlugin",
    ()=>ImagePreloaderPlugin
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$shape$2d$image$2f$esm$2f$Options$2f$Classes$2f$Preload$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/shape-image/esm/Options/Classes/Preload.js [app-ssr] (ecmascript)");
;
class ImagePreloaderPlugin {
    constructor(engine){
        this.id = "imagePreloader";
        this._engine = engine;
    }
    async getPlugin() {
        await Promise.resolve();
        return {};
    }
    loadOptions(options, source) {
        if (!source?.preload) {
            return;
        }
        if (!options.preload) {
            options.preload = [];
        }
        const preloadOptions = options.preload;
        for (const item of source.preload){
            const existing = preloadOptions.find((t)=>t.name === item.name || t.src === item.src);
            if (existing) {
                existing.load(item);
            } else {
                const preload = new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$shape$2d$image$2f$esm$2f$Options$2f$Classes$2f$Preload$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Preload"]();
                preload.load(item);
                preloadOptions.push(preload);
            }
        }
    }
    needsPlugin() {
        return true;
    }
}
}),
"[project]/theitern/node_modules/@tsparticles/shape-image/esm/index.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "loadImageShape",
    ()=>loadImageShape
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$shape$2d$image$2f$esm$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/shape-image/esm/Utils.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$shape$2d$image$2f$esm$2f$ImageDrawer$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/shape-image/esm/ImageDrawer.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$shape$2d$image$2f$esm$2f$ImagePreloader$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/shape-image/esm/ImagePreloader.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Core/Utils/Constants.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$shape$2d$image$2f$esm$2f$GifUtils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/shape-image/esm/GifUtils/Utils.js [app-ssr] (ecmascript)");
;
;
;
;
;
const extLength = 3;
function addLoadImageToEngine(engine) {
    if (engine.loadImage) {
        return;
    }
    engine.loadImage = async (data)=>{
        if (!data.name && !data.src) {
            throw new Error(`${__TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["errorPrefix"]} no image source provided`);
        }
        if (!engine.images) {
            engine.images = [];
        }
        if (engine.images.find((t)=>t.name === data.name || t.source === data.src)) {
            return;
        }
        try {
            const image = {
                gif: data.gif ?? false,
                name: data.name ?? data.src,
                source: data.src,
                type: data.src.substring(data.src.length - extLength),
                error: false,
                loading: true,
                replaceColor: data.replaceColor,
                ratio: data.width && data.height ? data.width / data.height : undefined
            };
            engine.images.push(image);
            let imageFunc;
            if (data.gif) {
                imageFunc = __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$shape$2d$image$2f$esm$2f$GifUtils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["loadGifImage"];
            } else {
                imageFunc = data.replaceColor ? __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$shape$2d$image$2f$esm$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["downloadSvgImage"] : __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$shape$2d$image$2f$esm$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["loadImage"];
            }
            await imageFunc(image);
        } catch  {
            throw new Error(`${__TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["errorPrefix"]} ${data.name ?? data.src} not found`);
        }
    };
}
async function loadImageShape(engine, refresh = true) {
    engine.checkVersion("3.9.1");
    addLoadImageToEngine(engine);
    const preloader = new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$shape$2d$image$2f$esm$2f$ImagePreloader$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ImagePreloaderPlugin"](engine);
    await engine.addPlugin(preloader, refresh);
    await engine.addShape(new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$shape$2d$image$2f$esm$2f$ImageDrawer$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ImageDrawer"](engine), refresh);
}
}),
"[project]/theitern/node_modules/@tsparticles/updater-life/esm/Options/Classes/LifeDelay.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "LifeDelay",
    ()=>LifeDelay
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$ValueWithRandom$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Classes/ValueWithRandom.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/TypeUtils.js [app-ssr] (ecmascript)");
;
class LifeDelay extends __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$ValueWithRandom$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ValueWithRandom"] {
    constructor(){
        super();
        this.sync = false;
    }
    load(data) {
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isNull"])(data)) {
            return;
        }
        super.load(data);
        if (data.sync !== undefined) {
            this.sync = data.sync;
        }
    }
}
}),
"[project]/theitern/node_modules/@tsparticles/updater-life/esm/Options/Classes/LifeDuration.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "LifeDuration",
    ()=>LifeDuration
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$ValueWithRandom$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Classes/ValueWithRandom.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/TypeUtils.js [app-ssr] (ecmascript)");
;
class LifeDuration extends __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$ValueWithRandom$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ValueWithRandom"] {
    constructor(){
        super();
        this.sync = false;
    }
    load(data) {
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isNull"])(data)) {
            return;
        }
        super.load(data);
        if (data.sync !== undefined) {
            this.sync = data.sync;
        }
    }
}
}),
"[project]/theitern/node_modules/@tsparticles/updater-life/esm/Options/Classes/Life.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Life",
    ()=>Life
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/TypeUtils.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$updater$2d$life$2f$esm$2f$Options$2f$Classes$2f$LifeDelay$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/updater-life/esm/Options/Classes/LifeDelay.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$updater$2d$life$2f$esm$2f$Options$2f$Classes$2f$LifeDuration$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/updater-life/esm/Options/Classes/LifeDuration.js [app-ssr] (ecmascript)");
;
;
;
class Life {
    constructor(){
        this.count = 0;
        this.delay = new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$updater$2d$life$2f$esm$2f$Options$2f$Classes$2f$LifeDelay$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["LifeDelay"]();
        this.duration = new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$updater$2d$life$2f$esm$2f$Options$2f$Classes$2f$LifeDuration$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["LifeDuration"]();
    }
    load(data) {
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isNull"])(data)) {
            return;
        }
        if (data.count !== undefined) {
            this.count = data.count;
        }
        this.delay.load(data.delay);
        this.duration.load(data.duration);
    }
}
}),
"[project]/theitern/node_modules/@tsparticles/updater-life/esm/Utils.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "updateLife",
    ()=>updateLife
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/NumberUtils.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Core/Utils/Constants.js [app-ssr] (ecmascript)");
;
const noTime = 0, infiniteValue = -1, noLife = 0, minCanvasSize = 0;
function updateLife(particle, delta, canvasSize) {
    if (!particle.life) {
        return;
    }
    const life = particle.life;
    let justSpawned = false;
    if (particle.spawning) {
        life.delayTime += delta.value;
        if (life.delayTime >= particle.life.delay) {
            justSpawned = true;
            particle.spawning = false;
            life.delayTime = noTime;
            life.time = noTime;
        } else {
            return;
        }
    }
    if (life.duration === infiniteValue) {
        return;
    }
    if (particle.spawning) {
        return;
    }
    if (justSpawned) {
        life.time = noTime;
    } else {
        life.time += delta.value;
    }
    if (life.time < life.duration) {
        return;
    }
    life.time = noTime;
    if (particle.life.count > noLife) {
        particle.life.count--;
    }
    if (particle.life.count === noLife) {
        particle.destroy();
        return;
    }
    const widthRange = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["setRangeValue"])(minCanvasSize, canvasSize.width), heightRange = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["setRangeValue"])(minCanvasSize, canvasSize.width);
    particle.position.x = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["randomInRange"])(widthRange);
    particle.position.y = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["randomInRange"])(heightRange);
    particle.spawning = true;
    life.delayTime = noTime;
    life.time = noTime;
    particle.reset();
    const lifeOptions = particle.options.life;
    if (lifeOptions) {
        life.delay = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getRangeValue"])(lifeOptions.delay.value) * __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["millisecondsToSeconds"];
        life.duration = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getRangeValue"])(lifeOptions.duration.value) * __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["millisecondsToSeconds"];
    }
}
}),
"[project]/theitern/node_modules/@tsparticles/updater-life/esm/LifeUpdater.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "LifeUpdater",
    ()=>LifeUpdater
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/NumberUtils.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Core/Utils/Constants.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$updater$2d$life$2f$esm$2f$Options$2f$Classes$2f$Life$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/updater-life/esm/Options/Classes/Life.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$updater$2d$life$2f$esm$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/updater-life/esm/Utils.js [app-ssr] (ecmascript)");
;
;
;
const noTime = 0, identity = 1, infiniteValue = -1;
class LifeUpdater {
    constructor(container){
        this.container = container;
    }
    init(particle) {
        const container = this.container, particlesOptions = particle.options, lifeOptions = particlesOptions.life;
        if (!lifeOptions) {
            return;
        }
        particle.life = {
            delay: container.retina.reduceFactor ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getRangeValue"])(lifeOptions.delay.value) * (lifeOptions.delay.sync ? identity : (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getRandom"])()) / container.retina.reduceFactor * __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["millisecondsToSeconds"] : noTime,
            delayTime: noTime,
            duration: container.retina.reduceFactor ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getRangeValue"])(lifeOptions.duration.value) * (lifeOptions.duration.sync ? identity : (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getRandom"])()) / container.retina.reduceFactor * __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["millisecondsToSeconds"] : noTime,
            time: noTime,
            count: lifeOptions.count
        };
        if (particle.life.duration <= noTime) {
            particle.life.duration = infiniteValue;
        }
        if (particle.life.count <= noTime) {
            particle.life.count = infiniteValue;
        }
        if (particle.life) {
            particle.spawning = particle.life.delay > noTime;
        }
    }
    isEnabled(particle) {
        return !particle.destroyed;
    }
    loadOptions(options, ...sources) {
        if (!options.life) {
            options.life = new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$updater$2d$life$2f$esm$2f$Options$2f$Classes$2f$Life$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Life"]();
        }
        for (const source of sources){
            options.life.load(source?.life);
        }
    }
    update(particle, delta) {
        if (!this.isEnabled(particle) || !particle.life) {
            return;
        }
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$updater$2d$life$2f$esm$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["updateLife"])(particle, delta, this.container.canvas.size);
    }
}
}),
"[project]/theitern/node_modules/@tsparticles/updater-life/esm/index.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "loadLifeUpdater",
    ()=>loadLifeUpdater
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$updater$2d$life$2f$esm$2f$LifeUpdater$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/updater-life/esm/LifeUpdater.js [app-ssr] (ecmascript)");
;
async function loadLifeUpdater(engine, refresh = true) {
    engine.checkVersion("3.9.1");
    await engine.addParticleUpdater("life", async (container)=>{
        return Promise.resolve(new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$updater$2d$life$2f$esm$2f$LifeUpdater$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["LifeUpdater"](container));
    }, refresh);
}
}),
"[project]/theitern/node_modules/@tsparticles/shape-line/esm/Utils.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "drawLine",
    ()=>drawLine
]);
function drawLine(data) {
    const { context, particle, radius } = data, shapeData = particle.shapeData, centerY = 0;
    context.moveTo(-radius, centerY);
    context.lineTo(radius, centerY);
    context.lineCap = shapeData?.cap ?? "butt";
}
}),
"[project]/theitern/node_modules/@tsparticles/shape-line/esm/LineDrawer.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "LineDrawer",
    ()=>LineDrawer
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$shape$2d$line$2f$esm$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/shape-line/esm/Utils.js [app-ssr] (ecmascript)");
;
const sides = 1;
class LineDrawer {
    constructor(){
        this.validTypes = [
            "line"
        ];
    }
    draw(data) {
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$shape$2d$line$2f$esm$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["drawLine"])(data);
    }
    getSidesCount() {
        return sides;
    }
}
}),
"[project]/theitern/node_modules/@tsparticles/shape-line/esm/index.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "loadLineShape",
    ()=>loadLineShape
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$shape$2d$line$2f$esm$2f$LineDrawer$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/shape-line/esm/LineDrawer.js [app-ssr] (ecmascript)");
;
async function loadLineShape(engine, refresh = true) {
    engine.checkVersion("3.9.1");
    await engine.addShape(new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$shape$2d$line$2f$esm$2f$LineDrawer$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["LineDrawer"](), refresh);
}
}),
"[project]/theitern/node_modules/@tsparticles/move-parallax/esm/ParallaxMover.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ParallaxMover",
    ()=>ParallaxMover
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/Utils.js [app-ssr] (ecmascript)");
;
const half = 0.5;
class ParallaxMover {
    init() {}
    isEnabled(particle) {
        return !(0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isSsr"])() && !particle.destroyed && particle.container.actualOptions.interactivity.events.onHover.parallax.enable;
    }
    move(particle) {
        const container = particle.container, options = container.actualOptions, parallaxOptions = options.interactivity.events.onHover.parallax;
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isSsr"])() || !parallaxOptions.enable) {
            return;
        }
        const parallaxForce = parallaxOptions.force, mousePos = container.interactivity.mouse.position;
        if (!mousePos) {
            return;
        }
        const canvasSize = container.canvas.size, canvasCenter = {
            x: canvasSize.width * half,
            y: canvasSize.height * half
        }, parallaxSmooth = parallaxOptions.smooth, factor = particle.getRadius() / parallaxForce, centerDistance = {
            x: (mousePos.x - canvasCenter.x) * factor,
            y: (mousePos.y - canvasCenter.y) * factor
        }, { offset } = particle;
        offset.x += (centerDistance.x - offset.x) / parallaxSmooth;
        offset.y += (centerDistance.y - offset.y) / parallaxSmooth;
    }
}
}),
"[project]/theitern/node_modules/@tsparticles/move-parallax/esm/index.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "loadParallaxMover",
    ()=>loadParallaxMover
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$move$2d$parallax$2f$esm$2f$ParallaxMover$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/move-parallax/esm/ParallaxMover.js [app-ssr] (ecmascript)");
;
async function loadParallaxMover(engine, refresh = true) {
    engine.checkVersion("3.9.1");
    await engine.addMover("parallax", ()=>{
        return Promise.resolve(new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$move$2d$parallax$2f$esm$2f$ParallaxMover$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ParallaxMover"]());
    }, refresh);
}
}),
"[project]/theitern/node_modules/@tsparticles/interaction-particles-attract/esm/Attractor.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Attractor",
    ()=>Attractor
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$ParticlesInteractorBase$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Core/Utils/ParticlesInteractorBase.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/NumberUtils.js [app-ssr] (ecmascript)");
;
const attractFactor = 1000, identity = 1;
class Attractor extends __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$ParticlesInteractorBase$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ParticlesInteractorBase"] {
    constructor(container){
        super(container);
    }
    clear() {}
    init() {}
    interact(p1) {
        const container = this.container;
        if (p1.attractDistance === undefined) {
            p1.attractDistance = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getRangeValue"])(p1.options.move.attract.distance) * container.retina.pixelRatio;
        }
        const distance = p1.attractDistance, pos1 = p1.getPosition(), query = container.particles.quadTree.queryCircle(pos1, distance);
        for (const p2 of query){
            if (p1 === p2 || !p2.options.move.attract.enable || p2.destroyed || p2.spawning) {
                continue;
            }
            const pos2 = p2.getPosition(), { dx, dy } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getDistances"])(pos1, pos2), rotate = p1.options.move.attract.rotate, ax = dx / (rotate.x * attractFactor), ay = dy / (rotate.y * attractFactor), p1Factor = p2.size.value / p1.size.value, p2Factor = identity / p1Factor;
            p1.velocity.x -= ax * p1Factor;
            p1.velocity.y -= ay * p1Factor;
            p2.velocity.x += ax * p2Factor;
            p2.velocity.y += ay * p2Factor;
        }
    }
    isEnabled(particle) {
        return particle.options.move.attract.enable;
    }
    reset() {}
}
}),
"[project]/theitern/node_modules/@tsparticles/interaction-particles-attract/esm/index.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "loadParticlesAttractInteraction",
    ()=>loadParticlesAttractInteraction
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$interaction$2d$particles$2d$attract$2f$esm$2f$Attractor$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/interaction-particles-attract/esm/Attractor.js [app-ssr] (ecmascript)");
;
async function loadParticlesAttractInteraction(engine, refresh = true) {
    engine.checkVersion("3.9.1");
    await engine.addInteractor("particlesAttract", (container)=>{
        return Promise.resolve(new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$interaction$2d$particles$2d$attract$2f$esm$2f$Attractor$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Attractor"](container));
    }, refresh);
}
}),
"[project]/theitern/node_modules/@tsparticles/interaction-particles-collisions/esm/Absorb.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "absorb",
    ()=>absorb
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/NumberUtils.js [app-ssr] (ecmascript)");
;
const half = 0.5, absorbFactor = 10, minAbsorbFactor = 0;
function updateAbsorb(p1, r1, p2, r2, delta, pixelRatio) {
    const factor = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["clamp"])(p1.options.collisions.absorb.speed * delta.factor / absorbFactor, minAbsorbFactor, r2);
    p1.size.value += factor * half;
    p2.size.value -= factor;
    if (r2 <= pixelRatio) {
        p2.size.value = 0;
        p2.destroy();
    }
}
function absorb(p1, p2, delta, pixelRatio) {
    const r1 = p1.getRadius(), r2 = p2.getRadius();
    if (r1 === undefined && r2 !== undefined) {
        p1.destroy();
    } else if (r1 !== undefined && r2 === undefined) {
        p2.destroy();
    } else if (r1 !== undefined && r2 !== undefined) {
        if (r1 >= r2) {
            updateAbsorb(p1, r1, p2, r2, delta, pixelRatio);
        } else {
            updateAbsorb(p2, r2, p1, r1, delta, pixelRatio);
        }
    }
}
}),
"[project]/theitern/node_modules/@tsparticles/interaction-particles-collisions/esm/Bounce.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "bounce",
    ()=>bounce
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/Utils.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/NumberUtils.js [app-ssr] (ecmascript)");
;
const fixBounceSpeed = (p)=>{
    if (p.collisionMaxSpeed === undefined) {
        p.collisionMaxSpeed = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getRangeValue"])(p.options.collisions.maxSpeed);
    }
    if (p.velocity.length > p.collisionMaxSpeed) {
        p.velocity.length = p.collisionMaxSpeed;
    }
};
function bounce(p1, p2) {
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["circleBounce"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["circleBounceDataFromParticle"])(p1), (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["circleBounceDataFromParticle"])(p2));
    fixBounceSpeed(p1);
    fixBounceSpeed(p2);
}
}),
"[project]/theitern/node_modules/@tsparticles/interaction-particles-collisions/esm/Destroy.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "destroy",
    ()=>destroy
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$interaction$2d$particles$2d$collisions$2f$esm$2f$Bounce$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/interaction-particles-collisions/esm/Bounce.js [app-ssr] (ecmascript)");
;
function destroy(p1, p2) {
    if (!p1.unbreakable && !p2.unbreakable) {
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$interaction$2d$particles$2d$collisions$2f$esm$2f$Bounce$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["bounce"])(p1, p2);
    }
    if (p1.getRadius() === undefined && p2.getRadius() !== undefined) {
        p1.destroy();
    } else if (p1.getRadius() !== undefined && p2.getRadius() === undefined) {
        p2.destroy();
    } else if (p1.getRadius() !== undefined && p2.getRadius() !== undefined) {
        const deleteP = p1.getRadius() >= p2.getRadius() ? p2 : p1;
        deleteP.destroy();
    }
}
}),
"[project]/theitern/node_modules/@tsparticles/interaction-particles-collisions/esm/ResolveCollision.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "resolveCollision",
    ()=>resolveCollision
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Modes$2f$CollisionMode$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Enums/Modes/CollisionMode.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$interaction$2d$particles$2d$collisions$2f$esm$2f$Absorb$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/interaction-particles-collisions/esm/Absorb.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$interaction$2d$particles$2d$collisions$2f$esm$2f$Bounce$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/interaction-particles-collisions/esm/Bounce.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$interaction$2d$particles$2d$collisions$2f$esm$2f$Destroy$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/interaction-particles-collisions/esm/Destroy.js [app-ssr] (ecmascript)");
;
;
;
;
function resolveCollision(p1, p2, delta, pixelRatio) {
    switch(p1.options.collisions.mode){
        case __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Modes$2f$CollisionMode$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["CollisionMode"].absorb:
            {
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$interaction$2d$particles$2d$collisions$2f$esm$2f$Absorb$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["absorb"])(p1, p2, delta, pixelRatio);
                break;
            }
        case __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Modes$2f$CollisionMode$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["CollisionMode"].bounce:
            {
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$interaction$2d$particles$2d$collisions$2f$esm$2f$Bounce$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["bounce"])(p1, p2);
                break;
            }
        case __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Modes$2f$CollisionMode$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["CollisionMode"].destroy:
            {
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$interaction$2d$particles$2d$collisions$2f$esm$2f$Destroy$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["destroy"])(p1, p2);
                break;
            }
    }
}
}),
"[project]/theitern/node_modules/@tsparticles/interaction-particles-collisions/esm/Collider.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Collider",
    ()=>Collider
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$ParticlesInteractorBase$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Core/Utils/ParticlesInteractorBase.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/NumberUtils.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$interaction$2d$particles$2d$collisions$2f$esm$2f$ResolveCollision$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/interaction-particles-collisions/esm/ResolveCollision.js [app-ssr] (ecmascript)");
;
;
const double = 2;
class Collider extends __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$ParticlesInteractorBase$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ParticlesInteractorBase"] {
    constructor(container){
        super(container);
    }
    clear() {}
    init() {}
    interact(p1, delta) {
        if (p1.destroyed || p1.spawning) {
            return;
        }
        const container = this.container, pos1 = p1.getPosition(), radius1 = p1.getRadius(), query = container.particles.quadTree.queryCircle(pos1, radius1 * double);
        for (const p2 of query){
            if (p1 === p2 || !p2.options.collisions.enable || p1.options.collisions.mode !== p2.options.collisions.mode || p2.destroyed || p2.spawning) {
                continue;
            }
            const pos2 = p2.getPosition(), radius2 = p2.getRadius();
            if (Math.abs(Math.round(pos1.z) - Math.round(pos2.z)) > radius1 + radius2) {
                continue;
            }
            const dist = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getDistance"])(pos1, pos2), distP = radius1 + radius2;
            if (dist > distP) {
                continue;
            }
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$interaction$2d$particles$2d$collisions$2f$esm$2f$ResolveCollision$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["resolveCollision"])(p1, p2, delta, container.retina.pixelRatio);
        }
    }
    isEnabled(particle) {
        return particle.options.collisions.enable;
    }
    reset() {}
}
}),
"[project]/theitern/node_modules/@tsparticles/interaction-particles-collisions/esm/index.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "loadParticlesCollisionsInteraction",
    ()=>loadParticlesCollisionsInteraction
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$interaction$2d$particles$2d$collisions$2f$esm$2f$Collider$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/interaction-particles-collisions/esm/Collider.js [app-ssr] (ecmascript)");
;
async function loadParticlesCollisionsInteraction(engine, refresh = true) {
    engine.checkVersion("3.9.1");
    await engine.addInteractor("particlesCollisions", (container)=>{
        return Promise.resolve(new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$interaction$2d$particles$2d$collisions$2f$esm$2f$Collider$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Collider"](container));
    }, refresh);
}
}),
"[project]/theitern/node_modules/@tsparticles/interaction-particles-links/esm/CircleWarp.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "CircleWarp",
    ()=>CircleWarp
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Ranges$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Core/Utils/Ranges.js [app-ssr] (ecmascript)");
;
const double = 2;
class CircleWarp extends __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Ranges$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Circle"] {
    constructor(x, y, radius, canvasSize){
        super(x, y, radius);
        this.canvasSize = canvasSize;
        this.canvasSize = {
            ...canvasSize
        };
    }
    contains(point) {
        const { width, height } = this.canvasSize, { x, y } = point;
        return super.contains(point) || super.contains({
            x: x - width,
            y
        }) || super.contains({
            x: x - width,
            y: y - height
        }) || super.contains({
            x,
            y: y - height
        });
    }
    intersects(range) {
        if (super.intersects(range)) {
            return true;
        }
        const rect = range, circle = range, newPos = {
            x: range.position.x - this.canvasSize.width,
            y: range.position.y - this.canvasSize.height
        };
        if (circle.radius !== undefined) {
            const biggerCircle = new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Ranges$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Circle"](newPos.x, newPos.y, circle.radius * double);
            return super.intersects(biggerCircle);
        } else if (rect.size !== undefined) {
            const rectSW = new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Ranges$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Rectangle"](newPos.x, newPos.y, rect.size.width * double, rect.size.height * double);
            return super.intersects(rectSW);
        }
        return false;
    }
}
}),
"[project]/theitern/node_modules/@tsparticles/interaction-particles-links/esm/Options/Classes/LinksShadow.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "LinksShadow",
    ()=>LinksShadow
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$OptionsColor$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Classes/OptionsColor.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/TypeUtils.js [app-ssr] (ecmascript)");
;
class LinksShadow {
    constructor(){
        this.blur = 5;
        this.color = new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$OptionsColor$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["OptionsColor"]();
        this.color.value = "#000";
        this.enable = false;
    }
    load(data) {
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isNull"])(data)) {
            return;
        }
        if (data.blur !== undefined) {
            this.blur = data.blur;
        }
        this.color = __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$OptionsColor$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["OptionsColor"].create(this.color, data.color);
        if (data.enable !== undefined) {
            this.enable = data.enable;
        }
    }
}
}),
"[project]/theitern/node_modules/@tsparticles/interaction-particles-links/esm/Options/Classes/LinksTriangle.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "LinksTriangle",
    ()=>LinksTriangle
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$OptionsColor$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Classes/OptionsColor.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/TypeUtils.js [app-ssr] (ecmascript)");
;
class LinksTriangle {
    constructor(){
        this.enable = false;
        this.frequency = 1;
    }
    load(data) {
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isNull"])(data)) {
            return;
        }
        if (data.color !== undefined) {
            this.color = __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$OptionsColor$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["OptionsColor"].create(this.color, data.color);
        }
        if (data.enable !== undefined) {
            this.enable = data.enable;
        }
        if (data.frequency !== undefined) {
            this.frequency = data.frequency;
        }
        if (data.opacity !== undefined) {
            this.opacity = data.opacity;
        }
    }
}
}),
"[project]/theitern/node_modules/@tsparticles/interaction-particles-links/esm/Options/Classes/Links.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Links",
    ()=>Links
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$OptionsColor$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Classes/OptionsColor.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/TypeUtils.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$interaction$2d$particles$2d$links$2f$esm$2f$Options$2f$Classes$2f$LinksShadow$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/interaction-particles-links/esm/Options/Classes/LinksShadow.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$interaction$2d$particles$2d$links$2f$esm$2f$Options$2f$Classes$2f$LinksTriangle$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/interaction-particles-links/esm/Options/Classes/LinksTriangle.js [app-ssr] (ecmascript)");
;
;
;
class Links {
    constructor(){
        this.blink = false;
        this.color = new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$OptionsColor$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["OptionsColor"]();
        this.color.value = "#fff";
        this.consent = false;
        this.distance = 100;
        this.enable = false;
        this.frequency = 1;
        this.opacity = 1;
        this.shadow = new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$interaction$2d$particles$2d$links$2f$esm$2f$Options$2f$Classes$2f$LinksShadow$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["LinksShadow"]();
        this.triangles = new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$interaction$2d$particles$2d$links$2f$esm$2f$Options$2f$Classes$2f$LinksTriangle$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["LinksTriangle"]();
        this.width = 1;
        this.warp = false;
    }
    load(data) {
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isNull"])(data)) {
            return;
        }
        if (data.id !== undefined) {
            this.id = data.id;
        }
        if (data.blink !== undefined) {
            this.blink = data.blink;
        }
        this.color = __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$OptionsColor$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["OptionsColor"].create(this.color, data.color);
        if (data.consent !== undefined) {
            this.consent = data.consent;
        }
        if (data.distance !== undefined) {
            this.distance = data.distance;
        }
        if (data.enable !== undefined) {
            this.enable = data.enable;
        }
        if (data.frequency !== undefined) {
            this.frequency = data.frequency;
        }
        if (data.opacity !== undefined) {
            this.opacity = data.opacity;
        }
        this.shadow.load(data.shadow);
        this.triangles.load(data.triangles);
        if (data.width !== undefined) {
            this.width = data.width;
        }
        if (data.warp !== undefined) {
            this.warp = data.warp;
        }
    }
}
}),
"[project]/theitern/node_modules/@tsparticles/interaction-particles-links/esm/Linker.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Linker",
    ()=>Linker
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Ranges$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Core/Utils/Ranges.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$ParticlesInteractorBase$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Core/Utils/ParticlesInteractorBase.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/NumberUtils.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$ColorUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/ColorUtils.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$interaction$2d$particles$2d$links$2f$esm$2f$CircleWarp$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/interaction-particles-links/esm/CircleWarp.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$interaction$2d$particles$2d$links$2f$esm$2f$Options$2f$Classes$2f$Links$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/interaction-particles-links/esm/Options/Classes/Links.js [app-ssr] (ecmascript)");
;
;
;
const squarePower = 2, opacityOffset = 1, origin = {
    x: 0,
    y: 0
}, minDistance = 0;
function getLinkDistance(pos1, pos2, optDistance, canvasSize, warp) {
    const { dx, dy, distance } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getDistances"])(pos1, pos2);
    if (!warp || distance <= optDistance) {
        return distance;
    }
    const absDiffs = {
        x: Math.abs(dx),
        y: Math.abs(dy)
    }, warpDistances = {
        x: Math.min(absDiffs.x, canvasSize.width - absDiffs.x),
        y: Math.min(absDiffs.y, canvasSize.height - absDiffs.y)
    };
    return Math.sqrt(warpDistances.x ** squarePower + warpDistances.y ** squarePower);
}
class Linker extends __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$ParticlesInteractorBase$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ParticlesInteractorBase"] {
    constructor(container, engine){
        super(container);
        this._setColor = (p1)=>{
            if (!p1.options.links) {
                return;
            }
            const container = this._linkContainer, linksOptions = p1.options.links;
            let linkColor = linksOptions.id === undefined ? container.particles.linksColor : container.particles.linksColors.get(linksOptions.id);
            if (linkColor) {
                return;
            }
            const optColor = linksOptions.color;
            linkColor = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$ColorUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getLinkRandomColor"])(this._engine, optColor, linksOptions.blink, linksOptions.consent);
            if (linksOptions.id === undefined) {
                container.particles.linksColor = linkColor;
            } else {
                container.particles.linksColors.set(linksOptions.id, linkColor);
            }
        };
        this._linkContainer = container;
        this._engine = engine;
    }
    clear() {}
    init() {
        this._linkContainer.particles.linksColor = undefined;
        this._linkContainer.particles.linksColors = new Map();
    }
    interact(p1) {
        if (!p1.options.links) {
            return;
        }
        p1.links = [];
        const pos1 = p1.getPosition(), container = this.container, canvasSize = container.canvas.size;
        if (pos1.x < origin.x || pos1.y < origin.y || pos1.x > canvasSize.width || pos1.y > canvasSize.height) {
            return;
        }
        const linkOpt1 = p1.options.links, optOpacity = linkOpt1.opacity, optDistance = p1.retina.linksDistance ?? minDistance, warp = linkOpt1.warp;
        let range;
        if (warp) {
            range = new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$interaction$2d$particles$2d$links$2f$esm$2f$CircleWarp$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["CircleWarp"](pos1.x, pos1.y, optDistance, canvasSize);
        } else {
            range = new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Core$2f$Utils$2f$Ranges$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Circle"](pos1.x, pos1.y, optDistance);
        }
        const query = container.particles.quadTree.query(range);
        for (const p2 of query){
            const linkOpt2 = p2.options.links;
            if (p1 === p2 || !linkOpt2?.enable || linkOpt1.id !== linkOpt2.id || p2.spawning || p2.destroyed || !p2.links || p1.links.some((t)=>t.destination === p2) || p2.links.some((t)=>t.destination === p1)) {
                continue;
            }
            const pos2 = p2.getPosition();
            if (pos2.x < origin.x || pos2.y < origin.y || pos2.x > canvasSize.width || pos2.y > canvasSize.height) {
                continue;
            }
            const distance = getLinkDistance(pos1, pos2, optDistance, canvasSize, warp && linkOpt2.warp);
            if (distance > optDistance) {
                continue;
            }
            const opacityLine = (opacityOffset - distance / optDistance) * optOpacity;
            this._setColor(p1);
            p1.links.push({
                destination: p2,
                opacity: opacityLine
            });
        }
    }
    isEnabled(particle) {
        return !!particle.options.links?.enable;
    }
    loadParticlesOptions(options, ...sources) {
        if (!options.links) {
            options.links = new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$interaction$2d$particles$2d$links$2f$esm$2f$Options$2f$Classes$2f$Links$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Links"]();
        }
        for (const source of sources){
            options.links.load(source?.links);
        }
    }
    reset() {}
}
}),
"[project]/theitern/node_modules/@tsparticles/interaction-particles-links/esm/interaction.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "loadLinksInteraction",
    ()=>loadLinksInteraction
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$interaction$2d$particles$2d$links$2f$esm$2f$Linker$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/interaction-particles-links/esm/Linker.js [app-ssr] (ecmascript)");
;
async function loadLinksInteraction(engine, refresh = true) {
    await engine.addInteractor("particlesLinks", async (container)=>{
        return Promise.resolve(new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$interaction$2d$particles$2d$links$2f$esm$2f$Linker$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Linker"](container, engine));
    }, refresh);
}
}),
"[project]/theitern/node_modules/@tsparticles/interaction-particles-links/esm/Utils.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "drawLinkLine",
    ()=>drawLinkLine,
    "drawLinkTriangle",
    ()=>drawLinkTriangle,
    "drawTriangle",
    ()=>drawTriangle,
    "getLinkKey",
    ()=>getLinkKey,
    "setLinkFrequency",
    ()=>setLinkFrequency
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$CanvasUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/CanvasUtils.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/NumberUtils.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$ColorUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/ColorUtils.js [app-ssr] (ecmascript)");
;
function drawTriangle(context, p1, p2, p3) {
    context.beginPath();
    context.moveTo(p1.x, p1.y);
    context.lineTo(p2.x, p2.y);
    context.lineTo(p3.x, p3.y);
    context.closePath();
}
function drawLinkLine(params) {
    let drawn = false;
    const { begin, end, engine, maxDistance, context, canvasSize, width, backgroundMask, colorLine, opacity, links } = params;
    if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getDistance"])(begin, end) <= maxDistance) {
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$CanvasUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["drawLine"])(context, begin, end);
        drawn = true;
    } else if (links.warp) {
        let pi1;
        let pi2;
        const endNE = {
            x: end.x - canvasSize.width,
            y: end.y
        };
        const d1 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getDistances"])(begin, endNE);
        if (d1.distance <= maxDistance) {
            const yi = begin.y - d1.dy / d1.dx * begin.x;
            pi1 = {
                x: 0,
                y: yi
            };
            pi2 = {
                x: canvasSize.width,
                y: yi
            };
        } else {
            const endSW = {
                x: end.x,
                y: end.y - canvasSize.height
            };
            const d2 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getDistances"])(begin, endSW);
            if (d2.distance <= maxDistance) {
                const yi = begin.y - d2.dy / d2.dx * begin.x;
                const xi = -yi / (d2.dy / d2.dx);
                pi1 = {
                    x: xi,
                    y: 0
                };
                pi2 = {
                    x: xi,
                    y: canvasSize.height
                };
            } else {
                const endSE = {
                    x: end.x - canvasSize.width,
                    y: end.y - canvasSize.height
                };
                const d3 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getDistances"])(begin, endSE);
                if (d3.distance <= maxDistance) {
                    const yi = begin.y - d3.dy / d3.dx * begin.x;
                    const xi = -yi / (d3.dy / d3.dx);
                    pi1 = {
                        x: xi,
                        y: yi
                    };
                    pi2 = {
                        x: pi1.x + canvasSize.width,
                        y: pi1.y + canvasSize.height
                    };
                }
            }
        }
        if (pi1 && pi2) {
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$CanvasUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["drawLine"])(context, begin, pi1);
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$CanvasUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["drawLine"])(context, end, pi2);
            drawn = true;
        }
    }
    if (!drawn) {
        return;
    }
    context.lineWidth = width;
    if (backgroundMask.enable) {
        context.globalCompositeOperation = backgroundMask.composite;
    }
    context.strokeStyle = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$ColorUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getStyleFromRgb"])(colorLine, opacity);
    const { shadow } = links;
    if (shadow.enable) {
        const shadowColor = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$ColorUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["rangeColorToRgb"])(engine, shadow.color);
        if (shadowColor) {
            context.shadowBlur = shadow.blur;
            context.shadowColor = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$ColorUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getStyleFromRgb"])(shadowColor);
        }
    }
    context.stroke();
}
function drawLinkTriangle(params) {
    const { context, pos1, pos2, pos3, backgroundMask, colorTriangle, opacityTriangle } = params;
    drawTriangle(context, pos1, pos2, pos3);
    if (backgroundMask.enable) {
        context.globalCompositeOperation = backgroundMask.composite;
    }
    context.fillStyle = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$ColorUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getStyleFromRgb"])(colorTriangle, opacityTriangle);
    context.fill();
}
function getLinkKey(ids) {
    ids.sort((a, b)=>a - b);
    return ids.join("_");
}
function setLinkFrequency(particles, dictionary) {
    const key = getLinkKey(particles.map((t)=>t.id));
    let res = dictionary.get(key);
    if (res === undefined) {
        res = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getRandom"])();
        dictionary.set(key, res);
    }
    return res;
}
}),
"[project]/theitern/node_modules/@tsparticles/interaction-particles-links/esm/LinkInstance.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "LinkInstance",
    ()=>LinkInstance
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/NumberUtils.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$ColorUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/ColorUtils.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$interaction$2d$particles$2d$links$2f$esm$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/interaction-particles-links/esm/Utils.js [app-ssr] (ecmascript)");
;
;
const minOpacity = 0, minWidth = 0, minDistance = 0, half = 0.5, maxFrequency = 1;
class LinkInstance {
    constructor(container, engine){
        this._drawLinkLine = (p1, link)=>{
            const p1LinksOptions = p1.options.links;
            if (!p1LinksOptions?.enable) {
                return;
            }
            const container = this._container, options = container.actualOptions, p2 = link.destination, pos1 = p1.getPosition(), pos2 = p2.getPosition();
            let opacity = link.opacity;
            container.canvas.draw((ctx)=>{
                let colorLine;
                const twinkle = p1.options.twinkle?.lines;
                if (twinkle?.enable) {
                    const twinkleFreq = twinkle.frequency, twinkleRgb = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$ColorUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["rangeColorToRgb"])(this._engine, twinkle.color), twinkling = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getRandom"])() < twinkleFreq;
                    if (twinkling && twinkleRgb) {
                        colorLine = twinkleRgb;
                        opacity = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getRangeValue"])(twinkle.opacity);
                    }
                }
                if (!colorLine) {
                    const linkColor = p1LinksOptions.id !== undefined ? container.particles.linksColors.get(p1LinksOptions.id) : container.particles.linksColor;
                    colorLine = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$ColorUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getLinkColor"])(p1, p2, linkColor);
                }
                if (!colorLine) {
                    return;
                }
                const width = p1.retina.linksWidth ?? minWidth, maxDistance = p1.retina.linksDistance ?? minDistance, { backgroundMask } = options;
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$interaction$2d$particles$2d$links$2f$esm$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["drawLinkLine"])({
                    context: ctx,
                    width,
                    begin: pos1,
                    end: pos2,
                    engine: this._engine,
                    maxDistance,
                    canvasSize: container.canvas.size,
                    links: p1LinksOptions,
                    backgroundMask: backgroundMask,
                    colorLine,
                    opacity
                });
            });
        };
        this._drawLinkTriangle = (p1, link1, link2)=>{
            const linksOptions = p1.options.links;
            if (!linksOptions?.enable) {
                return;
            }
            const triangleOptions = linksOptions.triangles;
            if (!triangleOptions.enable) {
                return;
            }
            const container = this._container, options = container.actualOptions, p2 = link1.destination, p3 = link2.destination, opacityTriangle = triangleOptions.opacity ?? (link1.opacity + link2.opacity) * half;
            if (opacityTriangle <= minOpacity) {
                return;
            }
            container.canvas.draw((ctx)=>{
                const pos1 = p1.getPosition(), pos2 = p2.getPosition(), pos3 = p3.getPosition(), linksDistance = p1.retina.linksDistance ?? minDistance;
                if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getDistance"])(pos1, pos2) > linksDistance || (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getDistance"])(pos3, pos2) > linksDistance || (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getDistance"])(pos3, pos1) > linksDistance) {
                    return;
                }
                let colorTriangle = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$ColorUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["rangeColorToRgb"])(this._engine, triangleOptions.color);
                if (!colorTriangle) {
                    const linkColor = linksOptions.id !== undefined ? container.particles.linksColors.get(linksOptions.id) : container.particles.linksColor;
                    colorTriangle = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$ColorUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getLinkColor"])(p1, p2, linkColor);
                }
                if (!colorTriangle) {
                    return;
                }
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$interaction$2d$particles$2d$links$2f$esm$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["drawLinkTriangle"])({
                    context: ctx,
                    pos1,
                    pos2,
                    pos3,
                    backgroundMask: options.backgroundMask,
                    colorTriangle,
                    opacityTriangle
                });
            });
        };
        this._drawTriangles = (options, p1, link, p1Links)=>{
            const p2 = link.destination;
            if (!(options.links?.triangles.enable && p2.options.links?.triangles.enable)) {
                return;
            }
            const vertices = p2.links?.filter((t)=>{
                const linkFreq = this._getLinkFrequency(p2, t.destination), minCount = 0;
                return p2.options.links && linkFreq <= p2.options.links.frequency && p1Links.findIndex((l)=>l.destination === t.destination) >= minCount;
            });
            if (!vertices?.length) {
                return;
            }
            for (const vertex of vertices){
                const p3 = vertex.destination, triangleFreq = this._getTriangleFrequency(p1, p2, p3);
                if (triangleFreq > options.links.triangles.frequency) {
                    continue;
                }
                this._drawLinkTriangle(p1, link, vertex);
            }
        };
        this._getLinkFrequency = (p1, p2)=>{
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$interaction$2d$particles$2d$links$2f$esm$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["setLinkFrequency"])([
                p1,
                p2
            ], this._freqs.links);
        };
        this._getTriangleFrequency = (p1, p2, p3)=>{
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$interaction$2d$particles$2d$links$2f$esm$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["setLinkFrequency"])([
                p1,
                p2,
                p3
            ], this._freqs.triangles);
        };
        this._container = container;
        this._engine = engine;
        this._freqs = {
            links: new Map(),
            triangles: new Map()
        };
    }
    drawParticle(context, particle) {
        const { links, options } = particle;
        if (!links?.length) {
            return;
        }
        const p1Links = links.filter((l)=>options.links && (options.links.frequency >= maxFrequency || this._getLinkFrequency(particle, l.destination) <= options.links.frequency));
        for (const link of p1Links){
            this._drawTriangles(options, particle, link, p1Links);
            if (link.opacity > minOpacity && (particle.retina.linksWidth ?? minWidth) > minWidth) {
                this._drawLinkLine(particle, link);
            }
        }
    }
    async init() {
        this._freqs.links = new Map();
        this._freqs.triangles = new Map();
        await Promise.resolve();
    }
    particleCreated(particle) {
        particle.links = [];
        if (!particle.options.links) {
            return;
        }
        const ratio = this._container.retina.pixelRatio, { retina } = particle, { distance, width } = particle.options.links;
        retina.linksDistance = distance * ratio;
        retina.linksWidth = width * ratio;
    }
    particleDestroyed(particle) {
        particle.links = [];
    }
}
}),
"[project]/theitern/node_modules/@tsparticles/interaction-particles-links/esm/LinksPlugin.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "LinksPlugin",
    ()=>LinksPlugin
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$interaction$2d$particles$2d$links$2f$esm$2f$LinkInstance$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/interaction-particles-links/esm/LinkInstance.js [app-ssr] (ecmascript)");
;
class LinksPlugin {
    constructor(engine){
        this.id = "links";
        this._engine = engine;
    }
    getPlugin(container) {
        return Promise.resolve(new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$interaction$2d$particles$2d$links$2f$esm$2f$LinkInstance$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["LinkInstance"](container, this._engine));
    }
    loadOptions() {}
    needsPlugin() {
        return true;
    }
}
}),
"[project]/theitern/node_modules/@tsparticles/interaction-particles-links/esm/plugin.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "loadLinksPlugin",
    ()=>loadLinksPlugin
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$interaction$2d$particles$2d$links$2f$esm$2f$LinksPlugin$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/interaction-particles-links/esm/LinksPlugin.js [app-ssr] (ecmascript)");
;
async function loadLinksPlugin(engine, refresh = true) {
    const plugin = new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$interaction$2d$particles$2d$links$2f$esm$2f$LinksPlugin$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["LinksPlugin"](engine);
    await engine.addPlugin(plugin, refresh);
}
}),
"[project]/theitern/node_modules/@tsparticles/interaction-particles-links/esm/Options/Interfaces/ILinks.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
;
}),
"[project]/theitern/node_modules/@tsparticles/interaction-particles-links/esm/Options/Interfaces/ILinksShadow.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
;
}),
"[project]/theitern/node_modules/@tsparticles/interaction-particles-links/esm/Options/Interfaces/ILinksTriangle.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
;
}),
"[project]/theitern/node_modules/@tsparticles/interaction-particles-links/esm/index.js [app-ssr] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "loadParticlesLinksInteraction",
    ()=>loadParticlesLinksInteraction
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$interaction$2d$particles$2d$links$2f$esm$2f$interaction$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/interaction-particles-links/esm/interaction.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$interaction$2d$particles$2d$links$2f$esm$2f$plugin$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/interaction-particles-links/esm/plugin.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$interaction$2d$particles$2d$links$2f$esm$2f$Options$2f$Classes$2f$Links$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/interaction-particles-links/esm/Options/Classes/Links.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$interaction$2d$particles$2d$links$2f$esm$2f$Options$2f$Classes$2f$LinksShadow$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/interaction-particles-links/esm/Options/Classes/LinksShadow.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$interaction$2d$particles$2d$links$2f$esm$2f$Options$2f$Classes$2f$LinksTriangle$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/interaction-particles-links/esm/Options/Classes/LinksTriangle.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$interaction$2d$particles$2d$links$2f$esm$2f$Options$2f$Interfaces$2f$ILinks$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/interaction-particles-links/esm/Options/Interfaces/ILinks.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$interaction$2d$particles$2d$links$2f$esm$2f$Options$2f$Interfaces$2f$ILinksShadow$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/interaction-particles-links/esm/Options/Interfaces/ILinksShadow.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$interaction$2d$particles$2d$links$2f$esm$2f$Options$2f$Interfaces$2f$ILinksTriangle$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/interaction-particles-links/esm/Options/Interfaces/ILinksTriangle.js [app-ssr] (ecmascript)");
;
;
async function loadParticlesLinksInteraction(engine, refresh = true) {
    engine.checkVersion("3.9.1");
    await (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$interaction$2d$particles$2d$links$2f$esm$2f$interaction$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["loadLinksInteraction"])(engine, refresh);
    await (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$interaction$2d$particles$2d$links$2f$esm$2f$plugin$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["loadLinksPlugin"])(engine, refresh);
}
;
;
;
;
;
;
}),
"[project]/theitern/node_modules/@tsparticles/shape-polygon/esm/Utils.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "drawPolygon",
    ()=>drawPolygon
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/NumberUtils.js [app-ssr] (ecmascript)");
;
const piDeg = 180, origin = {
    x: 0,
    y: 0
}, sidesOffset = 2;
function drawPolygon(data, start, side) {
    const { context } = data, sideCount = side.count.numerator * side.count.denominator, decimalSides = side.count.numerator / side.count.denominator, interiorAngleDegrees = piDeg * (decimalSides - sidesOffset) / decimalSides, interiorAngle = Math.PI - (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["degToRad"])(interiorAngleDegrees);
    if (!context) {
        return;
    }
    context.beginPath();
    context.translate(start.x, start.y);
    context.moveTo(origin.x, origin.y);
    for(let i = 0; i < sideCount; i++){
        context.lineTo(side.length, origin.y);
        context.translate(side.length, origin.y);
        context.rotate(interiorAngle);
    }
}
}),
"[project]/theitern/node_modules/@tsparticles/shape-polygon/esm/PolygonDrawerBase.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "PolygonDrawerBase",
    ()=>PolygonDrawerBase
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/NumberUtils.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$shape$2d$polygon$2f$esm$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/shape-polygon/esm/Utils.js [app-ssr] (ecmascript)");
;
;
const defaultSides = 5;
class PolygonDrawerBase {
    draw(data) {
        const { particle, radius } = data, start = this.getCenter(particle, radius), side = this.getSidesData(particle, radius);
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$shape$2d$polygon$2f$esm$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["drawPolygon"])(data, start, side);
    }
    getSidesCount(particle) {
        const polygon = particle.shapeData;
        return Math.round((0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getRangeValue"])(polygon?.sides ?? defaultSides));
    }
}
}),
"[project]/theitern/node_modules/@tsparticles/shape-polygon/esm/PolygonDrawer.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "PolygonDrawer",
    ()=>PolygonDrawer
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$shape$2d$polygon$2f$esm$2f$PolygonDrawerBase$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/shape-polygon/esm/PolygonDrawerBase.js [app-ssr] (ecmascript)");
;
const sidesCenterFactor = 3.5, yFactor = 2.66, sidesFactor = 3;
class PolygonDrawer extends __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$shape$2d$polygon$2f$esm$2f$PolygonDrawerBase$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["PolygonDrawerBase"] {
    constructor(){
        super(...arguments);
        this.validTypes = [
            "polygon"
        ];
    }
    getCenter(particle, radius) {
        return {
            x: -radius / (particle.sides / sidesCenterFactor),
            y: -radius / (yFactor / sidesCenterFactor)
        };
    }
    getSidesData(particle, radius) {
        const sides = particle.sides;
        return {
            count: {
                denominator: 1,
                numerator: sides
            },
            length: radius * yFactor / (sides / sidesFactor)
        };
    }
}
}),
"[project]/theitern/node_modules/@tsparticles/shape-polygon/esm/TriangleDrawer.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "TriangleDrawer",
    ()=>TriangleDrawer
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$shape$2d$polygon$2f$esm$2f$PolygonDrawerBase$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/shape-polygon/esm/PolygonDrawerBase.js [app-ssr] (ecmascript)");
;
const yFactor = 1.66, sides = 3, double = 2;
class TriangleDrawer extends __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$shape$2d$polygon$2f$esm$2f$PolygonDrawerBase$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["PolygonDrawerBase"] {
    constructor(){
        super(...arguments);
        this.validTypes = [
            "triangle"
        ];
    }
    getCenter(particle, radius) {
        return {
            x: -radius,
            y: radius / yFactor
        };
    }
    getSidesCount() {
        return sides;
    }
    getSidesData(particle, radius) {
        const diameter = radius * double;
        return {
            count: {
                denominator: 2,
                numerator: 3
            },
            length: diameter
        };
    }
}
}),
"[project]/theitern/node_modules/@tsparticles/shape-polygon/esm/index.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "loadGenericPolygonShape",
    ()=>loadGenericPolygonShape,
    "loadPolygonShape",
    ()=>loadPolygonShape,
    "loadTriangleShape",
    ()=>loadTriangleShape
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$shape$2d$polygon$2f$esm$2f$PolygonDrawer$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/shape-polygon/esm/PolygonDrawer.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$shape$2d$polygon$2f$esm$2f$TriangleDrawer$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/shape-polygon/esm/TriangleDrawer.js [app-ssr] (ecmascript)");
;
;
async function loadGenericPolygonShape(engine, refresh = true) {
    engine.checkVersion("3.9.1");
    await engine.addShape(new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$shape$2d$polygon$2f$esm$2f$PolygonDrawer$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["PolygonDrawer"](), refresh);
}
async function loadTriangleShape(engine, refresh = true) {
    engine.checkVersion("3.9.1");
    await engine.addShape(new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$shape$2d$polygon$2f$esm$2f$TriangleDrawer$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TriangleDrawer"](), refresh);
}
async function loadPolygonShape(engine, refresh = true) {
    engine.checkVersion("3.9.1");
    await loadGenericPolygonShape(engine, refresh);
    await loadTriangleShape(engine, refresh);
}
}),
"[project]/theitern/node_modules/@tsparticles/updater-rotate/esm/Options/Classes/RotateAnimation.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "RotateAnimation",
    ()=>RotateAnimation
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/TypeUtils.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/NumberUtils.js [app-ssr] (ecmascript)");
;
class RotateAnimation {
    constructor(){
        this.enable = false;
        this.speed = 0;
        this.decay = 0;
        this.sync = false;
    }
    load(data) {
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isNull"])(data)) {
            return;
        }
        if (data.enable !== undefined) {
            this.enable = data.enable;
        }
        if (data.speed !== undefined) {
            this.speed = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["setRangeValue"])(data.speed);
        }
        if (data.decay !== undefined) {
            this.decay = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["setRangeValue"])(data.decay);
        }
        if (data.sync !== undefined) {
            this.sync = data.sync;
        }
    }
}
}),
"[project]/theitern/node_modules/@tsparticles/updater-rotate/esm/Options/Classes/Rotate.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Rotate",
    ()=>Rotate
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Directions$2f$RotateDirection$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Enums/Directions/RotateDirection.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$ValueWithRandom$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Options/Classes/ValueWithRandom.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/TypeUtils.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$updater$2d$rotate$2f$esm$2f$Options$2f$Classes$2f$RotateAnimation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/updater-rotate/esm/Options/Classes/RotateAnimation.js [app-ssr] (ecmascript)");
;
;
class Rotate extends __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Options$2f$Classes$2f$ValueWithRandom$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ValueWithRandom"] {
    constructor(){
        super();
        this.animation = new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$updater$2d$rotate$2f$esm$2f$Options$2f$Classes$2f$RotateAnimation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["RotateAnimation"]();
        this.direction = __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Directions$2f$RotateDirection$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["RotateDirection"].clockwise;
        this.path = false;
        this.value = 0;
    }
    load(data) {
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$TypeUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isNull"])(data)) {
            return;
        }
        super.load(data);
        if (data.direction !== undefined) {
            this.direction = data.direction;
        }
        this.animation.load(data.animation);
        if (data.path !== undefined) {
            this.path = data.path;
        }
    }
}
}),
"[project]/theitern/node_modules/@tsparticles/updater-rotate/esm/RotateUpdater.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "RotateUpdater",
    ()=>RotateUpdater
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$AnimationStatus$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Enums/AnimationStatus.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Types$2f$DestroyType$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Enums/Types/DestroyType.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Directions$2f$RotateDirection$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Enums/Directions/RotateDirection.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/NumberUtils.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/Utils.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$updater$2d$rotate$2f$esm$2f$Options$2f$Classes$2f$Rotate$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/updater-rotate/esm/Options/Classes/Rotate.js [app-ssr] (ecmascript)");
;
;
const double = 2, doublePI = Math.PI * double, identity = 1, doublePIDeg = 360;
class RotateUpdater {
    constructor(container){
        this.container = container;
    }
    init(particle) {
        const rotateOptions = particle.options.rotate;
        if (!rotateOptions) {
            return;
        }
        particle.rotate = {
            enable: rotateOptions.animation.enable,
            value: (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["degToRad"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getRangeValue"])(rotateOptions.value)),
            min: 0,
            max: doublePI
        };
        particle.pathRotation = rotateOptions.path;
        let rotateDirection = rotateOptions.direction;
        if (rotateDirection === __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Directions$2f$RotateDirection$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["RotateDirection"].random) {
            const index = Math.floor((0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getRandom"])() * double), minIndex = 0;
            rotateDirection = index > minIndex ? __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Directions$2f$RotateDirection$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["RotateDirection"].counterClockwise : __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Directions$2f$RotateDirection$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["RotateDirection"].clockwise;
        }
        switch(rotateDirection){
            case __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Directions$2f$RotateDirection$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["RotateDirection"].counterClockwise:
            case "counterClockwise":
                particle.rotate.status = __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$AnimationStatus$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["AnimationStatus"].decreasing;
                break;
            case __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Directions$2f$RotateDirection$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["RotateDirection"].clockwise:
                particle.rotate.status = __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$AnimationStatus$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["AnimationStatus"].increasing;
                break;
        }
        const rotateAnimation = rotateOptions.animation;
        if (rotateAnimation.enable) {
            particle.rotate.decay = identity - (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getRangeValue"])(rotateAnimation.decay);
            particle.rotate.velocity = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getRangeValue"])(rotateAnimation.speed) / doublePIDeg * this.container.retina.reduceFactor;
            if (!rotateAnimation.sync) {
                particle.rotate.velocity *= (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getRandom"])();
            }
        }
        particle.rotation = particle.rotate.value;
    }
    isEnabled(particle) {
        const rotate = particle.options.rotate;
        if (!rotate) {
            return false;
        }
        return !particle.destroyed && !particle.spawning && (!!rotate.value || rotate.animation.enable || rotate.path);
    }
    loadOptions(options, ...sources) {
        if (!options.rotate) {
            options.rotate = new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$updater$2d$rotate$2f$esm$2f$Options$2f$Classes$2f$Rotate$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Rotate"]();
        }
        for (const source of sources){
            options.rotate.load(source?.rotate);
        }
    }
    update(particle, delta) {
        if (!this.isEnabled(particle)) {
            return;
        }
        particle.isRotating = !!particle.rotate;
        if (!particle.rotate) {
            return;
        }
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["updateAnimation"])(particle, particle.rotate, false, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Enums$2f$Types$2f$DestroyType$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["DestroyType"].none, delta);
        particle.rotation = particle.rotate.value;
    }
}
}),
"[project]/theitern/node_modules/@tsparticles/updater-rotate/esm/index.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "loadRotateUpdater",
    ()=>loadRotateUpdater
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$updater$2d$rotate$2f$esm$2f$RotateUpdater$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/updater-rotate/esm/RotateUpdater.js [app-ssr] (ecmascript)");
;
async function loadRotateUpdater(engine, refresh = true) {
    engine.checkVersion("3.9.1");
    await engine.addParticleUpdater("rotate", (container)=>{
        return Promise.resolve(new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$updater$2d$rotate$2f$esm$2f$RotateUpdater$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["RotateUpdater"](container));
    }, refresh);
}
}),
"[project]/theitern/node_modules/@tsparticles/shape-square/esm/Utils.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "drawSquare",
    ()=>drawSquare
]);
const fixFactorSquared = 2, fixFactor = Math.sqrt(fixFactorSquared), double = 2;
function drawSquare(data) {
    const { context, radius } = data, fixedRadius = radius / fixFactor, fixedDiameter = fixedRadius * double;
    context.rect(-fixedRadius, -fixedRadius, fixedDiameter, fixedDiameter);
}
}),
"[project]/theitern/node_modules/@tsparticles/shape-square/esm/SquareDrawer.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "SquareDrawer",
    ()=>SquareDrawer
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$shape$2d$square$2f$esm$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/shape-square/esm/Utils.js [app-ssr] (ecmascript)");
;
const sides = 4;
class SquareDrawer {
    constructor(){
        this.validTypes = [
            "edge",
            "square"
        ];
    }
    draw(data) {
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$shape$2d$square$2f$esm$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["drawSquare"])(data);
    }
    getSidesCount() {
        return sides;
    }
}
}),
"[project]/theitern/node_modules/@tsparticles/shape-square/esm/index.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "loadSquareShape",
    ()=>loadSquareShape
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$shape$2d$square$2f$esm$2f$SquareDrawer$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/shape-square/esm/SquareDrawer.js [app-ssr] (ecmascript)");
;
async function loadSquareShape(engine, refresh = true) {
    engine.checkVersion("3.9.1");
    await engine.addShape(new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$shape$2d$square$2f$esm$2f$SquareDrawer$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["SquareDrawer"](), refresh);
}
}),
"[project]/theitern/node_modules/@tsparticles/shape-star/esm/Utils.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "drawStar",
    ()=>drawStar
]);
const defaultInset = 2, origin = {
    x: 0,
    y: 0
};
function drawStar(data) {
    const { context, particle, radius } = data, sides = particle.sides, inset = particle.starInset ?? defaultInset;
    context.moveTo(origin.x, origin.y - radius);
    for(let i = 0; i < sides; i++){
        context.rotate(Math.PI / sides);
        context.lineTo(origin.x, origin.y - radius * inset);
        context.rotate(Math.PI / sides);
        context.lineTo(origin.x, origin.y - radius);
    }
}
}),
"[project]/theitern/node_modules/@tsparticles/shape-star/esm/StarDrawer.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "StarDrawer",
    ()=>StarDrawer
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/NumberUtils.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$shape$2d$star$2f$esm$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/shape-star/esm/Utils.js [app-ssr] (ecmascript)");
;
;
const defaultInset = 2, defaultSides = 5;
class StarDrawer {
    constructor(){
        this.validTypes = [
            "star"
        ];
    }
    draw(data) {
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$shape$2d$star$2f$esm$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["drawStar"])(data);
    }
    getSidesCount(particle) {
        const star = particle.shapeData;
        return Math.round((0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getRangeValue"])(star?.sides ?? defaultSides));
    }
    particleInit(container, particle) {
        const star = particle.shapeData;
        particle.starInset = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getRangeValue"])(star?.inset ?? defaultInset);
    }
}
}),
"[project]/theitern/node_modules/@tsparticles/shape-star/esm/index.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "loadStarShape",
    ()=>loadStarShape
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$shape$2d$star$2f$esm$2f$StarDrawer$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/shape-star/esm/StarDrawer.js [app-ssr] (ecmascript)");
;
async function loadStarShape(engine, refresh = true) {
    engine.checkVersion("3.9.1");
    await engine.addShape(new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$shape$2d$star$2f$esm$2f$StarDrawer$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["StarDrawer"](), refresh);
}
}),
"[project]/theitern/node_modules/@tsparticles/updater-stroke-color/esm/StrokeColorUpdater.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "StrokeColorUpdater",
    ()=>StrokeColorUpdater
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$ColorUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/ColorUtils.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/NumberUtils.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/engine/esm/Utils/Utils.js [app-ssr] (ecmascript)");
;
const defaultOpacity = 1;
class StrokeColorUpdater {
    constructor(container, engine){
        this._container = container;
        this._engine = engine;
    }
    init(particle) {
        const container = this._container, options = particle.options;
        const stroke = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["itemFromSingleOrMultiple"])(options.stroke, particle.id, options.reduceDuplicates);
        particle.strokeWidth = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getRangeValue"])(stroke.width) * container.retina.pixelRatio;
        particle.strokeOpacity = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getRangeValue"])(stroke.opacity ?? defaultOpacity);
        particle.strokeAnimation = stroke.color?.animation;
        const strokeHslColor = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$ColorUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["rangeColorToHsl"])(this._engine, stroke.color) ?? particle.getFillColor();
        if (strokeHslColor) {
            particle.strokeColor = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$ColorUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getHslAnimationFromHsl"])(strokeHslColor, particle.strokeAnimation, container.retina.reduceFactor);
        }
    }
    isEnabled(particle) {
        const color = particle.strokeAnimation, { strokeColor } = particle;
        return !particle.destroyed && !particle.spawning && !!color && (strokeColor?.h.value !== undefined && strokeColor.h.enable || strokeColor?.s.value !== undefined && strokeColor.s.enable || strokeColor?.l.value !== undefined && strokeColor.l.enable);
    }
    update(particle, delta) {
        if (!this.isEnabled(particle)) {
            return;
        }
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$engine$2f$esm$2f$Utils$2f$ColorUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["updateColor"])(particle.strokeColor, delta);
    }
}
}),
"[project]/theitern/node_modules/@tsparticles/updater-stroke-color/esm/index.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "loadStrokeColorUpdater",
    ()=>loadStrokeColorUpdater
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$updater$2d$stroke$2d$color$2f$esm$2f$StrokeColorUpdater$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/updater-stroke-color/esm/StrokeColorUpdater.js [app-ssr] (ecmascript)");
;
async function loadStrokeColorUpdater(engine, refresh = true) {
    engine.checkVersion("3.9.1");
    await engine.addParticleUpdater("strokeColor", (container)=>{
        return Promise.resolve(new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$updater$2d$stroke$2d$color$2f$esm$2f$StrokeColorUpdater$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["StrokeColorUpdater"](container, engine));
    }, refresh);
}
}),
"[project]/theitern/node_modules/@tsparticles/slim/esm/index.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "loadSlim",
    ()=>loadSlim
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$basic$2f$esm$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/basic/esm/index.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$plugin$2d$easing$2d$quad$2f$esm$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/plugin-easing-quad/esm/index.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$shape$2d$emoji$2f$esm$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/shape-emoji/esm/index.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$interaction$2d$external$2d$attract$2f$esm$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/interaction-external-attract/esm/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$interaction$2d$external$2d$bounce$2f$esm$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/interaction-external-bounce/esm/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$interaction$2d$external$2d$bubble$2f$esm$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/interaction-external-bubble/esm/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$interaction$2d$external$2d$connect$2f$esm$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/interaction-external-connect/esm/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$interaction$2d$external$2d$grab$2f$esm$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/interaction-external-grab/esm/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$interaction$2d$external$2d$pause$2f$esm$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/interaction-external-pause/esm/index.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$interaction$2d$external$2d$push$2f$esm$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/interaction-external-push/esm/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$interaction$2d$external$2d$remove$2f$esm$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/interaction-external-remove/esm/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$interaction$2d$external$2d$repulse$2f$esm$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/interaction-external-repulse/esm/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$interaction$2d$external$2d$slow$2f$esm$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/interaction-external-slow/esm/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$shape$2d$image$2f$esm$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/shape-image/esm/index.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$updater$2d$life$2f$esm$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/updater-life/esm/index.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$shape$2d$line$2f$esm$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/shape-line/esm/index.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$move$2d$parallax$2f$esm$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/move-parallax/esm/index.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$interaction$2d$particles$2d$attract$2f$esm$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/interaction-particles-attract/esm/index.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$interaction$2d$particles$2d$collisions$2f$esm$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/interaction-particles-collisions/esm/index.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$interaction$2d$particles$2d$links$2f$esm$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/interaction-particles-links/esm/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$shape$2d$polygon$2f$esm$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/shape-polygon/esm/index.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$updater$2d$rotate$2f$esm$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/updater-rotate/esm/index.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$shape$2d$square$2f$esm$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/shape-square/esm/index.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$shape$2d$star$2f$esm$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/shape-star/esm/index.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$updater$2d$stroke$2d$color$2f$esm$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/@tsparticles/updater-stroke-color/esm/index.js [app-ssr] (ecmascript)");
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
async function loadSlim(engine, refresh = true) {
    engine.checkVersion("3.9.1");
    await (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$move$2d$parallax$2f$esm$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["loadParallaxMover"])(engine, false);
    await (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$interaction$2d$external$2d$attract$2f$esm$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["loadExternalAttractInteraction"])(engine, false);
    await (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$interaction$2d$external$2d$bounce$2f$esm$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["loadExternalBounceInteraction"])(engine, false);
    await (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$interaction$2d$external$2d$bubble$2f$esm$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["loadExternalBubbleInteraction"])(engine, false);
    await (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$interaction$2d$external$2d$connect$2f$esm$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["loadExternalConnectInteraction"])(engine, false);
    await (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$interaction$2d$external$2d$grab$2f$esm$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["loadExternalGrabInteraction"])(engine, false);
    await (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$interaction$2d$external$2d$pause$2f$esm$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["loadExternalPauseInteraction"])(engine, false);
    await (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$interaction$2d$external$2d$push$2f$esm$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["loadExternalPushInteraction"])(engine, false);
    await (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$interaction$2d$external$2d$remove$2f$esm$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["loadExternalRemoveInteraction"])(engine, false);
    await (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$interaction$2d$external$2d$repulse$2f$esm$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["loadExternalRepulseInteraction"])(engine, false);
    await (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$interaction$2d$external$2d$slow$2f$esm$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["loadExternalSlowInteraction"])(engine, false);
    await (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$interaction$2d$particles$2d$attract$2f$esm$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["loadParticlesAttractInteraction"])(engine, false);
    await (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$interaction$2d$particles$2d$collisions$2f$esm$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["loadParticlesCollisionsInteraction"])(engine, false);
    await (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$interaction$2d$particles$2d$links$2f$esm$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["loadParticlesLinksInteraction"])(engine, false);
    await (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$plugin$2d$easing$2d$quad$2f$esm$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["loadEasingQuadPlugin"])(engine, false);
    await (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$shape$2d$emoji$2f$esm$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["loadEmojiShape"])(engine, false);
    await (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$shape$2d$image$2f$esm$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["loadImageShape"])(engine, false);
    await (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$shape$2d$line$2f$esm$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["loadLineShape"])(engine, false);
    await (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$shape$2d$polygon$2f$esm$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["loadPolygonShape"])(engine, false);
    await (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$shape$2d$square$2f$esm$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["loadSquareShape"])(engine, false);
    await (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$shape$2d$star$2f$esm$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["loadStarShape"])(engine, false);
    await (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$updater$2d$life$2f$esm$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["loadLifeUpdater"])(engine, false);
    await (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$updater$2d$rotate$2f$esm$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["loadRotateUpdater"])(engine, false);
    await (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$updater$2d$stroke$2d$color$2f$esm$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["loadStrokeColorUpdater"])(engine, false);
    await (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f40$tsparticles$2f$basic$2f$esm$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["loadBasic"])(engine, refresh);
}
}),
"[project]/theitern/node_modules/react-player/dist/patterns.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "AUDIO_EXTENSIONS",
    ()=>AUDIO_EXTENSIONS,
    "DASH_EXTENSIONS",
    ()=>DASH_EXTENSIONS,
    "HLS_EXTENSIONS",
    ()=>HLS_EXTENSIONS,
    "MATCH_URL_MUX",
    ()=>MATCH_URL_MUX,
    "MATCH_URL_SPOTIFY",
    ()=>MATCH_URL_SPOTIFY,
    "MATCH_URL_TIKTOK",
    ()=>MATCH_URL_TIKTOK,
    "MATCH_URL_TWITCH",
    ()=>MATCH_URL_TWITCH,
    "MATCH_URL_VIMEO",
    ()=>MATCH_URL_VIMEO,
    "MATCH_URL_WISTIA",
    ()=>MATCH_URL_WISTIA,
    "MATCH_URL_YOUTUBE",
    ()=>MATCH_URL_YOUTUBE,
    "VIDEO_EXTENSIONS",
    ()=>VIDEO_EXTENSIONS,
    "canPlay",
    ()=>canPlay
]);
const AUDIO_EXTENSIONS = /\.(m4a|m4b|mp4a|mpga|mp2|mp2a|mp3|m2a|m3a|wav|weba|aac|oga|spx)($|\?)/i;
const VIDEO_EXTENSIONS = /\.(mp4|og[gv]|webm|mov|m4v)(#t=[,\d+]+)?($|\?)/i;
const HLS_EXTENSIONS = /\.(m3u8)($|\?)/i;
const DASH_EXTENSIONS = /\.(mpd)($|\?)/i;
const MATCH_URL_MUX = /stream\.mux\.com\/(?!\w+\.m3u8)(\w+)/;
const MATCH_URL_YOUTUBE = /(?:youtu\.be\/|youtube(?:-nocookie|education)?\.com\/(?:embed\/|v\/|watch\/|watch\?v=|watch\?.+&v=|shorts\/|live\/))((\w|-){11})|youtube\.com\/playlist\?list=|youtube\.com\/user\//;
const MATCH_URL_VIMEO = /vimeo\.com\/(?!progressive_redirect).+/;
const MATCH_URL_WISTIA = /(?:wistia\.(?:com|net)|wi\.st)\/(?:medias|embed)\/(?:iframe\/)?([^?]+)/;
const MATCH_URL_SPOTIFY = /open\.spotify\.com\/(\w+)\/(\w+)/i;
const MATCH_URL_TWITCH = /(?:www\.|go\.)?twitch\.tv\/([a-zA-Z0-9_]+|(videos?\/|\?video=)\d+)($|\?)/;
const MATCH_URL_TIKTOK = /tiktok\.com\/(?:player\/v1\/|share\/video\/|@[^/]+\/video\/)([0-9]+)/;
const canPlayFile = (url, test)=>{
    if (Array.isArray(url)) {
        for (const item of url){
            if (typeof item === "string" && canPlayFile(item, test)) {
                return true;
            }
            if (canPlayFile(item.src, test)) {
                return true;
            }
        }
        return false;
    }
    return test(url);
};
const canPlay = {
    html: (url)=>canPlayFile(url, (u)=>AUDIO_EXTENSIONS.test(u) || VIDEO_EXTENSIONS.test(u)),
    hls: (url)=>canPlayFile(url, (u)=>HLS_EXTENSIONS.test(u)),
    dash: (url)=>canPlayFile(url, (u)=>DASH_EXTENSIONS.test(u)),
    mux: (url)=>MATCH_URL_MUX.test(url),
    youtube: (url)=>MATCH_URL_YOUTUBE.test(url),
    vimeo: (url)=>MATCH_URL_VIMEO.test(url) && !VIDEO_EXTENSIONS.test(url) && !HLS_EXTENSIONS.test(url),
    wistia: (url)=>MATCH_URL_WISTIA.test(url),
    spotify: (url)=>MATCH_URL_SPOTIFY.test(url),
    twitch: (url)=>MATCH_URL_TWITCH.test(url),
    tiktok: (url)=>MATCH_URL_TIKTOK.test(url)
};
;
}),
"[project]/theitern/node_modules/react-player/dist/HtmlPlayer.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>HtmlPlayer_default
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$react$2d$player$2f$dist$2f$patterns$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/react-player/dist/patterns.js [app-ssr] (ecmascript)");
;
;
const HtmlPlayer = __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].forwardRef((props, ref)=>{
    const Media = __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$react$2d$player$2f$dist$2f$patterns$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["AUDIO_EXTENSIONS"].test(`${props.src}`) ? "audio" : "video";
    return /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].createElement(Media, {
        ...props,
        ref
    }, props.children);
});
var HtmlPlayer_default = HtmlPlayer;
;
}),
"[project]/theitern/node_modules/react-player/dist/players.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>players_default
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$react$2d$player$2f$dist$2f$patterns$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/react-player/dist/patterns.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$react$2d$player$2f$dist$2f$HtmlPlayer$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/react-player/dist/HtmlPlayer.js [app-ssr] (ecmascript)");
;
;
;
const Players = [
    {
        key: "hls",
        name: "hls.js",
        canPlay: __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$react$2d$player$2f$dist$2f$patterns$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["canPlay"].hls,
        canEnablePIP: ()=>true,
        player: (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["lazy"])(()=>__turbopack_context__.A("[project]/theitern/node_modules/hls-video-element/dist/react.js [app-ssr] (ecmascript, async loader)"))
    },
    {
        key: "dash",
        name: "dash.js",
        canPlay: __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$react$2d$player$2f$dist$2f$patterns$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["canPlay"].dash,
        canEnablePIP: ()=>true,
        player: (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["lazy"])(()=>__turbopack_context__.A("[project]/theitern/node_modules/dash-video-element/dist/react.js [app-ssr] (ecmascript, async loader)"))
    },
    {
        key: "mux",
        name: "Mux",
        canPlay: __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$react$2d$player$2f$dist$2f$patterns$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["canPlay"].mux,
        canEnablePIP: ()=>true,
        player: (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["lazy"])(()=>__turbopack_context__.A("[project]/theitern/node_modules/@mux/mux-player-react/dist/index.mjs [app-ssr] (ecmascript, async loader)"))
    },
    {
        key: "youtube",
        name: "YouTube",
        canPlay: __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$react$2d$player$2f$dist$2f$patterns$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["canPlay"].youtube,
        player: (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["lazy"])(()=>__turbopack_context__.A("[project]/theitern/node_modules/youtube-video-element/dist/react.js [app-ssr] (ecmascript, async loader)"))
    },
    {
        key: "vimeo",
        name: "Vimeo",
        canPlay: __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$react$2d$player$2f$dist$2f$patterns$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["canPlay"].vimeo,
        player: (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["lazy"])(()=>__turbopack_context__.A("[project]/theitern/node_modules/vimeo-video-element/dist/react.js [app-ssr] (ecmascript, async loader)"))
    },
    {
        key: "wistia",
        name: "Wistia",
        canPlay: __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$react$2d$player$2f$dist$2f$patterns$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["canPlay"].wistia,
        canEnablePIP: ()=>true,
        player: (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["lazy"])(()=>__turbopack_context__.A("[project]/theitern/node_modules/wistia-video-element/dist/react.js [app-ssr] (ecmascript, async loader)"))
    },
    {
        key: "spotify",
        name: "Spotify",
        canPlay: __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$react$2d$player$2f$dist$2f$patterns$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["canPlay"].spotify,
        canEnablePIP: ()=>false,
        player: (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["lazy"])(()=>__turbopack_context__.A("[project]/theitern/node_modules/spotify-audio-element/dist/react.js [app-ssr] (ecmascript, async loader)"))
    },
    {
        key: "twitch",
        name: "Twitch",
        canPlay: __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$react$2d$player$2f$dist$2f$patterns$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["canPlay"].twitch,
        canEnablePIP: ()=>false,
        player: (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["lazy"])(()=>__turbopack_context__.A("[project]/theitern/node_modules/twitch-video-element/dist/react.js [app-ssr] (ecmascript, async loader)"))
    },
    {
        key: "tiktok",
        name: "TikTok",
        canPlay: __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$react$2d$player$2f$dist$2f$patterns$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["canPlay"].tiktok,
        canEnablePIP: ()=>false,
        player: (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["lazy"])(()=>__turbopack_context__.A("[project]/theitern/node_modules/tiktok-video-element/dist/react.js [app-ssr] (ecmascript, async loader)"))
    },
    {
        key: "html",
        name: "html",
        canPlay: __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$react$2d$player$2f$dist$2f$patterns$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["canPlay"].html,
        canEnablePIP: ()=>true,
        player: __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$react$2d$player$2f$dist$2f$HtmlPlayer$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]
    }
];
var players_default = Players;
;
}),
"[project]/theitern/node_modules/react-player/dist/props.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "defaultProps",
    ()=>defaultProps
]);
const defaultProps = {
    // Falsy values don't need to be defined
    //
    // native video attrs
    // src: undefined,
    // preload: undefined,
    // crossOrigin: undefined,
    // autoPlay: false,
    // muted: false,
    // loop: false,
    // controls: false,
    // playsInline: false,
    // disableRemotePlayback: false,
    width: "320px",
    height: "180px",
    // native video props
    volume: 1,
    playbackRate: 1,
    // custom props
    // playing: undefined,
    // pip: false,
    // light: false,
    // fallback: null,
    previewTabIndex: 0,
    previewAriaLabel: "",
    oEmbedUrl: "https://noembed.com/embed?url={url}"
};
;
}),
"[project]/theitern/node_modules/react-player/dist/Player.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>Player_default
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
;
const Player = __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].forwardRef((props, ref)=>{
    const { playing, pip } = props;
    const Player2 = props.activePlayer;
    const playerRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRef"])(null);
    const startOnPlayRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRef"])(true);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        var _a, _b;
        if (!playerRef.current) return;
        if (playerRef.current.paused && playing === true) {
            playerRef.current.play();
        }
        if (!playerRef.current.paused && playing === false) {
            playerRef.current.pause();
        }
        playerRef.current.playbackRate = (_a = props.playbackRate) != null ? _a : 1;
        playerRef.current.volume = (_b = props.volume) != null ? _b : 1;
    });
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        var _a, _b, _c, _d, _e;
        if (!playerRef.current || !globalThis.document) return;
        if (pip && !document.pictureInPictureElement) {
            try {
                (_b = (_a = playerRef.current).requestPictureInPicture) == null ? void 0 : _b.call(_a);
            } catch (err) {}
        }
        if (!pip && document.pictureInPictureElement) {
            try {
                (_d = (_c = playerRef.current).exitPictureInPicture) == null ? void 0 : _d.call(_c);
                (_e = document.exitPictureInPicture) == null ? void 0 : _e.call(document);
            } catch (err) {}
        }
    }, [
        pip
    ]);
    const handleLoadStart = (event)=>{
        var _a, _b;
        startOnPlayRef.current = true;
        (_a = props.onReady) == null ? void 0 : _a.call(props);
        (_b = props.onLoadStart) == null ? void 0 : _b.call(props, event);
    };
    const handlePlay = (event)=>{
        var _a, _b;
        if (startOnPlayRef.current) {
            startOnPlayRef.current = false;
            (_a = props.onStart) == null ? void 0 : _a.call(props, event);
        }
        (_b = props.onPlay) == null ? void 0 : _b.call(props, event);
    };
    if (!Player2) {
        return null;
    }
    const eventProps = {};
    const reactPlayerEventHandlers = [
        "onReady",
        "onStart"
    ];
    for(const key in props){
        if (key.startsWith("on") && !reactPlayerEventHandlers.includes(key)) {
            eventProps[key] = props[key];
        }
    }
    return /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].createElement(Player2, {
        ...eventProps,
        style: props.style,
        className: props.className,
        slot: props.slot,
        ref: (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useCallback"])((node)=>{
            playerRef.current = node;
            if (typeof ref === "function") {
                ref(node);
            } else if (ref !== null) {
                ref.current = node;
            }
        }, [
            ref
        ]),
        src: props.src,
        crossOrigin: props.crossOrigin,
        preload: props.preload,
        controls: props.controls,
        muted: props.muted,
        autoPlay: props.autoPlay,
        loop: props.loop,
        playsInline: props.playsInline,
        disableRemotePlayback: props.disableRemotePlayback,
        config: props.config,
        onLoadStart: handleLoadStart,
        onPlay: handlePlay
    }, props.children);
});
Player.displayName = "Player";
var Player_default = Player;
;
}),
"[project]/theitern/node_modules/react-player/dist/ReactPlayer.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "createReactPlayer",
    ()=>createReactPlayer
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$react$2d$player$2f$dist$2f$props$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/react-player/dist/props.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$react$2d$player$2f$dist$2f$Player$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/react-player/dist/Player.js [app-ssr] (ecmascript)");
;
;
;
const Preview = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["lazy"])(()=>__turbopack_context__.A("[project]/theitern/node_modules/react-player/dist/Preview.js [app-ssr] (ecmascript, async loader)"));
const customPlayers = [];
const createReactPlayer = (players, playerFallback)=>{
    const getActivePlayer = (src)=>{
        for (const player of [
            ...customPlayers,
            ...players
        ]){
            if (src && player.canPlay(src)) {
                return player;
            }
        }
        if (playerFallback) {
            return playerFallback;
        }
        return null;
    };
    const ReactPlayer = __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].forwardRef((_props, ref)=>{
        const props = {
            ...__TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$react$2d$player$2f$dist$2f$props$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["defaultProps"],
            ..._props
        };
        const { src, slot, className, style, width, height, fallback, wrapper } = props;
        const [showPreview, setShowPreview] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(!!props.light);
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
            if (props.light) {
                setShowPreview(true);
            } else {
                setShowPreview(false);
            }
        }, [
            props.light
        ]);
        const handleClickPreview = (e)=>{
            var _a;
            setShowPreview(false);
            (_a = props.onClickPreview) == null ? void 0 : _a.call(props, e);
        };
        const renderPreview = (src2)=>{
            if (!src2) return null;
            const { light, playIcon, previewTabIndex, oEmbedUrl, previewAriaLabel } = props;
            return /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].createElement(Preview, {
                src: src2,
                light,
                playIcon,
                previewTabIndex,
                previewAriaLabel,
                oEmbedUrl,
                onClickPreview: handleClickPreview
            });
        };
        const renderActivePlayer = (src2)=>{
            var _a, _b;
            const player = getActivePlayer(src2);
            if (!player) return null;
            const { style: style2, width: width2, height: height2, wrapper: wrapper2 } = props;
            const config = (_a = props.config) == null ? void 0 : _a[player.key];
            return /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].createElement(__TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$react$2d$player$2f$dist$2f$Player$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                ...props,
                ref,
                activePlayer: (_b = player.player) != null ? _b : player,
                slot: wrapper2 ? void 0 : slot,
                className: wrapper2 ? void 0 : className,
                style: wrapper2 ? {
                    display: "block",
                    width: "100%",
                    height: "100%"
                } : {
                    display: "block",
                    width: width2,
                    height: height2,
                    ...style2
                },
                config
            });
        };
        const Wrapper = wrapper == null ? ForwardChildren : wrapper;
        const UniversalSuspense = fallback === false ? ForwardChildren : __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Suspense"];
        return /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].createElement(Wrapper, {
            slot,
            className,
            style: {
                width,
                height,
                ...style
            }
        }, /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].createElement(UniversalSuspense, {
            fallback
        }, showPreview ? renderPreview(src) : renderActivePlayer(src)));
    });
    ReactPlayer.displayName = "ReactPlayer";
    ReactPlayer.addCustomPlayer = (player)=>{
        customPlayers.push(player);
    };
    ReactPlayer.removeCustomPlayers = ()=>{
        customPlayers.length = 0;
    };
    ReactPlayer.canPlay = (src)=>{
        if (src) {
            for (const Player2 of [
                ...customPlayers,
                ...players
            ]){
                if (Player2.canPlay(src)) {
                    return true;
                }
            }
        }
        return false;
    };
    ReactPlayer.canEnablePIP = (src)=>{
        var _a;
        if (src) {
            for (const Player2 of [
                ...customPlayers,
                ...players
            ]){
                if (Player2.canPlay(src) && ((_a = Player2.canEnablePIP) == null ? void 0 : _a.call(Player2))) {
                    return true;
                }
            }
        }
        return false;
    };
    return ReactPlayer;
};
const ForwardChildren = ({ children })=>children;
;
}),
"[project]/theitern/node_modules/react-player/dist/index.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>src_default
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$react$2d$player$2f$dist$2f$players$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/react-player/dist/players.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$react$2d$player$2f$dist$2f$ReactPlayer$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/react-player/dist/ReactPlayer.js [app-ssr] (ecmascript)");
"use client";
;
;
const fallback = __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$react$2d$player$2f$dist$2f$players$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"][__TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$react$2d$player$2f$dist$2f$players$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].length - 1];
var src_default = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$react$2d$player$2f$dist$2f$ReactPlayer$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createReactPlayer"])(__TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$react$2d$player$2f$dist$2f$players$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], fallback);
;
}),
];

//# sourceMappingURL=c6bf4_0812609c._.js.map