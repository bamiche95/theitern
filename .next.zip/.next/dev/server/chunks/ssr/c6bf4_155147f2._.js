module.exports = [
"[project]/theitern/node_modules/tsparticles-engine/esm/Core/Utils/Constants.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "errorPrefix",
    ()=>errorPrefix,
    "generatedAttribute",
    ()=>generatedAttribute,
    "mouseDownEvent",
    ()=>mouseDownEvent,
    "mouseLeaveEvent",
    ()=>mouseLeaveEvent,
    "mouseMoveEvent",
    ()=>mouseMoveEvent,
    "mouseOutEvent",
    ()=>mouseOutEvent,
    "mouseUpEvent",
    ()=>mouseUpEvent,
    "resizeEvent",
    ()=>resizeEvent,
    "touchCancelEvent",
    ()=>touchCancelEvent,
    "touchEndEvent",
    ()=>touchEndEvent,
    "touchMoveEvent",
    ()=>touchMoveEvent,
    "touchStartEvent",
    ()=>touchStartEvent,
    "visibilityChangeEvent",
    ()=>visibilityChangeEvent
]);
const generatedAttribute = "generated";
const mouseDownEvent = "pointerdown";
const mouseUpEvent = "pointerup";
const mouseLeaveEvent = "pointerleave";
const mouseOutEvent = "pointerout";
const mouseMoveEvent = "pointermove";
const touchStartEvent = "touchstart";
const touchEndEvent = "touchend";
const touchMoveEvent = "touchmove";
const touchCancelEvent = "touchcancel";
const resizeEvent = "resize";
const visibilityChangeEvent = "visibilitychange";
const errorPrefix = "tsParticles - Error";
}),
"[project]/theitern/node_modules/tsparticles-engine/esm/Core/Utils/Vector3d.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Vector3d",
    ()=>Vector3d
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/tsparticles-engine/esm/Core/Utils/Constants.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/tsparticles-engine/esm/Utils/Utils.js [app-ssr] (ecmascript)");
;
;
class Vector3d {
    constructor(xOrCoords, y, z){
        this._updateFromAngle = (angle, length)=>{
            this.x = Math.cos(angle) * length;
            this.y = Math.sin(angle) * length;
        };
        if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isNumber"])(xOrCoords) && xOrCoords) {
            this.x = xOrCoords.x;
            this.y = xOrCoords.y;
            const coords3d = xOrCoords;
            this.z = coords3d.z ? coords3d.z : 0;
        } else if (xOrCoords !== undefined && y !== undefined) {
            this.x = xOrCoords;
            this.y = y;
            this.z = z ?? 0;
        } else {
            throw new Error(`${__TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["errorPrefix"]} Vector3d not initialized correctly`);
        }
    }
    static get origin() {
        return Vector3d.create(0, 0, 0);
    }
    get angle() {
        return Math.atan2(this.y, this.x);
    }
    set angle(angle) {
        this._updateFromAngle(angle, this.length);
    }
    get length() {
        return Math.sqrt(this.getLengthSq());
    }
    set length(length) {
        this._updateFromAngle(this.angle, length);
    }
    static clone(source) {
        return Vector3d.create(source.x, source.y, source.z);
    }
    static create(x, y, z) {
        return new Vector3d(x, y, z);
    }
    add(v) {
        return Vector3d.create(this.x + v.x, this.y + v.y, this.z + v.z);
    }
    addTo(v) {
        this.x += v.x;
        this.y += v.y;
        this.z += v.z;
    }
    copy() {
        return Vector3d.clone(this);
    }
    distanceTo(v) {
        return this.sub(v).length;
    }
    distanceToSq(v) {
        return this.sub(v).getLengthSq();
    }
    div(n) {
        return Vector3d.create(this.x / n, this.y / n, this.z / n);
    }
    divTo(n) {
        this.x /= n;
        this.y /= n;
        this.z /= n;
    }
    getLengthSq() {
        return this.x ** 2 + this.y ** 2;
    }
    mult(n) {
        return Vector3d.create(this.x * n, this.y * n, this.z * n);
    }
    multTo(n) {
        this.x *= n;
        this.y *= n;
        this.z *= n;
    }
    normalize() {
        const length = this.length;
        if (length != 0) {
            this.multTo(1.0 / length);
        }
    }
    rotate(angle) {
        return Vector3d.create(this.x * Math.cos(angle) - this.y * Math.sin(angle), this.x * Math.sin(angle) + this.y * Math.cos(angle), 0);
    }
    setTo(c) {
        this.x = c.x;
        this.y = c.y;
        const v3d = c;
        this.z = v3d.z ? v3d.z : 0;
    }
    sub(v) {
        return Vector3d.create(this.x - v.x, this.y - v.y, this.z - v.z);
    }
    subFrom(v) {
        this.x -= v.x;
        this.y -= v.y;
        this.z -= v.z;
    }
}
}),
"[project]/theitern/node_modules/tsparticles-engine/esm/Core/Utils/Vector.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Vector",
    ()=>Vector
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Core$2f$Utils$2f$Vector3d$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/tsparticles-engine/esm/Core/Utils/Vector3d.js [app-ssr] (ecmascript)");
;
class Vector extends __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Core$2f$Utils$2f$Vector3d$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Vector3d"] {
    constructor(xOrCoords, y){
        super(xOrCoords, y, 0);
    }
    static get origin() {
        return Vector.create(0, 0);
    }
    static clone(source) {
        return Vector.create(source.x, source.y);
    }
    static create(x, y) {
        return new Vector(x, y);
    }
}
}),
"[project]/theitern/node_modules/tsparticles-engine/esm/Utils/NumberUtils.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "addEasing",
    ()=>addEasing,
    "calcExactPositionOrRandomFromSize",
    ()=>calcExactPositionOrRandomFromSize,
    "calcExactPositionOrRandomFromSizeRanged",
    ()=>calcExactPositionOrRandomFromSizeRanged,
    "calcPositionFromSize",
    ()=>calcPositionFromSize,
    "calcPositionOrRandomFromSize",
    ()=>calcPositionOrRandomFromSize,
    "calcPositionOrRandomFromSizeRanged",
    ()=>calcPositionOrRandomFromSizeRanged,
    "clamp",
    ()=>clamp,
    "collisionVelocity",
    ()=>collisionVelocity,
    "getDistance",
    ()=>getDistance,
    "getDistances",
    ()=>getDistances,
    "getEasing",
    ()=>getEasing,
    "getParticleBaseVelocity",
    ()=>getParticleBaseVelocity,
    "getParticleDirectionAngle",
    ()=>getParticleDirectionAngle,
    "getRandom",
    ()=>getRandom,
    "getRangeMax",
    ()=>getRangeMax,
    "getRangeMin",
    ()=>getRangeMin,
    "getRangeValue",
    ()=>getRangeValue,
    "getValue",
    ()=>getValue,
    "mix",
    ()=>mix,
    "parseAlpha",
    ()=>parseAlpha,
    "randomInRange",
    ()=>randomInRange,
    "setRandom",
    ()=>setRandom,
    "setRangeValue",
    ()=>setRangeValue
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/tsparticles-engine/esm/Utils/Utils.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Core$2f$Utils$2f$Vector$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/tsparticles-engine/esm/Core/Utils/Vector.js [app-ssr] (ecmascript)");
;
;
let _random = Math.random;
const easings = new Map();
function addEasing(name, easing) {
    if (easings.get(name)) {
        return;
    }
    easings.set(name, easing);
}
function getEasing(name) {
    return easings.get(name) || ((value)=>value);
}
function setRandom(rnd = Math.random) {
    _random = rnd;
}
function getRandom() {
    return clamp(_random(), 0, 1 - 1e-16);
}
function clamp(num, min, max) {
    return Math.min(Math.max(num, min), max);
}
function mix(comp1, comp2, weight1, weight2) {
    return Math.floor((comp1 * weight1 + comp2 * weight2) / (weight1 + weight2));
}
function randomInRange(r) {
    const max = getRangeMax(r);
    let min = getRangeMin(r);
    if (max === min) {
        min = 0;
    }
    return getRandom() * (max - min) + min;
}
function getRangeValue(value) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isNumber"])(value) ? value : randomInRange(value);
}
function getRangeMin(value) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isNumber"])(value) ? value : value.min;
}
function getRangeMax(value) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isNumber"])(value) ? value : value.max;
}
function setRangeValue(source, value) {
    if (source === value || value === undefined && (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isNumber"])(source)) {
        return source;
    }
    const min = getRangeMin(source), max = getRangeMax(source);
    return value !== undefined ? {
        min: Math.min(min, value),
        max: Math.max(max, value)
    } : setRangeValue(min, max);
}
function getValue(options) {
    const random = options.random, { enable, minimumValue } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isBoolean"])(random) ? {
        enable: random,
        minimumValue: 0
    } : random;
    return enable ? getRangeValue(setRangeValue(options.value, minimumValue)) : getRangeValue(options.value);
}
function getDistances(pointA, pointB) {
    const dx = pointA.x - pointB.x, dy = pointA.y - pointB.y;
    return {
        dx: dx,
        dy: dy,
        distance: Math.sqrt(dx ** 2 + dy ** 2)
    };
}
function getDistance(pointA, pointB) {
    return getDistances(pointA, pointB).distance;
}
function getParticleDirectionAngle(direction, position, center) {
    if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isNumber"])(direction)) {
        return direction * Math.PI / 180;
    }
    switch(direction){
        case "top":
            return -Math.PI / 2;
        case "top-right":
            return -Math.PI / 4;
        case "right":
            return 0;
        case "bottom-right":
            return Math.PI / 4;
        case "bottom":
            return Math.PI / 2;
        case "bottom-left":
            return 3 * Math.PI / 4;
        case "left":
            return Math.PI;
        case "top-left":
            return -3 * Math.PI / 4;
        case "inside":
            return Math.atan2(center.y - position.y, center.x - position.x);
        case "outside":
            return Math.atan2(position.y - center.y, position.x - center.x);
        default:
            return getRandom() * Math.PI * 2;
    }
}
function getParticleBaseVelocity(direction) {
    const baseVelocity = __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Core$2f$Utils$2f$Vector$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Vector"].origin;
    baseVelocity.length = 1;
    baseVelocity.angle = direction;
    return baseVelocity;
}
function collisionVelocity(v1, v2, m1, m2) {
    return __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Core$2f$Utils$2f$Vector$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Vector"].create(v1.x * (m1 - m2) / (m1 + m2) + v2.x * 2 * m2 / (m1 + m2), v1.y);
}
function calcPositionFromSize(data) {
    return data.position && data.position.x !== undefined && data.position.y !== undefined ? {
        x: data.position.x * data.size.width / 100,
        y: data.position.y * data.size.height / 100
    } : undefined;
}
function calcPositionOrRandomFromSize(data) {
    return {
        x: (data.position?.x ?? getRandom() * 100) * data.size.width / 100,
        y: (data.position?.y ?? getRandom() * 100) * data.size.height / 100
    };
}
function calcPositionOrRandomFromSizeRanged(data) {
    const position = {
        x: data.position?.x !== undefined ? getRangeValue(data.position.x) : undefined,
        y: data.position?.y !== undefined ? getRangeValue(data.position.y) : undefined
    };
    return calcPositionOrRandomFromSize({
        size: data.size,
        position
    });
}
function calcExactPositionOrRandomFromSize(data) {
    return {
        x: data.position?.x ?? getRandom() * data.size.width,
        y: data.position?.y ?? getRandom() * data.size.height
    };
}
function calcExactPositionOrRandomFromSizeRanged(data) {
    const position = {
        x: data.position?.x !== undefined ? getRangeValue(data.position.x) : undefined,
        y: data.position?.y !== undefined ? getRangeValue(data.position.y) : undefined
    };
    return calcExactPositionOrRandomFromSize({
        size: data.size,
        position
    });
}
function parseAlpha(input) {
    return input ? input.endsWith("%") ? parseFloat(input) / 100 : parseFloat(input) : 1;
}
}),
"[project]/theitern/node_modules/tsparticles-engine/esm/Utils/Utils.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "areBoundsInside",
    ()=>areBoundsInside,
    "arrayRandomIndex",
    ()=>arrayRandomIndex,
    "calculateBounds",
    ()=>calculateBounds,
    "circleBounce",
    ()=>circleBounce,
    "circleBounceDataFromParticle",
    ()=>circleBounceDataFromParticle,
    "deepExtend",
    ()=>deepExtend,
    "divMode",
    ()=>divMode,
    "divModeExecute",
    ()=>divModeExecute,
    "executeOnSingleOrMultiple",
    ()=>executeOnSingleOrMultiple,
    "findItemFromSingleOrMultiple",
    ()=>findItemFromSingleOrMultiple,
    "getLogger",
    ()=>getLogger,
    "getPosition",
    ()=>getPosition,
    "getSize",
    ()=>getSize,
    "hasMatchMedia",
    ()=>hasMatchMedia,
    "initParticleNumericAnimationValue",
    ()=>initParticleNumericAnimationValue,
    "isArray",
    ()=>isArray,
    "isBoolean",
    ()=>isBoolean,
    "isDivModeEnabled",
    ()=>isDivModeEnabled,
    "isFunction",
    ()=>isFunction,
    "isInArray",
    ()=>isInArray,
    "isNumber",
    ()=>isNumber,
    "isObject",
    ()=>isObject,
    "isPointInside",
    ()=>isPointInside,
    "isSsr",
    ()=>isSsr,
    "isString",
    ()=>isString,
    "itemFromArray",
    ()=>itemFromArray,
    "itemFromSingleOrMultiple",
    ()=>itemFromSingleOrMultiple,
    "loadFont",
    ()=>loadFont,
    "rectBounce",
    ()=>rectBounce,
    "safeMatchMedia",
    ()=>safeMatchMedia,
    "safeMutationObserver",
    ()=>safeMutationObserver,
    "setLogger",
    ()=>setLogger,
    "singleDivModeExecute",
    ()=>singleDivModeExecute
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/tsparticles-engine/esm/Utils/NumberUtils.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Core$2f$Utils$2f$Vector$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/tsparticles-engine/esm/Core/Utils/Vector.js [app-ssr] (ecmascript)");
;
;
const _logger = {
    debug: console.debug,
    error: console.error,
    info: console.info,
    log: console.log,
    verbose: console.log,
    warning: console.warn
};
function setLogger(logger) {
    _logger.debug = logger.debug || _logger.debug;
    _logger.error = logger.error || _logger.error;
    _logger.info = logger.info || _logger.info;
    _logger.log = logger.log || _logger.log;
    _logger.verbose = logger.verbose || _logger.verbose;
    _logger.warning = logger.warning || _logger.warning;
}
function getLogger() {
    return _logger;
}
function rectSideBounce(data) {
    const res = {
        bounced: false
    }, { pSide, pOtherSide, rectSide, rectOtherSide, velocity, factor } = data;
    if (pOtherSide.min < rectOtherSide.min || pOtherSide.min > rectOtherSide.max || pOtherSide.max < rectOtherSide.min || pOtherSide.max > rectOtherSide.max) {
        return res;
    }
    if (pSide.max >= rectSide.min && pSide.max <= (rectSide.max + rectSide.min) / 2 && velocity > 0 || pSide.min <= rectSide.max && pSide.min > (rectSide.max + rectSide.min) / 2 && velocity < 0) {
        res.velocity = velocity * -factor;
        res.bounced = true;
    }
    return res;
}
function checkSelector(element, selectors) {
    const res = executeOnSingleOrMultiple(selectors, (selector)=>{
        return element.matches(selector);
    });
    return isArray(res) ? res.some((t)=>t) : res;
}
function isSsr() {
    return ("TURBOPACK compile-time value", "undefined") === "undefined" || !window || typeof window.document === "undefined" || !window.document;
}
function hasMatchMedia() {
    return !isSsr() && typeof matchMedia !== "undefined";
}
function safeMatchMedia(query) {
    if (!hasMatchMedia()) {
        return;
    }
    //TURBOPACK unreachable
    ;
}
function safeMutationObserver(callback) {
    if (isSsr() || typeof MutationObserver === "undefined") {
        return;
    }
    //TURBOPACK unreachable
    ;
}
function isInArray(value, array) {
    return value === array || isArray(array) && array.indexOf(value) > -1;
}
async function loadFont(font, weight) {
    try {
        await document.fonts.load(`${weight ?? "400"} 36px '${font ?? "Verdana"}'`);
    } catch  {}
}
function arrayRandomIndex(array) {
    return Math.floor((0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getRandom"])() * array.length);
}
function itemFromArray(array, index, useIndex = true) {
    return array[index !== undefined && useIndex ? index % array.length : arrayRandomIndex(array)];
}
function isPointInside(point, size, offset, radius, direction) {
    return areBoundsInside(calculateBounds(point, radius ?? 0), size, offset, direction);
}
function areBoundsInside(bounds, size, offset, direction) {
    let inside = true;
    if (!direction || direction === "bottom") {
        inside = bounds.top < size.height + offset.x;
    }
    if (inside && (!direction || direction === "left")) {
        inside = bounds.right > offset.x;
    }
    if (inside && (!direction || direction === "right")) {
        inside = bounds.left < size.width + offset.y;
    }
    if (inside && (!direction || direction === "top")) {
        inside = bounds.bottom > offset.y;
    }
    return inside;
}
function calculateBounds(point, radius) {
    return {
        bottom: point.y + radius,
        left: point.x - radius,
        right: point.x + radius,
        top: point.y - radius
    };
}
function deepExtend(destination, ...sources) {
    for (const source of sources){
        if (source === undefined || source === null) {
            continue;
        }
        if (!isObject(source)) {
            destination = source;
            continue;
        }
        const sourceIsArray = Array.isArray(source);
        if (sourceIsArray && (isObject(destination) || !destination || !Array.isArray(destination))) {
            destination = [];
        } else if (!sourceIsArray && (isObject(destination) || !destination || Array.isArray(destination))) {
            destination = {};
        }
        for(const key in source){
            if (key === "__proto__") {
                continue;
            }
            const sourceDict = source, value = sourceDict[key], destDict = destination;
            destDict[key] = isObject(value) && Array.isArray(value) ? value.map((v)=>deepExtend(destDict[key], v)) : deepExtend(destDict[key], value);
        }
    }
    return destination;
}
function isDivModeEnabled(mode, divs) {
    return !!findItemFromSingleOrMultiple(divs, (t)=>t.enable && isInArray(mode, t.mode));
}
function divModeExecute(mode, divs, callback) {
    executeOnSingleOrMultiple(divs, (div)=>{
        const divMode = div.mode, divEnabled = div.enable;
        if (divEnabled && isInArray(mode, divMode)) {
            singleDivModeExecute(div, callback);
        }
    });
}
function singleDivModeExecute(div, callback) {
    const selectors = div.selectors;
    executeOnSingleOrMultiple(selectors, (selector)=>{
        callback(selector, div);
    });
}
function divMode(divs, element) {
    if (!element || !divs) {
        return;
    }
    return findItemFromSingleOrMultiple(divs, (div)=>{
        return checkSelector(element, div.selectors);
    });
}
function circleBounceDataFromParticle(p) {
    return {
        position: p.getPosition(),
        radius: p.getRadius(),
        mass: p.getMass(),
        velocity: p.velocity,
        factor: __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Core$2f$Utils$2f$Vector$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Vector"].create((0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getValue"])(p.options.bounce.horizontal), (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getValue"])(p.options.bounce.vertical))
    };
}
function circleBounce(p1, p2) {
    const { x: xVelocityDiff, y: yVelocityDiff } = p1.velocity.sub(p2.velocity), [pos1, pos2] = [
        p1.position,
        p2.position
    ], { dx: xDist, dy: yDist } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getDistances"])(pos2, pos1);
    if (xVelocityDiff * xDist + yVelocityDiff * yDist < 0) {
        return;
    }
    const angle = -Math.atan2(yDist, xDist), m1 = p1.mass, m2 = p2.mass, u1 = p1.velocity.rotate(angle), u2 = p2.velocity.rotate(angle), v1 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["collisionVelocity"])(u1, u2, m1, m2), v2 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["collisionVelocity"])(u2, u1, m1, m2), vFinal1 = v1.rotate(-angle), vFinal2 = v2.rotate(-angle);
    p1.velocity.x = vFinal1.x * p1.factor.x;
    p1.velocity.y = vFinal1.y * p1.factor.y;
    p2.velocity.x = vFinal2.x * p2.factor.x;
    p2.velocity.y = vFinal2.y * p2.factor.y;
}
function rectBounce(particle, divBounds) {
    const pPos = particle.getPosition(), size = particle.getRadius(), bounds = calculateBounds(pPos, size), resH = rectSideBounce({
        pSide: {
            min: bounds.left,
            max: bounds.right
        },
        pOtherSide: {
            min: bounds.top,
            max: bounds.bottom
        },
        rectSide: {
            min: divBounds.left,
            max: divBounds.right
        },
        rectOtherSide: {
            min: divBounds.top,
            max: divBounds.bottom
        },
        velocity: particle.velocity.x,
        factor: (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getValue"])(particle.options.bounce.horizontal)
    });
    if (resH.bounced) {
        if (resH.velocity !== undefined) {
            particle.velocity.x = resH.velocity;
        }
        if (resH.position !== undefined) {
            particle.position.x = resH.position;
        }
    }
    const resV = rectSideBounce({
        pSide: {
            min: bounds.top,
            max: bounds.bottom
        },
        pOtherSide: {
            min: bounds.left,
            max: bounds.right
        },
        rectSide: {
            min: divBounds.top,
            max: divBounds.bottom
        },
        rectOtherSide: {
            min: divBounds.left,
            max: divBounds.right
        },
        velocity: particle.velocity.y,
        factor: (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getValue"])(particle.options.bounce.vertical)
    });
    if (resV.bounced) {
        if (resV.velocity !== undefined) {
            particle.velocity.y = resV.velocity;
        }
        if (resV.position !== undefined) {
            particle.position.y = resV.position;
        }
    }
}
function executeOnSingleOrMultiple(obj, callback) {
    return isArray(obj) ? obj.map((item, index)=>callback(item, index)) : callback(obj, 0);
}
function itemFromSingleOrMultiple(obj, index, useIndex) {
    return isArray(obj) ? itemFromArray(obj, index, useIndex) : obj;
}
function findItemFromSingleOrMultiple(obj, callback) {
    return isArray(obj) ? obj.find((t, index)=>callback(t, index)) : callback(obj, 0) ? obj : undefined;
}
function initParticleNumericAnimationValue(options, pxRatio) {
    const valueRange = options.value, animationOptions = options.animation, res = {
        delayTime: (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getRangeValue"])(animationOptions.delay) * 1000,
        enable: animationOptions.enable,
        value: (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getRangeValue"])(options.value) * pxRatio,
        max: (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getRangeMax"])(valueRange) * pxRatio,
        min: (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getRangeMin"])(valueRange) * pxRatio,
        loops: 0,
        maxLoops: (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getRangeValue"])(animationOptions.count),
        time: 0
    };
    if (animationOptions.enable) {
        res.decay = 1 - (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getRangeValue"])(animationOptions.decay);
        switch(animationOptions.mode){
            case "increase":
                res.status = "increasing";
                break;
            case "decrease":
                res.status = "decreasing";
                break;
            case "random":
                res.status = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getRandom"])() >= 0.5 ? "increasing" : "decreasing";
                break;
        }
        const autoStatus = animationOptions.mode === "auto";
        switch(animationOptions.startValue){
            case "min":
                res.value = res.min;
                if (autoStatus) {
                    res.status = "increasing";
                }
                break;
            case "max":
                res.value = res.max;
                if (autoStatus) {
                    res.status = "decreasing";
                }
                break;
            case "random":
            default:
                res.value = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["randomInRange"])(res);
                if (autoStatus) {
                    res.status = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getRandom"])() >= 0.5 ? "increasing" : "decreasing";
                }
                break;
        }
    }
    res.initialValue = res.value;
    return res;
}
function getPositionOrSize(positionOrSize, canvasSize) {
    const isPercent = positionOrSize.mode === "percent";
    if (!isPercent) {
        const { mode: _, ...rest } = positionOrSize;
        return rest;
    }
    const isPosition = "x" in positionOrSize;
    if (isPosition) {
        return {
            x: positionOrSize.x / 100 * canvasSize.width,
            y: positionOrSize.y / 100 * canvasSize.height
        };
    } else {
        return {
            width: positionOrSize.width / 100 * canvasSize.width,
            height: positionOrSize.height / 100 * canvasSize.height
        };
    }
}
function getPosition(position, canvasSize) {
    return getPositionOrSize(position, canvasSize);
}
function getSize(size, canvasSize) {
    return getPositionOrSize(size, canvasSize);
}
function isBoolean(arg) {
    return typeof arg === "boolean";
}
function isString(arg) {
    return typeof arg === "string";
}
function isNumber(arg) {
    return typeof arg === "number";
}
function isFunction(arg) {
    return typeof arg === "function";
}
function isObject(arg) {
    return typeof arg === "object" && arg !== null;
}
function isArray(arg) {
    return Array.isArray(arg);
}
}),
"[project]/theitern/node_modules/tsparticles-engine/esm/Utils/ColorUtils.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "addColorManager",
    ()=>addColorManager,
    "colorMix",
    ()=>colorMix,
    "colorToHsl",
    ()=>colorToHsl,
    "colorToRgb",
    ()=>colorToRgb,
    "getHslAnimationFromHsl",
    ()=>getHslAnimationFromHsl,
    "getHslFromAnimation",
    ()=>getHslFromAnimation,
    "getLinkColor",
    ()=>getLinkColor,
    "getLinkRandomColor",
    ()=>getLinkRandomColor,
    "getRandomRgbColor",
    ()=>getRandomRgbColor,
    "getStyleFromHsl",
    ()=>getStyleFromHsl,
    "getStyleFromRgb",
    ()=>getStyleFromRgb,
    "hslToRgb",
    ()=>hslToRgb,
    "hslaToRgba",
    ()=>hslaToRgba,
    "rangeColorToHsl",
    ()=>rangeColorToHsl,
    "rangeColorToRgb",
    ()=>rangeColorToRgb,
    "rgbToHsl",
    ()=>rgbToHsl,
    "stringToAlpha",
    ()=>stringToAlpha,
    "stringToRgb",
    ()=>stringToRgb
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/tsparticles-engine/esm/Utils/NumberUtils.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/tsparticles-engine/esm/Utils/Utils.js [app-ssr] (ecmascript)");
;
;
const randomColorValue = "random", midColorValue = "mid", colorManagers = new Map();
function addColorManager(manager) {
    colorManagers.set(manager.key, manager);
}
function hue2rgb(p, q, t) {
    if (t < 0) {
        t += 1;
    }
    if (t > 1) {
        t -= 1;
    }
    if (t < 1 / 6) {
        return p + (q - p) * 6 * t;
    }
    if (t < 1 / 2) {
        return q;
    }
    if (t < 2 / 3) {
        return p + (q - p) * (2 / 3 - t) * 6;
    }
    return p;
}
function stringToRgba(input) {
    for (const [, manager] of colorManagers){
        if (input.startsWith(manager.stringPrefix)) {
            return manager.parseString(input);
        }
    }
    const shorthandRegex = /^#?([a-f\d])([a-f\d])([a-f\d])([a-f\d])?$/i, hexFixed = input.replace(shorthandRegex, (_, r, g, b, a)=>{
        return r + r + g + g + b + b + (a !== undefined ? a + a : "");
    }), regex = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})?$/i, result = regex.exec(hexFixed);
    return result ? {
        a: result[4] !== undefined ? parseInt(result[4], 16) / 0xff : 1,
        b: parseInt(result[3], 16),
        g: parseInt(result[2], 16),
        r: parseInt(result[1], 16)
    } : undefined;
}
function rangeColorToRgb(input, index, useIndex = true) {
    if (!input) {
        return;
    }
    const color = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isString"])(input) ? {
        value: input
    } : input;
    if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isString"])(color.value)) {
        return colorToRgb(color.value, index, useIndex);
    }
    if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isArray"])(color.value)) {
        return rangeColorToRgb({
            value: (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["itemFromArray"])(color.value, index, useIndex)
        });
    }
    for (const [, manager] of colorManagers){
        const res = manager.handleRangeColor(color);
        if (res) {
            return res;
        }
    }
}
function colorToRgb(input, index, useIndex = true) {
    if (!input) {
        return;
    }
    const color = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isString"])(input) ? {
        value: input
    } : input;
    if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isString"])(color.value)) {
        return color.value === randomColorValue ? getRandomRgbColor() : stringToRgb(color.value);
    }
    if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isArray"])(color.value)) {
        return colorToRgb({
            value: (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["itemFromArray"])(color.value, index, useIndex)
        });
    }
    for (const [, manager] of colorManagers){
        const res = manager.handleColor(color);
        if (res) {
            return res;
        }
    }
}
function colorToHsl(color, index, useIndex = true) {
    const rgb = colorToRgb(color, index, useIndex);
    return rgb ? rgbToHsl(rgb) : undefined;
}
function rangeColorToHsl(color, index, useIndex = true) {
    const rgb = rangeColorToRgb(color, index, useIndex);
    return rgb ? rgbToHsl(rgb) : undefined;
}
function rgbToHsl(color) {
    const r1 = color.r / 255, g1 = color.g / 255, b1 = color.b / 255, max = Math.max(r1, g1, b1), min = Math.min(r1, g1, b1), res = {
        h: 0,
        l: (max + min) / 2,
        s: 0
    };
    if (max !== min) {
        res.s = res.l < 0.5 ? (max - min) / (max + min) : (max - min) / (2.0 - max - min);
        res.h = r1 === max ? (g1 - b1) / (max - min) : res.h = g1 === max ? 2.0 + (b1 - r1) / (max - min) : 4.0 + (r1 - g1) / (max - min);
    }
    res.l *= 100;
    res.s *= 100;
    res.h *= 60;
    if (res.h < 0) {
        res.h += 360;
    }
    if (res.h >= 360) {
        res.h -= 360;
    }
    return res;
}
function stringToAlpha(input) {
    return stringToRgba(input)?.a;
}
function stringToRgb(input) {
    return stringToRgba(input);
}
function hslToRgb(hsl) {
    const result = {
        b: 0,
        g: 0,
        r: 0
    }, hslPercent = {
        h: hsl.h / 360,
        l: hsl.l / 100,
        s: hsl.s / 100
    };
    if (!hslPercent.s) {
        result.r = result.g = result.b = hslPercent.l;
    } else {
        const q = hslPercent.l < 0.5 ? hslPercent.l * (1 + hslPercent.s) : hslPercent.l + hslPercent.s - hslPercent.l * hslPercent.s, p = 2 * hslPercent.l - q;
        result.r = hue2rgb(p, q, hslPercent.h + 1 / 3);
        result.g = hue2rgb(p, q, hslPercent.h);
        result.b = hue2rgb(p, q, hslPercent.h - 1 / 3);
    }
    result.r = Math.floor(result.r * 255);
    result.g = Math.floor(result.g * 255);
    result.b = Math.floor(result.b * 255);
    return result;
}
function hslaToRgba(hsla) {
    const rgbResult = hslToRgb(hsla);
    return {
        a: hsla.a,
        b: rgbResult.b,
        g: rgbResult.g,
        r: rgbResult.r
    };
}
function getRandomRgbColor(min) {
    const fixedMin = min ?? 0;
    return {
        b: Math.floor((0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["randomInRange"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["setRangeValue"])(fixedMin, 256))),
        g: Math.floor((0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["randomInRange"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["setRangeValue"])(fixedMin, 256))),
        r: Math.floor((0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["randomInRange"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["setRangeValue"])(fixedMin, 256)))
    };
}
function getStyleFromRgb(color, opacity) {
    return `rgba(${color.r}, ${color.g}, ${color.b}, ${opacity ?? 1})`;
}
function getStyleFromHsl(color, opacity) {
    return `hsla(${color.h}, ${color.s}%, ${color.l}%, ${opacity ?? 1})`;
}
function colorMix(color1, color2, size1, size2) {
    let rgb1 = color1, rgb2 = color2;
    if (rgb1.r === undefined) {
        rgb1 = hslToRgb(color1);
    }
    if (rgb2.r === undefined) {
        rgb2 = hslToRgb(color2);
    }
    return {
        b: (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["mix"])(rgb1.b, rgb2.b, size1, size2),
        g: (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["mix"])(rgb1.g, rgb2.g, size1, size2),
        r: (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["mix"])(rgb1.r, rgb2.r, size1, size2)
    };
}
function getLinkColor(p1, p2, linkColor) {
    if (linkColor === randomColorValue) {
        return getRandomRgbColor();
    } else if (linkColor === midColorValue) {
        const sourceColor = p1.getFillColor() ?? p1.getStrokeColor(), destColor = p2?.getFillColor() ?? p2?.getStrokeColor();
        if (sourceColor && destColor && p2) {
            return colorMix(sourceColor, destColor, p1.getRadius(), p2.getRadius());
        } else {
            const hslColor = sourceColor ?? destColor;
            if (hslColor) {
                return hslToRgb(hslColor);
            }
        }
    } else {
        return linkColor;
    }
}
function getLinkRandomColor(optColor, blink, consent) {
    const color = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isString"])(optColor) ? optColor : optColor.value;
    if (color === randomColorValue) {
        if (consent) {
            return rangeColorToRgb({
                value: color
            });
        }
        if (blink) {
            return randomColorValue;
        }
        return midColorValue;
    } else if (color === midColorValue) {
        return midColorValue;
    } else {
        return rangeColorToRgb({
            value: color
        });
    }
}
function getHslFromAnimation(animation) {
    return animation !== undefined ? {
        h: animation.h.value,
        s: animation.s.value,
        l: animation.l.value
    } : undefined;
}
function getHslAnimationFromHsl(hsl, animationOptions, reduceFactor) {
    const resColor = {
        h: {
            enable: false,
            value: hsl.h
        },
        s: {
            enable: false,
            value: hsl.s
        },
        l: {
            enable: false,
            value: hsl.l
        }
    };
    if (animationOptions) {
        setColorAnimation(resColor.h, animationOptions.h, reduceFactor);
        setColorAnimation(resColor.s, animationOptions.s, reduceFactor);
        setColorAnimation(resColor.l, animationOptions.l, reduceFactor);
    }
    return resColor;
}
function setColorAnimation(colorValue, colorAnimation, reduceFactor) {
    colorValue.enable = colorAnimation.enable;
    if (colorValue.enable) {
        colorValue.velocity = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getRangeValue"])(colorAnimation.speed) / 100 * reduceFactor;
        colorValue.decay = 1 - (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getRangeValue"])(colorAnimation.decay);
        colorValue.status = "increasing";
        colorValue.loops = 0;
        colorValue.maxLoops = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getRangeValue"])(colorAnimation.count);
        colorValue.time = 0;
        colorValue.delayTime = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getRangeValue"])(colorAnimation.delay) * 1000;
        if (!colorAnimation.sync) {
            colorValue.velocity *= (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getRandom"])();
            colorValue.value *= (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getRandom"])();
        }
        colorValue.initialValue = colorValue.value;
    } else {
        colorValue.velocity = 0;
    }
}
}),
"[project]/theitern/node_modules/tsparticles-engine/esm/Utils/CanvasUtils.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "alterHsl",
    ()=>alterHsl,
    "clear",
    ()=>clear,
    "drawLine",
    ()=>drawLine,
    "drawParticle",
    ()=>drawParticle,
    "drawParticlePlugin",
    ()=>drawParticlePlugin,
    "drawPlugin",
    ()=>drawPlugin,
    "drawShape",
    ()=>drawShape,
    "drawShapeAfterEffect",
    ()=>drawShapeAfterEffect,
    "drawTriangle",
    ()=>drawTriangle,
    "paintBase",
    ()=>paintBase,
    "paintImage",
    ()=>paintImage
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$ColorUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/tsparticles-engine/esm/Utils/ColorUtils.js [app-ssr] (ecmascript)");
;
function drawLine(context, begin, end) {
    context.beginPath();
    context.moveTo(begin.x, begin.y);
    context.lineTo(end.x, end.y);
    context.closePath();
}
function drawTriangle(context, p1, p2, p3) {
    context.beginPath();
    context.moveTo(p1.x, p1.y);
    context.lineTo(p2.x, p2.y);
    context.lineTo(p3.x, p3.y);
    context.closePath();
}
function paintBase(context, dimension, baseColor) {
    context.fillStyle = baseColor ?? "rgba(0,0,0,0)";
    context.fillRect(0, 0, dimension.width, dimension.height);
}
function paintImage(context, dimension, image, opacity) {
    if (!image) {
        return;
    }
    context.globalAlpha = opacity;
    context.drawImage(image, 0, 0, dimension.width, dimension.height);
    context.globalAlpha = 1;
}
function clear(context, dimension) {
    context.clearRect(0, 0, dimension.width, dimension.height);
}
function drawParticle(data) {
    const { container, context, particle, delta, colorStyles, backgroundMask, composite, radius, opacity, shadow, transform } = data;
    const pos = particle.getPosition(), angle = particle.rotation + (particle.pathRotation ? particle.velocity.angle : 0), rotateData = {
        sin: Math.sin(angle),
        cos: Math.cos(angle)
    }, transformData = {
        a: rotateData.cos * (transform.a ?? 1),
        b: rotateData.sin * (transform.b ?? 1),
        c: -rotateData.sin * (transform.c ?? 1),
        d: rotateData.cos * (transform.d ?? 1)
    };
    context.setTransform(transformData.a, transformData.b, transformData.c, transformData.d, pos.x, pos.y);
    context.beginPath();
    if (backgroundMask) {
        context.globalCompositeOperation = composite;
    }
    const shadowColor = particle.shadowColor;
    if (shadow.enable && shadowColor) {
        context.shadowBlur = shadow.blur;
        context.shadowColor = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$ColorUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getStyleFromRgb"])(shadowColor);
        context.shadowOffsetX = shadow.offset.x;
        context.shadowOffsetY = shadow.offset.y;
    }
    if (colorStyles.fill) {
        context.fillStyle = colorStyles.fill;
    }
    const strokeWidth = particle.strokeWidth ?? 0;
    context.lineWidth = strokeWidth;
    if (colorStyles.stroke) {
        context.strokeStyle = colorStyles.stroke;
    }
    drawShape(container, context, particle, radius, opacity, delta);
    if (strokeWidth > 0) {
        context.stroke();
    }
    if (particle.close) {
        context.closePath();
    }
    if (particle.fill) {
        context.fill();
    }
    drawShapeAfterEffect(container, context, particle, radius, opacity, delta);
    context.globalCompositeOperation = "source-over";
    context.setTransform(1, 0, 0, 1, 0, 0);
}
function drawShape(container, context, particle, radius, opacity, delta) {
    if (!particle.shape) {
        return;
    }
    const drawer = container.drawers.get(particle.shape);
    if (!drawer) {
        return;
    }
    drawer.draw(context, particle, radius, opacity, delta, container.retina.pixelRatio);
}
function drawShapeAfterEffect(container, context, particle, radius, opacity, delta) {
    if (!particle.shape) {
        return;
    }
    const drawer = container.drawers.get(particle.shape);
    if (!drawer || !drawer.afterEffect) {
        return;
    }
    drawer.afterEffect(context, particle, radius, opacity, delta, container.retina.pixelRatio);
}
function drawPlugin(context, plugin, delta) {
    if (!plugin.draw) {
        return;
    }
    plugin.draw(context, delta);
}
function drawParticlePlugin(context, plugin, particle, delta) {
    if (!plugin.drawParticle) {
        return;
    }
    plugin.drawParticle(context, particle, delta);
}
function alterHsl(color, type, value) {
    return {
        h: color.h,
        s: color.s,
        l: color.l + (type === "darken" ? -1 : 1) * value
    };
}
}),
"[project]/theitern/node_modules/tsparticles-engine/esm/Core/Canvas.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Canvas",
    ()=>Canvas
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$CanvasUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/tsparticles-engine/esm/Utils/CanvasUtils.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/tsparticles-engine/esm/Utils/Utils.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$ColorUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/tsparticles-engine/esm/Utils/ColorUtils.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/tsparticles-engine/esm/Core/Utils/Constants.js [app-ssr] (ecmascript)");
;
;
;
;
function setTransformValue(factor, newFactor, key) {
    const newValue = newFactor[key];
    if (newValue !== undefined) {
        factor[key] = (factor[key] ?? 1) * newValue;
    }
}
class Canvas {
    constructor(container){
        this.container = container;
        this._applyPostDrawUpdaters = (particle)=>{
            for (const updater of this._postDrawUpdaters){
                updater.afterDraw && updater.afterDraw(particle);
            }
        };
        this._applyPreDrawUpdaters = (ctx, particle, radius, zOpacity, colorStyles, transform)=>{
            for (const updater of this._preDrawUpdaters){
                if (updater.getColorStyles) {
                    const { fill, stroke } = updater.getColorStyles(particle, ctx, radius, zOpacity);
                    if (fill) {
                        colorStyles.fill = fill;
                    }
                    if (stroke) {
                        colorStyles.stroke = stroke;
                    }
                }
                if (updater.getTransformValues) {
                    const updaterTransform = updater.getTransformValues(particle);
                    for(const key in updaterTransform){
                        setTransformValue(transform, updaterTransform, key);
                    }
                }
                updater.beforeDraw && updater.beforeDraw(particle);
            }
        };
        this._applyResizePlugins = ()=>{
            for (const plugin of this._resizePlugins){
                plugin.resize && plugin.resize();
            }
        };
        this._getPluginParticleColors = (particle)=>{
            let fColor, sColor;
            for (const plugin of this._colorPlugins){
                if (!fColor && plugin.particleFillColor) {
                    fColor = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$ColorUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["rangeColorToHsl"])(plugin.particleFillColor(particle));
                }
                if (!sColor && plugin.particleStrokeColor) {
                    sColor = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$ColorUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["rangeColorToHsl"])(plugin.particleStrokeColor(particle));
                }
                if (fColor && sColor) {
                    break;
                }
            }
            return [
                fColor,
                sColor
            ];
        };
        this._initCover = ()=>{
            const options = this.container.actualOptions, cover = options.backgroundMask.cover, color = cover.color, coverRgb = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$ColorUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["rangeColorToRgb"])(color);
            if (coverRgb) {
                const coverColor = {
                    ...coverRgb,
                    a: cover.opacity
                };
                this._coverColorStyle = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$ColorUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getStyleFromRgb"])(coverColor, coverColor.a);
            }
        };
        this._initStyle = ()=>{
            const element = this.element, options = this.container.actualOptions;
            if (!element) {
                return;
            }
            if (this._fullScreen) {
                this._originalStyle = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["deepExtend"])({}, element.style);
                this._setFullScreenStyle();
            } else {
                this._resetOriginalStyle();
            }
            for(const key in options.style){
                if (!key || !options.style) {
                    continue;
                }
                const value = options.style[key];
                if (!value) {
                    continue;
                }
                element.style.setProperty(key, value, "important");
            }
        };
        this._initTrail = async ()=>{
            const options = this.container.actualOptions, trail = options.particles.move.trail, trailFill = trail.fill;
            if (!trail.enable) {
                return;
            }
            if (trailFill.color) {
                const fillColor = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$ColorUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["rangeColorToRgb"])(trailFill.color);
                if (!fillColor) {
                    return;
                }
                const trail = options.particles.move.trail;
                this._trailFill = {
                    color: {
                        ...fillColor
                    },
                    opacity: 1 / trail.length
                };
            } else {
                await new Promise((resolve, reject)=>{
                    if (!trailFill.image) {
                        return;
                    }
                    const img = document.createElement("img");
                    img.addEventListener("load", ()=>{
                        this._trailFill = {
                            image: img,
                            opacity: 1 / trail.length
                        };
                        resolve();
                    });
                    img.addEventListener("error", (evt)=>{
                        reject(evt.error);
                    });
                    img.src = trailFill.image;
                });
            }
        };
        this._paintBase = (baseColor)=>{
            this.draw((ctx)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$CanvasUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["paintBase"])(ctx, this.size, baseColor));
        };
        this._paintImage = (image, opacity)=>{
            this.draw((ctx)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$CanvasUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["paintImage"])(ctx, this.size, image, opacity));
        };
        this._repairStyle = ()=>{
            const element = this.element;
            if (!element) {
                return;
            }
            this._safeMutationObserver((observer)=>observer.disconnect());
            this._initStyle();
            this.initBackground();
            this._safeMutationObserver((observer)=>observer.observe(element, {
                    attributes: true
                }));
        };
        this._resetOriginalStyle = ()=>{
            const element = this.element, originalStyle = this._originalStyle;
            if (!(element && originalStyle)) {
                return;
            }
            const style = element.style;
            style.position = originalStyle.position;
            style.zIndex = originalStyle.zIndex;
            style.top = originalStyle.top;
            style.left = originalStyle.left;
            style.width = originalStyle.width;
            style.height = originalStyle.height;
        };
        this._safeMutationObserver = (callback)=>{
            if (!this._mutationObserver) {
                return;
            }
            callback(this._mutationObserver);
        };
        this._setFullScreenStyle = ()=>{
            const element = this.element;
            if (!element) {
                return;
            }
            const priority = "important", style = element.style;
            style.setProperty("position", "fixed", priority);
            style.setProperty("z-index", this.container.actualOptions.fullScreen.zIndex.toString(10), priority);
            style.setProperty("top", "0", priority);
            style.setProperty("left", "0", priority);
            style.setProperty("width", "100%", priority);
            style.setProperty("height", "100%", priority);
        };
        this.size = {
            height: 0,
            width: 0
        };
        this._context = null;
        this._generated = false;
        this._preDrawUpdaters = [];
        this._postDrawUpdaters = [];
        this._resizePlugins = [];
        this._colorPlugins = [];
    }
    get _fullScreen() {
        return this.container.actualOptions.fullScreen.enable;
    }
    clear() {
        const options = this.container.actualOptions, trail = options.particles.move.trail, trailFill = this._trailFill;
        if (options.backgroundMask.enable) {
            this.paint();
        } else if (trail.enable && trail.length > 0 && trailFill) {
            if (trailFill.color) {
                this._paintBase((0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$ColorUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getStyleFromRgb"])(trailFill.color, trailFill.opacity));
            } else if (trailFill.image) {
                this._paintImage(trailFill.image, trailFill.opacity);
            }
        } else {
            this.draw((ctx)=>{
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$CanvasUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["clear"])(ctx, this.size);
            });
        }
    }
    destroy() {
        this.stop();
        if (this._generated) {
            const element = this.element;
            element && element.remove();
        } else {
            this._resetOriginalStyle();
        }
        this._preDrawUpdaters = [];
        this._postDrawUpdaters = [];
        this._resizePlugins = [];
        this._colorPlugins = [];
    }
    draw(cb) {
        const ctx = this._context;
        if (!ctx) {
            return;
        }
        return cb(ctx);
    }
    drawParticle(particle, delta) {
        if (particle.spawning || particle.destroyed) {
            return;
        }
        const radius = particle.getRadius();
        if (radius <= 0) {
            return;
        }
        const pfColor = particle.getFillColor(), psColor = particle.getStrokeColor() ?? pfColor;
        let [fColor, sColor] = this._getPluginParticleColors(particle);
        if (!fColor) {
            fColor = pfColor;
        }
        if (!sColor) {
            sColor = psColor;
        }
        if (!fColor && !sColor) {
            return;
        }
        this.draw((ctx)=>{
            const container = this.container, options = container.actualOptions, zIndexOptions = particle.options.zIndex, zOpacityFactor = (1 - particle.zIndexFactor) ** zIndexOptions.opacityRate, opacity = particle.bubble.opacity ?? particle.opacity?.value ?? 1, strokeOpacity = particle.strokeOpacity ?? opacity, zOpacity = opacity * zOpacityFactor, zStrokeOpacity = strokeOpacity * zOpacityFactor, transform = {}, colorStyles = {
                fill: fColor ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$ColorUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getStyleFromHsl"])(fColor, zOpacity) : undefined
            };
            colorStyles.stroke = sColor ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$ColorUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getStyleFromHsl"])(sColor, zStrokeOpacity) : colorStyles.fill;
            this._applyPreDrawUpdaters(ctx, particle, radius, zOpacity, colorStyles, transform);
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$CanvasUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["drawParticle"])({
                container,
                context: ctx,
                particle,
                delta,
                colorStyles,
                backgroundMask: options.backgroundMask.enable,
                composite: options.backgroundMask.composite,
                radius: radius * (1 - particle.zIndexFactor) ** zIndexOptions.sizeRate,
                opacity: zOpacity,
                shadow: particle.options.shadow,
                transform
            });
            this._applyPostDrawUpdaters(particle);
        });
    }
    drawParticlePlugin(plugin, particle, delta) {
        this.draw((ctx)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$CanvasUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["drawParticlePlugin"])(ctx, plugin, particle, delta));
    }
    drawPlugin(plugin, delta) {
        this.draw((ctx)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$CanvasUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["drawPlugin"])(ctx, plugin, delta));
    }
    async init() {
        this._safeMutationObserver((obs)=>obs.disconnect());
        this._mutationObserver = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["safeMutationObserver"])((records)=>{
            for (const record of records){
                if (record.type === "attributes" && record.attributeName === "style") {
                    this._repairStyle();
                }
            }
        });
        this.resize();
        this._initStyle();
        this._initCover();
        try {
            await this._initTrail();
        } catch (e) {
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getLogger"])().error(e);
        }
        this.initBackground();
        this._safeMutationObserver((obs)=>{
            if (!this.element) {
                return;
            }
            obs.observe(this.element, {
                attributes: true
            });
        });
        this.initUpdaters();
        this.initPlugins();
        this.paint();
    }
    initBackground() {
        const options = this.container.actualOptions, background = options.background, element = this.element;
        if (!element) {
            return;
        }
        const elementStyle = element.style;
        if (!elementStyle) {
            return;
        }
        if (background.color) {
            const color = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$ColorUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["rangeColorToRgb"])(background.color);
            elementStyle.backgroundColor = color ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$ColorUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getStyleFromRgb"])(color, background.opacity) : "";
        } else {
            elementStyle.backgroundColor = "";
        }
        elementStyle.backgroundImage = background.image || "";
        elementStyle.backgroundPosition = background.position || "";
        elementStyle.backgroundRepeat = background.repeat || "";
        elementStyle.backgroundSize = background.size || "";
    }
    initPlugins() {
        this._resizePlugins = [];
        for (const [, plugin] of this.container.plugins){
            if (plugin.resize) {
                this._resizePlugins.push(plugin);
            }
            if (plugin.particleFillColor || plugin.particleStrokeColor) {
                this._colorPlugins.push(plugin);
            }
        }
    }
    initUpdaters() {
        this._preDrawUpdaters = [];
        this._postDrawUpdaters = [];
        for (const updater of this.container.particles.updaters){
            if (updater.afterDraw) {
                this._postDrawUpdaters.push(updater);
            }
            if (updater.getColorStyles || updater.getTransformValues || updater.beforeDraw) {
                this._preDrawUpdaters.push(updater);
            }
        }
    }
    loadCanvas(canvas) {
        if (this._generated && this.element) {
            this.element.remove();
        }
        this._generated = canvas.dataset && __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["generatedAttribute"] in canvas.dataset ? canvas.dataset[__TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["generatedAttribute"]] === "true" : this._generated;
        this.element = canvas;
        this.element.ariaHidden = "true";
        this._originalStyle = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["deepExtend"])({}, this.element.style);
        this.size.height = canvas.offsetHeight;
        this.size.width = canvas.offsetWidth;
        this._context = this.element.getContext("2d");
        this._safeMutationObserver((obs)=>{
            if (!this.element) {
                return;
            }
            obs.observe(this.element, {
                attributes: true
            });
        });
        this.container.retina.init();
        this.initBackground();
    }
    paint() {
        const options = this.container.actualOptions;
        this.draw((ctx)=>{
            if (options.backgroundMask.enable && options.backgroundMask.cover) {
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$CanvasUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["clear"])(ctx, this.size);
                this._paintBase(this._coverColorStyle);
            } else {
                this._paintBase();
            }
        });
    }
    resize() {
        if (!this.element) {
            return false;
        }
        const container = this.container, pxRatio = container.retina.pixelRatio, size = container.canvas.size, newSize = {
            width: this.element.offsetWidth * pxRatio,
            height: this.element.offsetHeight * pxRatio
        };
        if (newSize.height === size.height && newSize.width === size.width && newSize.height === this.element.height && newSize.width === this.element.width) {
            return false;
        }
        const oldSize = {
            ...size
        };
        this.element.width = size.width = this.element.offsetWidth * pxRatio;
        this.element.height = size.height = this.element.offsetHeight * pxRatio;
        if (this.container.started) {
            this.resizeFactor = {
                width: size.width / oldSize.width,
                height: size.height / oldSize.height
            };
        }
        return true;
    }
    stop() {
        this._safeMutationObserver((obs)=>obs.disconnect());
        this._mutationObserver = undefined;
        this.draw((ctx)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$CanvasUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["clear"])(ctx, this.size));
    }
    async windowResize() {
        if (!this.element || !this.resize()) {
            return;
        }
        const container = this.container, needsRefresh = container.updateActualOptions();
        container.particles.setDensity();
        this._applyResizePlugins();
        if (needsRefresh) {
            await container.refresh();
        }
    }
}
}),
"[project]/theitern/node_modules/tsparticles-engine/esm/Core/Utils/EventListeners.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "EventListeners",
    ()=>EventListeners
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/tsparticles-engine/esm/Utils/Utils.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/tsparticles-engine/esm/Core/Utils/Constants.js [app-ssr] (ecmascript)");
;
;
function manageListener(element, event, handler, add, options) {
    if (add) {
        let addOptions = {
            passive: true
        };
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isBoolean"])(options)) {
            addOptions.capture = options;
        } else if (options !== undefined) {
            addOptions = options;
        }
        element.addEventListener(event, handler, addOptions);
    } else {
        const removeOptions = options;
        element.removeEventListener(event, handler, removeOptions);
    }
}
class EventListeners {
    constructor(container){
        this.container = container;
        this._doMouseTouchClick = (e)=>{
            const container = this.container, options = container.actualOptions;
            if (this._canPush) {
                const mouseInteractivity = container.interactivity.mouse, mousePos = mouseInteractivity.position;
                if (!mousePos) {
                    return;
                }
                mouseInteractivity.clickPosition = {
                    ...mousePos
                };
                mouseInteractivity.clickTime = new Date().getTime();
                const onClick = options.interactivity.events.onClick;
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["executeOnSingleOrMultiple"])(onClick.mode, (mode)=>this.container.handleClickMode(mode));
            }
            if (e.type === "touchend") {
                setTimeout(()=>this._mouseTouchFinish(), 500);
            }
        };
        this._handleThemeChange = (e)=>{
            const mediaEvent = e, container = this.container, options = container.options, defaultThemes = options.defaultThemes, themeName = mediaEvent.matches ? defaultThemes.dark : defaultThemes.light, theme = options.themes.find((theme)=>theme.name === themeName);
            if (theme && theme.default.auto) {
                container.loadTheme(themeName);
            }
        };
        this._handleVisibilityChange = ()=>{
            const container = this.container, options = container.actualOptions;
            this._mouseTouchFinish();
            if (!options.pauseOnBlur) {
                return;
            }
            if (document && document.hidden) {
                container.pageHidden = true;
                container.pause();
            } else {
                container.pageHidden = false;
                if (container.getAnimationStatus()) {
                    container.play(true);
                } else {
                    container.draw(true);
                }
            }
        };
        this._handleWindowResize = async ()=>{
            if (this._resizeTimeout) {
                clearTimeout(this._resizeTimeout);
                delete this._resizeTimeout;
            }
            this._resizeTimeout = setTimeout(async ()=>{
                const canvas = this.container.canvas;
                canvas && await canvas.windowResize();
            }, this.container.actualOptions.interactivity.events.resize.delay * 1000);
        };
        this._manageInteractivityListeners = (mouseLeaveTmpEvent, add)=>{
            const handlers = this._handlers, container = this.container, options = container.actualOptions;
            const interactivityEl = container.interactivity.element;
            if (!interactivityEl) {
                return;
            }
            const html = interactivityEl, canvasEl = container.canvas.element;
            if (canvasEl) {
                canvasEl.style.pointerEvents = html === canvasEl ? "initial" : "none";
            }
            if (!(options.interactivity.events.onHover.enable || options.interactivity.events.onClick.enable)) {
                return;
            }
            manageListener(interactivityEl, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["mouseMoveEvent"], handlers.mouseMove, add);
            manageListener(interactivityEl, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["touchStartEvent"], handlers.touchStart, add);
            manageListener(interactivityEl, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["touchMoveEvent"], handlers.touchMove, add);
            if (!options.interactivity.events.onClick.enable) {
                manageListener(interactivityEl, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["touchEndEvent"], handlers.touchEnd, add);
            } else {
                manageListener(interactivityEl, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["touchEndEvent"], handlers.touchEndClick, add);
                manageListener(interactivityEl, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["mouseUpEvent"], handlers.mouseUp, add);
                manageListener(interactivityEl, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["mouseDownEvent"], handlers.mouseDown, add);
            }
            manageListener(interactivityEl, mouseLeaveTmpEvent, handlers.mouseLeave, add);
            manageListener(interactivityEl, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["touchCancelEvent"], handlers.touchCancel, add);
        };
        this._manageListeners = (add)=>{
            const handlers = this._handlers, container = this.container, options = container.actualOptions, detectType = options.interactivity.detectsOn, canvasEl = container.canvas.element;
            let mouseLeaveTmpEvent = __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["mouseLeaveEvent"];
            if (detectType === "window") {
                container.interactivity.element = window;
                mouseLeaveTmpEvent = __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["mouseOutEvent"];
            } else if (detectType === "parent" && canvasEl) {
                container.interactivity.element = canvasEl.parentElement ?? canvasEl.parentNode;
            } else {
                container.interactivity.element = canvasEl;
            }
            this._manageMediaMatch(add);
            this._manageResize(add);
            this._manageInteractivityListeners(mouseLeaveTmpEvent, add);
            if (document) {
                manageListener(document, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["visibilityChangeEvent"], handlers.visibilityChange, add, false);
            }
        };
        this._manageMediaMatch = (add)=>{
            const handlers = this._handlers, mediaMatch = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["safeMatchMedia"])("(prefers-color-scheme: dark)");
            if (!mediaMatch) {
                return;
            }
            if (mediaMatch.addEventListener !== undefined) {
                manageListener(mediaMatch, "change", handlers.themeChange, add);
                return;
            }
            if (mediaMatch.addListener === undefined) {
                return;
            }
            if (add) {
                mediaMatch.addListener(handlers.oldThemeChange);
            } else {
                mediaMatch.removeListener(handlers.oldThemeChange);
            }
        };
        this._manageResize = (add)=>{
            const handlers = this._handlers, container = this.container, options = container.actualOptions;
            if (!options.interactivity.events.resize) {
                return;
            }
            if (typeof ResizeObserver === "undefined") {
                manageListener(window, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["resizeEvent"], handlers.resize, add);
                return;
            }
            const canvasEl = container.canvas.element;
            if (this._resizeObserver && !add) {
                if (canvasEl) {
                    this._resizeObserver.unobserve(canvasEl);
                }
                this._resizeObserver.disconnect();
                delete this._resizeObserver;
            } else if (!this._resizeObserver && add && canvasEl) {
                this._resizeObserver = new ResizeObserver(async (entries)=>{
                    const entry = entries.find((e)=>e.target === canvasEl);
                    if (!entry) {
                        return;
                    }
                    await this._handleWindowResize();
                });
                this._resizeObserver.observe(canvasEl);
            }
        };
        this._mouseDown = ()=>{
            const { interactivity } = this.container;
            if (!interactivity) {
                return;
            }
            const { mouse } = interactivity;
            mouse.clicking = true;
            mouse.downPosition = mouse.position;
        };
        this._mouseTouchClick = (e)=>{
            const container = this.container, options = container.actualOptions, { mouse } = container.interactivity;
            mouse.inside = true;
            let handled = false;
            const mousePosition = mouse.position;
            if (!mousePosition || !options.interactivity.events.onClick.enable) {
                return;
            }
            for (const [, plugin] of container.plugins){
                if (!plugin.clickPositionValid) {
                    continue;
                }
                handled = plugin.clickPositionValid(mousePosition);
                if (handled) {
                    break;
                }
            }
            if (!handled) {
                this._doMouseTouchClick(e);
            }
            mouse.clicking = false;
        };
        this._mouseTouchFinish = ()=>{
            const interactivity = this.container.interactivity;
            if (!interactivity) {
                return;
            }
            const mouse = interactivity.mouse;
            delete mouse.position;
            delete mouse.clickPosition;
            delete mouse.downPosition;
            interactivity.status = __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["mouseLeaveEvent"];
            mouse.inside = false;
            mouse.clicking = false;
        };
        this._mouseTouchMove = (e)=>{
            const container = this.container, options = container.actualOptions, interactivity = container.interactivity, canvasEl = container.canvas.element;
            if (!interactivity || !interactivity.element) {
                return;
            }
            interactivity.mouse.inside = true;
            let pos;
            if (e.type.startsWith("pointer")) {
                this._canPush = true;
                const mouseEvent = e;
                if (interactivity.element === window) {
                    if (canvasEl) {
                        const clientRect = canvasEl.getBoundingClientRect();
                        pos = {
                            x: mouseEvent.clientX - clientRect.left,
                            y: mouseEvent.clientY - clientRect.top
                        };
                    }
                } else if (options.interactivity.detectsOn === "parent") {
                    const source = mouseEvent.target, target = mouseEvent.currentTarget;
                    if (source && target && canvasEl) {
                        const sourceRect = source.getBoundingClientRect(), targetRect = target.getBoundingClientRect(), canvasRect = canvasEl.getBoundingClientRect();
                        pos = {
                            x: mouseEvent.offsetX + 2 * sourceRect.left - (targetRect.left + canvasRect.left),
                            y: mouseEvent.offsetY + 2 * sourceRect.top - (targetRect.top + canvasRect.top)
                        };
                    } else {
                        pos = {
                            x: mouseEvent.offsetX ?? mouseEvent.clientX,
                            y: mouseEvent.offsetY ?? mouseEvent.clientY
                        };
                    }
                } else if (mouseEvent.target === canvasEl) {
                    pos = {
                        x: mouseEvent.offsetX ?? mouseEvent.clientX,
                        y: mouseEvent.offsetY ?? mouseEvent.clientY
                    };
                }
            } else {
                this._canPush = e.type !== "touchmove";
                if (canvasEl) {
                    const touchEvent = e, lastTouch = touchEvent.touches[touchEvent.touches.length - 1], canvasRect = canvasEl.getBoundingClientRect();
                    pos = {
                        x: lastTouch.clientX - (canvasRect.left ?? 0),
                        y: lastTouch.clientY - (canvasRect.top ?? 0)
                    };
                }
            }
            const pxRatio = container.retina.pixelRatio;
            if (pos) {
                pos.x *= pxRatio;
                pos.y *= pxRatio;
            }
            interactivity.mouse.position = pos;
            interactivity.status = __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["mouseMoveEvent"];
        };
        this._touchEnd = (e)=>{
            const evt = e, touches = Array.from(evt.changedTouches);
            for (const touch of touches){
                this._touches.delete(touch.identifier);
            }
            this._mouseTouchFinish();
        };
        this._touchEndClick = (e)=>{
            const evt = e, touches = Array.from(evt.changedTouches);
            for (const touch of touches){
                this._touches.delete(touch.identifier);
            }
            this._mouseTouchClick(e);
        };
        this._touchStart = (e)=>{
            const evt = e, touches = Array.from(evt.changedTouches);
            for (const touch of touches){
                this._touches.set(touch.identifier, performance.now());
            }
            this._mouseTouchMove(e);
        };
        this._canPush = true;
        this._touches = new Map();
        this._handlers = {
            mouseDown: ()=>this._mouseDown(),
            mouseLeave: ()=>this._mouseTouchFinish(),
            mouseMove: (e)=>this._mouseTouchMove(e),
            mouseUp: (e)=>this._mouseTouchClick(e),
            touchStart: (e)=>this._touchStart(e),
            touchMove: (e)=>this._mouseTouchMove(e),
            touchEnd: (e)=>this._touchEnd(e),
            touchCancel: (e)=>this._touchEnd(e),
            touchEndClick: (e)=>this._touchEndClick(e),
            visibilityChange: ()=>this._handleVisibilityChange(),
            themeChange: (e)=>this._handleThemeChange(e),
            oldThemeChange: (e)=>this._handleThemeChange(e),
            resize: ()=>{
                this._handleWindowResize();
            }
        };
    }
    addListeners() {
        this._manageListeners(true);
    }
    removeListeners() {
        this._manageListeners(false);
    }
}
}),
"[project]/theitern/node_modules/tsparticles-engine/esm/Options/Classes/OptionsColor.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "OptionsColor",
    ()=>OptionsColor
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/tsparticles-engine/esm/Utils/Utils.js [app-ssr] (ecmascript)");
;
class OptionsColor {
    constructor(){
        this.value = "";
    }
    static create(source, data) {
        const color = new OptionsColor();
        color.load(source);
        if (data !== undefined) {
            if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isString"])(data) || (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isArray"])(data)) {
                color.load({
                    value: data
                });
            } else {
                color.load(data);
            }
        }
        return color;
    }
    load(data) {
        if (data?.value === undefined) {
            return;
        }
        this.value = data.value;
    }
}
}),
"[project]/theitern/node_modules/tsparticles-engine/esm/Options/Classes/Background/Background.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Background",
    ()=>Background
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Options$2f$Classes$2f$OptionsColor$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/tsparticles-engine/esm/Options/Classes/OptionsColor.js [app-ssr] (ecmascript)");
;
class Background {
    constructor(){
        this.color = new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Options$2f$Classes$2f$OptionsColor$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["OptionsColor"]();
        this.color.value = "";
        this.image = "";
        this.position = "";
        this.repeat = "";
        this.size = "";
        this.opacity = 1;
    }
    load(data) {
        if (!data) {
            return;
        }
        if (data.color !== undefined) {
            this.color = __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Options$2f$Classes$2f$OptionsColor$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["OptionsColor"].create(this.color, data.color);
        }
        if (data.image !== undefined) {
            this.image = data.image;
        }
        if (data.position !== undefined) {
            this.position = data.position;
        }
        if (data.repeat !== undefined) {
            this.repeat = data.repeat;
        }
        if (data.size !== undefined) {
            this.size = data.size;
        }
        if (data.opacity !== undefined) {
            this.opacity = data.opacity;
        }
    }
}
}),
"[project]/theitern/node_modules/tsparticles-engine/esm/Options/Classes/BackgroundMask/BackgroundMaskCover.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "BackgroundMaskCover",
    ()=>BackgroundMaskCover
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Options$2f$Classes$2f$OptionsColor$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/tsparticles-engine/esm/Options/Classes/OptionsColor.js [app-ssr] (ecmascript)");
;
class BackgroundMaskCover {
    constructor(){
        this.color = new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Options$2f$Classes$2f$OptionsColor$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["OptionsColor"]();
        this.color.value = "#fff";
        this.opacity = 1;
    }
    load(data) {
        if (!data) {
            return;
        }
        if (data.color !== undefined) {
            this.color = __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Options$2f$Classes$2f$OptionsColor$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["OptionsColor"].create(this.color, data.color);
        }
        if (data.opacity !== undefined) {
            this.opacity = data.opacity;
        }
    }
}
}),
"[project]/theitern/node_modules/tsparticles-engine/esm/Options/Classes/BackgroundMask/BackgroundMask.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "BackgroundMask",
    ()=>BackgroundMask
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Options$2f$Classes$2f$BackgroundMask$2f$BackgroundMaskCover$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/tsparticles-engine/esm/Options/Classes/BackgroundMask/BackgroundMaskCover.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/tsparticles-engine/esm/Utils/Utils.js [app-ssr] (ecmascript)");
;
;
class BackgroundMask {
    constructor(){
        this.composite = "destination-out";
        this.cover = new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Options$2f$Classes$2f$BackgroundMask$2f$BackgroundMaskCover$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["BackgroundMaskCover"]();
        this.enable = false;
    }
    load(data) {
        if (!data) {
            return;
        }
        if (data.composite !== undefined) {
            this.composite = data.composite;
        }
        if (data.cover !== undefined) {
            const cover = data.cover;
            const color = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isString"])(data.cover) ? {
                color: data.cover
            } : data.cover;
            this.cover.load(cover.color !== undefined ? cover : {
                color: color
            });
        }
        if (data.enable !== undefined) {
            this.enable = data.enable;
        }
    }
}
}),
"[project]/theitern/node_modules/tsparticles-engine/esm/Options/Classes/FullScreen/FullScreen.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "FullScreen",
    ()=>FullScreen
]);
class FullScreen {
    constructor(){
        this.enable = true;
        this.zIndex = 0;
    }
    load(data) {
        if (!data) {
            return;
        }
        if (data.enable !== undefined) {
            this.enable = data.enable;
        }
        if (data.zIndex !== undefined) {
            this.zIndex = data.zIndex;
        }
    }
}
}),
"[project]/theitern/node_modules/tsparticles-engine/esm/Options/Classes/Interactivity/Events/ClickEvent.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ClickEvent",
    ()=>ClickEvent
]);
class ClickEvent {
    constructor(){
        this.enable = false;
        this.mode = [];
    }
    load(data) {
        if (!data) {
            return;
        }
        if (data.enable !== undefined) {
            this.enable = data.enable;
        }
        if (data.mode !== undefined) {
            this.mode = data.mode;
        }
    }
}
}),
"[project]/theitern/node_modules/tsparticles-engine/esm/Options/Classes/Interactivity/Events/DivEvent.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "DivEvent",
    ()=>DivEvent
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/tsparticles-engine/esm/Utils/Utils.js [app-ssr] (ecmascript)");
;
class DivEvent {
    constructor(){
        this.selectors = [];
        this.enable = false;
        this.mode = [];
        this.type = "circle";
    }
    get el() {
        return this.elementId;
    }
    set el(value) {
        this.elementId = value;
    }
    get elementId() {
        return this.ids;
    }
    set elementId(value) {
        this.ids = value;
    }
    get ids() {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["executeOnSingleOrMultiple"])(this.selectors, (t)=>t.replace("#", ""));
    }
    set ids(value) {
        this.selectors = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["executeOnSingleOrMultiple"])(value, (t)=>`#${t}`);
    }
    load(data) {
        if (!data) {
            return;
        }
        const ids = data.ids ?? data.elementId ?? data.el;
        if (ids !== undefined) {
            this.ids = ids;
        }
        if (data.selectors !== undefined) {
            this.selectors = data.selectors;
        }
        if (data.enable !== undefined) {
            this.enable = data.enable;
        }
        if (data.mode !== undefined) {
            this.mode = data.mode;
        }
        if (data.type !== undefined) {
            this.type = data.type;
        }
    }
}
}),
"[project]/theitern/node_modules/tsparticles-engine/esm/Options/Classes/Interactivity/Events/Parallax.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Parallax",
    ()=>Parallax
]);
class Parallax {
    constructor(){
        this.enable = false;
        this.force = 2;
        this.smooth = 10;
    }
    load(data) {
        if (!data) {
            return;
        }
        if (data.enable !== undefined) {
            this.enable = data.enable;
        }
        if (data.force !== undefined) {
            this.force = data.force;
        }
        if (data.smooth !== undefined) {
            this.smooth = data.smooth;
        }
    }
}
}),
"[project]/theitern/node_modules/tsparticles-engine/esm/Options/Classes/Interactivity/Events/HoverEvent.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "HoverEvent",
    ()=>HoverEvent
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Options$2f$Classes$2f$Interactivity$2f$Events$2f$Parallax$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/tsparticles-engine/esm/Options/Classes/Interactivity/Events/Parallax.js [app-ssr] (ecmascript)");
;
class HoverEvent {
    constructor(){
        this.enable = false;
        this.mode = [];
        this.parallax = new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Options$2f$Classes$2f$Interactivity$2f$Events$2f$Parallax$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Parallax"]();
    }
    load(data) {
        if (!data) {
            return;
        }
        if (data.enable !== undefined) {
            this.enable = data.enable;
        }
        if (data.mode !== undefined) {
            this.mode = data.mode;
        }
        this.parallax.load(data.parallax);
    }
}
}),
"[project]/theitern/node_modules/tsparticles-engine/esm/Options/Classes/Interactivity/Events/ResizeEvent.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ResizeEvent",
    ()=>ResizeEvent
]);
class ResizeEvent {
    constructor(){
        this.delay = 0.5;
        this.enable = true;
    }
    load(data) {
        if (data === undefined) {
            return;
        }
        if (data.delay !== undefined) {
            this.delay = data.delay;
        }
        if (data.enable !== undefined) {
            this.enable = data.enable;
        }
    }
}
}),
"[project]/theitern/node_modules/tsparticles-engine/esm/Options/Classes/Interactivity/Events/Events.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Events",
    ()=>Events
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/tsparticles-engine/esm/Utils/Utils.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Options$2f$Classes$2f$Interactivity$2f$Events$2f$ClickEvent$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/tsparticles-engine/esm/Options/Classes/Interactivity/Events/ClickEvent.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Options$2f$Classes$2f$Interactivity$2f$Events$2f$DivEvent$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/tsparticles-engine/esm/Options/Classes/Interactivity/Events/DivEvent.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Options$2f$Classes$2f$Interactivity$2f$Events$2f$HoverEvent$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/tsparticles-engine/esm/Options/Classes/Interactivity/Events/HoverEvent.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Options$2f$Classes$2f$Interactivity$2f$Events$2f$ResizeEvent$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/tsparticles-engine/esm/Options/Classes/Interactivity/Events/ResizeEvent.js [app-ssr] (ecmascript)");
;
;
;
;
;
class Events {
    constructor(){
        this.onClick = new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Options$2f$Classes$2f$Interactivity$2f$Events$2f$ClickEvent$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ClickEvent"]();
        this.onDiv = new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Options$2f$Classes$2f$Interactivity$2f$Events$2f$DivEvent$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["DivEvent"]();
        this.onHover = new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Options$2f$Classes$2f$Interactivity$2f$Events$2f$HoverEvent$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["HoverEvent"]();
        this.resize = new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Options$2f$Classes$2f$Interactivity$2f$Events$2f$ResizeEvent$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ResizeEvent"]();
    }
    get onclick() {
        return this.onClick;
    }
    set onclick(value) {
        this.onClick = value;
    }
    get ondiv() {
        return this.onDiv;
    }
    set ondiv(value) {
        this.onDiv = value;
    }
    get onhover() {
        return this.onHover;
    }
    set onhover(value) {
        this.onHover = value;
    }
    load(data) {
        if (!data) {
            return;
        }
        this.onClick.load(data.onClick ?? data.onclick);
        const onDiv = data.onDiv ?? data.ondiv;
        if (onDiv !== undefined) {
            this.onDiv = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["executeOnSingleOrMultiple"])(onDiv, (t)=>{
                const tmp = new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Options$2f$Classes$2f$Interactivity$2f$Events$2f$DivEvent$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["DivEvent"]();
                tmp.load(t);
                return tmp;
            });
        }
        this.onHover.load(data.onHover ?? data.onhover);
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isBoolean"])(data.resize)) {
            this.resize.enable = data.resize;
        } else {
            this.resize.load(data.resize);
        }
    }
}
}),
"[project]/theitern/node_modules/tsparticles-engine/esm/Options/Classes/Interactivity/Modes/Modes.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Modes",
    ()=>Modes
]);
class Modes {
    constructor(engine, container){
        this._engine = engine;
        this._container = container;
    }
    load(data) {
        if (!data) {
            return;
        }
        if (!this._container) {
            return;
        }
        const interactors = this._engine.plugins.interactors.get(this._container);
        if (!interactors) {
            return;
        }
        for (const interactor of interactors){
            if (!interactor.loadModeOptions) {
                continue;
            }
            interactor.loadModeOptions(this, data);
        }
    }
}
}),
"[project]/theitern/node_modules/tsparticles-engine/esm/Options/Classes/Interactivity/Interactivity.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Interactivity",
    ()=>Interactivity
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Options$2f$Classes$2f$Interactivity$2f$Events$2f$Events$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/tsparticles-engine/esm/Options/Classes/Interactivity/Events/Events.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Options$2f$Classes$2f$Interactivity$2f$Modes$2f$Modes$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/tsparticles-engine/esm/Options/Classes/Interactivity/Modes/Modes.js [app-ssr] (ecmascript)");
;
;
class Interactivity {
    constructor(engine, container){
        this.detectsOn = "window";
        this.events = new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Options$2f$Classes$2f$Interactivity$2f$Events$2f$Events$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Events"]();
        this.modes = new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Options$2f$Classes$2f$Interactivity$2f$Modes$2f$Modes$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Modes"](engine, container);
    }
    get detect_on() {
        return this.detectsOn;
    }
    set detect_on(value) {
        this.detectsOn = value;
    }
    load(data) {
        if (!data) {
            return;
        }
        const detectsOn = data.detectsOn ?? data.detect_on;
        if (detectsOn !== undefined) {
            this.detectsOn = detectsOn;
        }
        this.events.load(data.events);
        this.modes.load(data.modes);
    }
}
}),
"[project]/theitern/node_modules/tsparticles-engine/esm/Options/Classes/ManualParticle.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ManualParticle",
    ()=>ManualParticle
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/tsparticles-engine/esm/Utils/Utils.js [app-ssr] (ecmascript)");
;
class ManualParticle {
    load(data) {
        if (!data) {
            return;
        }
        if (data.position) {
            this.position = {
                x: data.position.x ?? 50,
                y: data.position.y ?? 50,
                mode: data.position.mode ?? "percent"
            };
        }
        if (data.options) {
            this.options = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["deepExtend"])({}, data.options);
        }
    }
}
}),
"[project]/theitern/node_modules/tsparticles-engine/esm/Options/Classes/Responsive.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Responsive",
    ()=>Responsive
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/tsparticles-engine/esm/Utils/Utils.js [app-ssr] (ecmascript)");
;
class Responsive {
    constructor(){
        this.maxWidth = Infinity;
        this.options = {};
        this.mode = "canvas";
    }
    load(data) {
        if (!data) {
            return;
        }
        if (data.maxWidth !== undefined) {
            this.maxWidth = data.maxWidth;
        }
        if (data.mode !== undefined) {
            if (data.mode === "screen") {
                this.mode = "screen";
            } else {
                this.mode = "canvas";
            }
        }
        if (data.options !== undefined) {
            this.options = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["deepExtend"])({}, data.options);
        }
    }
}
}),
"[project]/theitern/node_modules/tsparticles-engine/esm/Options/Classes/Theme/ThemeDefault.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ThemeDefault",
    ()=>ThemeDefault
]);
class ThemeDefault {
    constructor(){
        this.auto = false;
        this.mode = "any";
        this.value = false;
    }
    load(data) {
        if (!data) {
            return;
        }
        if (data.auto !== undefined) {
            this.auto = data.auto;
        }
        if (data.mode !== undefined) {
            this.mode = data.mode;
        }
        if (data.value !== undefined) {
            this.value = data.value;
        }
    }
}
}),
"[project]/theitern/node_modules/tsparticles-engine/esm/Options/Classes/Theme/Theme.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Theme",
    ()=>Theme
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Options$2f$Classes$2f$Theme$2f$ThemeDefault$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/tsparticles-engine/esm/Options/Classes/Theme/ThemeDefault.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/tsparticles-engine/esm/Utils/Utils.js [app-ssr] (ecmascript)");
;
;
class Theme {
    constructor(){
        this.name = "";
        this.default = new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Options$2f$Classes$2f$Theme$2f$ThemeDefault$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ThemeDefault"]();
    }
    load(data) {
        if (!data) {
            return;
        }
        if (data.name !== undefined) {
            this.name = data.name;
        }
        this.default.load(data.default);
        if (data.options !== undefined) {
            this.options = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["deepExtend"])({}, data.options);
        }
    }
}
}),
"[project]/theitern/node_modules/tsparticles-engine/esm/Options/Classes/ColorAnimation.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ColorAnimation",
    ()=>ColorAnimation
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/tsparticles-engine/esm/Utils/NumberUtils.js [app-ssr] (ecmascript)");
;
class ColorAnimation {
    constructor(){
        this.count = 0;
        this.enable = false;
        this.offset = 0;
        this.speed = 1;
        this.delay = 0;
        this.decay = 0;
        this.sync = true;
    }
    load(data) {
        if (!data) {
            return;
        }
        if (data.count !== undefined) {
            this.count = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["setRangeValue"])(data.count);
        }
        if (data.enable !== undefined) {
            this.enable = data.enable;
        }
        if (data.offset !== undefined) {
            this.offset = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["setRangeValue"])(data.offset);
        }
        if (data.speed !== undefined) {
            this.speed = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["setRangeValue"])(data.speed);
        }
        if (data.decay !== undefined) {
            this.decay = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["setRangeValue"])(data.decay);
        }
        if (data.delay !== undefined) {
            this.delay = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["setRangeValue"])(data.delay);
        }
        if (data.sync !== undefined) {
            this.sync = data.sync;
        }
    }
}
}),
"[project]/theitern/node_modules/tsparticles-engine/esm/Options/Classes/HslAnimation.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "HslAnimation",
    ()=>HslAnimation
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Options$2f$Classes$2f$ColorAnimation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/tsparticles-engine/esm/Options/Classes/ColorAnimation.js [app-ssr] (ecmascript)");
;
class HslAnimation {
    constructor(){
        this.h = new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Options$2f$Classes$2f$ColorAnimation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ColorAnimation"]();
        this.s = new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Options$2f$Classes$2f$ColorAnimation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ColorAnimation"]();
        this.l = new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Options$2f$Classes$2f$ColorAnimation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ColorAnimation"]();
    }
    load(data) {
        if (!data) {
            return;
        }
        this.h.load(data.h);
        this.s.load(data.s);
        this.l.load(data.l);
    }
}
}),
"[project]/theitern/node_modules/tsparticles-engine/esm/Options/Classes/AnimatableColor.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "AnimatableColor",
    ()=>AnimatableColor
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/tsparticles-engine/esm/Utils/Utils.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Options$2f$Classes$2f$HslAnimation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/tsparticles-engine/esm/Options/Classes/HslAnimation.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Options$2f$Classes$2f$OptionsColor$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/tsparticles-engine/esm/Options/Classes/OptionsColor.js [app-ssr] (ecmascript)");
;
;
;
class AnimatableColor extends __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Options$2f$Classes$2f$OptionsColor$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["OptionsColor"] {
    constructor(){
        super();
        this.animation = new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Options$2f$Classes$2f$HslAnimation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["HslAnimation"]();
    }
    static create(source, data) {
        const color = new AnimatableColor();
        color.load(source);
        if (data !== undefined) {
            if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isString"])(data) || (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isArray"])(data)) {
                color.load({
                    value: data
                });
            } else {
                color.load(data);
            }
        }
        return color;
    }
    load(data) {
        super.load(data);
        if (!data) {
            return;
        }
        const colorAnimation = data.animation;
        if (colorAnimation !== undefined) {
            if (colorAnimation.enable !== undefined) {
                this.animation.h.load(colorAnimation);
            } else {
                this.animation.load(data.animation);
            }
        }
    }
}
}),
"[project]/theitern/node_modules/tsparticles-engine/esm/Options/Classes/Particles/Collisions/CollisionsAbsorb.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "CollisionsAbsorb",
    ()=>CollisionsAbsorb
]);
class CollisionsAbsorb {
    constructor(){
        this.speed = 2;
    }
    load(data) {
        if (!data) {
            return;
        }
        if (data.speed !== undefined) {
            this.speed = data.speed;
        }
    }
}
}),
"[project]/theitern/node_modules/tsparticles-engine/esm/Options/Classes/Particles/Collisions/CollisionsOverlap.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "CollisionsOverlap",
    ()=>CollisionsOverlap
]);
class CollisionsOverlap {
    constructor(){
        this.enable = true;
        this.retries = 0;
    }
    load(data) {
        if (!data) {
            return;
        }
        if (data.enable !== undefined) {
            this.enable = data.enable;
        }
        if (data.retries !== undefined) {
            this.retries = data.retries;
        }
    }
}
}),
"[project]/theitern/node_modules/tsparticles-engine/esm/Options/Classes/AnimationOptions.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "AnimationOptions",
    ()=>AnimationOptions,
    "RangedAnimationOptions",
    ()=>RangedAnimationOptions
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/tsparticles-engine/esm/Utils/NumberUtils.js [app-ssr] (ecmascript)");
;
class AnimationOptions {
    constructor(){
        this.count = 0;
        this.enable = false;
        this.speed = 1;
        this.decay = 0;
        this.delay = 0;
        this.sync = false;
    }
    load(data) {
        if (!data) {
            return;
        }
        if (data.count !== undefined) {
            this.count = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["setRangeValue"])(data.count);
        }
        if (data.enable !== undefined) {
            this.enable = data.enable;
        }
        if (data.speed !== undefined) {
            this.speed = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["setRangeValue"])(data.speed);
        }
        if (data.decay !== undefined) {
            this.decay = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["setRangeValue"])(data.decay);
        }
        if (data.delay !== undefined) {
            this.delay = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["setRangeValue"])(data.delay);
        }
        if (data.sync !== undefined) {
            this.sync = data.sync;
        }
    }
}
class RangedAnimationOptions extends AnimationOptions {
    constructor(){
        super();
        this.mode = "auto";
        this.startValue = "random";
    }
    load(data) {
        super.load(data);
        if (!data) {
            return;
        }
        if (data.minimumValue !== undefined) {
            this.minimumValue = data.minimumValue;
        }
        if (data.mode !== undefined) {
            this.mode = data.mode;
        }
        if (data.startValue !== undefined) {
            this.startValue = data.startValue;
        }
    }
}
}),
"[project]/theitern/node_modules/tsparticles-engine/esm/Options/Classes/Random.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Random",
    ()=>Random
]);
class Random {
    constructor(){
        this.enable = false;
        this.minimumValue = 0;
    }
    load(data) {
        if (!data) {
            return;
        }
        if (data.enable !== undefined) {
            this.enable = data.enable;
        }
        if (data.minimumValue !== undefined) {
            this.minimumValue = data.minimumValue;
        }
    }
}
}),
"[project]/theitern/node_modules/tsparticles-engine/esm/Options/Classes/ValueWithRandom.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "AnimationValueWithRandom",
    ()=>AnimationValueWithRandom,
    "RangedAnimationValueWithRandom",
    ()=>RangedAnimationValueWithRandom,
    "ValueWithRandom",
    ()=>ValueWithRandom
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Options$2f$Classes$2f$AnimationOptions$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/tsparticles-engine/esm/Options/Classes/AnimationOptions.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Options$2f$Classes$2f$Random$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/tsparticles-engine/esm/Options/Classes/Random.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/tsparticles-engine/esm/Utils/Utils.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/tsparticles-engine/esm/Utils/NumberUtils.js [app-ssr] (ecmascript)");
;
;
;
;
class ValueWithRandom {
    constructor(){
        this.random = new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Options$2f$Classes$2f$Random$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Random"]();
        this.value = 0;
    }
    load(data) {
        if (!data) {
            return;
        }
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isBoolean"])(data.random)) {
            this.random.enable = data.random;
        } else {
            this.random.load(data.random);
        }
        if (data.value !== undefined) {
            this.value = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["setRangeValue"])(data.value, this.random.enable ? this.random.minimumValue : undefined);
        }
    }
}
class AnimationValueWithRandom extends ValueWithRandom {
    constructor(){
        super();
        this.animation = new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Options$2f$Classes$2f$AnimationOptions$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["AnimationOptions"]();
    }
    get anim() {
        return this.animation;
    }
    set anim(value) {
        this.animation = value;
    }
    load(data) {
        super.load(data);
        if (!data) {
            return;
        }
        const animation = data.animation ?? data.anim;
        if (animation !== undefined) {
            this.animation.load(animation);
        }
    }
}
class RangedAnimationValueWithRandom extends AnimationValueWithRandom {
    constructor(){
        super();
        this.animation = new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Options$2f$Classes$2f$AnimationOptions$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["RangedAnimationOptions"]();
    }
    load(data) {
        super.load(data);
        if (!data) {
            return;
        }
        const animation = data.animation ?? data.anim;
        if (animation !== undefined) {
            this.value = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["setRangeValue"])(this.value, this.animation.enable ? this.animation.minimumValue : undefined);
        }
    }
}
}),
"[project]/theitern/node_modules/tsparticles-engine/esm/Options/Classes/Particles/Bounce/ParticlesBounceFactor.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ParticlesBounceFactor",
    ()=>ParticlesBounceFactor
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Options$2f$Classes$2f$ValueWithRandom$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/tsparticles-engine/esm/Options/Classes/ValueWithRandom.js [app-ssr] (ecmascript)");
;
class ParticlesBounceFactor extends __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Options$2f$Classes$2f$ValueWithRandom$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ValueWithRandom"] {
    constructor(){
        super();
        this.random.minimumValue = 0.1;
        this.value = 1;
    }
}
}),
"[project]/theitern/node_modules/tsparticles-engine/esm/Options/Classes/Particles/Bounce/ParticlesBounce.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ParticlesBounce",
    ()=>ParticlesBounce
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Options$2f$Classes$2f$Particles$2f$Bounce$2f$ParticlesBounceFactor$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/tsparticles-engine/esm/Options/Classes/Particles/Bounce/ParticlesBounceFactor.js [app-ssr] (ecmascript)");
;
class ParticlesBounce {
    constructor(){
        this.horizontal = new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Options$2f$Classes$2f$Particles$2f$Bounce$2f$ParticlesBounceFactor$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ParticlesBounceFactor"]();
        this.vertical = new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Options$2f$Classes$2f$Particles$2f$Bounce$2f$ParticlesBounceFactor$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ParticlesBounceFactor"]();
    }
    load(data) {
        if (!data) {
            return;
        }
        this.horizontal.load(data.horizontal);
        this.vertical.load(data.vertical);
    }
}
}),
"[project]/theitern/node_modules/tsparticles-engine/esm/Options/Classes/Particles/Collisions/Collisions.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Collisions",
    ()=>Collisions
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Options$2f$Classes$2f$Particles$2f$Collisions$2f$CollisionsAbsorb$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/tsparticles-engine/esm/Options/Classes/Particles/Collisions/CollisionsAbsorb.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Options$2f$Classes$2f$Particles$2f$Collisions$2f$CollisionsOverlap$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/tsparticles-engine/esm/Options/Classes/Particles/Collisions/CollisionsOverlap.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Options$2f$Classes$2f$Particles$2f$Bounce$2f$ParticlesBounce$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/tsparticles-engine/esm/Options/Classes/Particles/Bounce/ParticlesBounce.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/tsparticles-engine/esm/Utils/NumberUtils.js [app-ssr] (ecmascript)");
;
;
;
;
class Collisions {
    constructor(){
        this.absorb = new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Options$2f$Classes$2f$Particles$2f$Collisions$2f$CollisionsAbsorb$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["CollisionsAbsorb"]();
        this.bounce = new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Options$2f$Classes$2f$Particles$2f$Bounce$2f$ParticlesBounce$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ParticlesBounce"]();
        this.enable = false;
        this.maxSpeed = 50;
        this.mode = "bounce";
        this.overlap = new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Options$2f$Classes$2f$Particles$2f$Collisions$2f$CollisionsOverlap$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["CollisionsOverlap"]();
    }
    load(data) {
        if (!data) {
            return;
        }
        this.absorb.load(data.absorb);
        this.bounce.load(data.bounce);
        if (data.enable !== undefined) {
            this.enable = data.enable;
        }
        if (data.maxSpeed !== undefined) {
            this.maxSpeed = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["setRangeValue"])(data.maxSpeed);
        }
        if (data.mode !== undefined) {
            this.mode = data.mode;
        }
        this.overlap.load(data.overlap);
    }
}
}),
"[project]/theitern/node_modules/tsparticles-engine/esm/Options/Classes/Particles/Move/MoveAngle.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "MoveAngle",
    ()=>MoveAngle
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/tsparticles-engine/esm/Utils/NumberUtils.js [app-ssr] (ecmascript)");
;
class MoveAngle {
    constructor(){
        this.offset = 0;
        this.value = 90;
    }
    load(data) {
        if (!data) {
            return;
        }
        if (data.offset !== undefined) {
            this.offset = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["setRangeValue"])(data.offset);
        }
        if (data.value !== undefined) {
            this.value = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["setRangeValue"])(data.value);
        }
    }
}
}),
"[project]/theitern/node_modules/tsparticles-engine/esm/Options/Classes/Particles/Move/MoveAttract.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "MoveAttract",
    ()=>MoveAttract
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/tsparticles-engine/esm/Utils/NumberUtils.js [app-ssr] (ecmascript)");
;
class MoveAttract {
    constructor(){
        this.distance = 200;
        this.enable = false;
        this.rotate = {
            x: 3000,
            y: 3000
        };
    }
    get rotateX() {
        return this.rotate.x;
    }
    set rotateX(value) {
        this.rotate.x = value;
    }
    get rotateY() {
        return this.rotate.y;
    }
    set rotateY(value) {
        this.rotate.y = value;
    }
    load(data) {
        if (!data) {
            return;
        }
        if (data.distance !== undefined) {
            this.distance = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["setRangeValue"])(data.distance);
        }
        if (data.enable !== undefined) {
            this.enable = data.enable;
        }
        const rotateX = data.rotate?.x ?? data.rotateX;
        if (rotateX !== undefined) {
            this.rotate.x = rotateX;
        }
        const rotateY = data.rotate?.y ?? data.rotateY;
        if (rotateY !== undefined) {
            this.rotate.y = rotateY;
        }
    }
}
}),
"[project]/theitern/node_modules/tsparticles-engine/esm/Options/Classes/Particles/Move/MoveCenter.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "MoveCenter",
    ()=>MoveCenter
]);
class MoveCenter {
    constructor(){
        this.x = 50;
        this.y = 50;
        this.mode = "percent";
        this.radius = 0;
    }
    load(data) {
        if (!data) {
            return;
        }
        if (data.x !== undefined) {
            this.x = data.x;
        }
        if (data.y !== undefined) {
            this.y = data.y;
        }
        if (data.mode !== undefined) {
            this.mode = data.mode;
        }
        if (data.radius !== undefined) {
            this.radius = data.radius;
        }
    }
}
}),
"[project]/theitern/node_modules/tsparticles-engine/esm/Options/Classes/Particles/Move/MoveGravity.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "MoveGravity",
    ()=>MoveGravity
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/tsparticles-engine/esm/Utils/NumberUtils.js [app-ssr] (ecmascript)");
;
class MoveGravity {
    constructor(){
        this.acceleration = 9.81;
        this.enable = false;
        this.inverse = false;
        this.maxSpeed = 50;
    }
    load(data) {
        if (!data) {
            return;
        }
        if (data.acceleration !== undefined) {
            this.acceleration = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["setRangeValue"])(data.acceleration);
        }
        if (data.enable !== undefined) {
            this.enable = data.enable;
        }
        if (data.inverse !== undefined) {
            this.inverse = data.inverse;
        }
        if (data.maxSpeed !== undefined) {
            this.maxSpeed = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["setRangeValue"])(data.maxSpeed);
        }
    }
}
}),
"[project]/theitern/node_modules/tsparticles-engine/esm/Options/Classes/Particles/Move/Path/MovePath.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "MovePath",
    ()=>MovePath
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Options$2f$Classes$2f$ValueWithRandom$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/tsparticles-engine/esm/Options/Classes/ValueWithRandom.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/tsparticles-engine/esm/Utils/Utils.js [app-ssr] (ecmascript)");
;
;
class MovePath {
    constructor(){
        this.clamp = true;
        this.delay = new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Options$2f$Classes$2f$ValueWithRandom$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ValueWithRandom"]();
        this.enable = false;
        this.options = {};
    }
    load(data) {
        if (!data) {
            return;
        }
        if (data.clamp !== undefined) {
            this.clamp = data.clamp;
        }
        this.delay.load(data.delay);
        if (data.enable !== undefined) {
            this.enable = data.enable;
        }
        this.generator = data.generator;
        if (data.options) {
            this.options = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["deepExtend"])(this.options, data.options);
        }
    }
}
}),
"[project]/theitern/node_modules/tsparticles-engine/esm/Options/Classes/Particles/Move/MoveTrailFill.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "MoveTrailFill",
    ()=>MoveTrailFill
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Options$2f$Classes$2f$OptionsColor$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/tsparticles-engine/esm/Options/Classes/OptionsColor.js [app-ssr] (ecmascript)");
;
class MoveTrailFill {
    load(data) {
        if (!data) {
            return;
        }
        if (data.color !== undefined) {
            this.color = __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Options$2f$Classes$2f$OptionsColor$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["OptionsColor"].create(this.color, data.color);
        }
        if (data.image !== undefined) {
            this.image = data.image;
        }
    }
}
}),
"[project]/theitern/node_modules/tsparticles-engine/esm/Options/Classes/Particles/Move/MoveTrail.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "MoveTrail",
    ()=>MoveTrail
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Options$2f$Classes$2f$Particles$2f$Move$2f$MoveTrailFill$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/tsparticles-engine/esm/Options/Classes/Particles/Move/MoveTrailFill.js [app-ssr] (ecmascript)");
;
class MoveTrail {
    constructor(){
        this.enable = false;
        this.length = 10;
        this.fill = new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Options$2f$Classes$2f$Particles$2f$Move$2f$MoveTrailFill$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["MoveTrailFill"]();
    }
    get fillColor() {
        return this.fill.color;
    }
    set fillColor(value) {
        this.fill.load({
            color: value
        });
    }
    load(data) {
        if (!data) {
            return;
        }
        if (data.enable !== undefined) {
            this.enable = data.enable;
        }
        if (data.fill !== undefined || data.fillColor !== undefined) {
            this.fill.load(data.fill || {
                color: data.fillColor
            });
        }
        if (data.length !== undefined) {
            this.length = data.length;
        }
    }
}
}),
"[project]/theitern/node_modules/tsparticles-engine/esm/Options/Classes/Particles/Move/OutModes.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "OutModes",
    ()=>OutModes
]);
class OutModes {
    constructor(){
        this.default = "out";
    }
    load(data) {
        if (!data) {
            return;
        }
        if (data.default !== undefined) {
            this.default = data.default;
        }
        this.bottom = data.bottom ?? data.default;
        this.left = data.left ?? data.default;
        this.right = data.right ?? data.default;
        this.top = data.top ?? data.default;
    }
}
}),
"[project]/theitern/node_modules/tsparticles-engine/esm/Options/Classes/Particles/Move/Spin.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Spin",
    ()=>Spin
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/tsparticles-engine/esm/Utils/Utils.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/tsparticles-engine/esm/Utils/NumberUtils.js [app-ssr] (ecmascript)");
;
;
class Spin {
    constructor(){
        this.acceleration = 0;
        this.enable = false;
    }
    load(data) {
        if (!data) {
            return;
        }
        if (data.acceleration !== undefined) {
            this.acceleration = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["setRangeValue"])(data.acceleration);
        }
        if (data.enable !== undefined) {
            this.enable = data.enable;
        }
        if (data.position) {
            this.position = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["deepExtend"])({}, data.position);
        }
    }
}
}),
"[project]/theitern/node_modules/tsparticles-engine/esm/Options/Classes/Particles/Move/Move.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Move",
    ()=>Move
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/tsparticles-engine/esm/Utils/Utils.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Options$2f$Classes$2f$Particles$2f$Move$2f$MoveAngle$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/tsparticles-engine/esm/Options/Classes/Particles/Move/MoveAngle.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Options$2f$Classes$2f$Particles$2f$Move$2f$MoveAttract$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/tsparticles-engine/esm/Options/Classes/Particles/Move/MoveAttract.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Options$2f$Classes$2f$Particles$2f$Move$2f$MoveCenter$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/tsparticles-engine/esm/Options/Classes/Particles/Move/MoveCenter.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Options$2f$Classes$2f$Particles$2f$Move$2f$MoveGravity$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/tsparticles-engine/esm/Options/Classes/Particles/Move/MoveGravity.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Options$2f$Classes$2f$Particles$2f$Move$2f$Path$2f$MovePath$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/tsparticles-engine/esm/Options/Classes/Particles/Move/Path/MovePath.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Options$2f$Classes$2f$Particles$2f$Move$2f$MoveTrail$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/tsparticles-engine/esm/Options/Classes/Particles/Move/MoveTrail.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Options$2f$Classes$2f$Particles$2f$Move$2f$OutModes$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/tsparticles-engine/esm/Options/Classes/Particles/Move/OutModes.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Options$2f$Classes$2f$Particles$2f$Move$2f$Spin$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/tsparticles-engine/esm/Options/Classes/Particles/Move/Spin.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/tsparticles-engine/esm/Utils/NumberUtils.js [app-ssr] (ecmascript)");
;
;
;
;
;
;
;
;
;
;
class Move {
    constructor(){
        this.angle = new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Options$2f$Classes$2f$Particles$2f$Move$2f$MoveAngle$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["MoveAngle"]();
        this.attract = new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Options$2f$Classes$2f$Particles$2f$Move$2f$MoveAttract$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["MoveAttract"]();
        this.center = new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Options$2f$Classes$2f$Particles$2f$Move$2f$MoveCenter$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["MoveCenter"]();
        this.decay = 0;
        this.distance = {};
        this.direction = "none";
        this.drift = 0;
        this.enable = false;
        this.gravity = new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Options$2f$Classes$2f$Particles$2f$Move$2f$MoveGravity$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["MoveGravity"]();
        this.path = new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Options$2f$Classes$2f$Particles$2f$Move$2f$Path$2f$MovePath$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["MovePath"]();
        this.outModes = new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Options$2f$Classes$2f$Particles$2f$Move$2f$OutModes$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["OutModes"]();
        this.random = false;
        this.size = false;
        this.speed = 2;
        this.spin = new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Options$2f$Classes$2f$Particles$2f$Move$2f$Spin$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Spin"]();
        this.straight = false;
        this.trail = new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Options$2f$Classes$2f$Particles$2f$Move$2f$MoveTrail$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["MoveTrail"]();
        this.vibrate = false;
        this.warp = false;
    }
    get bounce() {
        return this.collisions;
    }
    set bounce(value) {
        this.collisions = value;
    }
    get collisions() {
        return false;
    }
    set collisions(_) {}
    get noise() {
        return this.path;
    }
    set noise(value) {
        this.path = value;
    }
    get outMode() {
        return this.outModes.default;
    }
    set outMode(value) {
        this.outModes.default = value;
    }
    get out_mode() {
        return this.outMode;
    }
    set out_mode(value) {
        this.outMode = value;
    }
    load(data) {
        if (!data) {
            return;
        }
        this.angle.load((0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isNumber"])(data.angle) ? {
            value: data.angle
        } : data.angle);
        this.attract.load(data.attract);
        this.center.load(data.center);
        if (data.decay !== undefined) {
            this.decay = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["setRangeValue"])(data.decay);
        }
        if (data.direction !== undefined) {
            this.direction = data.direction;
        }
        if (data.distance !== undefined) {
            this.distance = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isNumber"])(data.distance) ? {
                horizontal: data.distance,
                vertical: data.distance
            } : {
                ...data.distance
            };
        }
        if (data.drift !== undefined) {
            this.drift = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["setRangeValue"])(data.drift);
        }
        if (data.enable !== undefined) {
            this.enable = data.enable;
        }
        this.gravity.load(data.gravity);
        const outModes = data.outModes ?? data.outMode ?? data.out_mode;
        if (outModes !== undefined) {
            if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isObject"])(outModes)) {
                this.outModes.load(outModes);
            } else {
                this.outModes.load({
                    default: outModes
                });
            }
        }
        this.path.load(data.path ?? data.noise);
        if (data.random !== undefined) {
            this.random = data.random;
        }
        if (data.size !== undefined) {
            this.size = data.size;
        }
        if (data.speed !== undefined) {
            this.speed = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["setRangeValue"])(data.speed);
        }
        this.spin.load(data.spin);
        if (data.straight !== undefined) {
            this.straight = data.straight;
        }
        this.trail.load(data.trail);
        if (data.vibrate !== undefined) {
            this.vibrate = data.vibrate;
        }
        if (data.warp !== undefined) {
            this.warp = data.warp;
        }
    }
}
}),
"[project]/theitern/node_modules/tsparticles-engine/esm/Options/Classes/Particles/Opacity/OpacityAnimation.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "OpacityAnimation",
    ()=>OpacityAnimation
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Options$2f$Classes$2f$AnimationOptions$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/tsparticles-engine/esm/Options/Classes/AnimationOptions.js [app-ssr] (ecmascript)");
;
class OpacityAnimation extends __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Options$2f$Classes$2f$AnimationOptions$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["RangedAnimationOptions"] {
    constructor(){
        super();
        this.destroy = "none";
        this.speed = 2;
    }
    get opacity_min() {
        return this.minimumValue;
    }
    set opacity_min(value) {
        this.minimumValue = value;
    }
    load(data) {
        if (data?.opacity_min !== undefined && data.minimumValue === undefined) {
            data.minimumValue = data.opacity_min;
        }
        super.load(data);
        if (!data) {
            return;
        }
        if (data.destroy !== undefined) {
            this.destroy = data.destroy;
        }
    }
}
}),
"[project]/theitern/node_modules/tsparticles-engine/esm/Options/Classes/Particles/Opacity/Opacity.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Opacity",
    ()=>Opacity
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Options$2f$Classes$2f$Particles$2f$Opacity$2f$OpacityAnimation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/tsparticles-engine/esm/Options/Classes/Particles/Opacity/OpacityAnimation.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Options$2f$Classes$2f$ValueWithRandom$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/tsparticles-engine/esm/Options/Classes/ValueWithRandom.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/tsparticles-engine/esm/Utils/NumberUtils.js [app-ssr] (ecmascript)");
;
;
;
class Opacity extends __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Options$2f$Classes$2f$ValueWithRandom$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ValueWithRandom"] {
    constructor(){
        super();
        this.animation = new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Options$2f$Classes$2f$Particles$2f$Opacity$2f$OpacityAnimation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["OpacityAnimation"]();
        this.random.minimumValue = 0.1;
        this.value = 1;
    }
    get anim() {
        return this.animation;
    }
    set anim(value) {
        this.animation = value;
    }
    load(data) {
        if (!data) {
            return;
        }
        super.load(data);
        const animation = data.animation ?? data.anim;
        if (animation !== undefined) {
            this.animation.load(animation);
            this.value = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["setRangeValue"])(this.value, this.animation.enable ? this.animation.minimumValue : undefined);
        }
    }
}
}),
"[project]/theitern/node_modules/tsparticles-engine/esm/Options/Classes/Particles/Number/ParticlesDensity.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ParticlesDensity",
    ()=>ParticlesDensity
]);
class ParticlesDensity {
    constructor(){
        this.enable = false;
        this.width = 1920;
        this.height = 1080;
    }
    get area() {
        return this.width;
    }
    set area(value) {
        this.width = value;
    }
    get factor() {
        return this.height;
    }
    set factor(value) {
        this.height = value;
    }
    get value_area() {
        return this.area;
    }
    set value_area(value) {
        this.area = value;
    }
    load(data) {
        if (!data) {
            return;
        }
        if (data.enable !== undefined) {
            this.enable = data.enable;
        }
        const width = data.width ?? data.area ?? data.value_area;
        if (width !== undefined) {
            this.width = width;
        }
        const height = data.height ?? data.factor;
        if (height !== undefined) {
            this.height = height;
        }
    }
}
}),
"[project]/theitern/node_modules/tsparticles-engine/esm/Options/Classes/Particles/Number/ParticlesNumber.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ParticlesNumber",
    ()=>ParticlesNumber
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Options$2f$Classes$2f$Particles$2f$Number$2f$ParticlesDensity$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/tsparticles-engine/esm/Options/Classes/Particles/Number/ParticlesDensity.js [app-ssr] (ecmascript)");
;
class ParticlesNumber {
    constructor(){
        this.density = new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Options$2f$Classes$2f$Particles$2f$Number$2f$ParticlesDensity$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ParticlesDensity"]();
        this.limit = 0;
        this.value = 0;
    }
    get max() {
        return this.limit;
    }
    set max(value) {
        this.limit = value;
    }
    load(data) {
        if (!data) {
            return;
        }
        this.density.load(data.density);
        const limit = data.limit ?? data.max;
        if (limit !== undefined) {
            this.limit = limit;
        }
        if (data.value !== undefined) {
            this.value = data.value;
        }
    }
}
}),
"[project]/theitern/node_modules/tsparticles-engine/esm/Options/Classes/Particles/Shadow.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Shadow",
    ()=>Shadow
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Options$2f$Classes$2f$OptionsColor$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/tsparticles-engine/esm/Options/Classes/OptionsColor.js [app-ssr] (ecmascript)");
;
class Shadow {
    constructor(){
        this.blur = 0;
        this.color = new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Options$2f$Classes$2f$OptionsColor$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["OptionsColor"]();
        this.enable = false;
        this.offset = {
            x: 0,
            y: 0
        };
        this.color.value = "#000";
    }
    load(data) {
        if (!data) {
            return;
        }
        if (data.blur !== undefined) {
            this.blur = data.blur;
        }
        this.color = __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Options$2f$Classes$2f$OptionsColor$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["OptionsColor"].create(this.color, data.color);
        if (data.enable !== undefined) {
            this.enable = data.enable;
        }
        if (data.offset === undefined) {
            return;
        }
        if (data.offset.x !== undefined) {
            this.offset.x = data.offset.x;
        }
        if (data.offset.y !== undefined) {
            this.offset.y = data.offset.y;
        }
    }
}
}),
"[project]/theitern/node_modules/tsparticles-engine/esm/Options/Classes/Particles/Shape/Shape.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Shape",
    ()=>Shape
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/tsparticles-engine/esm/Utils/Utils.js [app-ssr] (ecmascript)");
;
const charKey = "character", charAltKey = "char", imageKey = "image", imageAltKey = "images", polygonKey = "polygon", polygonAltKey = "star";
class Shape {
    constructor(){
        this.loadShape = (item, mainKey, altKey, altOverride)=>{
            if (!item) {
                return;
            }
            const itemIsArray = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isArray"])(item), emptyValue = itemIsArray ? [] : {}, mainDifferentValues = itemIsArray !== (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isArray"])(this.options[mainKey]), altDifferentValues = itemIsArray !== (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isArray"])(this.options[altKey]);
            if (mainDifferentValues) {
                this.options[mainKey] = emptyValue;
            }
            if (altDifferentValues && altOverride) {
                this.options[altKey] = emptyValue;
            }
            this.options[mainKey] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["deepExtend"])(this.options[mainKey] ?? emptyValue, item);
            if (!this.options[altKey] || altOverride) {
                this.options[altKey] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["deepExtend"])(this.options[altKey] ?? emptyValue, item);
            }
        };
        this.close = true;
        this.fill = true;
        this.options = {};
        this.type = "circle";
    }
    get character() {
        return this.options[charKey] ?? this.options[charAltKey];
    }
    set character(value) {
        this.options[charAltKey] = this.options[charKey] = value;
    }
    get custom() {
        return this.options;
    }
    set custom(value) {
        this.options = value;
    }
    get image() {
        return this.options[imageKey] ?? this.options[imageAltKey];
    }
    set image(value) {
        this.options[imageAltKey] = this.options[imageKey] = value;
    }
    get images() {
        return this.image;
    }
    set images(value) {
        this.image = value;
    }
    get polygon() {
        return this.options[polygonKey] ?? this.options[polygonAltKey];
    }
    set polygon(value) {
        this.options[polygonAltKey] = this.options[polygonKey] = value;
    }
    get stroke() {
        return [];
    }
    set stroke(_value) {}
    load(data) {
        if (!data) {
            return;
        }
        const options = data.options ?? data.custom;
        if (options !== undefined) {
            for(const shape in options){
                const item = options[shape];
                if (item) {
                    this.options[shape] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["deepExtend"])(this.options[shape] ?? {}, item);
                }
            }
        }
        this.loadShape(data.character, charKey, charAltKey, true);
        this.loadShape(data.polygon, polygonKey, polygonAltKey, false);
        this.loadShape(data.image ?? data.images, imageKey, imageAltKey, true);
        if (data.close !== undefined) {
            this.close = data.close;
        }
        if (data.fill !== undefined) {
            this.fill = data.fill;
        }
        if (data.type !== undefined) {
            this.type = data.type;
        }
    }
}
}),
"[project]/theitern/node_modules/tsparticles-engine/esm/Options/Classes/Particles/Size/SizeAnimation.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "SizeAnimation",
    ()=>SizeAnimation
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Options$2f$Classes$2f$AnimationOptions$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/tsparticles-engine/esm/Options/Classes/AnimationOptions.js [app-ssr] (ecmascript)");
;
class SizeAnimation extends __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Options$2f$Classes$2f$AnimationOptions$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["RangedAnimationOptions"] {
    constructor(){
        super();
        this.destroy = "none";
        this.speed = 5;
    }
    get size_min() {
        return this.minimumValue;
    }
    set size_min(value) {
        this.minimumValue = value;
    }
    load(data) {
        if (data?.size_min !== undefined && data.minimumValue === undefined) {
            data.minimumValue = data.size_min;
        }
        super.load(data);
        if (!data) {
            return;
        }
        if (data.destroy !== undefined) {
            this.destroy = data.destroy;
        }
    }
}
}),
"[project]/theitern/node_modules/tsparticles-engine/esm/Options/Classes/Particles/Size/Size.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Size",
    ()=>Size
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Options$2f$Classes$2f$Particles$2f$Size$2f$SizeAnimation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/tsparticles-engine/esm/Options/Classes/Particles/Size/SizeAnimation.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Options$2f$Classes$2f$ValueWithRandom$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/tsparticles-engine/esm/Options/Classes/ValueWithRandom.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/tsparticles-engine/esm/Utils/NumberUtils.js [app-ssr] (ecmascript)");
;
;
;
class Size extends __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Options$2f$Classes$2f$ValueWithRandom$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ValueWithRandom"] {
    constructor(){
        super();
        this.animation = new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Options$2f$Classes$2f$Particles$2f$Size$2f$SizeAnimation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["SizeAnimation"]();
        this.random.minimumValue = 1;
        this.value = 3;
    }
    get anim() {
        return this.animation;
    }
    set anim(value) {
        this.animation = value;
    }
    load(data) {
        super.load(data);
        if (!data) {
            return;
        }
        const animation = data.animation ?? data.anim;
        if (animation !== undefined) {
            this.animation.load(animation);
            this.value = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["setRangeValue"])(this.value, this.animation.enable ? this.animation.minimumValue : undefined);
        }
    }
}
}),
"[project]/theitern/node_modules/tsparticles-engine/esm/Options/Classes/Particles/Stroke.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Stroke",
    ()=>Stroke
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Options$2f$Classes$2f$AnimatableColor$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/tsparticles-engine/esm/Options/Classes/AnimatableColor.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/tsparticles-engine/esm/Utils/NumberUtils.js [app-ssr] (ecmascript)");
;
;
class Stroke {
    constructor(){
        this.width = 0;
    }
    load(data) {
        if (!data) {
            return;
        }
        if (data.color !== undefined) {
            this.color = __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Options$2f$Classes$2f$AnimatableColor$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["AnimatableColor"].create(this.color, data.color);
        }
        if (data.width !== undefined) {
            this.width = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["setRangeValue"])(data.width);
        }
        if (data.opacity !== undefined) {
            this.opacity = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["setRangeValue"])(data.opacity);
        }
    }
}
}),
"[project]/theitern/node_modules/tsparticles-engine/esm/Options/Classes/Particles/ZIndex/ZIndex.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ZIndex",
    ()=>ZIndex
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Options$2f$Classes$2f$ValueWithRandom$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/tsparticles-engine/esm/Options/Classes/ValueWithRandom.js [app-ssr] (ecmascript)");
;
class ZIndex extends __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Options$2f$Classes$2f$ValueWithRandom$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ValueWithRandom"] {
    constructor(){
        super();
        this.opacityRate = 1;
        this.sizeRate = 1;
        this.velocityRate = 1;
    }
    load(data) {
        super.load(data);
        if (!data) {
            return;
        }
        if (data.opacityRate !== undefined) {
            this.opacityRate = data.opacityRate;
        }
        if (data.sizeRate !== undefined) {
            this.sizeRate = data.sizeRate;
        }
        if (data.velocityRate !== undefined) {
            this.velocityRate = data.velocityRate;
        }
    }
}
}),
"[project]/theitern/node_modules/tsparticles-engine/esm/Options/Classes/Particles/ParticlesOptions.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ParticlesOptions",
    ()=>ParticlesOptions
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/tsparticles-engine/esm/Utils/Utils.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Options$2f$Classes$2f$AnimatableColor$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/tsparticles-engine/esm/Options/Classes/AnimatableColor.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Options$2f$Classes$2f$Particles$2f$Collisions$2f$Collisions$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/tsparticles-engine/esm/Options/Classes/Particles/Collisions/Collisions.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Options$2f$Classes$2f$Particles$2f$Move$2f$Move$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/tsparticles-engine/esm/Options/Classes/Particles/Move/Move.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Options$2f$Classes$2f$Particles$2f$Opacity$2f$Opacity$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/tsparticles-engine/esm/Options/Classes/Particles/Opacity/Opacity.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Options$2f$Classes$2f$Particles$2f$Bounce$2f$ParticlesBounce$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/tsparticles-engine/esm/Options/Classes/Particles/Bounce/ParticlesBounce.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Options$2f$Classes$2f$Particles$2f$Number$2f$ParticlesNumber$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/tsparticles-engine/esm/Options/Classes/Particles/Number/ParticlesNumber.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Options$2f$Classes$2f$Particles$2f$Shadow$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/tsparticles-engine/esm/Options/Classes/Particles/Shadow.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Options$2f$Classes$2f$Particles$2f$Shape$2f$Shape$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/tsparticles-engine/esm/Options/Classes/Particles/Shape/Shape.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Options$2f$Classes$2f$Particles$2f$Size$2f$Size$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/tsparticles-engine/esm/Options/Classes/Particles/Size/Size.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Options$2f$Classes$2f$Particles$2f$Stroke$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/tsparticles-engine/esm/Options/Classes/Particles/Stroke.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Options$2f$Classes$2f$Particles$2f$ZIndex$2f$ZIndex$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/tsparticles-engine/esm/Options/Classes/Particles/ZIndex/ZIndex.js [app-ssr] (ecmascript)");
;
;
;
;
;
;
;
;
;
;
;
;
class ParticlesOptions {
    constructor(engine, container){
        this._engine = engine;
        this._container = container;
        this.bounce = new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Options$2f$Classes$2f$Particles$2f$Bounce$2f$ParticlesBounce$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ParticlesBounce"]();
        this.collisions = new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Options$2f$Classes$2f$Particles$2f$Collisions$2f$Collisions$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Collisions"]();
        this.color = new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Options$2f$Classes$2f$AnimatableColor$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["AnimatableColor"]();
        this.color.value = "#fff";
        this.groups = {};
        this.move = new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Options$2f$Classes$2f$Particles$2f$Move$2f$Move$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Move"]();
        this.number = new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Options$2f$Classes$2f$Particles$2f$Number$2f$ParticlesNumber$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ParticlesNumber"]();
        this.opacity = new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Options$2f$Classes$2f$Particles$2f$Opacity$2f$Opacity$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Opacity"]();
        this.reduceDuplicates = false;
        this.shadow = new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Options$2f$Classes$2f$Particles$2f$Shadow$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Shadow"]();
        this.shape = new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Options$2f$Classes$2f$Particles$2f$Shape$2f$Shape$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Shape"]();
        this.size = new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Options$2f$Classes$2f$Particles$2f$Size$2f$Size$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Size"]();
        this.stroke = new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Options$2f$Classes$2f$Particles$2f$Stroke$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Stroke"]();
        this.zIndex = new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Options$2f$Classes$2f$Particles$2f$ZIndex$2f$ZIndex$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ZIndex"]();
    }
    load(data) {
        if (!data) {
            return;
        }
        this.bounce.load(data.bounce);
        this.color.load(__TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Options$2f$Classes$2f$AnimatableColor$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["AnimatableColor"].create(this.color, data.color));
        if (data.groups !== undefined) {
            for(const group in data.groups){
                const item = data.groups[group];
                if (item !== undefined) {
                    this.groups[group] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["deepExtend"])(this.groups[group] ?? {}, item);
                }
            }
        }
        this.move.load(data.move);
        this.number.load(data.number);
        this.opacity.load(data.opacity);
        if (data.reduceDuplicates !== undefined) {
            this.reduceDuplicates = data.reduceDuplicates;
        }
        this.shape.load(data.shape);
        this.size.load(data.size);
        this.shadow.load(data.shadow);
        this.zIndex.load(data.zIndex);
        const collisions = data.move?.collisions ?? data.move?.bounce;
        if (collisions !== undefined) {
            this.collisions.enable = collisions;
        }
        this.collisions.load(data.collisions);
        if (data.interactivity !== undefined) {
            this.interactivity = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["deepExtend"])({}, data.interactivity);
        }
        const strokeToLoad = data.stroke ?? data.shape?.stroke;
        if (strokeToLoad) {
            this.stroke = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["executeOnSingleOrMultiple"])(strokeToLoad, (t)=>{
                const tmp = new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Options$2f$Classes$2f$Particles$2f$Stroke$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Stroke"]();
                tmp.load(t);
                return tmp;
            });
        }
        if (this._container) {
            const updaters = this._engine.plugins.updaters.get(this._container);
            if (updaters) {
                for (const updater of updaters){
                    if (updater.loadOptions) {
                        updater.loadOptions(this, data);
                    }
                }
            }
            const interactors = this._engine.plugins.interactors.get(this._container);
            if (interactors) {
                for (const interactor of interactors){
                    if (interactor.loadParticlesOptions) {
                        interactor.loadParticlesOptions(this, data);
                    }
                }
            }
        }
    }
}
}),
"[project]/theitern/node_modules/tsparticles-engine/esm/Utils/OptionsUtils.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "loadOptions",
    ()=>loadOptions,
    "loadParticlesOptions",
    ()=>loadParticlesOptions
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Options$2f$Classes$2f$Particles$2f$ParticlesOptions$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/tsparticles-engine/esm/Options/Classes/Particles/ParticlesOptions.js [app-ssr] (ecmascript)");
;
function loadOptions(options, ...sourceOptionsArr) {
    for (const sourceOptions of sourceOptionsArr){
        options.load(sourceOptions);
    }
}
function loadParticlesOptions(engine, container, ...sourceOptionsArr) {
    const options = new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Options$2f$Classes$2f$Particles$2f$ParticlesOptions$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ParticlesOptions"](engine, container);
    loadOptions(options, ...sourceOptionsArr);
    return options;
}
}),
"[project]/theitern/node_modules/tsparticles-engine/esm/Options/Classes/Options.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Options",
    ()=>Options
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/tsparticles-engine/esm/Utils/Utils.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Options$2f$Classes$2f$Background$2f$Background$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/tsparticles-engine/esm/Options/Classes/Background/Background.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Options$2f$Classes$2f$BackgroundMask$2f$BackgroundMask$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/tsparticles-engine/esm/Options/Classes/BackgroundMask/BackgroundMask.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Options$2f$Classes$2f$FullScreen$2f$FullScreen$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/tsparticles-engine/esm/Options/Classes/FullScreen/FullScreen.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Options$2f$Classes$2f$Interactivity$2f$Interactivity$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/tsparticles-engine/esm/Options/Classes/Interactivity/Interactivity.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Options$2f$Classes$2f$ManualParticle$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/tsparticles-engine/esm/Options/Classes/ManualParticle.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Options$2f$Classes$2f$Responsive$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/tsparticles-engine/esm/Options/Classes/Responsive.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Options$2f$Classes$2f$Theme$2f$Theme$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/tsparticles-engine/esm/Options/Classes/Theme/Theme.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$OptionsUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/tsparticles-engine/esm/Utils/OptionsUtils.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/tsparticles-engine/esm/Utils/NumberUtils.js [app-ssr] (ecmascript)");
;
;
;
;
;
;
;
;
;
;
class Options {
    constructor(engine, container){
        this._findDefaultTheme = (mode)=>{
            return this.themes.find((theme)=>theme.default.value && theme.default.mode === mode) ?? this.themes.find((theme)=>theme.default.value && theme.default.mode === "any");
        };
        this._importPreset = (preset)=>{
            this.load(this._engine.plugins.getPreset(preset));
        };
        this._engine = engine;
        this._container = container;
        this.autoPlay = true;
        this.background = new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Options$2f$Classes$2f$Background$2f$Background$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Background"]();
        this.backgroundMask = new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Options$2f$Classes$2f$BackgroundMask$2f$BackgroundMask$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["BackgroundMask"]();
        this.defaultThemes = {};
        this.delay = 0;
        this.fullScreen = new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Options$2f$Classes$2f$FullScreen$2f$FullScreen$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["FullScreen"]();
        this.detectRetina = true;
        this.duration = 0;
        this.fpsLimit = 120;
        this.interactivity = new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Options$2f$Classes$2f$Interactivity$2f$Interactivity$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Interactivity"](engine, container);
        this.manualParticles = [];
        this.particles = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$OptionsUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["loadParticlesOptions"])(this._engine, this._container);
        this.pauseOnBlur = true;
        this.pauseOnOutsideViewport = true;
        this.responsive = [];
        this.smooth = false;
        this.style = {};
        this.themes = [];
        this.zLayers = 100;
    }
    get backgroundMode() {
        return this.fullScreen;
    }
    set backgroundMode(value) {
        this.fullScreen.load(value);
    }
    get fps_limit() {
        return this.fpsLimit;
    }
    set fps_limit(value) {
        this.fpsLimit = value;
    }
    get retina_detect() {
        return this.detectRetina;
    }
    set retina_detect(value) {
        this.detectRetina = value;
    }
    load(data) {
        if (!data) {
            return;
        }
        if (data.preset !== undefined) {
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["executeOnSingleOrMultiple"])(data.preset, (preset)=>this._importPreset(preset));
        }
        if (data.autoPlay !== undefined) {
            this.autoPlay = data.autoPlay;
        }
        if (data.delay !== undefined) {
            this.delay = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["setRangeValue"])(data.delay);
        }
        const detectRetina = data.detectRetina ?? data.retina_detect;
        if (detectRetina !== undefined) {
            this.detectRetina = detectRetina;
        }
        if (data.duration !== undefined) {
            this.duration = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["setRangeValue"])(data.duration);
        }
        const fpsLimit = data.fpsLimit ?? data.fps_limit;
        if (fpsLimit !== undefined) {
            this.fpsLimit = fpsLimit;
        }
        if (data.pauseOnBlur !== undefined) {
            this.pauseOnBlur = data.pauseOnBlur;
        }
        if (data.pauseOnOutsideViewport !== undefined) {
            this.pauseOnOutsideViewport = data.pauseOnOutsideViewport;
        }
        if (data.zLayers !== undefined) {
            this.zLayers = data.zLayers;
        }
        this.background.load(data.background);
        const fullScreen = data.fullScreen ?? data.backgroundMode;
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isBoolean"])(fullScreen)) {
            this.fullScreen.enable = fullScreen;
        } else {
            this.fullScreen.load(fullScreen);
        }
        this.backgroundMask.load(data.backgroundMask);
        this.interactivity.load(data.interactivity);
        if (data.manualParticles) {
            this.manualParticles = data.manualParticles.map((t)=>{
                const tmp = new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Options$2f$Classes$2f$ManualParticle$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ManualParticle"]();
                tmp.load(t);
                return tmp;
            });
        }
        this.particles.load(data.particles);
        this.style = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["deepExtend"])(this.style, data.style);
        this._engine.plugins.loadOptions(this, data);
        if (data.smooth !== undefined) {
            this.smooth = data.smooth;
        }
        const interactors = this._engine.plugins.interactors.get(this._container);
        if (interactors) {
            for (const interactor of interactors){
                if (interactor.loadOptions) {
                    interactor.loadOptions(this, data);
                }
            }
        }
        if (data.responsive !== undefined) {
            for (const responsive of data.responsive){
                const optResponsive = new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Options$2f$Classes$2f$Responsive$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Responsive"]();
                optResponsive.load(responsive);
                this.responsive.push(optResponsive);
            }
        }
        this.responsive.sort((a, b)=>a.maxWidth - b.maxWidth);
        if (data.themes !== undefined) {
            for (const theme of data.themes){
                const existingTheme = this.themes.find((t)=>t.name === theme.name);
                if (!existingTheme) {
                    const optTheme = new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Options$2f$Classes$2f$Theme$2f$Theme$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Theme"]();
                    optTheme.load(theme);
                    this.themes.push(optTheme);
                } else {
                    existingTheme.load(theme);
                }
            }
        }
        this.defaultThemes.dark = this._findDefaultTheme("dark")?.name;
        this.defaultThemes.light = this._findDefaultTheme("light")?.name;
    }
    setResponsive(width, pxRatio, defaultOptions) {
        this.load(defaultOptions);
        const responsiveOptions = this.responsive.find((t)=>t.mode === "screen" && screen ? t.maxWidth > screen.availWidth : t.maxWidth * pxRatio > width);
        this.load(responsiveOptions?.options);
        return responsiveOptions?.maxWidth;
    }
    setTheme(name) {
        if (name) {
            const chosenTheme = this.themes.find((theme)=>theme.name === name);
            if (chosenTheme) {
                this.load(chosenTheme.options);
            }
        } else {
            const mediaMatch = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["safeMatchMedia"])("(prefers-color-scheme: dark)"), clientDarkMode = mediaMatch && mediaMatch.matches, defaultTheme = this._findDefaultTheme(clientDarkMode ? "dark" : "light");
            if (defaultTheme) {
                this.load(defaultTheme.options);
            }
        }
    }
}
}),
"[project]/theitern/node_modules/tsparticles-engine/esm/Core/Utils/InteractionManager.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "InteractionManager",
    ()=>InteractionManager
]);
class InteractionManager {
    constructor(engine, container){
        this.container = container;
        this._engine = engine;
        this._interactors = engine.plugins.getInteractors(this.container, true);
        this._externalInteractors = [];
        this._particleInteractors = [];
    }
    async externalInteract(delta) {
        for (const interactor of this._externalInteractors){
            interactor.isEnabled() && await interactor.interact(delta);
        }
    }
    handleClickMode(mode) {
        for (const interactor of this._externalInteractors){
            interactor.handleClickMode && interactor.handleClickMode(mode);
        }
    }
    init() {
        this._externalInteractors = [];
        this._particleInteractors = [];
        for (const interactor of this._interactors){
            switch(interactor.type){
                case "external":
                    this._externalInteractors.push(interactor);
                    break;
                case "particles":
                    this._particleInteractors.push(interactor);
                    break;
            }
            interactor.init();
        }
    }
    async particlesInteract(particle, delta) {
        for (const interactor of this._externalInteractors){
            interactor.clear(particle, delta);
        }
        for (const interactor of this._particleInteractors){
            interactor.isEnabled(particle) && await interactor.interact(particle, delta);
        }
    }
    async reset(particle) {
        for (const interactor of this._externalInteractors){
            interactor.isEnabled() && interactor.reset(particle);
        }
        for (const interactor of this._particleInteractors){
            interactor.isEnabled(particle) && interactor.reset(particle);
        }
    }
}
}),
"[project]/theitern/node_modules/tsparticles-engine/esm/Core/Particle.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Particle",
    ()=>Particle
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/tsparticles-engine/esm/Utils/NumberUtils.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/tsparticles-engine/esm/Utils/Utils.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$ColorUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/tsparticles-engine/esm/Utils/ColorUtils.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Options$2f$Classes$2f$Interactivity$2f$Interactivity$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/tsparticles-engine/esm/Options/Classes/Interactivity/Interactivity.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Core$2f$Utils$2f$Vector$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/tsparticles-engine/esm/Core/Utils/Vector.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Core$2f$Utils$2f$Vector3d$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/tsparticles-engine/esm/Core/Utils/Vector3d.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$CanvasUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/tsparticles-engine/esm/Utils/CanvasUtils.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/tsparticles-engine/esm/Core/Utils/Constants.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$OptionsUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/tsparticles-engine/esm/Utils/OptionsUtils.js [app-ssr] (ecmascript)");
;
;
;
;
;
;
;
;
;
const fixOutMode = (data)=>{
    if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isInArray"])(data.outMode, data.checkModes)) {
        return;
    }
    const diameter = data.radius * 2;
    if (data.coord > data.maxCoord - diameter) {
        data.setCb(-data.radius);
    } else if (data.coord < diameter) {
        data.setCb(data.radius);
    }
};
class Particle {
    constructor(engine, id, container, position, overrideOptions, group){
        this.container = container;
        this._calcPosition = (container, position, zIndex, tryCount = 0)=>{
            for (const [, plugin] of container.plugins){
                const pluginPos = plugin.particlePosition !== undefined ? plugin.particlePosition(position, this) : undefined;
                if (pluginPos) {
                    return __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Core$2f$Utils$2f$Vector3d$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Vector3d"].create(pluginPos.x, pluginPos.y, zIndex);
                }
            }
            const canvasSize = container.canvas.size, exactPosition = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["calcExactPositionOrRandomFromSize"])({
                size: canvasSize,
                position: position
            }), pos = __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Core$2f$Utils$2f$Vector3d$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Vector3d"].create(exactPosition.x, exactPosition.y, zIndex), radius = this.getRadius(), outModes = this.options.move.outModes, fixHorizontal = (outMode)=>{
                fixOutMode({
                    outMode,
                    checkModes: [
                        "bounce",
                        "bounce-horizontal"
                    ],
                    coord: pos.x,
                    maxCoord: container.canvas.size.width,
                    setCb: (value)=>pos.x += value,
                    radius
                });
            }, fixVertical = (outMode)=>{
                fixOutMode({
                    outMode,
                    checkModes: [
                        "bounce",
                        "bounce-vertical"
                    ],
                    coord: pos.y,
                    maxCoord: container.canvas.size.height,
                    setCb: (value)=>pos.y += value,
                    radius
                });
            };
            fixHorizontal(outModes.left ?? outModes.default);
            fixHorizontal(outModes.right ?? outModes.default);
            fixVertical(outModes.top ?? outModes.default);
            fixVertical(outModes.bottom ?? outModes.default);
            if (this._checkOverlap(pos, tryCount)) {
                return this._calcPosition(container, undefined, zIndex, tryCount + 1);
            }
            return pos;
        };
        this._calculateVelocity = ()=>{
            const baseVelocity = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getParticleBaseVelocity"])(this.direction), res = baseVelocity.copy(), moveOptions = this.options.move;
            if (moveOptions.direction === "inside" || moveOptions.direction === "outside") {
                return res;
            }
            const rad = Math.PI / 180 * (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getRangeValue"])(moveOptions.angle.value), radOffset = Math.PI / 180 * (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getRangeValue"])(moveOptions.angle.offset), range = {
                left: radOffset - rad / 2,
                right: radOffset + rad / 2
            };
            if (!moveOptions.straight) {
                res.angle += (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["randomInRange"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["setRangeValue"])(range.left, range.right));
            }
            if (moveOptions.random && typeof moveOptions.speed === "number") {
                res.length *= (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getRandom"])();
            }
            return res;
        };
        this._checkOverlap = (pos, tryCount = 0)=>{
            const collisionsOptions = this.options.collisions, radius = this.getRadius();
            if (!collisionsOptions.enable) {
                return false;
            }
            const overlapOptions = collisionsOptions.overlap;
            if (overlapOptions.enable) {
                return false;
            }
            const retries = overlapOptions.retries;
            if (retries >= 0 && tryCount > retries) {
                throw new Error(`${__TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["errorPrefix"]} particle is overlapping and can't be placed`);
            }
            return !!this.container.particles.find((particle)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getDistance"])(pos, particle.position) < radius + particle.getRadius());
        };
        this._getRollColor = (color)=>{
            if (!color || !this.roll || !this.backColor && !this.roll.alter) {
                return color;
            }
            const backFactor = this.roll.horizontal && this.roll.vertical ? 2 : 1, backSum = this.roll.horizontal ? Math.PI / 2 : 0, rolled = Math.floor(((this.roll.angle ?? 0) + backSum) / (Math.PI / backFactor)) % 2;
            if (!rolled) {
                return color;
            }
            if (this.backColor) {
                return this.backColor;
            }
            if (this.roll.alter) {
                return (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$CanvasUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["alterHsl"])(color, this.roll.alter.type, this.roll.alter.value);
            }
            return color;
        };
        this._initPosition = (position)=>{
            const container = this.container, zIndexValue = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getRangeValue"])(this.options.zIndex.value);
            this.position = this._calcPosition(container, position, (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["clamp"])(zIndexValue, 0, container.zLayers));
            this.initialPosition = this.position.copy();
            const canvasSize = container.canvas.size;
            this.moveCenter = {
                ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getPosition"])(this.options.move.center, canvasSize),
                radius: this.options.move.center.radius ?? 0,
                mode: this.options.move.center.mode ?? "percent"
            };
            this.direction = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getParticleDirectionAngle"])(this.options.move.direction, this.position, this.moveCenter);
            switch(this.options.move.direction){
                case "inside":
                    this.outType = "inside";
                    break;
                case "outside":
                    this.outType = "outside";
                    break;
            }
            this.offset = __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Core$2f$Utils$2f$Vector$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Vector"].origin;
        };
        this._loadShapeData = (shapeOptions, reduceDuplicates)=>{
            const shapeData = shapeOptions.options[this.shape];
            if (!shapeData) {
                return;
            }
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["deepExtend"])({
                close: shapeOptions.close,
                fill: shapeOptions.fill
            }, (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["itemFromSingleOrMultiple"])(shapeData, this.id, reduceDuplicates));
        };
        this._engine = engine;
        this.init(id, position, overrideOptions, group);
    }
    destroy(override) {
        if (this.unbreakable || this.destroyed) {
            return;
        }
        this.destroyed = true;
        this.bubble.inRange = false;
        this.slow.inRange = false;
        const container = this.container, pathGenerator = this.pathGenerator;
        for (const [, plugin] of container.plugins){
            if (plugin.particleDestroyed) {
                plugin.particleDestroyed(this, override);
            }
        }
        for (const updater of container.particles.updaters){
            if (updater.particleDestroyed) {
                updater.particleDestroyed(this, override);
            }
        }
        if (pathGenerator) {
            pathGenerator.reset(this);
        }
    }
    draw(delta) {
        const container = this.container;
        for (const [, plugin] of container.plugins){
            container.canvas.drawParticlePlugin(plugin, this, delta);
        }
        container.canvas.drawParticle(this, delta);
    }
    getFillColor() {
        return this._getRollColor(this.bubble.color ?? (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$ColorUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getHslFromAnimation"])(this.color));
    }
    getMass() {
        return this.getRadius() ** 2 * Math.PI / 2;
    }
    getPosition() {
        return {
            x: this.position.x + this.offset.x,
            y: this.position.y + this.offset.y,
            z: this.position.z
        };
    }
    getRadius() {
        return this.bubble.radius ?? this.size.value;
    }
    getStrokeColor() {
        return this._getRollColor(this.bubble.color ?? (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$ColorUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getHslFromAnimation"])(this.strokeColor));
    }
    init(id, position, overrideOptions, group) {
        const container = this.container, engine = this._engine;
        this.id = id;
        this.group = group;
        this.fill = true;
        this.pathRotation = false;
        this.close = true;
        this.lastPathTime = 0;
        this.destroyed = false;
        this.unbreakable = false;
        this.rotation = 0;
        this.misplaced = false;
        this.retina = {
            maxDistance: {}
        };
        this.outType = "normal";
        this.ignoresResizeRatio = true;
        const pxRatio = container.retina.pixelRatio, mainOptions = container.actualOptions, particlesOptions = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$OptionsUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["loadParticlesOptions"])(this._engine, container, mainOptions.particles), shapeType = particlesOptions.shape.type, { reduceDuplicates } = particlesOptions;
        this.shape = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["itemFromSingleOrMultiple"])(shapeType, this.id, reduceDuplicates);
        const shapeOptions = particlesOptions.shape;
        if (overrideOptions && overrideOptions.shape && overrideOptions.shape.type) {
            const overrideShapeType = overrideOptions.shape.type, shape = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["itemFromSingleOrMultiple"])(overrideShapeType, this.id, reduceDuplicates);
            if (shape) {
                this.shape = shape;
                shapeOptions.load(overrideOptions.shape);
            }
        }
        this.shapeData = this._loadShapeData(shapeOptions, reduceDuplicates);
        particlesOptions.load(overrideOptions);
        const shapeData = this.shapeData;
        if (shapeData) {
            particlesOptions.load(shapeData.particles);
        }
        const interactivity = new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Options$2f$Classes$2f$Interactivity$2f$Interactivity$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Interactivity"](engine, container);
        interactivity.load(container.actualOptions.interactivity);
        interactivity.load(particlesOptions.interactivity);
        this.interactivity = interactivity;
        this.fill = shapeData?.fill ?? particlesOptions.shape.fill;
        this.close = shapeData?.close ?? particlesOptions.shape.close;
        this.options = particlesOptions;
        const pathOptions = this.options.move.path;
        this.pathDelay = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getValue"])(pathOptions.delay) * 1000;
        if (pathOptions.generator) {
            this.pathGenerator = this._engine.plugins.getPathGenerator(pathOptions.generator);
            if (this.pathGenerator && container.addPath(pathOptions.generator, this.pathGenerator)) {
                this.pathGenerator.init(container);
            }
        }
        container.retina.initParticle(this);
        this.size = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["initParticleNumericAnimationValue"])(this.options.size, pxRatio);
        this.bubble = {
            inRange: false
        };
        this.slow = {
            inRange: false,
            factor: 1
        };
        this._initPosition(position);
        this.initialVelocity = this._calculateVelocity();
        this.velocity = this.initialVelocity.copy();
        this.moveDecay = 1 - (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getRangeValue"])(this.options.move.decay);
        const particles = container.particles;
        particles.needsSort = particles.needsSort || particles.lastZIndex < this.position.z;
        particles.lastZIndex = this.position.z;
        this.zIndexFactor = this.position.z / container.zLayers;
        this.sides = 24;
        let drawer = container.drawers.get(this.shape);
        if (!drawer) {
            drawer = this._engine.plugins.getShapeDrawer(this.shape);
            if (drawer) {
                container.drawers.set(this.shape, drawer);
            }
        }
        if (drawer && drawer.loadShape) {
            drawer.loadShape(this);
        }
        const sideCountFunc = drawer?.getSidesCount;
        if (sideCountFunc) {
            this.sides = sideCountFunc(this);
        }
        this.spawning = false;
        this.shadowColor = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$ColorUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["rangeColorToRgb"])(this.options.shadow.color);
        for (const updater of container.particles.updaters){
            updater.init(this);
        }
        for (const mover of container.particles.movers){
            mover.init && mover.init(this);
        }
        if (drawer && drawer.particleInit) {
            drawer.particleInit(container, this);
        }
        for (const [, plugin] of container.plugins){
            plugin.particleCreated && plugin.particleCreated(this);
        }
    }
    isInsideCanvas() {
        const radius = this.getRadius(), canvasSize = this.container.canvas.size, position = this.position;
        return position.x >= -radius && position.y >= -radius && position.y <= canvasSize.height + radius && position.x <= canvasSize.width + radius;
    }
    isVisible() {
        return !this.destroyed && !this.spawning && this.isInsideCanvas();
    }
    reset() {
        for (const updater of this.container.particles.updaters){
            updater.reset && updater.reset(this);
        }
    }
}
}),
"[project]/theitern/node_modules/tsparticles-engine/esm/Core/Utils/Point.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Point",
    ()=>Point
]);
class Point {
    constructor(position, particle){
        this.position = position;
        this.particle = particle;
    }
}
}),
"[project]/theitern/node_modules/tsparticles-engine/esm/Core/Utils/Range.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Range",
    ()=>Range
]);
class Range {
    constructor(x, y){
        this.position = {
            x: x,
            y: y
        };
    }
}
}),
"[project]/theitern/node_modules/tsparticles-engine/esm/Core/Utils/Rectangle.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Rectangle",
    ()=>Rectangle
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Core$2f$Utils$2f$Circle$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/tsparticles-engine/esm/Core/Utils/Circle.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Core$2f$Utils$2f$Range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/tsparticles-engine/esm/Core/Utils/Range.js [app-ssr] (ecmascript)");
;
;
class Rectangle extends __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Core$2f$Utils$2f$Range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Range"] {
    constructor(x, y, width, height){
        super(x, y);
        this.size = {
            height: height,
            width: width
        };
    }
    contains(point) {
        const w = this.size.width, h = this.size.height, pos = this.position;
        return point.x >= pos.x && point.x <= pos.x + w && point.y >= pos.y && point.y <= pos.y + h;
    }
    intersects(range) {
        if (range instanceof __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Core$2f$Utils$2f$Circle$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Circle"]) {
            range.intersects(this);
        }
        const w = this.size.width, h = this.size.height, pos1 = this.position, pos2 = range.position, size2 = range instanceof Rectangle ? range.size : {
            width: 0,
            height: 0
        }, w2 = size2.width, h2 = size2.height;
        return pos2.x < pos1.x + w && pos2.x + w2 > pos1.x && pos2.y < pos1.y + h && pos2.y + h2 > pos1.y;
    }
}
}),
"[project]/theitern/node_modules/tsparticles-engine/esm/Core/Utils/Circle.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Circle",
    ()=>Circle
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Core$2f$Utils$2f$Range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/tsparticles-engine/esm/Core/Utils/Range.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Core$2f$Utils$2f$Rectangle$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/tsparticles-engine/esm/Core/Utils/Rectangle.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/tsparticles-engine/esm/Utils/NumberUtils.js [app-ssr] (ecmascript)");
;
;
;
class Circle extends __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Core$2f$Utils$2f$Range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Range"] {
    constructor(x, y, radius){
        super(x, y);
        this.radius = radius;
    }
    contains(point) {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getDistance"])(point, this.position) <= this.radius;
    }
    intersects(range) {
        const pos1 = this.position, pos2 = range.position, distPos = {
            x: Math.abs(pos2.x - pos1.x),
            y: Math.abs(pos2.y - pos1.y)
        }, r = this.radius;
        if (range instanceof Circle) {
            const rSum = r + range.radius, dist = Math.sqrt(distPos.x ** 2 + distPos.y ** 2);
            return rSum > dist;
        } else if (range instanceof __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Core$2f$Utils$2f$Rectangle$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Rectangle"]) {
            const { width, height } = range.size, edges = Math.pow(distPos.x - width, 2) + Math.pow(distPos.y - height, 2);
            return edges <= r ** 2 || distPos.x <= r + width && distPos.y <= r + height || distPos.x <= width || distPos.y <= height;
        }
        return false;
    }
}
}),
"[project]/theitern/node_modules/tsparticles-engine/esm/Core/Utils/QuadTree.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "QuadTree",
    ()=>QuadTree
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Core$2f$Utils$2f$Circle$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/tsparticles-engine/esm/Core/Utils/Circle.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Core$2f$Utils$2f$Rectangle$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/tsparticles-engine/esm/Core/Utils/Rectangle.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/tsparticles-engine/esm/Utils/NumberUtils.js [app-ssr] (ecmascript)");
;
;
;
class QuadTree {
    constructor(rectangle, capacity){
        this.rectangle = rectangle;
        this.capacity = capacity;
        this._subdivide = ()=>{
            const { x, y } = this.rectangle.position, { width, height } = this.rectangle.size, { capacity } = this;
            for(let i = 0; i < 4; i++){
                this._subs.push(new QuadTree(new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Core$2f$Utils$2f$Rectangle$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Rectangle"](x + width / 2 * (i % 2), y + height / 2 * (Math.round(i / 2) - i % 2), width / 2, height / 2), capacity));
            }
            this._divided = true;
        };
        this._points = [];
        this._divided = false;
        this._subs = [];
    }
    insert(point) {
        if (!this.rectangle.contains(point.position)) {
            return false;
        }
        if (this._points.length < this.capacity) {
            this._points.push(point);
            return true;
        }
        if (!this._divided) {
            this._subdivide();
        }
        return this._subs.some((sub)=>sub.insert(point));
    }
    query(range, check, found) {
        const res = found || [];
        if (!range.intersects(this.rectangle)) {
            return [];
        }
        for (const p of this._points){
            if (!range.contains(p.position) && (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getDistance"])(range.position, p.position) > p.particle.getRadius() && (!check || check(p.particle))) {
                continue;
            }
            res.push(p.particle);
        }
        if (this._divided) {
            for (const sub of this._subs){
                sub.query(range, check, res);
            }
        }
        return res;
    }
    queryCircle(position, radius, check) {
        return this.query(new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Core$2f$Utils$2f$Circle$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Circle"](position.x, position.y, radius), check);
    }
    queryRectangle(position, size, check) {
        return this.query(new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Core$2f$Utils$2f$Rectangle$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Rectangle"](position.x, position.y, size.width, size.height), check);
    }
}
}),
"[project]/theitern/node_modules/tsparticles-engine/esm/Core/Particles.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Particles",
    ()=>Particles
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/tsparticles-engine/esm/Utils/Utils.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Core$2f$Utils$2f$InteractionManager$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/tsparticles-engine/esm/Core/Utils/InteractionManager.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Core$2f$Particle$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/tsparticles-engine/esm/Core/Particle.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Core$2f$Utils$2f$Point$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/tsparticles-engine/esm/Core/Utils/Point.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Core$2f$Utils$2f$QuadTree$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/tsparticles-engine/esm/Core/Utils/QuadTree.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Core$2f$Utils$2f$Rectangle$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/tsparticles-engine/esm/Core/Utils/Rectangle.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/tsparticles-engine/esm/Core/Utils/Constants.js [app-ssr] (ecmascript)");
;
;
;
;
;
;
;
const qTreeCapacity = 4;
const qTreeRectangle = (canvasSize)=>{
    return new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Core$2f$Utils$2f$Rectangle$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Rectangle"](-canvasSize.width / 4, -canvasSize.height / 4, canvasSize.width * 3 / 2, canvasSize.height * 3 / 2);
};
class Particles {
    constructor(engine, container){
        this._applyDensity = (options, manualCount, group)=>{
            if (!options.number.density?.enable) {
                return;
            }
            const numberOptions = options.number, densityFactor = this._initDensityFactor(numberOptions.density), optParticlesNumber = numberOptions.value, optParticlesLimit = numberOptions.limit > 0 ? numberOptions.limit : optParticlesNumber, particlesNumber = Math.min(optParticlesNumber, optParticlesLimit) * densityFactor + manualCount, particlesCount = Math.min(this.count, this.filter((t)=>t.group === group).length);
            this.limit = numberOptions.limit * densityFactor;
            if (particlesCount < particlesNumber) {
                this.push(Math.abs(particlesNumber - particlesCount), undefined, options, group);
            } else if (particlesCount > particlesNumber) {
                this.removeQuantity(particlesCount - particlesNumber, group);
            }
        };
        this._initDensityFactor = (densityOptions)=>{
            const container = this._container;
            if (!container.canvas.element || !densityOptions.enable) {
                return 1;
            }
            const canvas = container.canvas.element, pxRatio = container.retina.pixelRatio;
            return canvas.width * canvas.height / (densityOptions.factor * pxRatio ** 2 * densityOptions.area);
        };
        this._pushParticle = (position, overrideOptions, group, initializer)=>{
            try {
                let particle = this.pool.pop();
                if (particle) {
                    particle.init(this._nextId, position, overrideOptions, group);
                } else {
                    particle = new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Core$2f$Particle$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Particle"](this._engine, this._nextId, this._container, position, overrideOptions, group);
                }
                let canAdd = true;
                if (initializer) {
                    canAdd = initializer(particle);
                }
                if (!canAdd) {
                    return;
                }
                this._array.push(particle);
                this._zArray.push(particle);
                this._nextId++;
                this._engine.dispatchEvent("particleAdded", {
                    container: this._container,
                    data: {
                        particle
                    }
                });
                return particle;
            } catch (e) {
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getLogger"])().warning(`${__TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["errorPrefix"]} adding particle: ${e}`);
                return;
            }
        };
        this._removeParticle = (index, group, override)=>{
            const particle = this._array[index];
            if (!particle || particle.group !== group) {
                return false;
            }
            particle.destroy(override);
            const zIdx = this._zArray.indexOf(particle);
            this._array.splice(index, 1);
            this._zArray.splice(zIdx, 1);
            this.pool.push(particle);
            this._engine.dispatchEvent("particleRemoved", {
                container: this._container,
                data: {
                    particle
                }
            });
            return true;
        };
        this._engine = engine;
        this._container = container;
        this._nextId = 0;
        this._array = [];
        this._zArray = [];
        this.pool = [];
        this.limit = 0;
        this.needsSort = false;
        this.lastZIndex = 0;
        this._interactionManager = new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Core$2f$Utils$2f$InteractionManager$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["InteractionManager"](engine, container);
        const canvasSize = container.canvas.size;
        this.quadTree = new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Core$2f$Utils$2f$QuadTree$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["QuadTree"](qTreeRectangle(canvasSize), qTreeCapacity);
        this.movers = this._engine.plugins.getMovers(container, true);
        this.updaters = this._engine.plugins.getUpdaters(container, true);
    }
    get count() {
        return this._array.length;
    }
    addManualParticles() {
        const container = this._container, options = container.actualOptions;
        for (const particle of options.manualParticles){
            this.addParticle(particle.position ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getPosition"])(particle.position, container.canvas.size) : undefined, particle.options);
        }
    }
    addParticle(position, overrideOptions, group, initializer) {
        const container = this._container, options = container.actualOptions, limit = options.particles.number.limit;
        if (limit > 0) {
            const countToRemove = this.count + 1 - limit;
            if (countToRemove > 0) {
                this.removeQuantity(countToRemove);
            }
        }
        return this._pushParticle(position, overrideOptions, group, initializer);
    }
    clear() {
        this._array = [];
        this._zArray = [];
    }
    destroy() {
        this._array = [];
        this._zArray = [];
        this.movers = [];
        this.updaters = [];
    }
    async draw(delta) {
        const container = this._container;
        container.canvas.clear();
        await this.update(delta);
        for (const [, plugin] of container.plugins){
            container.canvas.drawPlugin(plugin, delta);
        }
        for (const p of this._zArray){
            p.draw(delta);
        }
    }
    filter(condition) {
        return this._array.filter(condition);
    }
    find(condition) {
        return this._array.find(condition);
    }
    handleClickMode(mode) {
        this._interactionManager.handleClickMode(mode);
    }
    init() {
        const container = this._container, options = container.actualOptions;
        this.lastZIndex = 0;
        this.needsSort = false;
        let handled = false;
        this.updaters = this._engine.plugins.getUpdaters(container, true);
        this._interactionManager.init();
        for (const [, plugin] of container.plugins){
            if (plugin.particlesInitialization !== undefined) {
                handled = plugin.particlesInitialization();
            }
            if (handled) {
                break;
            }
        }
        this._interactionManager.init();
        for (const [, pathGenerator] of container.pathGenerators){
            pathGenerator.init(container);
        }
        this.addManualParticles();
        if (!handled) {
            for(const group in options.particles.groups){
                const groupOptions = options.particles.groups[group];
                for(let i = this.count, j = 0; j < groupOptions.number?.value && i < options.particles.number.value; i++, j++){
                    this.addParticle(undefined, groupOptions, group);
                }
            }
            for(let i = this.count; i < options.particles.number.value; i++){
                this.addParticle();
            }
        }
    }
    push(nb, mouse, overrideOptions, group) {
        this.pushing = true;
        for(let i = 0; i < nb; i++){
            this.addParticle(mouse?.position, overrideOptions, group);
        }
        this.pushing = false;
    }
    async redraw() {
        this.clear();
        this.init();
        await this.draw({
            value: 0,
            factor: 0
        });
    }
    remove(particle, group, override) {
        this.removeAt(this._array.indexOf(particle), undefined, group, override);
    }
    removeAt(index, quantity = 1, group, override) {
        if (index < 0 || index > this.count) {
            return;
        }
        let deleted = 0;
        for(let i = index; deleted < quantity && i < this.count; i++){
            this._removeParticle(i--, group, override) && deleted++;
        }
    }
    removeQuantity(quantity, group) {
        this.removeAt(0, quantity, group);
    }
    setDensity() {
        const options = this._container.actualOptions, groups = options.particles.groups;
        for(const group in groups){
            this._applyDensity(groups[group], 0, group);
        }
        this._applyDensity(options.particles, options.manualParticles.length);
    }
    async update(delta) {
        const container = this._container, particlesToDelete = new Set();
        this.quadTree = new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Core$2f$Utils$2f$QuadTree$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["QuadTree"](qTreeRectangle(container.canvas.size), qTreeCapacity);
        for (const [, pathGenerator] of container.pathGenerators){
            pathGenerator.update();
        }
        for (const [, plugin] of container.plugins){
            plugin.update && plugin.update(delta);
        }
        for (const particle of this._array){
            const resizeFactor = container.canvas.resizeFactor;
            if (resizeFactor && !particle.ignoresResizeRatio) {
                particle.position.x *= resizeFactor.width;
                particle.position.y *= resizeFactor.height;
                particle.initialPosition.x *= resizeFactor.width;
                particle.initialPosition.y *= resizeFactor.height;
            }
            particle.ignoresResizeRatio = false;
            await this._interactionManager.reset(particle);
            for (const [, plugin] of this._container.plugins){
                if (particle.destroyed) {
                    break;
                }
                if (plugin.particleUpdate) {
                    plugin.particleUpdate(particle, delta);
                }
            }
            for (const mover of this.movers){
                mover.isEnabled(particle) && mover.move(particle, delta);
            }
            if (particle.destroyed) {
                particlesToDelete.add(particle);
                continue;
            }
            this.quadTree.insert(new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Core$2f$Utils$2f$Point$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Point"](particle.getPosition(), particle));
        }
        if (particlesToDelete.size) {
            const checkDelete = (p)=>!particlesToDelete.has(p);
            this._array = this.filter(checkDelete);
            this._zArray = this._zArray.filter(checkDelete);
            this.pool.push(...particlesToDelete);
        }
        await this._interactionManager.externalInteract(delta);
        for (const particle of this._array){
            for (const updater of this.updaters){
                updater.update(particle, delta);
            }
            if (!particle.destroyed && !particle.spawning) {
                await this._interactionManager.particlesInteract(particle, delta);
            }
        }
        delete container.canvas.resizeFactor;
        if (this.needsSort) {
            const zArray = this._zArray;
            zArray.sort((a, b)=>b.position.z - a.position.z || a.id - b.id);
            this.lastZIndex = zArray[zArray.length - 1].position.z;
            this.needsSort = false;
        }
    }
}
}),
"[project]/theitern/node_modules/tsparticles-engine/esm/Core/Retina.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Retina",
    ()=>Retina
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/tsparticles-engine/esm/Utils/NumberUtils.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/tsparticles-engine/esm/Utils/Utils.js [app-ssr] (ecmascript)");
;
;
class Retina {
    constructor(container){
        this.container = container;
        this.pixelRatio = 1;
        this.reduceFactor = 1;
    }
    init() {
        const container = this.container, options = container.actualOptions;
        this.pixelRatio = !options.detectRetina || (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isSsr"])() ? 1 : window.devicePixelRatio;
        this.reduceFactor = 1;
        const ratio = this.pixelRatio;
        if (container.canvas.element) {
            const element = container.canvas.element;
            container.canvas.size.width = element.offsetWidth * ratio;
            container.canvas.size.height = element.offsetHeight * ratio;
        }
        const particles = options.particles, moveOptions = particles.move;
        this.attractDistance = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getRangeValue"])(moveOptions.attract.distance) * ratio;
        this.maxSpeed = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getRangeValue"])(moveOptions.gravity.maxSpeed) * ratio;
        this.sizeAnimationSpeed = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getRangeValue"])(particles.size.animation.speed) * ratio;
    }
    initParticle(particle) {
        const options = particle.options, ratio = this.pixelRatio, moveOptions = options.move, moveDistance = moveOptions.distance, props = particle.retina;
        props.attractDistance = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getRangeValue"])(moveOptions.attract.distance) * ratio;
        props.moveDrift = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getRangeValue"])(moveOptions.drift) * ratio;
        props.moveSpeed = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getRangeValue"])(moveOptions.speed) * ratio;
        props.sizeAnimationSpeed = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getRangeValue"])(options.size.animation.speed) * ratio;
        const maxDistance = props.maxDistance;
        maxDistance.horizontal = moveDistance.horizontal !== undefined ? moveDistance.horizontal * ratio : undefined;
        maxDistance.vertical = moveDistance.vertical !== undefined ? moveDistance.vertical * ratio : undefined;
        props.maxSpeed = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getRangeValue"])(moveOptions.gravity.maxSpeed) * ratio;
    }
}
}),
"[project]/theitern/node_modules/tsparticles-engine/esm/Core/Container.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Container",
    ()=>Container
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/tsparticles-engine/esm/Utils/Utils.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Core$2f$Canvas$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/tsparticles-engine/esm/Core/Canvas.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Core$2f$Utils$2f$EventListeners$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/tsparticles-engine/esm/Core/Utils/EventListeners.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Options$2f$Classes$2f$Options$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/tsparticles-engine/esm/Options/Classes/Options.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Core$2f$Particles$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/tsparticles-engine/esm/Core/Particles.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Core$2f$Retina$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/tsparticles-engine/esm/Core/Retina.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/tsparticles-engine/esm/Core/Utils/Constants.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/tsparticles-engine/esm/Utils/NumberUtils.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$OptionsUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/tsparticles-engine/esm/Utils/OptionsUtils.js [app-ssr] (ecmascript)");
;
;
;
;
;
;
;
;
;
function guardCheck(container) {
    return container && !container.destroyed;
}
function initDelta(value, fpsLimit = 60, smooth = false) {
    return {
        value,
        factor: smooth ? 60 / fpsLimit : 60 * value / 1000
    };
}
function loadContainerOptions(engine, container, ...sourceOptionsArr) {
    const options = new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Options$2f$Classes$2f$Options$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Options"](engine, container);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$OptionsUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["loadOptions"])(options, ...sourceOptionsArr);
    return options;
}
const defaultPathGeneratorKey = "default", defaultPathGenerator = {
    generate: (p)=>p.velocity,
    init: ()=>{},
    update: ()=>{},
    reset: ()=>{}
};
class Container {
    constructor(engine, id, sourceOptions){
        this.id = id;
        this._intersectionManager = (entries)=>{
            if (!guardCheck(this) || !this.actualOptions.pauseOnOutsideViewport) {
                return;
            }
            for (const entry of entries){
                if (entry.target !== this.interactivity.element) {
                    continue;
                }
                (entry.isIntersecting ? this.play : this.pause)();
            }
        };
        this._nextFrame = async (timestamp)=>{
            try {
                if (!this.smooth && this.lastFrameTime !== undefined && timestamp < this.lastFrameTime + 1000 / this.fpsLimit) {
                    this.draw(false);
                    return;
                }
                this.lastFrameTime ??= timestamp;
                const delta = initDelta(timestamp - this.lastFrameTime, this.fpsLimit, this.smooth);
                this.addLifeTime(delta.value);
                this.lastFrameTime = timestamp;
                if (delta.value > 1000) {
                    this.draw(false);
                    return;
                }
                await this.particles.draw(delta);
                if (!this.alive()) {
                    this.destroy();
                    return;
                }
                if (this.getAnimationStatus()) {
                    this.draw(false);
                }
            } catch (e) {
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getLogger"])().error(`${__TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["errorPrefix"]} in animation loop`, e);
            }
        };
        this._engine = engine;
        this.fpsLimit = 120;
        this.smooth = false;
        this._delay = 0;
        this._duration = 0;
        this._lifeTime = 0;
        this._firstStart = true;
        this.started = false;
        this.destroyed = false;
        this._paused = true;
        this.lastFrameTime = 0;
        this.zLayers = 100;
        this.pageHidden = false;
        this._sourceOptions = sourceOptions;
        this._initialSourceOptions = sourceOptions;
        this.retina = new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Core$2f$Retina$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Retina"](this);
        this.canvas = new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Core$2f$Canvas$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Canvas"](this);
        this.particles = new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Core$2f$Particles$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Particles"](this._engine, this);
        this.pathGenerators = new Map();
        this.interactivity = {
            mouse: {
                clicking: false,
                inside: false
            }
        };
        this.plugins = new Map();
        this.drawers = new Map();
        this._options = loadContainerOptions(this._engine, this);
        this.actualOptions = loadContainerOptions(this._engine, this);
        this._eventListeners = new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Core$2f$Utils$2f$EventListeners$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["EventListeners"](this);
        if (typeof IntersectionObserver !== "undefined" && IntersectionObserver) {
            this._intersectionObserver = new IntersectionObserver((entries)=>this._intersectionManager(entries));
        }
        this._engine.dispatchEvent("containerBuilt", {
            container: this
        });
    }
    get options() {
        return this._options;
    }
    get sourceOptions() {
        return this._sourceOptions;
    }
    addClickHandler(callback) {
        if (!guardCheck(this)) {
            return;
        }
        const el = this.interactivity.element;
        if (!el) {
            return;
        }
        const clickOrTouchHandler = (e, pos, radius)=>{
            if (!guardCheck(this)) {
                return;
            }
            const pxRatio = this.retina.pixelRatio, posRetina = {
                x: pos.x * pxRatio,
                y: pos.y * pxRatio
            }, particles = this.particles.quadTree.queryCircle(posRetina, radius * pxRatio);
            callback(e, particles);
        };
        const clickHandler = (e)=>{
            if (!guardCheck(this)) {
                return;
            }
            const mouseEvent = e, pos = {
                x: mouseEvent.offsetX || mouseEvent.clientX,
                y: mouseEvent.offsetY || mouseEvent.clientY
            };
            clickOrTouchHandler(e, pos, 1);
        };
        const touchStartHandler = ()=>{
            if (!guardCheck(this)) {
                return;
            }
            touched = true;
            touchMoved = false;
        };
        const touchMoveHandler = ()=>{
            if (!guardCheck(this)) {
                return;
            }
            touchMoved = true;
        };
        const touchEndHandler = (e)=>{
            if (!guardCheck(this)) {
                return;
            }
            if (touched && !touchMoved) {
                const touchEvent = e;
                let lastTouch = touchEvent.touches[touchEvent.touches.length - 1];
                if (!lastTouch) {
                    lastTouch = touchEvent.changedTouches[touchEvent.changedTouches.length - 1];
                    if (!lastTouch) {
                        return;
                    }
                }
                const element = this.canvas.element, canvasRect = element ? element.getBoundingClientRect() : undefined, pos = {
                    x: lastTouch.clientX - (canvasRect ? canvasRect.left : 0),
                    y: lastTouch.clientY - (canvasRect ? canvasRect.top : 0)
                };
                clickOrTouchHandler(e, pos, Math.max(lastTouch.radiusX, lastTouch.radiusY));
            }
            touched = false;
            touchMoved = false;
        };
        const touchCancelHandler = ()=>{
            if (!guardCheck(this)) {
                return;
            }
            touched = false;
            touchMoved = false;
        };
        let touched = false, touchMoved = false;
        el.addEventListener("click", clickHandler);
        el.addEventListener("touchstart", touchStartHandler);
        el.addEventListener("touchmove", touchMoveHandler);
        el.addEventListener("touchend", touchEndHandler);
        el.addEventListener("touchcancel", touchCancelHandler);
    }
    addLifeTime(value) {
        this._lifeTime += value;
    }
    addPath(key, generator, override = false) {
        if (!guardCheck(this) || !override && this.pathGenerators.has(key)) {
            return false;
        }
        this.pathGenerators.set(key, generator ?? defaultPathGenerator);
        return true;
    }
    alive() {
        return !this._duration || this._lifeTime <= this._duration;
    }
    destroy() {
        if (!guardCheck(this)) {
            return;
        }
        this.stop();
        this.particles.destroy();
        this.canvas.destroy();
        for (const [, drawer] of this.drawers){
            drawer.destroy && drawer.destroy(this);
        }
        for (const key of this.drawers.keys()){
            this.drawers.delete(key);
        }
        this._engine.plugins.destroy(this);
        this.destroyed = true;
        const mainArr = this._engine.dom(), idx = mainArr.findIndex((t)=>t === this);
        if (idx >= 0) {
            mainArr.splice(idx, 1);
        }
        this._engine.dispatchEvent("containerDestroyed", {
            container: this
        });
    }
    draw(force) {
        if (!guardCheck(this)) {
            return;
        }
        let refreshTime = force;
        this._drawAnimationFrame = requestAnimationFrame(async (timestamp)=>{
            if (refreshTime) {
                this.lastFrameTime = undefined;
                refreshTime = false;
            }
            await this._nextFrame(timestamp);
        });
    }
    async export(type, options = {}) {
        for (const [, plugin] of this.plugins){
            if (!plugin.export) {
                continue;
            }
            const res = await plugin.export(type, options);
            if (!res.supported) {
                continue;
            }
            return res.blob;
        }
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getLogger"])().error(`${__TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["errorPrefix"]} - Export plugin with type ${type} not found`);
    }
    getAnimationStatus() {
        return !this._paused && !this.pageHidden && guardCheck(this);
    }
    handleClickMode(mode) {
        if (!guardCheck(this)) {
            return;
        }
        this.particles.handleClickMode(mode);
        for (const [, plugin] of this.plugins){
            plugin.handleClickMode && plugin.handleClickMode(mode);
        }
    }
    async init() {
        if (!guardCheck(this)) {
            return;
        }
        const shapes = this._engine.plugins.getSupportedShapes();
        for (const type of shapes){
            const drawer = this._engine.plugins.getShapeDrawer(type);
            if (drawer) {
                this.drawers.set(type, drawer);
            }
        }
        this._options = loadContainerOptions(this._engine, this, this._initialSourceOptions, this.sourceOptions);
        this.actualOptions = loadContainerOptions(this._engine, this, this._options);
        const availablePlugins = this._engine.plugins.getAvailablePlugins(this);
        for (const [id, plugin] of availablePlugins){
            this.plugins.set(id, plugin);
        }
        this.retina.init();
        await this.canvas.init();
        this.updateActualOptions();
        this.canvas.initBackground();
        this.canvas.resize();
        this.zLayers = this.actualOptions.zLayers;
        this._duration = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getRangeValue"])(this.actualOptions.duration) * 1000;
        this._delay = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getRangeValue"])(this.actualOptions.delay) * 1000;
        this._lifeTime = 0;
        this.fpsLimit = this.actualOptions.fpsLimit > 0 ? this.actualOptions.fpsLimit : 120;
        this.smooth = this.actualOptions.smooth;
        for (const [, drawer] of this.drawers){
            drawer.init && await drawer.init(this);
        }
        for (const [, plugin] of this.plugins){
            plugin.init && await plugin.init();
        }
        this._engine.dispatchEvent("containerInit", {
            container: this
        });
        this.particles.init();
        this.particles.setDensity();
        for (const [, plugin] of this.plugins){
            plugin.particlesSetup && plugin.particlesSetup();
        }
        this._engine.dispatchEvent("particlesSetup", {
            container: this
        });
    }
    async loadTheme(name) {
        if (!guardCheck(this)) {
            return;
        }
        this._currentTheme = name;
        await this.refresh();
    }
    pause() {
        if (!guardCheck(this)) {
            return;
        }
        if (this._drawAnimationFrame !== undefined) {
            cancelAnimationFrame(this._drawAnimationFrame);
            delete this._drawAnimationFrame;
        }
        if (this._paused) {
            return;
        }
        for (const [, plugin] of this.plugins){
            plugin.pause && plugin.pause();
        }
        if (!this.pageHidden) {
            this._paused = true;
        }
        this._engine.dispatchEvent("containerPaused", {
            container: this
        });
    }
    play(force) {
        if (!guardCheck(this)) {
            return;
        }
        const needsUpdate = this._paused || force;
        if (this._firstStart && !this.actualOptions.autoPlay) {
            this._firstStart = false;
            return;
        }
        if (this._paused) {
            this._paused = false;
        }
        if (needsUpdate) {
            for (const [, plugin] of this.plugins){
                if (plugin.play) {
                    plugin.play();
                }
            }
        }
        this._engine.dispatchEvent("containerPlay", {
            container: this
        });
        this.draw(needsUpdate || false);
    }
    async refresh() {
        if (!guardCheck(this)) {
            return;
        }
        this.stop();
        return this.start();
    }
    async reset() {
        if (!guardCheck(this)) {
            return;
        }
        this._initialSourceOptions = undefined;
        this._options = loadContainerOptions(this._engine, this);
        this.actualOptions = loadContainerOptions(this._engine, this, this._options);
        return this.refresh();
    }
    setNoise(noiseOrGenerator, init, update) {
        if (!guardCheck(this)) {
            return;
        }
        this.setPath(noiseOrGenerator, init, update);
    }
    setPath(pathOrGenerator, init, update) {
        if (!pathOrGenerator || !guardCheck(this)) {
            return;
        }
        const pathGenerator = {
            ...defaultPathGenerator
        };
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isFunction"])(pathOrGenerator)) {
            pathGenerator.generate = pathOrGenerator;
            if (init) {
                pathGenerator.init = init;
            }
            if (update) {
                pathGenerator.update = update;
            }
        } else {
            const oldGenerator = pathGenerator;
            pathGenerator.generate = pathOrGenerator.generate || oldGenerator.generate;
            pathGenerator.init = pathOrGenerator.init || oldGenerator.init;
            pathGenerator.update = pathOrGenerator.update || oldGenerator.update;
        }
        this.addPath(defaultPathGeneratorKey, pathGenerator, true);
    }
    async start() {
        if (!guardCheck(this) || this.started) {
            return;
        }
        await this.init();
        this.started = true;
        await new Promise((resolve)=>{
            this._delayTimeout = setTimeout(async ()=>{
                this._eventListeners.addListeners();
                if (this.interactivity.element instanceof HTMLElement && this._intersectionObserver) {
                    this._intersectionObserver.observe(this.interactivity.element);
                }
                for (const [, plugin] of this.plugins){
                    plugin.start && await plugin.start();
                }
                this._engine.dispatchEvent("containerStarted", {
                    container: this
                });
                this.play();
                resolve();
            }, this._delay);
        });
    }
    stop() {
        if (!guardCheck(this) || !this.started) {
            return;
        }
        if (this._delayTimeout) {
            clearTimeout(this._delayTimeout);
            delete this._delayTimeout;
        }
        this._firstStart = true;
        this.started = false;
        this._eventListeners.removeListeners();
        this.pause();
        this.particles.clear();
        this.canvas.stop();
        if (this.interactivity.element instanceof HTMLElement && this._intersectionObserver) {
            this._intersectionObserver.unobserve(this.interactivity.element);
        }
        for (const [, plugin] of this.plugins){
            plugin.stop && plugin.stop();
        }
        for (const key of this.plugins.keys()){
            this.plugins.delete(key);
        }
        this._sourceOptions = this._options;
        this._engine.dispatchEvent("containerStopped", {
            container: this
        });
    }
    updateActualOptions() {
        this.actualOptions.responsive = [];
        const newMaxWidth = this.actualOptions.setResponsive(this.canvas.size.width, this.retina.pixelRatio, this._options);
        this.actualOptions.setTheme(this._currentTheme);
        if (this.responsiveMaxWidth === newMaxWidth) {
            return false;
        }
        this.responsiveMaxWidth = newMaxWidth;
        return true;
    }
}
}),
"[project]/theitern/node_modules/tsparticles-engine/esm/Utils/EventDispatcher.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "EventDispatcher",
    ()=>EventDispatcher
]);
class EventDispatcher {
    constructor(){
        this._listeners = new Map();
    }
    addEventListener(type, listener) {
        this.removeEventListener(type, listener);
        let arr = this._listeners.get(type);
        if (!arr) {
            arr = [];
            this._listeners.set(type, arr);
        }
        arr.push(listener);
    }
    dispatchEvent(type, args) {
        const listeners = this._listeners.get(type);
        listeners && listeners.forEach((handler)=>handler(args));
    }
    hasEventListener(type) {
        return !!this._listeners.get(type);
    }
    removeAllEventListeners(type) {
        if (!type) {
            this._listeners = new Map();
        } else {
            this._listeners.delete(type);
        }
    }
    removeEventListener(type, listener) {
        const arr = this._listeners.get(type);
        if (!arr) {
            return;
        }
        const length = arr.length, idx = arr.indexOf(listener);
        if (idx < 0) {
            return;
        }
        if (length === 1) {
            this._listeners.delete(type);
        } else {
            arr.splice(idx, 1);
        }
    }
}
}),
"[project]/theitern/node_modules/tsparticles-engine/esm/Core/Utils/Plugins.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Plugins",
    ()=>Plugins
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/tsparticles-engine/esm/Utils/Utils.js [app-ssr] (ecmascript)");
;
function getItemsFromInitializer(container, map, initializers, force = false) {
    let res = map.get(container);
    if (!res || force) {
        res = [
            ...initializers.values()
        ].map((t)=>t(container));
        map.set(container, res);
    }
    return res;
}
class Plugins {
    constructor(engine){
        this._engine = engine;
        this.plugins = [];
        this._initializers = {
            interactors: new Map(),
            movers: new Map(),
            updaters: new Map()
        };
        this.interactors = new Map();
        this.movers = new Map();
        this.updaters = new Map();
        this.presets = new Map();
        this.drawers = new Map();
        this.pathGenerators = new Map();
    }
    addInteractor(name, initInteractor) {
        this._initializers.interactors.set(name, initInteractor);
    }
    addParticleMover(name, initMover) {
        this._initializers.movers.set(name, initMover);
    }
    addParticleUpdater(name, initUpdater) {
        this._initializers.updaters.set(name, initUpdater);
    }
    addPathGenerator(type, pathGenerator) {
        !this.getPathGenerator(type) && this.pathGenerators.set(type, pathGenerator);
    }
    addPlugin(plugin) {
        !this.getPlugin(plugin.id) && this.plugins.push(plugin);
    }
    addPreset(presetKey, options, override = false) {
        (override || !this.getPreset(presetKey)) && this.presets.set(presetKey, options);
    }
    addShapeDrawer(types, drawer) {
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["executeOnSingleOrMultiple"])(types, (type)=>{
            !this.getShapeDrawer(type) && this.drawers.set(type, drawer);
        });
    }
    destroy(container) {
        this.updaters.delete(container);
        this.movers.delete(container);
        this.interactors.delete(container);
    }
    getAvailablePlugins(container) {
        const res = new Map();
        for (const plugin of this.plugins){
            plugin.needsPlugin(container.actualOptions) && res.set(plugin.id, plugin.getPlugin(container));
        }
        return res;
    }
    getInteractors(container, force = false) {
        return getItemsFromInitializer(container, this.interactors, this._initializers.interactors, force);
    }
    getMovers(container, force = false) {
        return getItemsFromInitializer(container, this.movers, this._initializers.movers, force);
    }
    getPathGenerator(type) {
        return this.pathGenerators.get(type);
    }
    getPlugin(plugin) {
        return this.plugins.find((t)=>t.id === plugin);
    }
    getPreset(preset) {
        return this.presets.get(preset);
    }
    getShapeDrawer(type) {
        return this.drawers.get(type);
    }
    getSupportedShapes() {
        return this.drawers.keys();
    }
    getUpdaters(container, force = false) {
        return getItemsFromInitializer(container, this.updaters, this._initializers.updaters, force);
    }
    loadOptions(options, sourceOptions) {
        for (const plugin of this.plugins){
            plugin.loadOptions(options, sourceOptions);
        }
    }
    loadParticlesOptions(container, options, ...sourceOptions) {
        const updaters = this.updaters.get(container);
        if (!updaters) {
            return;
        }
        for (const updater of updaters){
            updater.loadOptions && updater.loadOptions(options, ...sourceOptions);
        }
    }
}
}),
"[project]/theitern/node_modules/tsparticles-engine/esm/Core/Engine.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Engine",
    ()=>Engine
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/tsparticles-engine/esm/Core/Utils/Constants.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/tsparticles-engine/esm/Utils/Utils.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Core$2f$Container$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/tsparticles-engine/esm/Core/Container.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$EventDispatcher$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/tsparticles-engine/esm/Utils/EventDispatcher.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Core$2f$Utils$2f$Plugins$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/tsparticles-engine/esm/Core/Utils/Plugins.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/tsparticles-engine/esm/Utils/NumberUtils.js [app-ssr] (ecmascript)");
;
;
;
;
;
;
async function getDataFromUrl(data) {
    const url = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["itemFromSingleOrMultiple"])(data.url, data.index);
    if (!url) {
        return data.fallback;
    }
    const response = await fetch(url);
    if (response.ok) {
        return response.json();
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getLogger"])().error(`${__TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["errorPrefix"]} ${response.status} while retrieving config file`);
    return data.fallback;
}
function isParamsEmpty(params) {
    return !params.id && !params.element && !params.url && !params.options;
}
function isParams(obj) {
    return !isParamsEmpty(obj);
}
class Engine {
    constructor(){
        this._configs = new Map();
        this._domArray = [];
        this._eventDispatcher = new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$EventDispatcher$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["EventDispatcher"]();
        this._initialized = false;
        this.plugins = new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Core$2f$Utils$2f$Plugins$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Plugins"](this);
    }
    get configs() {
        const res = {};
        for (const [name, config] of this._configs){
            res[name] = config;
        }
        return res;
    }
    get version() {
        return "2.12.0";
    }
    addConfig(nameOrConfig, config) {
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isString"])(nameOrConfig)) {
            if (config) {
                config.name = nameOrConfig;
                this._configs.set(nameOrConfig, config);
            }
        } else {
            this._configs.set(nameOrConfig.name ?? "default", nameOrConfig);
        }
    }
    addEventListener(type, listener) {
        this._eventDispatcher.addEventListener(type, listener);
    }
    async addInteractor(name, interactorInitializer, refresh = true) {
        this.plugins.addInteractor(name, interactorInitializer);
        await this.refresh(refresh);
    }
    async addMover(name, moverInitializer, refresh = true) {
        this.plugins.addParticleMover(name, moverInitializer);
        await this.refresh(refresh);
    }
    async addParticleUpdater(name, updaterInitializer, refresh = true) {
        this.plugins.addParticleUpdater(name, updaterInitializer);
        await this.refresh(refresh);
    }
    async addPathGenerator(name, generator, refresh = true) {
        this.plugins.addPathGenerator(name, generator);
        await this.refresh(refresh);
    }
    async addPlugin(plugin, refresh = true) {
        this.plugins.addPlugin(plugin);
        await this.refresh(refresh);
    }
    async addPreset(preset, options, override = false, refresh = true) {
        this.plugins.addPreset(preset, options, override);
        await this.refresh(refresh);
    }
    async addShape(shape, drawer, initOrRefresh, afterEffectOrRefresh, destroyOrRefresh, refresh = true) {
        let customDrawer;
        let realRefresh = refresh, realInit, realAfterEffect, realDestroy;
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isBoolean"])(initOrRefresh)) {
            realRefresh = initOrRefresh;
            realInit = undefined;
        } else {
            realInit = initOrRefresh;
        }
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isBoolean"])(afterEffectOrRefresh)) {
            realRefresh = afterEffectOrRefresh;
            realAfterEffect = undefined;
        } else {
            realAfterEffect = afterEffectOrRefresh;
        }
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isBoolean"])(destroyOrRefresh)) {
            realRefresh = destroyOrRefresh;
            realDestroy = undefined;
        } else {
            realDestroy = destroyOrRefresh;
        }
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isFunction"])(drawer)) {
            customDrawer = {
                afterEffect: realAfterEffect,
                destroy: realDestroy,
                draw: drawer,
                init: realInit
            };
        } else {
            customDrawer = drawer;
        }
        this.plugins.addShapeDrawer(shape, customDrawer);
        await this.refresh(realRefresh);
    }
    dispatchEvent(type, args) {
        this._eventDispatcher.dispatchEvent(type, args);
    }
    dom() {
        return this._domArray;
    }
    domItem(index) {
        const dom = this.dom(), item = dom[index];
        if (!item || item.destroyed) {
            dom.splice(index, 1);
            return;
        }
        return item;
    }
    init() {
        if (this._initialized) {
            return;
        }
        this._initialized = true;
    }
    async load(tagIdOrOptionsOrParams, options) {
        return this.loadFromArray(tagIdOrOptionsOrParams, options);
    }
    async loadFromArray(tagIdOrOptionsOrParams, optionsOrIndex, index) {
        let params;
        if (!isParams(tagIdOrOptionsOrParams)) {
            params = {};
            if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isString"])(tagIdOrOptionsOrParams)) {
                params.id = tagIdOrOptionsOrParams;
            } else {
                params.options = tagIdOrOptionsOrParams;
            }
            if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isNumber"])(optionsOrIndex)) {
                params.index = optionsOrIndex;
            } else {
                params.options = optionsOrIndex ?? params.options;
            }
            params.index = index ?? params.index;
        } else {
            params = tagIdOrOptionsOrParams;
        }
        return this._loadParams(params);
    }
    async loadJSON(tagId, pathConfigJson, index) {
        let url, id;
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isNumber"])(pathConfigJson) || pathConfigJson === undefined) {
            url = tagId;
        } else {
            id = tagId;
            url = pathConfigJson;
        }
        return this._loadParams({
            id: id,
            url,
            index
        });
    }
    async refresh(refresh = true) {
        if (!refresh) {
            return;
        }
        this.dom().forEach((t)=>t.refresh());
    }
    removeEventListener(type, listener) {
        this._eventDispatcher.removeEventListener(type, listener);
    }
    async set(id, element, options, index) {
        const params = {
            index
        };
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isString"])(id)) {
            params.id = id;
        } else {
            params.element = id;
        }
        if (element instanceof HTMLElement) {
            params.element = element;
        } else {
            params.options = element;
        }
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isNumber"])(options)) {
            params.index = options;
        } else {
            params.options = options ?? params.options;
        }
        return this._loadParams(params);
    }
    async setJSON(id, element, pathConfigJson, index) {
        const params = {};
        if (id instanceof HTMLElement) {
            params.element = id;
            params.url = element;
            params.index = pathConfigJson;
        } else {
            params.id = id;
            params.element = element;
            params.url = pathConfigJson;
            params.index = index;
        }
        return this._loadParams(params);
    }
    setOnClickHandler(callback) {
        const dom = this.dom();
        if (!dom.length) {
            throw new Error(`${__TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["errorPrefix"]} can only set click handlers after calling tsParticles.load()`);
        }
        for (const domItem of dom){
            domItem.addClickHandler(callback);
        }
    }
    async _loadParams(params) {
        const id = params.id ?? `tsparticles${Math.floor((0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getRandom"])() * 10000)}`, { index, url } = params, options = url ? await getDataFromUrl({
            fallback: params.options,
            url,
            index
        }) : params.options;
        let domContainer = params.element ?? document.getElementById(id);
        if (!domContainer) {
            domContainer = document.createElement("div");
            domContainer.id = id;
            document.body.append(domContainer);
        }
        const currentOptions = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["itemFromSingleOrMultiple"])(options, index), dom = this.dom(), oldIndex = dom.findIndex((v)=>v.id === id);
        if (oldIndex >= 0) {
            const old = this.domItem(oldIndex);
            if (old && !old.destroyed) {
                old.destroy();
                dom.splice(oldIndex, 1);
            }
        }
        let canvasEl;
        if (domContainer.tagName.toLowerCase() === "canvas") {
            canvasEl = domContainer;
            canvasEl.dataset[__TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["generatedAttribute"]] = "false";
        } else {
            const existingCanvases = domContainer.getElementsByTagName("canvas");
            if (existingCanvases.length) {
                canvasEl = existingCanvases[0];
                canvasEl.dataset[__TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["generatedAttribute"]] = "false";
            } else {
                canvasEl = document.createElement("canvas");
                canvasEl.dataset[__TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Core$2f$Utils$2f$Constants$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["generatedAttribute"]] = "true";
                domContainer.appendChild(canvasEl);
            }
        }
        if (!canvasEl.style.width) {
            canvasEl.style.width = "100%";
        }
        if (!canvasEl.style.height) {
            canvasEl.style.height = "100%";
        }
        const newItem = new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Core$2f$Container$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Container"](this, id, currentOptions);
        if (oldIndex >= 0) {
            dom.splice(oldIndex, 0, newItem);
        } else {
            dom.push(newItem);
        }
        newItem.canvas.loadCanvas(canvasEl);
        await newItem.start();
        return newItem;
    }
}
}),
"[project]/theitern/node_modules/tsparticles-engine/esm/Utils/HslColorManager.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "HslColorManager",
    ()=>HslColorManager
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/tsparticles-engine/esm/Utils/NumberUtils.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$ColorUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/tsparticles-engine/esm/Utils/ColorUtils.js [app-ssr] (ecmascript)");
;
;
class HslColorManager {
    constructor(){
        this.key = "hsl";
        this.stringPrefix = "hsl";
    }
    handleColor(color) {
        const colorValue = color.value, hslColor = colorValue.hsl ?? color.value;
        if (hslColor.h !== undefined && hslColor.s !== undefined && hslColor.l !== undefined) {
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$ColorUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["hslToRgb"])(hslColor);
        }
    }
    handleRangeColor(color) {
        const colorValue = color.value, hslColor = colorValue.hsl ?? color.value;
        if (hslColor.h !== undefined && hslColor.l !== undefined) {
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$ColorUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["hslToRgb"])({
                h: (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getRangeValue"])(hslColor.h),
                l: (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getRangeValue"])(hslColor.l),
                s: (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getRangeValue"])(hslColor.s)
            });
        }
    }
    parseString(input) {
        if (!input.startsWith("hsl")) {
            return;
        }
        const regex = /hsla?\(\s*(\d+)\s*,\s*(\d+)%\s*,\s*(\d+)%\s*(,\s*([\d.%]+)\s*)?\)/i, result = regex.exec(input);
        return result ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$ColorUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["hslaToRgba"])({
            a: result.length > 4 ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["parseAlpha"])(result[5]) : 1,
            h: parseInt(result[1], 10),
            l: parseInt(result[3], 10),
            s: parseInt(result[2], 10)
        }) : undefined;
    }
}
}),
"[project]/theitern/node_modules/tsparticles-engine/esm/Utils/RgbColorManager.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "RgbColorManager",
    ()=>RgbColorManager
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/tsparticles-engine/esm/Utils/NumberUtils.js [app-ssr] (ecmascript)");
;
class RgbColorManager {
    constructor(){
        this.key = "rgb";
        this.stringPrefix = "rgb";
    }
    handleColor(color) {
        const colorValue = color.value, rgbColor = colorValue.rgb ?? color.value;
        if (rgbColor.r !== undefined) {
            return rgbColor;
        }
    }
    handleRangeColor(color) {
        const colorValue = color.value, rgbColor = colorValue.rgb ?? color.value;
        if (rgbColor.r !== undefined) {
            return {
                r: (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getRangeValue"])(rgbColor.r),
                g: (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getRangeValue"])(rgbColor.g),
                b: (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getRangeValue"])(rgbColor.b)
            };
        }
    }
    parseString(input) {
        if (!input.startsWith(this.stringPrefix)) {
            return;
        }
        const regex = /rgba?\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*(,\s*([\d.%]+)\s*)?\)/i, result = regex.exec(input);
        return result ? {
            a: result.length > 4 ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$NumberUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["parseAlpha"])(result[5]) : 1,
            b: parseInt(result[3], 10),
            g: parseInt(result[2], 10),
            r: parseInt(result[1], 10)
        } : undefined;
    }
}
}),
"[project]/theitern/node_modules/tsparticles-engine/esm/init.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "init",
    ()=>init
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Core$2f$Engine$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/tsparticles-engine/esm/Core/Engine.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$HslColorManager$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/tsparticles-engine/esm/Utils/HslColorManager.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$RgbColorManager$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/tsparticles-engine/esm/Utils/RgbColorManager.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$ColorUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/tsparticles-engine/esm/Utils/ColorUtils.js [app-ssr] (ecmascript)");
;
;
;
;
function init() {
    const rgbColorManager = new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$RgbColorManager$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["RgbColorManager"](), hslColorManager = new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$HslColorManager$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["HslColorManager"]();
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$ColorUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["addColorManager"])(rgbColorManager);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$ColorUtils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["addColorManager"])(hslColorManager);
    const engine = new __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Core$2f$Engine$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Engine"]();
    engine.init();
    return engine;
}
}),
"[project]/theitern/node_modules/tsparticles-engine/esm/index.js [app-ssr] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "tsParticles",
    ()=>tsParticles
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$init$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/tsparticles-engine/esm/init.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/tsparticles-engine/esm/Utils/Utils.js [app-ssr] (ecmascript)");
;
;
const tsParticles = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$init$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["init"])();
if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$Utils$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isSsr"])()) {
    window.tsParticles = tsParticles;
}
;
;
;
}),
"[project]/theitern/node_modules/react-particles/esm/Utils.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "deepCompare",
    ()=>deepCompare
]);
const isObject = (val)=>typeof val === "object" && val !== null;
function deepCompare(obj1, obj2, excludeKeyFn = ()=>false) {
    if (!isObject(obj1) || !isObject(obj2)) {
        return obj1 === obj2;
    }
    const keys1 = Object.keys(obj1).filter((key)=>!excludeKeyFn(key)), keys2 = Object.keys(obj2).filter((key)=>!excludeKeyFn(key));
    if (keys1.length !== keys2.length) {
        return false;
    }
    for (const key of keys1){
        const value1 = obj1[key], value2 = obj2[key];
        if (isObject(value1) && isObject(value2)) {
            if (value1 === obj2 && value2 === obj1) {
                continue;
            }
            if (!deepCompare(value1, value2, excludeKeyFn)) {
                return false;
            }
        } else if (Array.isArray(value1) && Array.isArray(value2)) {
            if (!deepCompareArrays(value1, value2, excludeKeyFn)) {
                return false;
            }
        } else if (value1 !== value2) {
            return false;
        }
    }
    return true;
}
function deepCompareArrays(arr1, arr2, excludeKeyFn) {
    if (arr1.length !== arr2.length) {
        return false;
    }
    for(let i = 0; i < arr1.length; i++){
        const val1 = arr1[i], val2 = arr2[i];
        if (Array.isArray(val1) && Array.isArray(val2)) {
            if (!deepCompareArrays(val1, val2, excludeKeyFn)) {
                return false;
            }
        } else if (isObject(val1) && isObject(val2)) {
            if (!deepCompare(val1, val2, excludeKeyFn)) {
                return false;
            }
        } else if (val1 !== val2) {
            return false;
        }
    }
    return true;
}
}),
"[project]/theitern/node_modules/react-particles/esm/Particles.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/theitern/node_modules/tsparticles-engine/esm/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$react$2d$particles$2f$esm$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/react-particles/esm/Utils.js [app-ssr] (ecmascript)");
;
;
;
const defaultId = "tsparticles";
class Particles extends __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Component"] {
    constructor(props){
        super(props);
        this.state = {
            init: false,
            library: undefined
        };
    }
    destroy() {
        if (!this.state.library) {
            return;
        }
        this.state.library.destroy();
        this.setState({
            library: undefined
        });
    }
    shouldComponentUpdate(nextProps) {
        const nextOptions = nextProps.options ?? nextProps.params, currentOptions = this.props.options ?? this.props.params;
        return nextProps.url !== this.props.url || nextProps.id !== this.props.id || nextProps.canvasClassName !== this.props.canvasClassName || nextProps.className !== this.props.className || nextProps.height !== this.props.height || nextProps.width !== this.props.width || !(0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$react$2d$particles$2f$esm$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["deepCompare"])(nextProps.style, this.props.style) || nextProps.init !== this.props.init || nextProps.loaded !== this.props.loaded || !(0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$react$2d$particles$2f$esm$2f$Utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["deepCompare"])(nextOptions, currentOptions, (key)=>key.startsWith("_"));
    }
    componentDidUpdate() {
        this.refresh();
    }
    forceUpdate() {
        this.refresh().then(()=>{
            super.forceUpdate();
        });
    }
    componentDidMount() {
        (async ()=>{
            if (this.props.init) {
                await this.props.init(__TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["tsParticles"]);
            }
            this.setState({
                init: true
            }, async ()=>{
                await this.loadParticles();
            });
        })();
    }
    componentWillUnmount() {
        this.destroy();
    }
    render() {
        const { width, height, className, canvasClassName, id } = this.props;
        return __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].createElement("div", {
            className: className,
            id: id
        }, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].createElement("canvas", {
            className: canvasClassName,
            style: {
                ...this.props.style,
                width,
                height
            }
        }));
    }
    async refresh() {
        this.destroy();
        await this.loadParticles();
    }
    async loadParticles() {
        if (!this.state.init) {
            return;
        }
        const id = this.props.id ?? Particles.defaultProps.id ?? defaultId, container = await __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["tsParticles"].load({
            url: this.props.url,
            id,
            options: this.props.options ?? this.props.params
        });
        if (this.props.container) {
            this.props.container.current = container;
        }
        this.setState({
            library: container
        });
        if (this.props.loaded) {
            await this.props.loaded(container);
        }
    }
}
Particles.defaultProps = {
    width: "100%",
    height: "100%",
    options: {},
    style: {},
    url: undefined,
    id: defaultId
};
const __TURBOPACK__default__export__ = Particles;
}),
"[project]/theitern/node_modules/react-particles/esm/index.js [app-ssr] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$react$2d$particles$2f$esm$2f$Particles$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/react-particles/esm/Particles.js [app-ssr] (ecmascript)");
;
const __TURBOPACK__default__export__ = __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$react$2d$particles$2f$esm$2f$Particles$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"];
;
}),
"[project]/theitern/node_modules/react-player/dist/patterns.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "AUDIO_EXTENSIONS",
    ()=>AUDIO_EXTENSIONS,
    "DASH_EXTENSIONS",
    ()=>DASH_EXTENSIONS,
    "HLS_EXTENSIONS",
    ()=>HLS_EXTENSIONS,
    "MATCH_URL_MUX",
    ()=>MATCH_URL_MUX,
    "MATCH_URL_SPOTIFY",
    ()=>MATCH_URL_SPOTIFY,
    "MATCH_URL_TIKTOK",
    ()=>MATCH_URL_TIKTOK,
    "MATCH_URL_TWITCH",
    ()=>MATCH_URL_TWITCH,
    "MATCH_URL_VIMEO",
    ()=>MATCH_URL_VIMEO,
    "MATCH_URL_WISTIA",
    ()=>MATCH_URL_WISTIA,
    "MATCH_URL_YOUTUBE",
    ()=>MATCH_URL_YOUTUBE,
    "VIDEO_EXTENSIONS",
    ()=>VIDEO_EXTENSIONS,
    "canPlay",
    ()=>canPlay
]);
const AUDIO_EXTENSIONS = /\.(m4a|m4b|mp4a|mpga|mp2|mp2a|mp3|m2a|m3a|wav|weba|aac|oga|spx)($|\?)/i;
const VIDEO_EXTENSIONS = /\.(mp4|og[gv]|webm|mov|m4v)(#t=[,\d+]+)?($|\?)/i;
const HLS_EXTENSIONS = /\.(m3u8)($|\?)/i;
const DASH_EXTENSIONS = /\.(mpd)($|\?)/i;
const MATCH_URL_MUX = /stream\.mux\.com\/(?!\w+\.m3u8)(\w+)/;
const MATCH_URL_YOUTUBE = /(?:youtu\.be\/|youtube(?:-nocookie|education)?\.com\/(?:embed\/|v\/|watch\/|watch\?v=|watch\?.+&v=|shorts\/|live\/))((\w|-){11})|youtube\.com\/playlist\?list=|youtube\.com\/user\//;
const MATCH_URL_VIMEO = /vimeo\.com\/(?!progressive_redirect).+/;
const MATCH_URL_WISTIA = /(?:wistia\.(?:com|net)|wi\.st)\/(?:medias|embed)\/(?:iframe\/)?([^?]+)/;
const MATCH_URL_SPOTIFY = /open\.spotify\.com\/(\w+)\/(\w+)/i;
const MATCH_URL_TWITCH = /(?:www\.|go\.)?twitch\.tv\/([a-zA-Z0-9_]+|(videos?\/|\?video=)\d+)($|\?)/;
const MATCH_URL_TIKTOK = /tiktok\.com\/(?:player\/v1\/|share\/video\/|@[^/]+\/video\/)([0-9]+)/;
const canPlayFile = (url, test)=>{
    if (Array.isArray(url)) {
        for (const item of url){
            if (typeof item === "string" && canPlayFile(item, test)) {
                return true;
            }
            if (canPlayFile(item.src, test)) {
                return true;
            }
        }
        return false;
    }
    return test(url);
};
const canPlay = {
    html: (url)=>canPlayFile(url, (u)=>AUDIO_EXTENSIONS.test(u) || VIDEO_EXTENSIONS.test(u)),
    hls: (url)=>canPlayFile(url, (u)=>HLS_EXTENSIONS.test(u)),
    dash: (url)=>canPlayFile(url, (u)=>DASH_EXTENSIONS.test(u)),
    mux: (url)=>MATCH_URL_MUX.test(url),
    youtube: (url)=>MATCH_URL_YOUTUBE.test(url),
    vimeo: (url)=>MATCH_URL_VIMEO.test(url) && !VIDEO_EXTENSIONS.test(url) && !HLS_EXTENSIONS.test(url),
    wistia: (url)=>MATCH_URL_WISTIA.test(url),
    spotify: (url)=>MATCH_URL_SPOTIFY.test(url),
    twitch: (url)=>MATCH_URL_TWITCH.test(url),
    tiktok: (url)=>MATCH_URL_TIKTOK.test(url)
};
;
}),
"[project]/theitern/node_modules/react-player/dist/HtmlPlayer.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>HtmlPlayer_default
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$react$2d$player$2f$dist$2f$patterns$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/react-player/dist/patterns.js [app-ssr] (ecmascript)");
;
;
const HtmlPlayer = __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].forwardRef((props, ref)=>{
    const Media = __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$react$2d$player$2f$dist$2f$patterns$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["AUDIO_EXTENSIONS"].test(`${props.src}`) ? "audio" : "video";
    return /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].createElement(Media, {
        ...props,
        ref
    }, props.children);
});
var HtmlPlayer_default = HtmlPlayer;
;
}),
"[project]/theitern/node_modules/react-player/dist/players.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>players_default
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$react$2d$player$2f$dist$2f$patterns$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/react-player/dist/patterns.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$react$2d$player$2f$dist$2f$HtmlPlayer$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/react-player/dist/HtmlPlayer.js [app-ssr] (ecmascript)");
;
;
;
const Players = [
    {
        key: "hls",
        name: "hls.js",
        canPlay: __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$react$2d$player$2f$dist$2f$patterns$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["canPlay"].hls,
        canEnablePIP: ()=>true,
        player: (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["lazy"])(()=>__turbopack_context__.A("[project]/theitern/node_modules/hls-video-element/dist/react.js [app-ssr] (ecmascript, async loader)"))
    },
    {
        key: "dash",
        name: "dash.js",
        canPlay: __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$react$2d$player$2f$dist$2f$patterns$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["canPlay"].dash,
        canEnablePIP: ()=>true,
        player: (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["lazy"])(()=>__turbopack_context__.A("[project]/theitern/node_modules/dash-video-element/dist/react.js [app-ssr] (ecmascript, async loader)"))
    },
    {
        key: "mux",
        name: "Mux",
        canPlay: __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$react$2d$player$2f$dist$2f$patterns$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["canPlay"].mux,
        canEnablePIP: ()=>true,
        player: (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["lazy"])(()=>__turbopack_context__.A("[project]/theitern/node_modules/@mux/mux-player-react/dist/index.mjs [app-ssr] (ecmascript, async loader)"))
    },
    {
        key: "youtube",
        name: "YouTube",
        canPlay: __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$react$2d$player$2f$dist$2f$patterns$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["canPlay"].youtube,
        player: (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["lazy"])(()=>__turbopack_context__.A("[project]/theitern/node_modules/youtube-video-element/dist/react.js [app-ssr] (ecmascript, async loader)"))
    },
    {
        key: "vimeo",
        name: "Vimeo",
        canPlay: __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$react$2d$player$2f$dist$2f$patterns$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["canPlay"].vimeo,
        player: (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["lazy"])(()=>__turbopack_context__.A("[project]/theitern/node_modules/vimeo-video-element/dist/react.js [app-ssr] (ecmascript, async loader)"))
    },
    {
        key: "wistia",
        name: "Wistia",
        canPlay: __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$react$2d$player$2f$dist$2f$patterns$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["canPlay"].wistia,
        canEnablePIP: ()=>true,
        player: (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["lazy"])(()=>__turbopack_context__.A("[project]/theitern/node_modules/wistia-video-element/dist/react.js [app-ssr] (ecmascript, async loader)"))
    },
    {
        key: "spotify",
        name: "Spotify",
        canPlay: __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$react$2d$player$2f$dist$2f$patterns$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["canPlay"].spotify,
        canEnablePIP: ()=>false,
        player: (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["lazy"])(()=>__turbopack_context__.A("[project]/theitern/node_modules/spotify-audio-element/dist/react.js [app-ssr] (ecmascript, async loader)"))
    },
    {
        key: "twitch",
        name: "Twitch",
        canPlay: __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$react$2d$player$2f$dist$2f$patterns$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["canPlay"].twitch,
        canEnablePIP: ()=>false,
        player: (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["lazy"])(()=>__turbopack_context__.A("[project]/theitern/node_modules/twitch-video-element/dist/react.js [app-ssr] (ecmascript, async loader)"))
    },
    {
        key: "tiktok",
        name: "TikTok",
        canPlay: __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$react$2d$player$2f$dist$2f$patterns$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["canPlay"].tiktok,
        canEnablePIP: ()=>false,
        player: (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["lazy"])(()=>__turbopack_context__.A("[project]/theitern/node_modules/tiktok-video-element/dist/react.js [app-ssr] (ecmascript, async loader)"))
    },
    {
        key: "html",
        name: "html",
        canPlay: __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$react$2d$player$2f$dist$2f$patterns$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["canPlay"].html,
        canEnablePIP: ()=>true,
        player: __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$react$2d$player$2f$dist$2f$HtmlPlayer$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]
    }
];
var players_default = Players;
;
}),
"[project]/theitern/node_modules/react-player/dist/props.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "defaultProps",
    ()=>defaultProps
]);
const defaultProps = {
    // Falsy values don't need to be defined
    //
    // native video attrs
    // src: undefined,
    // preload: undefined,
    // crossOrigin: undefined,
    // autoPlay: false,
    // muted: false,
    // loop: false,
    // controls: false,
    // playsInline: false,
    // disableRemotePlayback: false,
    width: "320px",
    height: "180px",
    // native video props
    volume: 1,
    playbackRate: 1,
    // custom props
    // playing: undefined,
    // pip: false,
    // light: false,
    // fallback: null,
    previewTabIndex: 0,
    previewAriaLabel: "",
    oEmbedUrl: "https://noembed.com/embed?url={url}"
};
;
}),
"[project]/theitern/node_modules/react-player/dist/Player.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>Player_default
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
;
const Player = __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].forwardRef((props, ref)=>{
    const { playing, pip } = props;
    const Player2 = props.activePlayer;
    const playerRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRef"])(null);
    const startOnPlayRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRef"])(true);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        var _a, _b;
        if (!playerRef.current) return;
        if (playerRef.current.paused && playing === true) {
            playerRef.current.play();
        }
        if (!playerRef.current.paused && playing === false) {
            playerRef.current.pause();
        }
        playerRef.current.playbackRate = (_a = props.playbackRate) != null ? _a : 1;
        playerRef.current.volume = (_b = props.volume) != null ? _b : 1;
    });
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        var _a, _b, _c, _d, _e;
        if (!playerRef.current || !globalThis.document) return;
        if (pip && !document.pictureInPictureElement) {
            try {
                (_b = (_a = playerRef.current).requestPictureInPicture) == null ? void 0 : _b.call(_a);
            } catch (err) {}
        }
        if (!pip && document.pictureInPictureElement) {
            try {
                (_d = (_c = playerRef.current).exitPictureInPicture) == null ? void 0 : _d.call(_c);
                (_e = document.exitPictureInPicture) == null ? void 0 : _e.call(document);
            } catch (err) {}
        }
    }, [
        pip
    ]);
    const handleLoadStart = (event)=>{
        var _a, _b;
        startOnPlayRef.current = true;
        (_a = props.onReady) == null ? void 0 : _a.call(props);
        (_b = props.onLoadStart) == null ? void 0 : _b.call(props, event);
    };
    const handlePlay = (event)=>{
        var _a, _b;
        if (startOnPlayRef.current) {
            startOnPlayRef.current = false;
            (_a = props.onStart) == null ? void 0 : _a.call(props, event);
        }
        (_b = props.onPlay) == null ? void 0 : _b.call(props, event);
    };
    if (!Player2) {
        return null;
    }
    const eventProps = {};
    const reactPlayerEventHandlers = [
        "onReady",
        "onStart"
    ];
    for(const key in props){
        if (key.startsWith("on") && !reactPlayerEventHandlers.includes(key)) {
            eventProps[key] = props[key];
        }
    }
    return /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].createElement(Player2, {
        ...eventProps,
        style: props.style,
        className: props.className,
        slot: props.slot,
        ref: (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useCallback"])((node)=>{
            playerRef.current = node;
            if (typeof ref === "function") {
                ref(node);
            } else if (ref !== null) {
                ref.current = node;
            }
        }, [
            ref
        ]),
        src: props.src,
        crossOrigin: props.crossOrigin,
        preload: props.preload,
        controls: props.controls,
        muted: props.muted,
        autoPlay: props.autoPlay,
        loop: props.loop,
        playsInline: props.playsInline,
        disableRemotePlayback: props.disableRemotePlayback,
        config: props.config,
        onLoadStart: handleLoadStart,
        onPlay: handlePlay
    }, props.children);
});
Player.displayName = "Player";
var Player_default = Player;
;
}),
"[project]/theitern/node_modules/react-player/dist/ReactPlayer.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "createReactPlayer",
    ()=>createReactPlayer
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$react$2d$player$2f$dist$2f$props$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/react-player/dist/props.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$react$2d$player$2f$dist$2f$Player$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/react-player/dist/Player.js [app-ssr] (ecmascript)");
;
;
;
const Preview = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["lazy"])(()=>__turbopack_context__.A("[project]/theitern/node_modules/react-player/dist/Preview.js [app-ssr] (ecmascript, async loader)"));
const customPlayers = [];
const createReactPlayer = (players, playerFallback)=>{
    const getActivePlayer = (src)=>{
        for (const player of [
            ...customPlayers,
            ...players
        ]){
            if (src && player.canPlay(src)) {
                return player;
            }
        }
        if (playerFallback) {
            return playerFallback;
        }
        return null;
    };
    const ReactPlayer = __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].forwardRef((_props, ref)=>{
        const props = {
            ...__TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$react$2d$player$2f$dist$2f$props$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["defaultProps"],
            ..._props
        };
        const { src, slot, className, style, width, height, fallback, wrapper } = props;
        const [showPreview, setShowPreview] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(!!props.light);
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
            if (props.light) {
                setShowPreview(true);
            } else {
                setShowPreview(false);
            }
        }, [
            props.light
        ]);
        const handleClickPreview = (e)=>{
            var _a;
            setShowPreview(false);
            (_a = props.onClickPreview) == null ? void 0 : _a.call(props, e);
        };
        const renderPreview = (src2)=>{
            if (!src2) return null;
            const { light, playIcon, previewTabIndex, oEmbedUrl, previewAriaLabel } = props;
            return /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].createElement(Preview, {
                src: src2,
                light,
                playIcon,
                previewTabIndex,
                previewAriaLabel,
                oEmbedUrl,
                onClickPreview: handleClickPreview
            });
        };
        const renderActivePlayer = (src2)=>{
            var _a, _b;
            const player = getActivePlayer(src2);
            if (!player) return null;
            const { style: style2, width: width2, height: height2, wrapper: wrapper2 } = props;
            const config = (_a = props.config) == null ? void 0 : _a[player.key];
            return /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].createElement(__TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$react$2d$player$2f$dist$2f$Player$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                ...props,
                ref,
                activePlayer: (_b = player.player) != null ? _b : player,
                slot: wrapper2 ? void 0 : slot,
                className: wrapper2 ? void 0 : className,
                style: wrapper2 ? {
                    display: "block",
                    width: "100%",
                    height: "100%"
                } : {
                    display: "block",
                    width: width2,
                    height: height2,
                    ...style2
                },
                config
            });
        };
        const Wrapper = wrapper == null ? ForwardChildren : wrapper;
        const UniversalSuspense = fallback === false ? ForwardChildren : __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Suspense"];
        return /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].createElement(Wrapper, {
            slot,
            className,
            style: {
                width,
                height,
                ...style
            }
        }, /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].createElement(UniversalSuspense, {
            fallback
        }, showPreview ? renderPreview(src) : renderActivePlayer(src)));
    });
    ReactPlayer.displayName = "ReactPlayer";
    ReactPlayer.addCustomPlayer = (player)=>{
        customPlayers.push(player);
    };
    ReactPlayer.removeCustomPlayers = ()=>{
        customPlayers.length = 0;
    };
    ReactPlayer.canPlay = (src)=>{
        if (src) {
            for (const Player2 of [
                ...customPlayers,
                ...players
            ]){
                if (Player2.canPlay(src)) {
                    return true;
                }
            }
        }
        return false;
    };
    ReactPlayer.canEnablePIP = (src)=>{
        var _a;
        if (src) {
            for (const Player2 of [
                ...customPlayers,
                ...players
            ]){
                if (Player2.canPlay(src) && ((_a = Player2.canEnablePIP) == null ? void 0 : _a.call(Player2))) {
                    return true;
                }
            }
        }
        return false;
    };
    return ReactPlayer;
};
const ForwardChildren = ({ children })=>children;
;
}),
"[project]/theitern/node_modules/react-player/dist/index.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>src_default
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$react$2d$player$2f$dist$2f$players$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/react-player/dist/players.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$react$2d$player$2f$dist$2f$ReactPlayer$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/react-player/dist/ReactPlayer.js [app-ssr] (ecmascript)");
"use client";
;
;
const fallback = __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$react$2d$player$2f$dist$2f$players$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"][__TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$react$2d$player$2f$dist$2f$players$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].length - 1];
var src_default = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$react$2d$player$2f$dist$2f$ReactPlayer$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createReactPlayer"])(__TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$react$2d$player$2f$dist$2f$players$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], fallback);
;
}),
];

//# sourceMappingURL=c6bf4_155147f2._.js.map