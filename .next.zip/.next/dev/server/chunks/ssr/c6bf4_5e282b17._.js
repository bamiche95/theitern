module.exports = [
"[project]/theitern/node_modules/react-particles/esm/Utils.js [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "deepCompare",
    ()=>deepCompare
]);
const isObject = (val)=>typeof val === "object" && val !== null;
function deepCompare(obj1, obj2, excludeKeyFn = ()=>false) {
    if (!isObject(obj1) || !isObject(obj2)) {
        return obj1 === obj2;
    }
    const keys1 = Object.keys(obj1).filter((key)=>!excludeKeyFn(key)), keys2 = Object.keys(obj2).filter((key)=>!excludeKeyFn(key));
    if (keys1.length !== keys2.length) {
        return false;
    }
    for (const key of keys1){
        const value1 = obj1[key], value2 = obj2[key];
        if (isObject(value1) && isObject(value2)) {
            if (value1 === obj2 && value2 === obj1) {
                continue;
            }
            if (!deepCompare(value1, value2, excludeKeyFn)) {
                return false;
            }
        } else if (Array.isArray(value1) && Array.isArray(value2)) {
            if (!deepCompareArrays(value1, value2, excludeKeyFn)) {
                return false;
            }
        } else if (value1 !== value2) {
            return false;
        }
    }
    return true;
}
function deepCompareArrays(arr1, arr2, excludeKeyFn) {
    if (arr1.length !== arr2.length) {
        return false;
    }
    for(let i = 0; i < arr1.length; i++){
        const val1 = arr1[i], val2 = arr2[i];
        if (Array.isArray(val1) && Array.isArray(val2)) {
            if (!deepCompareArrays(val1, val2, excludeKeyFn)) {
                return false;
            }
        } else if (isObject(val1) && isObject(val2)) {
            if (!deepCompare(val1, val2, excludeKeyFn)) {
                return false;
            }
        } else if (val1 !== val2) {
            return false;
        }
    }
    return true;
}
}),
"[project]/theitern/node_modules/react-particles/esm/Particles.js [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$index$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/theitern/node_modules/tsparticles-engine/esm/index.js [app-rsc] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$react$2d$particles$2f$esm$2f$Utils$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/react-particles/esm/Utils.js [app-rsc] (ecmascript)");
;
;
;
const defaultId = "tsparticles";
class Particles extends __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["Component"] {
    constructor(props){
        super(props);
        this.state = {
            init: false,
            library: undefined
        };
    }
    destroy() {
        if (!this.state.library) {
            return;
        }
        this.state.library.destroy();
        this.setState({
            library: undefined
        });
    }
    shouldComponentUpdate(nextProps) {
        const nextOptions = nextProps.options ?? nextProps.params, currentOptions = this.props.options ?? this.props.params;
        return nextProps.url !== this.props.url || nextProps.id !== this.props.id || nextProps.canvasClassName !== this.props.canvasClassName || nextProps.className !== this.props.className || nextProps.height !== this.props.height || nextProps.width !== this.props.width || !(0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$react$2d$particles$2f$esm$2f$Utils$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["deepCompare"])(nextProps.style, this.props.style) || nextProps.init !== this.props.init || nextProps.loaded !== this.props.loaded || !(0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$react$2d$particles$2f$esm$2f$Utils$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["deepCompare"])(nextOptions, currentOptions, (key)=>key.startsWith("_"));
    }
    componentDidUpdate() {
        this.refresh();
    }
    forceUpdate() {
        this.refresh().then(()=>{
            super.forceUpdate();
        });
    }
    componentDidMount() {
        (async ()=>{
            if (this.props.init) {
                await this.props.init(__TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$index$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$locals$3e$__["tsParticles"]);
            }
            this.setState({
                init: true
            }, async ()=>{
                await this.loadParticles();
            });
        })();
    }
    componentWillUnmount() {
        this.destroy();
    }
    render() {
        const { width, height, className, canvasClassName, id } = this.props;
        return __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"].createElement("div", {
            className: className,
            id: id
        }, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"].createElement("canvas", {
            className: canvasClassName,
            style: {
                ...this.props.style,
                width,
                height
            }
        }));
    }
    async refresh() {
        this.destroy();
        await this.loadParticles();
    }
    async loadParticles() {
        if (!this.state.init) {
            return;
        }
        const id = this.props.id ?? Particles.defaultProps.id ?? defaultId, container = await __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$tsparticles$2d$engine$2f$esm$2f$index$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$locals$3e$__["tsParticles"].load({
            url: this.props.url,
            id,
            options: this.props.options ?? this.props.params
        });
        if (this.props.container) {
            this.props.container.current = container;
        }
        this.setState({
            library: container
        });
        if (this.props.loaded) {
            await this.props.loaded(container);
        }
    }
}
Particles.defaultProps = {
    width: "100%",
    height: "100%",
    options: {},
    style: {},
    url: undefined,
    id: defaultId
};
const __TURBOPACK__default__export__ = Particles;
}),
"[project]/theitern/node_modules/react-particles/esm/index.js [app-rsc] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$react$2d$particles$2f$esm$2f$Particles$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/react-particles/esm/Particles.js [app-rsc] (ecmascript)");
;
const __TURBOPACK__default__export__ = __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$react$2d$particles$2f$esm$2f$Particles$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"];
;
}),
"[project]/theitern/node_modules/react-player/dist/index.js [app-rsc] (client reference proxy) <module evaluation>", ((__turbopack_context__) => {
"use strict";

// This file is generated by next-core EcmascriptClientReferenceModule.
__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server.js [app-rsc] (ecmascript)");
;
const __TURBOPACK__default__export__ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call the default export of [project]/theitern/node_modules/react-player/dist/index.js <module evaluation> from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/theitern/node_modules/react-player/dist/index.js <module evaluation>", "default");
}),
"[project]/theitern/node_modules/react-player/dist/index.js [app-rsc] (client reference proxy)", ((__turbopack_context__) => {
"use strict";

// This file is generated by next-core EcmascriptClientReferenceModule.
__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server.js [app-rsc] (ecmascript)");
;
const __TURBOPACK__default__export__ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call the default export of [project]/theitern/node_modules/react-player/dist/index.js from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/theitern/node_modules/react-player/dist/index.js", "default");
}),
"[project]/theitern/node_modules/react-player/dist/index.js [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$react$2d$player$2f$dist$2f$index$2e$js__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/theitern/node_modules/react-player/dist/index.js [app-rsc] (client reference proxy) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$react$2d$player$2f$dist$2f$index$2e$js__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__ = __turbopack_context__.i("[project]/theitern/node_modules/react-player/dist/index.js [app-rsc] (client reference proxy)");
;
__turbopack_context__.n(__TURBOPACK__imported__module__$5b$project$5d2f$theitern$2f$node_modules$2f$react$2d$player$2f$dist$2f$index$2e$js__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__);
}),
];

//# sourceMappingURL=c6bf4_5e282b17._.js.map